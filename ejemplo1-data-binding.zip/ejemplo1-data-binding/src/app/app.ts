import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  nombre: string = "Anabel";
  apellido: string = 'Vegas';

  deshabilitado: boolean = true;

  texto: string = '';

  constructor(){
    // Crear un temporizador que cuando transcurran 3 segundos, habilite el boton
    // setTimeout(funcion, tiempo);
    setTimeout(() => {
      this.deshabilitado = false;
    }, 3000);
  }

  saludar(): void{
    alert("Bienvenidos al curso de Angular");
  }
}

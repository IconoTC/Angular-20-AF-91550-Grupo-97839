import { Component, inject, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Pokemon } from './services/pokemon';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit{

  pokemons = signal<any[]>([]);   // pokemons: any[] = [];
  cargando = signal(true);
  url_siguientes: string = '';
  url_anteriores: string = '';
  pokemon = signal<any>({});
  nombre: string = '';

  private pokemonService = inject(Pokemon);

  buscar(): void{
    this.pokemonService.buscarPokemon(this.nombre).subscribe({
        next: (item) => {
          console.log(item);
          this.pokemon.set(item);
        },
        error: (err) => {
          console.log(err);
        },
        complete: () => {
          console.log("Peticion finalizada");
        }
    });
  }

  atras(): void{
    this.solicitarDatos(this.url_anteriores);
  }

  adelante(): void{
    this.solicitarDatos(this.url_siguientes)
  }

  solicitarDatos(url: string): void{
    this.pokemonService.emitirPeticion(url).subscribe({
        next: (datos) => {
          console.log(datos);
          this.pokemons.set(datos.results);
          this.cargando.set(false);
          this.url_siguientes = datos.next;
          this.url_anteriores = datos.previous;
        },
        error: (err) => {
          console.log(err);
        },
        complete: () => {
          console.log("Peticion finalizada");
        }
    });
  }

  ngOnInit(): void {
    // No lo puedo hacer
    // this.pokemons = this.pokemonService.getAll();

    setTimeout( () => {
      this.pokemonService.getAll().subscribe({
        next: (datos) => {
          console.log(datos);
          this.pokemons.set(datos.results);
          this.cargando.set(false);
          this.url_siguientes = datos.next;
          this.url_anteriores = datos.previous;
        },
        error: (err) => {
          console.log(err);
        },
        complete: () => {
          console.log("Peticion finalizada");
        }
      });
    }, 3000);
  }
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Pokemon {

  url: string = "https://pokeapi.co/api/v2/pokemon/";
  cabeceras: HttpHeaders = new HttpHeaders({'Content-type':'application/json'});

  private http = inject(HttpClient);

  getAll(): Observable<any>{
    return this.http.get(this.url, {headers: this.cabeceras});
  }

  emitirPeticion(peticion: string): Observable<any>{
    return this.http.get(peticion, {headers: this.cabeceras});
  }

  buscarPokemon(nombre: string): Observable<any>{
    const ruta = this.url + nombre;
    return this.http.get(ruta, {headers: this.cabeceras});
  }
}

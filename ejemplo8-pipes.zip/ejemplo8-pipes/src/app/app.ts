import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { MioPipe } from './pipes/mio-pipe';

@Component({
  selector: 'app-root',
  imports: [CommonModule, MioPipe],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  texto: string = "Bienvenidos al curso de Angular";
  numero: number = 45465768687.24567876578;
  cantidad: number = 3665.8876;
  porcentaje: number = 0.456775;

  // Funciona de varias formas
  fecha: Date = new Date();
  fecha2: Date = new Date("9/25/2026");   // mes/dia/año
  fecha3: string = "9/25/2026";

  persona: Object = {
    nombre: "Pepito",
    apellido: "Perez",
    edad: 39,
    telefonos: {
      fijo: 917659874,
      movil: 616123456
    }
  };

  /*
  private datePipe = inject(DatePipe);

  resultado = this.datePipe.transform(
    new Date(),
    'dd/MM/yyyy HH:mm',
    'Atlantic/Canary'
  );
  */
}

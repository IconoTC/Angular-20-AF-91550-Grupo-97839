import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mio'
})
export class MioPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    // value -> es el dato que recibimos
    // ...args: unknown[] -> parametros recibidos en el pipe

    // Retornar el value modificado segun los parametros recibidos
    let num_palabras = <number>args[0];
    return (<string>value).split(" ", num_palabras) ;
  }

}

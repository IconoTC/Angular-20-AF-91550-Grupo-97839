import { Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Museos } from './components/museos/museos';
import { DetalleMuseo } from './components/detalle-museo/detalle-museo';
import { Equipo } from './components/equipo/equipo';
import { Contacto } from './components/contacto/contacto';
import { Error } from './components/error/error';

export const routes: Routes = [
  {path: 'home', component: Home},
  {path: 'museos', component: Museos},
  {path: 'detalle-museo/:id', component: DetalleMuseo},
  {path: 'equipo', component: Equipo},
  {path: 'contacto', component: Contacto},
  {path: '', redirectTo: 'home', pathMatch: 'full'},   // localhost:4200
  {path: '**', component: Error}
];

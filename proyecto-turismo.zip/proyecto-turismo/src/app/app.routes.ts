import { Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Museos } from './components/museos/museos';
import { DetalleMuseo } from './components/detalle-museo/detalle-museo';
import { Equipo } from './components/equipo/equipo';
import { Contacto } from './components/contacto/contacto';
import { Error } from './components/error/error';
import { Login } from './components/login/login';
import { Admin } from './components/admin/admin';
import { authGuard } from './guards/auth-guard';

export const routes: Routes = [
  {path: 'home', component: Home},
  {path: 'museos', component: Museos},
  {path: 'detalle-museo/:id', component: DetalleMuseo},
  {path: 'equipo', component: Equipo},
  {path: 'contacto', component: Contacto},
  {path: 'login', component: Login},
  {path: 'admin', component: Admin, canActivate: [authGuard]},
  {path: '', redirectTo: 'home', pathMatch: 'full'},   // localhost:4200
  {path: '**', component: Error}
];

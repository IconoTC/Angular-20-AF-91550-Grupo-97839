import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Museos } from './museos';

describe('Museos', () => {
  let component: Museos;
  let fixture: ComponentFixture<Museos>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Museos]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Museos);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

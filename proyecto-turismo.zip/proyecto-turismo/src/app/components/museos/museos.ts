import { Component, inject, OnInit } from '@angular/core';
import { Museo } from '../../models/museo';
import { RouterLink } from "@angular/router";
import { ServicioMuseos } from '../../services/servicio-museos';

@Component({
  selector: 'app-museos',
  imports: [RouterLink],
  templateUrl: './museos.html',
  styleUrl: './museos.css',
})
export class Museos implements OnInit{

  museos: Museo[] = [];

  // Con las nuevas versiones de Angular, inyectamos los servicios con inject
  // En las versiones anteriores se hacia a través del constructor
  private museosService = inject(ServicioMuseos);

  ngOnInit(): void {
    this.museos = this.museosService.getAll();
  }
}

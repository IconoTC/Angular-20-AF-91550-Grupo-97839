import { AfterViewInit, Component, inject, OnInit, ViewChild } from '@angular/core';
import { Museo } from '../../models/museo';
import { RouterLink } from "@angular/router";
import { ServicioMuseos } from '../../services/servicio-museos';

import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-museos',
  imports: [RouterLink, MatTableModule, MatSortModule, MatPaginatorModule, MatInputModule, FormsModule],
  templateUrl: './museos.html',
  styleUrl: './museos.css',
})
export class Museos implements OnInit, AfterViewInit{

  museos: Museo[] = [];
  displayedColumns: string[] = ['nombre', 'abierto', 'horario', 'precio']; // propiedades del museo
  dataSource: any;
  dato: string = '';

  @ViewChild(MatSort) // Se inyecte la dependencia cuando sea visible en el navegador
  sort: MatSort | undefined;

  @ViewChild(MatPaginator)
  paginador: MatPaginator | undefined;

  // Con las nuevas versiones de Angular, inyectamos los servicios con inject
  // En las versiones anteriores se hacia a través del constructor
  private museosService = inject(ServicioMuseos);

  filtrar(): void{
    this.dataSource.filter = this.dato.toLowerCase();
  }

  ngOnInit(): void {
    this.museos = this.museosService.getAll();
    this.dataSource = new MatTableDataSource(this.museos);
  }

  ngAfterViewInit(): void {
    // Agregar el sort al dataSource
    if (this.sort != undefined){
      this.dataSource.sort = this.sort;
    }

    // Agregar el paginator al dataSource
    if (this.paginador != undefined){
      this.dataSource.paginator = this.paginador;
    }

    // Si solo quiero filtrar por el nombre del museo
    this.dataSource.filterPredicate = (item: Museo, filter: string) => {
      return item.nombre.toLowerCase().includes(filter);
    };
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleMuseo } from './detalle-museo';

describe('DetalleMuseo', () => {
  let component: DetalleMuseo;
  let fixture: ComponentFixture<DetalleMuseo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetalleMuseo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetalleMuseo);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-museo',
  imports: [],
  templateUrl: './detalle-museo.html',
  styleUrl: './detalle-museo.css',
})
export class DetalleMuseo {

}

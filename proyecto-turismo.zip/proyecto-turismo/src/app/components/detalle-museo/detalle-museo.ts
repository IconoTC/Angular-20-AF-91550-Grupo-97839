import { Component, inject } from '@angular/core';
import { Museo } from '../../models/museo';
import { ServicioMuseos } from '../../services/servicio-museos';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-detalle-museo',
  imports: [CommonModule],
  templateUrl: './detalle-museo.html',
  styleUrl: './detalle-museo.css',
})
export class DetalleMuseo {

  museo?: Museo;

  private museosService = inject(ServicioMuseos);

  constructor(private ruta: ActivatedRoute){
      let id = ruta.snapshot.params['id'];
      this.museo = this.museosService.buscarMuseo(id);
  }
}

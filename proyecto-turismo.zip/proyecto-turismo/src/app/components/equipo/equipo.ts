import { Component, inject, OnInit, signal } from '@angular/core';
import { ServicioEquipo } from '../../services/servicio-equipo';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-equipo',
  imports: [CommonModule],
  templateUrl: './equipo.html',
  styleUrl: './equipo.css',
})
export class Equipo implements OnInit{

  miembros = signal<any[]>([]);
  cargando = signal(true);

  private equipoService = inject(ServicioEquipo);

  ngOnInit(): void {
    setTimeout(() => {
        this.equipoService.getAll().subscribe({
            next: (datos) => {
              console.log(datos);
              this.miembros.set(datos.results);
              this.cargando.set(false);
            },
            error: (err) => {
              console.log(err);
            }
          });
        }, 2000);

  }

}

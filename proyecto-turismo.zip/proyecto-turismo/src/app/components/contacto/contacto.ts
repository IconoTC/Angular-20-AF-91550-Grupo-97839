import { Component, inject } from '@angular/core';
import { FormGroup, FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-contacto',
  imports: [FormsModule, ReactiveFormsModule,MatInputModule, MatButtonModule],
  templateUrl: './contacto.html',
  styleUrl: './contacto.css',
})
export class Contacto {

  private fb = inject(NonNullableFormBuilder);

  contactoForm: FormGroup = this.fb.group({
    nombre:  ['', [Validators.required, Validators.minLength(3)]],
    telefono: ['', [Validators.required, Validators.pattern('[6,7,9]{1}[0-9]{8}')]],
    email: ['', [Validators.required, Validators.email]],
    asunto: ['', [Validators.required, Validators.minLength(5)]],
    mensaje: ['', [Validators.required, Validators.minLength(10)]]
  });

  guardar(): void{
    console.log(this.contactoForm.value);
    alert("Mensaje recibido");
  }
}

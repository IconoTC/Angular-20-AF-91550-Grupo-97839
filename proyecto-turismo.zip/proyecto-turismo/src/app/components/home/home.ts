import { Component, inject } from '@angular/core';
import { Museo } from '../../models/museo';
import { ServicioMuseos } from '../../services/servicio-museos';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [CommonModule],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {

  museos: Museo[] = [];
  activeSlideIndex = 0;

  private museosService = inject(ServicioMuseos);

  constructor(){
    this.museos = this.museosService.getAll();
  }

  selectSlide(idx: number){
    this.activeSlideIndex = idx;
  }

}

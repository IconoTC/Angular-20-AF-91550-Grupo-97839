import { Component, inject } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  imports: [TranslatePipe],
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {

  idioma:string = 'es';

  private translate = inject(TranslateService);

  constructor(){
    // Indicamos el idioma por defecto de la aplicacion
    this.translate.use(this.idioma);
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;

    // Forzamos el cambio de idioma
    this.translate.use(this.idioma);
  }

}

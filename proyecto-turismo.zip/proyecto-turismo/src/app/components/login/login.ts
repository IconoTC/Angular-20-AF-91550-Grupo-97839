import { Router } from '@angular/router';
import { ServicioAuth } from './../../services/servicio-auth';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-login',
  imports: [FormsModule, MatInputModule, MatButtonModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

  usuario: string = '';
  pw: string = '';

  auth = inject(ServicioAuth);
  router = inject(Router);

  autenticacion(){
    this.auth.login(this.usuario, this.pw)
        .then((datos) => {
          console.log(datos);
          // Solo el usuario logado puede ir al componente admin
          if (datos != null){
            this.router.navigate(['/admin']);
          }
        })
        .catch((err) => {
          console.log(err);
        });
  }
}

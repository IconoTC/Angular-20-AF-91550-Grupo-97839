import { Component, inject } from '@angular/core';
import { ServicioAuth } from '../../services/servicio-auth';
import { Router } from '@angular/router';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-admin',
  imports: [MatCardModule, MatButtonModule, MatIconModule],
  templateUrl: './admin.html',
  styleUrl: './admin.css',
})
export class Admin {

  auth = inject(ServicioAuth);
  router = inject(Router);

  cerrarSesion(){
    this.auth.logout();

    // Le enviamos al componente home
    this.router.navigate(['/home']);

  }

}

import { TestBed } from '@angular/core/testing';

import { ServicioEquipo } from './servicio-equipo';

describe('ServicioEquipo', () => {
  let service: ServicioEquipo;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServicioEquipo);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

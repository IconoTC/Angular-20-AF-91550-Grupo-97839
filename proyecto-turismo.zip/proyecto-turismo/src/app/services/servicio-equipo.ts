import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ServicioEquipo {

  url: string = "https://rickandmortyapi.com/api/character";
  cabeceras: HttpHeaders = new HttpHeaders({'Content-type': 'application/json'});

  private http = inject(HttpClient);

  getAll(): Observable<any>{
    return this.http.get(this.url, {headers: this.cabeceras});
  }

}

import { Observable } from 'rxjs';
import { Injectable, inject} from '@angular/core';
import { Auth, authState, signInWithEmailAndPassword, signOut, User } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root',
})
export class ServicioAuth {

  //private logado = false;

  auth = inject(Auth);

  login(email: string, pw: string): Promise<any>{
    return signInWithEmailAndPassword(this.auth, email,pw);
  }

  logout(): Promise<void>{
    return signOut(this.auth);
  }

  isLogado(): Observable<User | null>{
    // Si el usuario no esta logado retorna null, si lo esta retorna User
    return authState(this.auth);
  }
}

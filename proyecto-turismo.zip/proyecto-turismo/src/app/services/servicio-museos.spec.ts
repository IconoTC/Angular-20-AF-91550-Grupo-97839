import { TestBed } from '@angular/core/testing';

import { ServicioMuseos } from './servicio-museos';

describe('ServicioMuseos', () => {
  let service: ServicioMuseos;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServicioMuseos);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('hay 16 museos', () => {
    expect(service.getAll().length).toHaveSize(16);
  })
});

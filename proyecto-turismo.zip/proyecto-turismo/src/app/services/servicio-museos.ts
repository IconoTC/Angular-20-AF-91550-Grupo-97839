import { Injectable } from '@angular/core';
import { Museo } from '../models/museo';

@Injectable({
  providedIn: 'root',
})
export class ServicioMuseos {

  private museos: Museo[] = [
      { id: 1, nombre: 'Museo del Prado', telefono: '913 30 28 00', direccion: 'Calle de Ruiz de Alarcón, 23, 28014 Madrid', horario: '10:00 – 20:00', imagen: 'https://upload.wikimedia.org/wikipedia/commons/6/68/Museo_del_Prado_2016_%2825185969599%29.jpg', web: 'https://www.museodelprado.es/', coordenadas: [40.4137818, -3.6921271], precio: 15, abierto: true },
      { id: 2, nombre: 'Reina Sofia', telefono: '917741000', direccion: 'Calle Santa Isabel', horario: 'Cierra a las 21:00', imagen: 'https://recursos.museoreinasofia.es/styles/large_landscape/public/Visita/sabatini.jpg.webp', web: 'http://www.museoreinasofia.es', coordenadas: [40.408644, -3.693992], precio: 15, abierto: true },
      { id: 3, nombre: 'Biblioteca Nacional', telefono: ' 91 516 89 67 / 91 580 77 59', direccion: 'Paseo de Recoletos, 20-22. 28071. Madrid.', horario: 'De Martes a Sabado de 10 a 20 h. Domingos de 10 a 14 h.', imagen: 'https://patrimonioypaisaje.madrid.es/FWProjects/monumenta/Edificios/25821/04.14-img3C.jpg', web: 'museo@bne.es', coordenadas: [40.42348498519113, -3.6910447306827954], precio: 0, abierto: true },
      { id: 4, nombre: "Museo Thyssen", telefono: '917911370', direccion: "Paseo del Prado, 8", horario: '10:00 a 19:00', imagen: 'https://www.museothyssen.org/themes/thyssen/img/thyssen-redes-sociales.jpg', web: 'https://www.museothyssen.org/', coordenadas: [40.416137331924666, -3.694930865545187], precio: 13, abierto: true },
      { id: 5, nombre: 'Real academia de Bellas Artes de San Fernando', telefono: '+34 91-524 08 64', direccion: 'Alcalá, 13 28014 Madrid', horario: 'Martes a domingo de 10:00 a 15:00 horas, incluyendo festivos. Lunes cerrado.', imagen: 'https://www.realacademiabellasartessanfernando.com/wp-content/uploads/2023/02/DSC00191-scaled.jpg', web: 'https://www.realacademiabellasartessanfernando.com/es', coordenadas: [40.4180405, -3.7029775], precio: 8, abierto: true },
      { id: 6, nombre: 'Museo Arqueológico', telefono: '915777912', direccion: 'Calle de Serrano, 13, 28001 Madrid', horario: '9:30–20:00', imagen: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/07/26/8b/44/entrada-museo-arqueologico.jpg?w=1200&h=1200&s=1', web: 'http://www.man.es/man/home.html', coordenadas: [40.423553, -3.689402], precio: 3, abierto: true },
      { id: 7, nombre: 'Museo Ciencias Naturales', telefono: '914111328', direccion: 'C/José Gutierrez Abascal', horario: '10.00 a 17.00', imagen: 'https://estaticos.esmadrid.com/cdn/farfuture/vRECDnNX8Zss7WBKZaSAvXL80YO3vSStu3G-sIdz9NE/mtime:1646728991/sites/default/files/styles/content_type_full/public/recursosturisticos/infoturistica/museo_de_ciencias_naturales_4.jpg?itok=2sXEh5HX', web: 'http://www.mncn.csic.es/es', coordenadas: [40.4404062, -3.6912279], precio: 7, abierto: true },
      { id: 8, nombre: 'Museo del Traje', telefono: '+34 91 550 47 00', direccion: 'Avenida de Juan de Herrera, 228040', horario: 'Mar-Sáb: 9:30-19:00 h; Dom-Fest: 10:00-15:00 h Jueves (julio y agosto): 9:30 – 22:30 h', imagen: 'https://estaticos.esmadrid.com/cdn/farfuture/kvJKokxVD1Xx7E2RpzInIBSVbFOT7YS5YkLv4_MdBPo/mtime:1638267451/sites/default/files/recursosturisticos/infoturistica/museo_del_traje_madrid_destinoc_alvaro_lopez_13.jpg', web: 'http://www.culturaydeporte.gob.es/mtraje/inicio.html', coordenadas: [40.4400972, -3.7318693], precio: 3, abierto: true },
      { id: 9, nombre: 'Museo de Ciencias y Tecnologia', telefono: '914250919', direccion: 'Parque de Andalucia. C/Pintor Velázquez,5 28100 Alcobendas, Madrid', horario: '11:00-19:00', imagen: 'https://www.esmadrid.com/sites/default/files/styles/content_type_full/public/recursosturisticos/infoturistica/museo_nacional_de_ciencia_y_tecnologia.jpg?itok=uTnl5LLm', web: 'http://www.muncyt.es/', coordenadas: [40.5375439, -3.643642], precio: 3.0, abierto: true },
      { id: 10, nombre: 'Museo de Lope de Vega', telefono: '914299216', direccion: 'Callede Cervantes, 11,28014 Madrid', horario: 'Mar-Dom: 10:00 - 18:00', imagen: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2a/69/c4/b5/caption.jpg?w=1400&h=800&s=1', web: 'http://casamuseolopedevega.org/es/', coordenadas: [40.3980385, -3.7054334], precio: 0, abierto: true },
      { id: 11, nombre: 'Museo de cera', telefono: '+34 91 319 93 30', direccion: 'Plaza de Colón, 1', horario: '11:00–19:00', imagen: 'https://media.istockphoto.com/id/862579804/es/foto/vista-exterior-del-museo-de-cera-de-madrid.jpg?s=170667a&w=0&k=20&c=f41bGPr1q5pcTDvfD5SsjWtKedH_0uEodOSx1xlUGpM=', web: 'https://www.museodecerademadrid.com', coordenadas: [40.4250641, -3.6935975], precio: 18, abierto: true },
      { id: 12, nombre: 'Museo de dibujo e ilustracción', telefono: '+34 91 758 83 79', direccion: 'Amaniel 29-31. 28015 Madrid', horario: 'Cerrado Temporalmente', imagen: 'https://images.adsttc.com/media/images/512a/f0b8/b3fc/4b11/a700/a6f4/large_jpg/1309145300-jesus-granada-5.jpg?1414269001', web: 'https://museo.abc.es/', coordenadas: [40.4276904, -3.7117588], precio: 0, abierto: false },
      { id: 13, nombre: 'Museo de la imprenta', telefono: '914294881', direccion: '28012, Calle de Concepción Jerónima, 15, 28012 Madrid', horario: '10:00-20:00', imagen: 'https://artedemadrid.wordpress.com/wp-content/uploads/2011/12/sala-maquinas.jpg?w=784&h=588', web: 'https://museomadrid.com/imprenta-municipal-artes-del-libro/', coordenadas: [40.4138972, -3.7054722], precio: 0, abierto: true },
      { id: 14, nombre: 'Museo Naval', telefono: '(+34) 91 523 85 16', direccion: ' Paseo del Prado, 3 28014 ', horario: 'Mar - Dom: 10:00 - 19:00 h ', imagen: 'https://www.arkiplus.com/wp-content/uploads/2019/02/museo-naval-de-madrid.jpg', web: 'https://www.esmadrid.com/informacion-turistica/museo-naval', coordenadas: [40.41851257605143, -3.6928194306791697], precio: 3, abierto: true },
      { id: 15, nombre: 'Museo Sorolla', telefono: '+34 91 310 15 84', direccion: 'Paseo del General Martinez Campos, 37, 28010 Madrid', horario: '9:30-20:00', imagen: 'https://upload.wikimedia.org/wikipedia/commons/4/4e/Museo_Sorolla_%28Madrid%29_07.jpg', web: 'https://www.culturaydeporte.gob.es/msorolla/inicio.html', coordenadas: [40.4354555, -3.6947111], precio: 3, abierto: true },
      { id: 16, nombre: 'Museo de la ilusion', telefono: '+34 911 03 34 55', direccion: 'Calle del Dr. Cortezo 8', horario: 'Cierra a las 22:00', imagen: 'https://www.madridlowcost.es/wp-content/uploads/2020/06/museo-de-las-ilusiones-770x492.jpg', web: 'https://museumofillusions.es/', coordenadas: [40.4134667, -3.7060788], precio: 15, abierto: true }
    ];

    getAll(): Museo[]{
      return this.museos;
    }

    buscarMuseo(id: number): Museo | undefined{
      return this.museos.find(item => item.id == id);   // No funciona con igualdad estricta ===
    }

}

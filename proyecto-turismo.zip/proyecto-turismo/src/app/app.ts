import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Museos } from './components/museos/museos';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Museos],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

}

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ServicioAuth } from '../services/servicio-auth';
import { map } from 'rxjs/operators';

export const authGuard: CanActivateFn = () => {

  const auth = inject(ServicioAuth);
  const router = inject(Router);

  return auth.isLogado().pipe(
    map((datos) => {
      if (datos != null) {
          return true;
      } else {
          return router.createUrlTree(['/login']);
      }
    })
  );

};

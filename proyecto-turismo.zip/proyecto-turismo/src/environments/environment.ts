export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDMAajB6mI0jC_iS4xkTI1DnHWuUz4kC_Y",
    authDomain: "angular-indra-anabel-10-julio.firebaseapp.com",
    projectId: "angular-indra-anabel-10-julio",
    storageBucket: "angular-indra-anabel-10-julio.firebasestorage.app",
    messagingSenderId: "387041210339",
    appId: "1:387041210339:web:d7d7cb7a3d9a6a8db57ad6"
  }

};

/*!
  * Bootstrap v5.3.8 (https://getbootstrap.com/)
  * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
  * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
  */
!(function(t, e) {
  "object" == typeof exports && "undefined" != typeof module ? module.exports = e(require("@popperjs/core")) : "function" == typeof define && define.amd ? define(["@popperjs/core"], e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).bootstrap = e(t.Popper);
})(this, function(t) {
  "use strict";
  function e(t2) {
    const e2 = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
    if (t2) {
      for (const i2 in t2) if ("default" !== i2) {
        const s2 = Object.getOwnPropertyDescriptor(t2, i2);
        Object.defineProperty(e2, i2, s2.get ? s2 : { enumerable: true, get: () => t2[i2] });
      }
    }
    return e2.default = t2, Object.freeze(e2);
  }
  const i = e(t), s = /* @__PURE__ */ new Map(), n = { set(t2, e2, i2) {
    s.has(t2) || s.set(t2, /* @__PURE__ */ new Map());
    const n2 = s.get(t2);
    n2.has(e2) || 0 === n2.size ? n2.set(e2, i2) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(n2.keys())[0]}.`);
  }, get: (t2, e2) => s.has(t2) && s.get(t2).get(e2) || null, remove(t2, e2) {
    if (!s.has(t2)) return;
    const i2 = s.get(t2);
    i2.delete(e2), 0 === i2.size && s.delete(t2);
  } }, o = "transitionend", r = (t2) => (t2 && window.CSS && window.CSS.escape && (t2 = t2.replace(/#([^\s"#']+)/g, (t3, e2) => `#${CSS.escape(e2)}`)), t2), a = (t2) => null == t2 ? `${t2}` : Object.prototype.toString.call(t2).match(/\s([a-z]+)/i)[1].toLowerCase(), l = (t2) => {
    t2.dispatchEvent(new Event(o));
  }, c = (t2) => !(!t2 || "object" != typeof t2) && (void 0 !== t2.jquery && (t2 = t2[0]), void 0 !== t2.nodeType), h = (t2) => c(t2) ? t2.jquery ? t2[0] : t2 : "string" == typeof t2 && t2.length > 0 ? document.querySelector(r(t2)) : null, d = (t2) => {
    if (!c(t2) || 0 === t2.getClientRects().length) return false;
    const e2 = "visible" === getComputedStyle(t2).getPropertyValue("visibility"), i2 = t2.closest("details:not([open])");
    if (!i2) return e2;
    if (i2 !== t2) {
      const e3 = t2.closest("summary");
      if (e3 && e3.parentNode !== i2) return false;
      if (null === e3) return false;
    }
    return e2;
  }, u = (t2) => !t2 || t2.nodeType !== Node.ELEMENT_NODE || !!t2.classList.contains("disabled") || (void 0 !== t2.disabled ? t2.disabled : t2.hasAttribute("disabled") && "false" !== t2.getAttribute("disabled")), _ = (t2) => {
    if (!document.documentElement.attachShadow) return null;
    if ("function" == typeof t2.getRootNode) {
      const e2 = t2.getRootNode();
      return e2 instanceof ShadowRoot ? e2 : null;
    }
    return t2 instanceof ShadowRoot ? t2 : t2.parentNode ? _(t2.parentNode) : null;
  }, g = () => {
  }, f = (t2) => {
    t2.offsetHeight;
  }, m = () => window.jQuery && !document.body.hasAttribute("data-bs-no-jquery") ? window.jQuery : null, p = [], b = () => "rtl" === document.documentElement.dir, v = (t2) => {
    var e2;
    e2 = () => {
      const e3 = m();
      if (e3) {
        const i2 = t2.NAME, s2 = e3.fn[i2];
        e3.fn[i2] = t2.jQueryInterface, e3.fn[i2].Constructor = t2, e3.fn[i2].noConflict = () => (e3.fn[i2] = s2, t2.jQueryInterface);
      }
    }, "loading" === document.readyState ? (p.length || document.addEventListener("DOMContentLoaded", () => {
      for (const t3 of p) t3();
    }), p.push(e2)) : e2();
  }, y = (t2, e2 = [], i2 = t2) => "function" == typeof t2 ? t2.call(...e2) : i2, w = (t2, e2, i2 = true) => {
    if (!i2) return void y(t2);
    const s2 = ((t3) => {
      if (!t3) return 0;
      let { transitionDuration: e3, transitionDelay: i3 } = window.getComputedStyle(t3);
      const s3 = Number.parseFloat(e3), n3 = Number.parseFloat(i3);
      return s3 || n3 ? (e3 = e3.split(",")[0], i3 = i3.split(",")[0], 1e3 * (Number.parseFloat(e3) + Number.parseFloat(i3))) : 0;
    })(e2) + 5;
    let n2 = false;
    const r2 = ({ target: i3 }) => {
      i3 === e2 && (n2 = true, e2.removeEventListener(o, r2), y(t2));
    };
    e2.addEventListener(o, r2), setTimeout(() => {
      n2 || l(e2);
    }, s2);
  }, A = (t2, e2, i2, s2) => {
    const n2 = t2.length;
    let o2 = t2.indexOf(e2);
    return -1 === o2 ? !i2 && s2 ? t2[n2 - 1] : t2[0] : (o2 += i2 ? 1 : -1, s2 && (o2 = (o2 + n2) % n2), t2[Math.max(0, Math.min(o2, n2 - 1))]);
  }, E = /[^.]*(?=\..*)\.|.*/, C = /\..*/, T = /::\d+$/, k = {};
  let $ = 1;
  const S = { mouseenter: "mouseover", mouseleave: "mouseout" }, L = /* @__PURE__ */ new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);
  function O(t2, e2) {
    return e2 && `${e2}::${$++}` || t2.uidEvent || $++;
  }
  function I(t2) {
    const e2 = O(t2);
    return t2.uidEvent = e2, k[e2] = k[e2] || {}, k[e2];
  }
  function D(t2, e2, i2 = null) {
    return Object.values(t2).find((t3) => t3.callable === e2 && t3.delegationSelector === i2);
  }
  function N(t2, e2, i2) {
    const s2 = "string" == typeof e2, n2 = s2 ? i2 : e2 || i2;
    let o2 = j(t2);
    return L.has(o2) || (o2 = t2), [s2, n2, o2];
  }
  function P(t2, e2, i2, s2, n2) {
    if ("string" != typeof e2 || !t2) return;
    let [o2, r2, a2] = N(e2, i2, s2);
    if (e2 in S) {
      const t3 = (t4) => function(e3) {
        if (!e3.relatedTarget || e3.relatedTarget !== e3.delegateTarget && !e3.delegateTarget.contains(e3.relatedTarget)) return t4.call(this, e3);
      };
      r2 = t3(r2);
    }
    const l2 = I(t2), c2 = l2[a2] || (l2[a2] = {}), h2 = D(c2, r2, o2 ? i2 : null);
    if (h2) return void (h2.oneOff = h2.oneOff && n2);
    const d2 = O(r2, e2.replace(E, "")), u2 = o2 ? /* @__PURE__ */ (function(t3, e3, i3) {
      return function s3(n3) {
        const o3 = t3.querySelectorAll(e3);
        for (let { target: r3 } = n3; r3 && r3 !== this; r3 = r3.parentNode) for (const a3 of o3) if (a3 === r3) return z(n3, { delegateTarget: r3 }), s3.oneOff && F.off(t3, n3.type, e3, i3), i3.apply(r3, [n3]);
      };
    })(t2, i2, r2) : /* @__PURE__ */ (function(t3, e3) {
      return function i3(s3) {
        return z(s3, { delegateTarget: t3 }), i3.oneOff && F.off(t3, s3.type, e3), e3.apply(t3, [s3]);
      };
    })(t2, r2);
    u2.delegationSelector = o2 ? i2 : null, u2.callable = r2, u2.oneOff = n2, u2.uidEvent = d2, c2[d2] = u2, t2.addEventListener(a2, u2, o2);
  }
  function x(t2, e2, i2, s2, n2) {
    const o2 = D(e2[i2], s2, n2);
    o2 && (t2.removeEventListener(i2, o2, Boolean(n2)), delete e2[i2][o2.uidEvent]);
  }
  function M(t2, e2, i2, s2) {
    const n2 = e2[i2] || {};
    for (const [o2, r2] of Object.entries(n2)) o2.includes(s2) && x(t2, e2, i2, r2.callable, r2.delegationSelector);
  }
  function j(t2) {
    return t2 = t2.replace(C, ""), S[t2] || t2;
  }
  const F = { on(t2, e2, i2, s2) {
    P(t2, e2, i2, s2, false);
  }, one(t2, e2, i2, s2) {
    P(t2, e2, i2, s2, true);
  }, off(t2, e2, i2, s2) {
    if ("string" != typeof e2 || !t2) return;
    const [n2, o2, r2] = N(e2, i2, s2), a2 = r2 !== e2, l2 = I(t2), c2 = l2[r2] || {}, h2 = e2.startsWith(".");
    if (void 0 === o2) {
      if (h2) for (const i3 of Object.keys(l2)) M(t2, l2, i3, e2.slice(1));
      for (const [i3, s3] of Object.entries(c2)) {
        const n3 = i3.replace(T, "");
        a2 && !e2.includes(n3) || x(t2, l2, r2, s3.callable, s3.delegationSelector);
      }
    } else {
      if (!Object.keys(c2).length) return;
      x(t2, l2, r2, o2, n2 ? i2 : null);
    }
  }, trigger(t2, e2, i2) {
    if ("string" != typeof e2 || !t2) return null;
    const s2 = m();
    let n2 = null, o2 = true, r2 = true, a2 = false;
    e2 !== j(e2) && s2 && (n2 = s2.Event(e2, i2), s2(t2).trigger(n2), o2 = !n2.isPropagationStopped(), r2 = !n2.isImmediatePropagationStopped(), a2 = n2.isDefaultPrevented());
    const l2 = z(new Event(e2, { bubbles: o2, cancelable: true }), i2);
    return a2 && l2.preventDefault(), r2 && t2.dispatchEvent(l2), l2.defaultPrevented && n2 && n2.preventDefault(), l2;
  } };
  function z(t2, e2 = {}) {
    for (const [i2, s2] of Object.entries(e2)) try {
      t2[i2] = s2;
    } catch (e3) {
      Object.defineProperty(t2, i2, { configurable: true, get: () => s2 });
    }
    return t2;
  }
  function H(t2) {
    if ("true" === t2) return true;
    if ("false" === t2) return false;
    if (t2 === Number(t2).toString()) return Number(t2);
    if ("" === t2 || "null" === t2) return null;
    if ("string" != typeof t2) return t2;
    try {
      return JSON.parse(decodeURIComponent(t2));
    } catch (e2) {
      return t2;
    }
  }
  function B(t2) {
    return t2.replace(/[A-Z]/g, (t3) => `-${t3.toLowerCase()}`);
  }
  const q = { setDataAttribute(t2, e2, i2) {
    t2.setAttribute(`data-bs-${B(e2)}`, i2);
  }, removeDataAttribute(t2, e2) {
    t2.removeAttribute(`data-bs-${B(e2)}`);
  }, getDataAttributes(t2) {
    if (!t2) return {};
    const e2 = {}, i2 = Object.keys(t2.dataset).filter((t3) => t3.startsWith("bs") && !t3.startsWith("bsConfig"));
    for (const s2 of i2) {
      let i3 = s2.replace(/^bs/, "");
      i3 = i3.charAt(0).toLowerCase() + i3.slice(1), e2[i3] = H(t2.dataset[s2]);
    }
    return e2;
  }, getDataAttribute: (t2, e2) => H(t2.getAttribute(`data-bs-${B(e2)}`)) };
  class W {
    static get Default() {
      return {};
    }
    static get DefaultType() {
      return {};
    }
    static get NAME() {
      throw new Error('You have to implement the static method "NAME", for each component!');
    }
    _getConfig(t2) {
      return t2 = this._mergeConfigObj(t2), t2 = this._configAfterMerge(t2), this._typeCheckConfig(t2), t2;
    }
    _configAfterMerge(t2) {
      return t2;
    }
    _mergeConfigObj(t2, e2) {
      const i2 = c(e2) ? q.getDataAttribute(e2, "config") : {};
      return { ...this.constructor.Default, ..."object" == typeof i2 ? i2 : {}, ...c(e2) ? q.getDataAttributes(e2) : {}, ..."object" == typeof t2 ? t2 : {} };
    }
    _typeCheckConfig(t2, e2 = this.constructor.DefaultType) {
      for (const [i2, s2] of Object.entries(e2)) {
        const e3 = t2[i2], n2 = c(e3) ? "element" : a(e3);
        if (!new RegExp(s2).test(n2)) throw new TypeError(`${this.constructor.NAME.toUpperCase()}: Option "${i2}" provided type "${n2}" but expected type "${s2}".`);
      }
    }
  }
  class R extends W {
    constructor(t2, e2) {
      super(), (t2 = h(t2)) && (this._element = t2, this._config = this._getConfig(e2), n.set(this._element, this.constructor.DATA_KEY, this));
    }
    dispose() {
      n.remove(this._element, this.constructor.DATA_KEY), F.off(this._element, this.constructor.EVENT_KEY);
      for (const t2 of Object.getOwnPropertyNames(this)) this[t2] = null;
    }
    _queueCallback(t2, e2, i2 = true) {
      w(t2, e2, i2);
    }
    _getConfig(t2) {
      return t2 = this._mergeConfigObj(t2, this._element), t2 = this._configAfterMerge(t2), this._typeCheckConfig(t2), t2;
    }
    static getInstance(t2) {
      return n.get(h(t2), this.DATA_KEY);
    }
    static getOrCreateInstance(t2, e2 = {}) {
      return this.getInstance(t2) || new this(t2, "object" == typeof e2 ? e2 : null);
    }
    static get VERSION() {
      return "5.3.8";
    }
    static get DATA_KEY() {
      return `bs.${this.NAME}`;
    }
    static get EVENT_KEY() {
      return `.${this.DATA_KEY}`;
    }
    static eventName(t2) {
      return `${t2}${this.EVENT_KEY}`;
    }
  }
  const K = (t2) => {
    let e2 = t2.getAttribute("data-bs-target");
    if (!e2 || "#" === e2) {
      let i2 = t2.getAttribute("href");
      if (!i2 || !i2.includes("#") && !i2.startsWith(".")) return null;
      i2.includes("#") && !i2.startsWith("#") && (i2 = `#${i2.split("#")[1]}`), e2 = i2 && "#" !== i2 ? i2.trim() : null;
    }
    return e2 ? e2.split(",").map((t3) => r(t3)).join(",") : null;
  }, V = { find: (t2, e2 = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(e2, t2)), findOne: (t2, e2 = document.documentElement) => Element.prototype.querySelector.call(e2, t2), children: (t2, e2) => [].concat(...t2.children).filter((t3) => t3.matches(e2)), parents(t2, e2) {
    const i2 = [];
    let s2 = t2.parentNode.closest(e2);
    for (; s2; ) i2.push(s2), s2 = s2.parentNode.closest(e2);
    return i2;
  }, prev(t2, e2) {
    let i2 = t2.previousElementSibling;
    for (; i2; ) {
      if (i2.matches(e2)) return [i2];
      i2 = i2.previousElementSibling;
    }
    return [];
  }, next(t2, e2) {
    let i2 = t2.nextElementSibling;
    for (; i2; ) {
      if (i2.matches(e2)) return [i2];
      i2 = i2.nextElementSibling;
    }
    return [];
  }, focusableChildren(t2) {
    const e2 = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map((t3) => `${t3}:not([tabindex^="-"])`).join(",");
    return this.find(e2, t2).filter((t3) => !u(t3) && d(t3));
  }, getSelectorFromElement(t2) {
    const e2 = K(t2);
    return e2 && V.findOne(e2) ? e2 : null;
  }, getElementFromSelector(t2) {
    const e2 = K(t2);
    return e2 ? V.findOne(e2) : null;
  }, getMultipleElementsFromSelector(t2) {
    const e2 = K(t2);
    return e2 ? V.find(e2) : [];
  } }, Q = (t2, e2 = "hide") => {
    const i2 = `click.dismiss${t2.EVENT_KEY}`, s2 = t2.NAME;
    F.on(document, i2, `[data-bs-dismiss="${s2}"]`, function(i3) {
      if (["A", "AREA"].includes(this.tagName) && i3.preventDefault(), u(this)) return;
      const n2 = V.getElementFromSelector(this) || this.closest(`.${s2}`);
      t2.getOrCreateInstance(n2)[e2]();
    });
  }, X = ".bs.alert", Y = `close${X}`, U = `closed${X}`;
  class G extends R {
    static get NAME() {
      return "alert";
    }
    close() {
      if (F.trigger(this._element, Y).defaultPrevented) return;
      this._element.classList.remove("show");
      const t2 = this._element.classList.contains("fade");
      this._queueCallback(() => this._destroyElement(), this._element, t2);
    }
    _destroyElement() {
      this._element.remove(), F.trigger(this._element, U), this.dispose();
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = G.getOrCreateInstance(this);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2](this);
        }
      });
    }
  }
  Q(G, "close"), v(G);
  const J = '[data-bs-toggle="button"]';
  class Z extends R {
    static get NAME() {
      return "button";
    }
    toggle() {
      this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"));
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Z.getOrCreateInstance(this);
        "toggle" === t2 && e2[t2]();
      });
    }
  }
  F.on(document, "click.bs.button.data-api", J, (t2) => {
    t2.preventDefault();
    const e2 = t2.target.closest(J);
    Z.getOrCreateInstance(e2).toggle();
  }), v(Z);
  const tt = ".bs.swipe", et = `touchstart${tt}`, it = `touchmove${tt}`, st = `touchend${tt}`, nt = `pointerdown${tt}`, ot = `pointerup${tt}`, rt = { endCallback: null, leftCallback: null, rightCallback: null }, at = { endCallback: "(function|null)", leftCallback: "(function|null)", rightCallback: "(function|null)" };
  class lt extends W {
    constructor(t2, e2) {
      super(), this._element = t2, t2 && lt.isSupported() && (this._config = this._getConfig(e2), this._deltaX = 0, this._supportPointerEvents = Boolean(window.PointerEvent), this._initEvents());
    }
    static get Default() {
      return rt;
    }
    static get DefaultType() {
      return at;
    }
    static get NAME() {
      return "swipe";
    }
    dispose() {
      F.off(this._element, tt);
    }
    _start(t2) {
      this._supportPointerEvents ? this._eventIsPointerPenTouch(t2) && (this._deltaX = t2.clientX) : this._deltaX = t2.touches[0].clientX;
    }
    _end(t2) {
      this._eventIsPointerPenTouch(t2) && (this._deltaX = t2.clientX - this._deltaX), this._handleSwipe(), y(this._config.endCallback);
    }
    _move(t2) {
      this._deltaX = t2.touches && t2.touches.length > 1 ? 0 : t2.touches[0].clientX - this._deltaX;
    }
    _handleSwipe() {
      const t2 = Math.abs(this._deltaX);
      if (t2 <= 40) return;
      const e2 = t2 / this._deltaX;
      this._deltaX = 0, e2 && y(e2 > 0 ? this._config.rightCallback : this._config.leftCallback);
    }
    _initEvents() {
      this._supportPointerEvents ? (F.on(this._element, nt, (t2) => this._start(t2)), F.on(this._element, ot, (t2) => this._end(t2)), this._element.classList.add("pointer-event")) : (F.on(this._element, et, (t2) => this._start(t2)), F.on(this._element, it, (t2) => this._move(t2)), F.on(this._element, st, (t2) => this._end(t2)));
    }
    _eventIsPointerPenTouch(t2) {
      return this._supportPointerEvents && ("pen" === t2.pointerType || "touch" === t2.pointerType);
    }
    static isSupported() {
      return "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0;
    }
  }
  const ct = ".bs.carousel", ht = ".data-api", dt = "ArrowLeft", ut = "ArrowRight", _t = "next", gt = "prev", ft = "left", mt = "right", pt = `slide${ct}`, bt = `slid${ct}`, vt = `keydown${ct}`, yt = `mouseenter${ct}`, wt = `mouseleave${ct}`, At = `dragstart${ct}`, Et = `load${ct}${ht}`, Ct = `click${ct}${ht}`, Tt = "carousel", kt = "active", $t = ".active", St = ".carousel-item", Lt = $t + St, Ot = { [dt]: mt, [ut]: ft }, It = { interval: 5e3, keyboard: true, pause: "hover", ride: false, touch: true, wrap: true }, Dt = { interval: "(number|boolean)", keyboard: "boolean", pause: "(string|boolean)", ride: "(boolean|string)", touch: "boolean", wrap: "boolean" };
  class Nt extends R {
    constructor(t2, e2) {
      super(t2, e2), this._interval = null, this._activeElement = null, this._isSliding = false, this.touchTimeout = null, this._swipeHelper = null, this._indicatorsElement = V.findOne(".carousel-indicators", this._element), this._addEventListeners(), this._config.ride === Tt && this.cycle();
    }
    static get Default() {
      return It;
    }
    static get DefaultType() {
      return Dt;
    }
    static get NAME() {
      return "carousel";
    }
    next() {
      this._slide(_t);
    }
    nextWhenVisible() {
      !document.hidden && d(this._element) && this.next();
    }
    prev() {
      this._slide(gt);
    }
    pause() {
      this._isSliding && l(this._element), this._clearInterval();
    }
    cycle() {
      this._clearInterval(), this._updateInterval(), this._interval = setInterval(() => this.nextWhenVisible(), this._config.interval);
    }
    _maybeEnableCycle() {
      this._config.ride && (this._isSliding ? F.one(this._element, bt, () => this.cycle()) : this.cycle());
    }
    to(t2) {
      const e2 = this._getItems();
      if (t2 > e2.length - 1 || t2 < 0) return;
      if (this._isSliding) return void F.one(this._element, bt, () => this.to(t2));
      const i2 = this._getItemIndex(this._getActive());
      if (i2 === t2) return;
      const s2 = t2 > i2 ? _t : gt;
      this._slide(s2, e2[t2]);
    }
    dispose() {
      this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
    }
    _configAfterMerge(t2) {
      return t2.defaultInterval = t2.interval, t2;
    }
    _addEventListeners() {
      this._config.keyboard && F.on(this._element, vt, (t2) => this._keydown(t2)), "hover" === this._config.pause && (F.on(this._element, yt, () => this.pause()), F.on(this._element, wt, () => this._maybeEnableCycle())), this._config.touch && lt.isSupported() && this._addTouchEventListeners();
    }
    _addTouchEventListeners() {
      for (const t3 of V.find(".carousel-item img", this._element)) F.on(t3, At, (t4) => t4.preventDefault());
      const t2 = { leftCallback: () => this._slide(this._directionToOrder(ft)), rightCallback: () => this._slide(this._directionToOrder(mt)), endCallback: () => {
        "hover" === this._config.pause && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(() => this._maybeEnableCycle(), 500 + this._config.interval));
      } };
      this._swipeHelper = new lt(this._element, t2);
    }
    _keydown(t2) {
      if (/input|textarea/i.test(t2.target.tagName)) return;
      const e2 = Ot[t2.key];
      e2 && (t2.preventDefault(), this._slide(this._directionToOrder(e2)));
    }
    _getItemIndex(t2) {
      return this._getItems().indexOf(t2);
    }
    _setActiveIndicatorElement(t2) {
      if (!this._indicatorsElement) return;
      const e2 = V.findOne($t, this._indicatorsElement);
      e2.classList.remove(kt), e2.removeAttribute("aria-current");
      const i2 = V.findOne(`[data-bs-slide-to="${t2}"]`, this._indicatorsElement);
      i2 && (i2.classList.add(kt), i2.setAttribute("aria-current", "true"));
    }
    _updateInterval() {
      const t2 = this._activeElement || this._getActive();
      if (!t2) return;
      const e2 = Number.parseInt(t2.getAttribute("data-bs-interval"), 10);
      this._config.interval = e2 || this._config.defaultInterval;
    }
    _slide(t2, e2 = null) {
      if (this._isSliding) return;
      const i2 = this._getActive(), s2 = t2 === _t, n2 = e2 || A(this._getItems(), i2, s2, this._config.wrap);
      if (n2 === i2) return;
      const o2 = this._getItemIndex(n2), r2 = (e3) => F.trigger(this._element, e3, { relatedTarget: n2, direction: this._orderToDirection(t2), from: this._getItemIndex(i2), to: o2 });
      if (r2(pt).defaultPrevented) return;
      if (!i2 || !n2) return;
      const a2 = Boolean(this._interval);
      this.pause(), this._isSliding = true, this._setActiveIndicatorElement(o2), this._activeElement = n2;
      const l2 = s2 ? "carousel-item-start" : "carousel-item-end", c2 = s2 ? "carousel-item-next" : "carousel-item-prev";
      n2.classList.add(c2), f(n2), i2.classList.add(l2), n2.classList.add(l2), this._queueCallback(() => {
        n2.classList.remove(l2, c2), n2.classList.add(kt), i2.classList.remove(kt, c2, l2), this._isSliding = false, r2(bt);
      }, i2, this._isAnimated()), a2 && this.cycle();
    }
    _isAnimated() {
      return this._element.classList.contains("slide");
    }
    _getActive() {
      return V.findOne(Lt, this._element);
    }
    _getItems() {
      return V.find(St, this._element);
    }
    _clearInterval() {
      this._interval && (clearInterval(this._interval), this._interval = null);
    }
    _directionToOrder(t2) {
      return b() ? t2 === ft ? gt : _t : t2 === ft ? _t : gt;
    }
    _orderToDirection(t2) {
      return b() ? t2 === gt ? ft : mt : t2 === gt ? mt : ft;
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Nt.getOrCreateInstance(this, t2);
        if ("number" != typeof t2) {
          if ("string" == typeof t2) {
            if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
            e2[t2]();
          }
        } else e2.to(t2);
      });
    }
  }
  F.on(document, Ct, "[data-bs-slide], [data-bs-slide-to]", function(t2) {
    const e2 = V.getElementFromSelector(this);
    if (!e2 || !e2.classList.contains(Tt)) return;
    t2.preventDefault();
    const i2 = Nt.getOrCreateInstance(e2), s2 = this.getAttribute("data-bs-slide-to");
    return s2 ? (i2.to(s2), void i2._maybeEnableCycle()) : "next" === q.getDataAttribute(this, "slide") ? (i2.next(), void i2._maybeEnableCycle()) : (i2.prev(), void i2._maybeEnableCycle());
  }), F.on(window, Et, () => {
    const t2 = V.find('[data-bs-ride="carousel"]');
    for (const e2 of t2) Nt.getOrCreateInstance(e2);
  }), v(Nt);
  const Pt = ".bs.collapse", xt = `show${Pt}`, Mt = `shown${Pt}`, jt = `hide${Pt}`, Ft = `hidden${Pt}`, zt = `click${Pt}.data-api`, Ht = "show", Bt = "collapse", qt = "collapsing", Wt = `:scope .${Bt} .${Bt}`, Rt = '[data-bs-toggle="collapse"]', Kt = { parent: null, toggle: true }, Vt = { parent: "(null|element)", toggle: "boolean" };
  class Qt extends R {
    constructor(t2, e2) {
      super(t2, e2), this._isTransitioning = false, this._triggerArray = [];
      const i2 = V.find(Rt);
      for (const t3 of i2) {
        const e3 = V.getSelectorFromElement(t3), i3 = V.find(e3).filter((t4) => t4 === this._element);
        null !== e3 && i3.length && this._triggerArray.push(t3);
      }
      this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle();
    }
    static get Default() {
      return Kt;
    }
    static get DefaultType() {
      return Vt;
    }
    static get NAME() {
      return "collapse";
    }
    toggle() {
      this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (this._isTransitioning || this._isShown()) return;
      let t2 = [];
      if (this._config.parent && (t2 = this._getFirstLevelChildren(".collapse.show, .collapse.collapsing").filter((t3) => t3 !== this._element).map((t3) => Qt.getOrCreateInstance(t3, { toggle: false }))), t2.length && t2[0]._isTransitioning) return;
      if (F.trigger(this._element, xt).defaultPrevented) return;
      for (const e3 of t2) e3.hide();
      const e2 = this._getDimension();
      this._element.classList.remove(Bt), this._element.classList.add(qt), this._element.style[e2] = 0, this._addAriaAndCollapsedClass(this._triggerArray, true), this._isTransitioning = true;
      const i2 = `scroll${e2[0].toUpperCase() + e2.slice(1)}`;
      this._queueCallback(() => {
        this._isTransitioning = false, this._element.classList.remove(qt), this._element.classList.add(Bt, Ht), this._element.style[e2] = "", F.trigger(this._element, Mt);
      }, this._element, true), this._element.style[e2] = `${this._element[i2]}px`;
    }
    hide() {
      if (this._isTransitioning || !this._isShown()) return;
      if (F.trigger(this._element, jt).defaultPrevented) return;
      const t2 = this._getDimension();
      this._element.style[t2] = `${this._element.getBoundingClientRect()[t2]}px`, f(this._element), this._element.classList.add(qt), this._element.classList.remove(Bt, Ht);
      for (const t3 of this._triggerArray) {
        const e2 = V.getElementFromSelector(t3);
        e2 && !this._isShown(e2) && this._addAriaAndCollapsedClass([t3], false);
      }
      this._isTransitioning = true, this._element.style[t2] = "", this._queueCallback(() => {
        this._isTransitioning = false, this._element.classList.remove(qt), this._element.classList.add(Bt), F.trigger(this._element, Ft);
      }, this._element, true);
    }
    _isShown(t2 = this._element) {
      return t2.classList.contains(Ht);
    }
    _configAfterMerge(t2) {
      return t2.toggle = Boolean(t2.toggle), t2.parent = h(t2.parent), t2;
    }
    _getDimension() {
      return this._element.classList.contains("collapse-horizontal") ? "width" : "height";
    }
    _initializeChildren() {
      if (!this._config.parent) return;
      const t2 = this._getFirstLevelChildren(Rt);
      for (const e2 of t2) {
        const t3 = V.getElementFromSelector(e2);
        t3 && this._addAriaAndCollapsedClass([e2], this._isShown(t3));
      }
    }
    _getFirstLevelChildren(t2) {
      const e2 = V.find(Wt, this._config.parent);
      return V.find(t2, this._config.parent).filter((t3) => !e2.includes(t3));
    }
    _addAriaAndCollapsedClass(t2, e2) {
      if (t2.length) for (const i2 of t2) i2.classList.toggle("collapsed", !e2), i2.setAttribute("aria-expanded", e2);
    }
    static jQueryInterface(t2) {
      const e2 = {};
      return "string" == typeof t2 && /show|hide/.test(t2) && (e2.toggle = false), this.each(function() {
        const i2 = Qt.getOrCreateInstance(this, e2);
        if ("string" == typeof t2) {
          if (void 0 === i2[t2]) throw new TypeError(`No method named "${t2}"`);
          i2[t2]();
        }
      });
    }
  }
  F.on(document, zt, Rt, function(t2) {
    ("A" === t2.target.tagName || t2.delegateTarget && "A" === t2.delegateTarget.tagName) && t2.preventDefault();
    for (const t3 of V.getMultipleElementsFromSelector(this)) Qt.getOrCreateInstance(t3, { toggle: false }).toggle();
  }), v(Qt);
  const Xt = "dropdown", Yt = ".bs.dropdown", Ut = ".data-api", Gt = "ArrowUp", Jt = "ArrowDown", Zt = `hide${Yt}`, te = `hidden${Yt}`, ee = `show${Yt}`, ie = `shown${Yt}`, se = `click${Yt}${Ut}`, ne = `keydown${Yt}${Ut}`, oe = `keyup${Yt}${Ut}`, re = "show", ae = '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)', le = `${ae}.${re}`, ce = ".dropdown-menu", he = b() ? "top-end" : "top-start", de = b() ? "top-start" : "top-end", ue = b() ? "bottom-end" : "bottom-start", _e = b() ? "bottom-start" : "bottom-end", ge = b() ? "left-start" : "right-start", fe = b() ? "right-start" : "left-start", me = { autoClose: true, boundary: "clippingParents", display: "dynamic", offset: [0, 2], popperConfig: null, reference: "toggle" }, pe = { autoClose: "(boolean|string)", boundary: "(string|element)", display: "string", offset: "(array|string|function)", popperConfig: "(null|object|function)", reference: "(string|element|object)" };
  class be extends R {
    constructor(t2, e2) {
      super(t2, e2), this._popper = null, this._parent = this._element.parentNode, this._menu = V.next(this._element, ce)[0] || V.prev(this._element, ce)[0] || V.findOne(ce, this._parent), this._inNavbar = this._detectNavbar();
    }
    static get Default() {
      return me;
    }
    static get DefaultType() {
      return pe;
    }
    static get NAME() {
      return Xt;
    }
    toggle() {
      return this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (u(this._element) || this._isShown()) return;
      const t2 = { relatedTarget: this._element };
      if (!F.trigger(this._element, ee, t2).defaultPrevented) {
        if (this._createPopper(), "ontouchstart" in document.documentElement && !this._parent.closest(".navbar-nav")) for (const t3 of [].concat(...document.body.children)) F.on(t3, "mouseover", g);
        this._element.focus(), this._element.setAttribute("aria-expanded", true), this._menu.classList.add(re), this._element.classList.add(re), F.trigger(this._element, ie, t2);
      }
    }
    hide() {
      if (u(this._element) || !this._isShown()) return;
      const t2 = { relatedTarget: this._element };
      this._completeHide(t2);
    }
    dispose() {
      this._popper && this._popper.destroy(), super.dispose();
    }
    update() {
      this._inNavbar = this._detectNavbar(), this._popper && this._popper.update();
    }
    _completeHide(t2) {
      if (!F.trigger(this._element, Zt, t2).defaultPrevented) {
        if ("ontouchstart" in document.documentElement) for (const t3 of [].concat(...document.body.children)) F.off(t3, "mouseover", g);
        this._popper && this._popper.destroy(), this._menu.classList.remove(re), this._element.classList.remove(re), this._element.setAttribute("aria-expanded", "false"), q.removeDataAttribute(this._menu, "popper"), F.trigger(this._element, te, t2);
      }
    }
    _getConfig(t2) {
      if ("object" == typeof (t2 = super._getConfig(t2)).reference && !c(t2.reference) && "function" != typeof t2.reference.getBoundingClientRect) throw new TypeError(`${Xt.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
      return t2;
    }
    _createPopper() {
      if (void 0 === i) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)");
      let t2 = this._element;
      "parent" === this._config.reference ? t2 = this._parent : c(this._config.reference) ? t2 = h(this._config.reference) : "object" == typeof this._config.reference && (t2 = this._config.reference);
      const e2 = this._getPopperConfig();
      this._popper = i.createPopper(t2, this._menu, e2);
    }
    _isShown() {
      return this._menu.classList.contains(re);
    }
    _getPlacement() {
      const t2 = this._parent;
      if (t2.classList.contains("dropend")) return ge;
      if (t2.classList.contains("dropstart")) return fe;
      if (t2.classList.contains("dropup-center")) return "top";
      if (t2.classList.contains("dropdown-center")) return "bottom";
      const e2 = "end" === getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
      return t2.classList.contains("dropup") ? e2 ? de : he : e2 ? _e : ue;
    }
    _detectNavbar() {
      return null !== this._element.closest(".navbar");
    }
    _getOffset() {
      const { offset: t2 } = this._config;
      return "string" == typeof t2 ? t2.split(",").map((t3) => Number.parseInt(t3, 10)) : "function" == typeof t2 ? (e2) => t2(e2, this._element) : t2;
    }
    _getPopperConfig() {
      const t2 = { placement: this._getPlacement(), modifiers: [{ name: "preventOverflow", options: { boundary: this._config.boundary } }, { name: "offset", options: { offset: this._getOffset() } }] };
      return (this._inNavbar || "static" === this._config.display) && (q.setDataAttribute(this._menu, "popper", "static"), t2.modifiers = [{ name: "applyStyles", enabled: false }]), { ...t2, ...y(this._config.popperConfig, [void 0, t2]) };
    }
    _selectMenuItem({ key: t2, target: e2 }) {
      const i2 = V.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter((t3) => d(t3));
      i2.length && A(i2, e2, t2 === Jt, !i2.includes(e2)).focus();
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = be.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
    static clearMenus(t2) {
      if (2 === t2.button || "keyup" === t2.type && "Tab" !== t2.key) return;
      const e2 = V.find(le);
      for (const i2 of e2) {
        const e3 = be.getInstance(i2);
        if (!e3 || false === e3._config.autoClose) continue;
        const s2 = t2.composedPath(), n2 = s2.includes(e3._menu);
        if (s2.includes(e3._element) || "inside" === e3._config.autoClose && !n2 || "outside" === e3._config.autoClose && n2) continue;
        if (e3._menu.contains(t2.target) && ("keyup" === t2.type && "Tab" === t2.key || /input|select|option|textarea|form/i.test(t2.target.tagName))) continue;
        const o2 = { relatedTarget: e3._element };
        "click" === t2.type && (o2.clickEvent = t2), e3._completeHide(o2);
      }
    }
    static dataApiKeydownHandler(t2) {
      const e2 = /input|textarea/i.test(t2.target.tagName), i2 = "Escape" === t2.key, s2 = [Gt, Jt].includes(t2.key);
      if (!s2 && !i2) return;
      if (e2 && !i2) return;
      t2.preventDefault();
      const n2 = this.matches(ae) ? this : V.prev(this, ae)[0] || V.next(this, ae)[0] || V.findOne(ae, t2.delegateTarget.parentNode), o2 = be.getOrCreateInstance(n2);
      if (s2) return t2.stopPropagation(), o2.show(), void o2._selectMenuItem(t2);
      o2._isShown() && (t2.stopPropagation(), o2.hide(), n2.focus());
    }
  }
  F.on(document, ne, ae, be.dataApiKeydownHandler), F.on(document, ne, ce, be.dataApiKeydownHandler), F.on(document, se, be.clearMenus), F.on(document, oe, be.clearMenus), F.on(document, se, ae, function(t2) {
    t2.preventDefault(), be.getOrCreateInstance(this).toggle();
  }), v(be);
  const ve = "backdrop", ye = "show", we = `mousedown.bs.${ve}`, Ae = { className: "modal-backdrop", clickCallback: null, isAnimated: false, isVisible: true, rootElement: "body" }, Ee = { className: "string", clickCallback: "(function|null)", isAnimated: "boolean", isVisible: "boolean", rootElement: "(element|string)" };
  class Ce extends W {
    constructor(t2) {
      super(), this._config = this._getConfig(t2), this._isAppended = false, this._element = null;
    }
    static get Default() {
      return Ae;
    }
    static get DefaultType() {
      return Ee;
    }
    static get NAME() {
      return ve;
    }
    show(t2) {
      if (!this._config.isVisible) return void y(t2);
      this._append();
      const e2 = this._getElement();
      this._config.isAnimated && f(e2), e2.classList.add(ye), this._emulateAnimation(() => {
        y(t2);
      });
    }
    hide(t2) {
      this._config.isVisible ? (this._getElement().classList.remove(ye), this._emulateAnimation(() => {
        this.dispose(), y(t2);
      })) : y(t2);
    }
    dispose() {
      this._isAppended && (F.off(this._element, we), this._element.remove(), this._isAppended = false);
    }
    _getElement() {
      if (!this._element) {
        const t2 = document.createElement("div");
        t2.className = this._config.className, this._config.isAnimated && t2.classList.add("fade"), this._element = t2;
      }
      return this._element;
    }
    _configAfterMerge(t2) {
      return t2.rootElement = h(t2.rootElement), t2;
    }
    _append() {
      if (this._isAppended) return;
      const t2 = this._getElement();
      this._config.rootElement.append(t2), F.on(t2, we, () => {
        y(this._config.clickCallback);
      }), this._isAppended = true;
    }
    _emulateAnimation(t2) {
      w(t2, this._getElement(), this._config.isAnimated);
    }
  }
  const Te = ".bs.focustrap", ke = `focusin${Te}`, $e = `keydown.tab${Te}`, Se = "backward", Le = { autofocus: true, trapElement: null }, Oe = { autofocus: "boolean", trapElement: "element" };
  class Ie extends W {
    constructor(t2) {
      super(), this._config = this._getConfig(t2), this._isActive = false, this._lastTabNavDirection = null;
    }
    static get Default() {
      return Le;
    }
    static get DefaultType() {
      return Oe;
    }
    static get NAME() {
      return "focustrap";
    }
    activate() {
      this._isActive || (this._config.autofocus && this._config.trapElement.focus(), F.off(document, Te), F.on(document, ke, (t2) => this._handleFocusin(t2)), F.on(document, $e, (t2) => this._handleKeydown(t2)), this._isActive = true);
    }
    deactivate() {
      this._isActive && (this._isActive = false, F.off(document, Te));
    }
    _handleFocusin(t2) {
      const { trapElement: e2 } = this._config;
      if (t2.target === document || t2.target === e2 || e2.contains(t2.target)) return;
      const i2 = V.focusableChildren(e2);
      0 === i2.length ? e2.focus() : this._lastTabNavDirection === Se ? i2[i2.length - 1].focus() : i2[0].focus();
    }
    _handleKeydown(t2) {
      "Tab" === t2.key && (this._lastTabNavDirection = t2.shiftKey ? Se : "forward");
    }
  }
  const De = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", Ne = ".sticky-top", Pe = "padding-right", xe = "margin-right";
  class Me {
    constructor() {
      this._element = document.body;
    }
    getWidth() {
      const t2 = document.documentElement.clientWidth;
      return Math.abs(window.innerWidth - t2);
    }
    hide() {
      const t2 = this.getWidth();
      this._disableOverFlow(), this._setElementAttributes(this._element, Pe, (e2) => e2 + t2), this._setElementAttributes(De, Pe, (e2) => e2 + t2), this._setElementAttributes(Ne, xe, (e2) => e2 - t2);
    }
    reset() {
      this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, Pe), this._resetElementAttributes(De, Pe), this._resetElementAttributes(Ne, xe);
    }
    isOverflowing() {
      return this.getWidth() > 0;
    }
    _disableOverFlow() {
      this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden";
    }
    _setElementAttributes(t2, e2, i2) {
      const s2 = this.getWidth();
      this._applyManipulationCallback(t2, (t3) => {
        if (t3 !== this._element && window.innerWidth > t3.clientWidth + s2) return;
        this._saveInitialAttribute(t3, e2);
        const n2 = window.getComputedStyle(t3).getPropertyValue(e2);
        t3.style.setProperty(e2, `${i2(Number.parseFloat(n2))}px`);
      });
    }
    _saveInitialAttribute(t2, e2) {
      const i2 = t2.style.getPropertyValue(e2);
      i2 && q.setDataAttribute(t2, e2, i2);
    }
    _resetElementAttributes(t2, e2) {
      this._applyManipulationCallback(t2, (t3) => {
        const i2 = q.getDataAttribute(t3, e2);
        null !== i2 ? (q.removeDataAttribute(t3, e2), t3.style.setProperty(e2, i2)) : t3.style.removeProperty(e2);
      });
    }
    _applyManipulationCallback(t2, e2) {
      if (c(t2)) e2(t2);
      else for (const i2 of V.find(t2, this._element)) e2(i2);
    }
  }
  const je = ".bs.modal", Fe = `hide${je}`, ze = `hidePrevented${je}`, He = `hidden${je}`, Be = `show${je}`, qe = `shown${je}`, We = `resize${je}`, Re = `click.dismiss${je}`, Ke = `mousedown.dismiss${je}`, Ve = `keydown.dismiss${je}`, Qe = `click${je}.data-api`, Xe = "modal-open", Ye = "show", Ue = "modal-static", Ge = { backdrop: true, focus: true, keyboard: true }, Je = { backdrop: "(boolean|string)", focus: "boolean", keyboard: "boolean" };
  class Ze extends R {
    constructor(t2, e2) {
      super(t2, e2), this._dialog = V.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = false, this._isTransitioning = false, this._scrollBar = new Me(), this._addEventListeners();
    }
    static get Default() {
      return Ge;
    }
    static get DefaultType() {
      return Je;
    }
    static get NAME() {
      return "modal";
    }
    toggle(t2) {
      return this._isShown ? this.hide() : this.show(t2);
    }
    show(t2) {
      this._isShown || this._isTransitioning || F.trigger(this._element, Be, { relatedTarget: t2 }).defaultPrevented || (this._isShown = true, this._isTransitioning = true, this._scrollBar.hide(), document.body.classList.add(Xe), this._adjustDialog(), this._backdrop.show(() => this._showElement(t2)));
    }
    hide() {
      this._isShown && !this._isTransitioning && (F.trigger(this._element, Fe).defaultPrevented || (this._isShown = false, this._isTransitioning = true, this._focustrap.deactivate(), this._element.classList.remove(Ye), this._queueCallback(() => this._hideModal(), this._element, this._isAnimated())));
    }
    dispose() {
      F.off(window, je), F.off(this._dialog, je), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
    }
    handleUpdate() {
      this._adjustDialog();
    }
    _initializeBackDrop() {
      return new Ce({ isVisible: Boolean(this._config.backdrop), isAnimated: this._isAnimated() });
    }
    _initializeFocusTrap() {
      return new Ie({ trapElement: this._element });
    }
    _showElement(t2) {
      document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", true), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
      const e2 = V.findOne(".modal-body", this._dialog);
      e2 && (e2.scrollTop = 0), f(this._element), this._element.classList.add(Ye), this._queueCallback(() => {
        this._config.focus && this._focustrap.activate(), this._isTransitioning = false, F.trigger(this._element, qe, { relatedTarget: t2 });
      }, this._dialog, this._isAnimated());
    }
    _addEventListeners() {
      F.on(this._element, Ve, (t2) => {
        "Escape" === t2.key && (this._config.keyboard ? this.hide() : this._triggerBackdropTransition());
      }), F.on(window, We, () => {
        this._isShown && !this._isTransitioning && this._adjustDialog();
      }), F.on(this._element, Ke, (t2) => {
        F.one(this._element, Re, (e2) => {
          this._element === t2.target && this._element === e2.target && ("static" !== this._config.backdrop ? this._config.backdrop && this.hide() : this._triggerBackdropTransition());
        });
      });
    }
    _hideModal() {
      this._element.style.display = "none", this._element.setAttribute("aria-hidden", true), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = false, this._backdrop.hide(() => {
        document.body.classList.remove(Xe), this._resetAdjustments(), this._scrollBar.reset(), F.trigger(this._element, He);
      });
    }
    _isAnimated() {
      return this._element.classList.contains("fade");
    }
    _triggerBackdropTransition() {
      if (F.trigger(this._element, ze).defaultPrevented) return;
      const t2 = this._element.scrollHeight > document.documentElement.clientHeight, e2 = this._element.style.overflowY;
      "hidden" === e2 || this._element.classList.contains(Ue) || (t2 || (this._element.style.overflowY = "hidden"), this._element.classList.add(Ue), this._queueCallback(() => {
        this._element.classList.remove(Ue), this._queueCallback(() => {
          this._element.style.overflowY = e2;
        }, this._dialog);
      }, this._dialog), this._element.focus());
    }
    _adjustDialog() {
      const t2 = this._element.scrollHeight > document.documentElement.clientHeight, e2 = this._scrollBar.getWidth(), i2 = e2 > 0;
      if (i2 && !t2) {
        const t3 = b() ? "paddingLeft" : "paddingRight";
        this._element.style[t3] = `${e2}px`;
      }
      if (!i2 && t2) {
        const t3 = b() ? "paddingRight" : "paddingLeft";
        this._element.style[t3] = `${e2}px`;
      }
    }
    _resetAdjustments() {
      this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
    }
    static jQueryInterface(t2, e2) {
      return this.each(function() {
        const i2 = Ze.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === i2[t2]) throw new TypeError(`No method named "${t2}"`);
          i2[t2](e2);
        }
      });
    }
  }
  F.on(document, Qe, '[data-bs-toggle="modal"]', function(t2) {
    const e2 = V.getElementFromSelector(this);
    ["A", "AREA"].includes(this.tagName) && t2.preventDefault(), F.one(e2, Be, (t3) => {
      t3.defaultPrevented || F.one(e2, He, () => {
        d(this) && this.focus();
      });
    });
    const i2 = V.findOne(".modal.show");
    i2 && Ze.getInstance(i2).hide(), Ze.getOrCreateInstance(e2).toggle(this);
  }), Q(Ze), v(Ze);
  const ti = ".bs.offcanvas", ei = ".data-api", ii = `load${ti}${ei}`, si = "show", ni = "showing", oi = "hiding", ri = ".offcanvas.show", ai = `show${ti}`, li = `shown${ti}`, ci = `hide${ti}`, hi = `hidePrevented${ti}`, di = `hidden${ti}`, ui = `resize${ti}`, _i = `click${ti}${ei}`, gi = `keydown.dismiss${ti}`, fi = { backdrop: true, keyboard: true, scroll: false }, mi = { backdrop: "(boolean|string)", keyboard: "boolean", scroll: "boolean" };
  class pi extends R {
    constructor(t2, e2) {
      super(t2, e2), this._isShown = false, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners();
    }
    static get Default() {
      return fi;
    }
    static get DefaultType() {
      return mi;
    }
    static get NAME() {
      return "offcanvas";
    }
    toggle(t2) {
      return this._isShown ? this.hide() : this.show(t2);
    }
    show(t2) {
      this._isShown || F.trigger(this._element, ai, { relatedTarget: t2 }).defaultPrevented || (this._isShown = true, this._backdrop.show(), this._config.scroll || new Me().hide(), this._element.setAttribute("aria-modal", true), this._element.setAttribute("role", "dialog"), this._element.classList.add(ni), this._queueCallback(() => {
        this._config.scroll && !this._config.backdrop || this._focustrap.activate(), this._element.classList.add(si), this._element.classList.remove(ni), F.trigger(this._element, li, { relatedTarget: t2 });
      }, this._element, true));
    }
    hide() {
      this._isShown && (F.trigger(this._element, ci).defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = false, this._element.classList.add(oi), this._backdrop.hide(), this._queueCallback(() => {
        this._element.classList.remove(si, oi), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._config.scroll || new Me().reset(), F.trigger(this._element, di);
      }, this._element, true)));
    }
    dispose() {
      this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
    }
    _initializeBackDrop() {
      const t2 = Boolean(this._config.backdrop);
      return new Ce({ className: "offcanvas-backdrop", isVisible: t2, isAnimated: true, rootElement: this._element.parentNode, clickCallback: t2 ? () => {
        "static" !== this._config.backdrop ? this.hide() : F.trigger(this._element, hi);
      } : null });
    }
    _initializeFocusTrap() {
      return new Ie({ trapElement: this._element });
    }
    _addEventListeners() {
      F.on(this._element, gi, (t2) => {
        "Escape" === t2.key && (this._config.keyboard ? this.hide() : F.trigger(this._element, hi));
      });
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = pi.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2](this);
        }
      });
    }
  }
  F.on(document, _i, '[data-bs-toggle="offcanvas"]', function(t2) {
    const e2 = V.getElementFromSelector(this);
    if (["A", "AREA"].includes(this.tagName) && t2.preventDefault(), u(this)) return;
    F.one(e2, di, () => {
      d(this) && this.focus();
    });
    const i2 = V.findOne(ri);
    i2 && i2 !== e2 && pi.getInstance(i2).hide(), pi.getOrCreateInstance(e2).toggle(this);
  }), F.on(window, ii, () => {
    for (const t2 of V.find(ri)) pi.getOrCreateInstance(t2).show();
  }), F.on(window, ui, () => {
    for (const t2 of V.find("[aria-modal][class*=show][class*=offcanvas-]")) "fixed" !== getComputedStyle(t2).position && pi.getOrCreateInstance(t2).hide();
  }), Q(pi), v(pi);
  const bi = { "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i], a: ["target", "href", "title", "rel"], area: [], b: [], br: [], col: [], code: [], dd: [], div: [], dl: [], dt: [], em: [], hr: [], h1: [], h2: [], h3: [], h4: [], h5: [], h6: [], i: [], img: ["src", "srcset", "alt", "title", "width", "height"], li: [], ol: [], p: [], pre: [], s: [], small: [], span: [], sub: [], sup: [], strong: [], u: [], ul: [] }, vi = /* @__PURE__ */ new Set(["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]), yi = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i, wi = (t2, e2) => {
    const i2 = t2.nodeName.toLowerCase();
    return e2.includes(i2) ? !vi.has(i2) || Boolean(yi.test(t2.nodeValue)) : e2.filter((t3) => t3 instanceof RegExp).some((t3) => t3.test(i2));
  }, Ai = { allowList: bi, content: {}, extraClass: "", html: false, sanitize: true, sanitizeFn: null, template: "<div></div>" }, Ei = { allowList: "object", content: "object", extraClass: "(string|function)", html: "boolean", sanitize: "boolean", sanitizeFn: "(null|function)", template: "string" }, Ci = { entry: "(string|element|function|null)", selector: "(string|element)" };
  class Ti extends W {
    constructor(t2) {
      super(), this._config = this._getConfig(t2);
    }
    static get Default() {
      return Ai;
    }
    static get DefaultType() {
      return Ei;
    }
    static get NAME() {
      return "TemplateFactory";
    }
    getContent() {
      return Object.values(this._config.content).map((t2) => this._resolvePossibleFunction(t2)).filter(Boolean);
    }
    hasContent() {
      return this.getContent().length > 0;
    }
    changeContent(t2) {
      return this._checkContent(t2), this._config.content = { ...this._config.content, ...t2 }, this;
    }
    toHtml() {
      const t2 = document.createElement("div");
      t2.innerHTML = this._maybeSanitize(this._config.template);
      for (const [e3, i3] of Object.entries(this._config.content)) this._setContent(t2, i3, e3);
      const e2 = t2.children[0], i2 = this._resolvePossibleFunction(this._config.extraClass);
      return i2 && e2.classList.add(...i2.split(" ")), e2;
    }
    _typeCheckConfig(t2) {
      super._typeCheckConfig(t2), this._checkContent(t2.content);
    }
    _checkContent(t2) {
      for (const [e2, i2] of Object.entries(t2)) super._typeCheckConfig({ selector: e2, entry: i2 }, Ci);
    }
    _setContent(t2, e2, i2) {
      const s2 = V.findOne(i2, t2);
      s2 && ((e2 = this._resolvePossibleFunction(e2)) ? c(e2) ? this._putElementInTemplate(h(e2), s2) : this._config.html ? s2.innerHTML = this._maybeSanitize(e2) : s2.textContent = e2 : s2.remove());
    }
    _maybeSanitize(t2) {
      return this._config.sanitize ? (function(t3, e2, i2) {
        if (!t3.length) return t3;
        if (i2 && "function" == typeof i2) return i2(t3);
        const s2 = new window.DOMParser().parseFromString(t3, "text/html"), n2 = [].concat(...s2.body.querySelectorAll("*"));
        for (const t4 of n2) {
          const i3 = t4.nodeName.toLowerCase();
          if (!Object.keys(e2).includes(i3)) {
            t4.remove();
            continue;
          }
          const s3 = [].concat(...t4.attributes), n3 = [].concat(e2["*"] || [], e2[i3] || []);
          for (const e3 of s3) wi(e3, n3) || t4.removeAttribute(e3.nodeName);
        }
        return s2.body.innerHTML;
      })(t2, this._config.allowList, this._config.sanitizeFn) : t2;
    }
    _resolvePossibleFunction(t2) {
      return y(t2, [void 0, this]);
    }
    _putElementInTemplate(t2, e2) {
      if (this._config.html) return e2.innerHTML = "", void e2.append(t2);
      e2.textContent = t2.textContent;
    }
  }
  const ki = /* @__PURE__ */ new Set(["sanitize", "allowList", "sanitizeFn"]), $i = "fade", Si = "show", Li = ".tooltip-inner", Oi = ".modal", Ii = "hide.bs.modal", Di = "hover", Ni = "focus", Pi = "click", xi = { AUTO: "auto", TOP: "top", RIGHT: b() ? "left" : "right", BOTTOM: "bottom", LEFT: b() ? "right" : "left" }, Mi = { allowList: bi, animation: true, boundary: "clippingParents", container: false, customClass: "", delay: 0, fallbackPlacements: ["top", "right", "bottom", "left"], html: false, offset: [0, 6], placement: "top", popperConfig: null, sanitize: true, sanitizeFn: null, selector: false, template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>', title: "", trigger: "hover focus" }, ji = { allowList: "object", animation: "boolean", boundary: "(string|element)", container: "(string|element|boolean)", customClass: "(string|function)", delay: "(number|object)", fallbackPlacements: "array", html: "boolean", offset: "(array|string|function)", placement: "(string|function)", popperConfig: "(null|object|function)", sanitize: "boolean", sanitizeFn: "(null|function)", selector: "(string|boolean)", template: "string", title: "(string|element|function)", trigger: "string" };
  class Fi extends R {
    constructor(t2, e2) {
      if (void 0 === i) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)");
      super(t2, e2), this._isEnabled = true, this._timeout = 0, this._isHovered = null, this._activeTrigger = {}, this._popper = null, this._templateFactory = null, this._newContent = null, this.tip = null, this._setListeners(), this._config.selector || this._fixTitle();
    }
    static get Default() {
      return Mi;
    }
    static get DefaultType() {
      return ji;
    }
    static get NAME() {
      return "tooltip";
    }
    enable() {
      this._isEnabled = true;
    }
    disable() {
      this._isEnabled = false;
    }
    toggleEnabled() {
      this._isEnabled = !this._isEnabled;
    }
    toggle() {
      this._isEnabled && (this._isShown() ? this._leave() : this._enter());
    }
    dispose() {
      clearTimeout(this._timeout), F.off(this._element.closest(Oi), Ii, this._hideModalHandler), this._element.getAttribute("data-bs-original-title") && this._element.setAttribute("title", this._element.getAttribute("data-bs-original-title")), this._disposePopper(), super.dispose();
    }
    show() {
      if ("none" === this._element.style.display) throw new Error("Please use show on visible elements");
      if (!this._isWithContent() || !this._isEnabled) return;
      const t2 = F.trigger(this._element, this.constructor.eventName("show")), e2 = (_(this._element) || this._element.ownerDocument.documentElement).contains(this._element);
      if (t2.defaultPrevented || !e2) return;
      this._disposePopper();
      const i2 = this._getTipElement();
      this._element.setAttribute("aria-describedby", i2.getAttribute("id"));
      const { container: s2 } = this._config;
      if (this._element.ownerDocument.documentElement.contains(this.tip) || (s2.append(i2), F.trigger(this._element, this.constructor.eventName("inserted"))), this._popper = this._createPopper(i2), i2.classList.add(Si), "ontouchstart" in document.documentElement) for (const t3 of [].concat(...document.body.children)) F.on(t3, "mouseover", g);
      this._queueCallback(() => {
        F.trigger(this._element, this.constructor.eventName("shown")), false === this._isHovered && this._leave(), this._isHovered = false;
      }, this.tip, this._isAnimated());
    }
    hide() {
      if (this._isShown() && !F.trigger(this._element, this.constructor.eventName("hide")).defaultPrevented) {
        if (this._getTipElement().classList.remove(Si), "ontouchstart" in document.documentElement) for (const t2 of [].concat(...document.body.children)) F.off(t2, "mouseover", g);
        this._activeTrigger[Pi] = false, this._activeTrigger[Ni] = false, this._activeTrigger[Di] = false, this._isHovered = null, this._queueCallback(() => {
          this._isWithActiveTrigger() || (this._isHovered || this._disposePopper(), this._element.removeAttribute("aria-describedby"), F.trigger(this._element, this.constructor.eventName("hidden")));
        }, this.tip, this._isAnimated());
      }
    }
    update() {
      this._popper && this._popper.update();
    }
    _isWithContent() {
      return Boolean(this._getTitle());
    }
    _getTipElement() {
      return this.tip || (this.tip = this._createTipElement(this._newContent || this._getContentForTemplate())), this.tip;
    }
    _createTipElement(t2) {
      const e2 = this._getTemplateFactory(t2).toHtml();
      if (!e2) return null;
      e2.classList.remove($i, Si), e2.classList.add(`bs-${this.constructor.NAME}-auto`);
      const i2 = ((t3) => {
        do {
          t3 += Math.floor(1e6 * Math.random());
        } while (document.getElementById(t3));
        return t3;
      })(this.constructor.NAME).toString();
      return e2.setAttribute("id", i2), this._isAnimated() && e2.classList.add($i), e2;
    }
    setContent(t2) {
      this._newContent = t2, this._isShown() && (this._disposePopper(), this.show());
    }
    _getTemplateFactory(t2) {
      return this._templateFactory ? this._templateFactory.changeContent(t2) : this._templateFactory = new Ti({ ...this._config, content: t2, extraClass: this._resolvePossibleFunction(this._config.customClass) }), this._templateFactory;
    }
    _getContentForTemplate() {
      return { [Li]: this._getTitle() };
    }
    _getTitle() {
      return this._resolvePossibleFunction(this._config.title) || this._element.getAttribute("data-bs-original-title");
    }
    _initializeOnDelegatedTarget(t2) {
      return this.constructor.getOrCreateInstance(t2.delegateTarget, this._getDelegateConfig());
    }
    _isAnimated() {
      return this._config.animation || this.tip && this.tip.classList.contains($i);
    }
    _isShown() {
      return this.tip && this.tip.classList.contains(Si);
    }
    _createPopper(t2) {
      const e2 = y(this._config.placement, [this, t2, this._element]), s2 = xi[e2.toUpperCase()];
      return i.createPopper(this._element, t2, this._getPopperConfig(s2));
    }
    _getOffset() {
      const { offset: t2 } = this._config;
      return "string" == typeof t2 ? t2.split(",").map((t3) => Number.parseInt(t3, 10)) : "function" == typeof t2 ? (e2) => t2(e2, this._element) : t2;
    }
    _resolvePossibleFunction(t2) {
      return y(t2, [this._element, this._element]);
    }
    _getPopperConfig(t2) {
      const e2 = { placement: t2, modifiers: [{ name: "flip", options: { fallbackPlacements: this._config.fallbackPlacements } }, { name: "offset", options: { offset: this._getOffset() } }, { name: "preventOverflow", options: { boundary: this._config.boundary } }, { name: "arrow", options: { element: `.${this.constructor.NAME}-arrow` } }, { name: "preSetPlacement", enabled: true, phase: "beforeMain", fn: (t3) => {
        this._getTipElement().setAttribute("data-popper-placement", t3.state.placement);
      } }] };
      return { ...e2, ...y(this._config.popperConfig, [void 0, e2]) };
    }
    _setListeners() {
      const t2 = this._config.trigger.split(" ");
      for (const e2 of t2) if ("click" === e2) F.on(this._element, this.constructor.eventName("click"), this._config.selector, (t3) => {
        const e3 = this._initializeOnDelegatedTarget(t3);
        e3._activeTrigger[Pi] = !(e3._isShown() && e3._activeTrigger[Pi]), e3.toggle();
      });
      else if ("manual" !== e2) {
        const t3 = e2 === Di ? this.constructor.eventName("mouseenter") : this.constructor.eventName("focusin"), i2 = e2 === Di ? this.constructor.eventName("mouseleave") : this.constructor.eventName("focusout");
        F.on(this._element, t3, this._config.selector, (t4) => {
          const e3 = this._initializeOnDelegatedTarget(t4);
          e3._activeTrigger["focusin" === t4.type ? Ni : Di] = true, e3._enter();
        }), F.on(this._element, i2, this._config.selector, (t4) => {
          const e3 = this._initializeOnDelegatedTarget(t4);
          e3._activeTrigger["focusout" === t4.type ? Ni : Di] = e3._element.contains(t4.relatedTarget), e3._leave();
        });
      }
      this._hideModalHandler = () => {
        this._element && this.hide();
      }, F.on(this._element.closest(Oi), Ii, this._hideModalHandler);
    }
    _fixTitle() {
      const t2 = this._element.getAttribute("title");
      t2 && (this._element.getAttribute("aria-label") || this._element.textContent.trim() || this._element.setAttribute("aria-label", t2), this._element.setAttribute("data-bs-original-title", t2), this._element.removeAttribute("title"));
    }
    _enter() {
      this._isShown() || this._isHovered ? this._isHovered = true : (this._isHovered = true, this._setTimeout(() => {
        this._isHovered && this.show();
      }, this._config.delay.show));
    }
    _leave() {
      this._isWithActiveTrigger() || (this._isHovered = false, this._setTimeout(() => {
        this._isHovered || this.hide();
      }, this._config.delay.hide));
    }
    _setTimeout(t2, e2) {
      clearTimeout(this._timeout), this._timeout = setTimeout(t2, e2);
    }
    _isWithActiveTrigger() {
      return Object.values(this._activeTrigger).includes(true);
    }
    _getConfig(t2) {
      const e2 = q.getDataAttributes(this._element);
      for (const t3 of Object.keys(e2)) ki.has(t3) && delete e2[t3];
      return t2 = { ...e2, ..."object" == typeof t2 && t2 ? t2 : {} }, t2 = this._mergeConfigObj(t2), t2 = this._configAfterMerge(t2), this._typeCheckConfig(t2), t2;
    }
    _configAfterMerge(t2) {
      return t2.container = false === t2.container ? document.body : h(t2.container), "number" == typeof t2.delay && (t2.delay = { show: t2.delay, hide: t2.delay }), "number" == typeof t2.title && (t2.title = t2.title.toString()), "number" == typeof t2.content && (t2.content = t2.content.toString()), t2;
    }
    _getDelegateConfig() {
      const t2 = {};
      for (const [e2, i2] of Object.entries(this._config)) this.constructor.Default[e2] !== i2 && (t2[e2] = i2);
      return t2.selector = false, t2.trigger = "manual", t2;
    }
    _disposePopper() {
      this._popper && (this._popper.destroy(), this._popper = null), this.tip && (this.tip.remove(), this.tip = null);
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Fi.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  v(Fi);
  const zi = ".popover-header", Hi = ".popover-body", Bi = { ...Fi.Default, content: "", offset: [0, 8], placement: "right", template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>', trigger: "click" }, qi = { ...Fi.DefaultType, content: "(null|string|element|function)" };
  class Wi extends Fi {
    static get Default() {
      return Bi;
    }
    static get DefaultType() {
      return qi;
    }
    static get NAME() {
      return "popover";
    }
    _isWithContent() {
      return this._getTitle() || this._getContent();
    }
    _getContentForTemplate() {
      return { [zi]: this._getTitle(), [Hi]: this._getContent() };
    }
    _getContent() {
      return this._resolvePossibleFunction(this._config.content);
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Wi.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  v(Wi);
  const Ri = ".bs.scrollspy", Ki = `activate${Ri}`, Vi = `click${Ri}`, Qi = `load${Ri}.data-api`, Xi = "active", Yi = "[href]", Ui = ".nav-link", Gi = `${Ui}, .nav-item > ${Ui}, .list-group-item`, Ji = { offset: null, rootMargin: "0px 0px -25%", smoothScroll: false, target: null, threshold: [0.1, 0.5, 1] }, Zi = { offset: "(number|null)", rootMargin: "string", smoothScroll: "boolean", target: "element", threshold: "array" };
  class ts extends R {
    constructor(t2, e2) {
      super(t2, e2), this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map(), this._rootElement = "visible" === getComputedStyle(this._element).overflowY ? null : this._element, this._activeTarget = null, this._observer = null, this._previousScrollData = { visibleEntryTop: 0, parentScrollTop: 0 }, this.refresh();
    }
    static get Default() {
      return Ji;
    }
    static get DefaultType() {
      return Zi;
    }
    static get NAME() {
      return "scrollspy";
    }
    refresh() {
      this._initializeTargetsAndObservables(), this._maybeEnableSmoothScroll(), this._observer ? this._observer.disconnect() : this._observer = this._getNewObserver();
      for (const t2 of this._observableSections.values()) this._observer.observe(t2);
    }
    dispose() {
      this._observer.disconnect(), super.dispose();
    }
    _configAfterMerge(t2) {
      return t2.target = h(t2.target) || document.body, t2.rootMargin = t2.offset ? `${t2.offset}px 0px -30%` : t2.rootMargin, "string" == typeof t2.threshold && (t2.threshold = t2.threshold.split(",").map((t3) => Number.parseFloat(t3))), t2;
    }
    _maybeEnableSmoothScroll() {
      this._config.smoothScroll && (F.off(this._config.target, Vi), F.on(this._config.target, Vi, Yi, (t2) => {
        const e2 = this._observableSections.get(t2.target.hash);
        if (e2) {
          t2.preventDefault();
          const i2 = this._rootElement || window, s2 = e2.offsetTop - this._element.offsetTop;
          if (i2.scrollTo) return void i2.scrollTo({ top: s2, behavior: "smooth" });
          i2.scrollTop = s2;
        }
      }));
    }
    _getNewObserver() {
      const t2 = { root: this._rootElement, threshold: this._config.threshold, rootMargin: this._config.rootMargin };
      return new IntersectionObserver((t3) => this._observerCallback(t3), t2);
    }
    _observerCallback(t2) {
      const e2 = (t3) => this._targetLinks.get(`#${t3.target.id}`), i2 = (t3) => {
        this._previousScrollData.visibleEntryTop = t3.target.offsetTop, this._process(e2(t3));
      }, s2 = (this._rootElement || document.documentElement).scrollTop, n2 = s2 >= this._previousScrollData.parentScrollTop;
      this._previousScrollData.parentScrollTop = s2;
      for (const o2 of t2) {
        if (!o2.isIntersecting) {
          this._activeTarget = null, this._clearActiveClass(e2(o2));
          continue;
        }
        const t3 = o2.target.offsetTop >= this._previousScrollData.visibleEntryTop;
        if (n2 && t3) {
          if (i2(o2), !s2) return;
        } else n2 || t3 || i2(o2);
      }
    }
    _initializeTargetsAndObservables() {
      this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map();
      const t2 = V.find(Yi, this._config.target);
      for (const e2 of t2) {
        if (!e2.hash || u(e2)) continue;
        const t3 = V.findOne(decodeURI(e2.hash), this._element);
        d(t3) && (this._targetLinks.set(decodeURI(e2.hash), e2), this._observableSections.set(e2.hash, t3));
      }
    }
    _process(t2) {
      this._activeTarget !== t2 && (this._clearActiveClass(this._config.target), this._activeTarget = t2, t2.classList.add(Xi), this._activateParents(t2), F.trigger(this._element, Ki, { relatedTarget: t2 }));
    }
    _activateParents(t2) {
      if (t2.classList.contains("dropdown-item")) V.findOne(".dropdown-toggle", t2.closest(".dropdown")).classList.add(Xi);
      else for (const e2 of V.parents(t2, ".nav, .list-group")) for (const t3 of V.prev(e2, Gi)) t3.classList.add(Xi);
    }
    _clearActiveClass(t2) {
      t2.classList.remove(Xi);
      const e2 = V.find(`${Yi}.${Xi}`, t2);
      for (const t3 of e2) t3.classList.remove(Xi);
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = ts.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  F.on(window, Qi, () => {
    for (const t2 of V.find('[data-bs-spy="scroll"]')) ts.getOrCreateInstance(t2);
  }), v(ts);
  const es = ".bs.tab", is = `hide${es}`, ss = `hidden${es}`, ns = `show${es}`, os = `shown${es}`, rs = `click${es}`, as = `keydown${es}`, ls = `load${es}`, cs = "ArrowLeft", hs = "ArrowRight", ds = "ArrowUp", us = "ArrowDown", _s = "Home", gs = "End", fs = "active", ms = "fade", ps = "show", bs = ".dropdown-toggle", vs = `:not(${bs})`, ys = '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]', ws = `.nav-link${vs}, .list-group-item${vs}, [role="tab"]${vs}, ${ys}`, As = `.${fs}[data-bs-toggle="tab"], .${fs}[data-bs-toggle="pill"], .${fs}[data-bs-toggle="list"]`;
  class Es extends R {
    constructor(t2) {
      super(t2), this._parent = this._element.closest('.list-group, .nav, [role="tablist"]'), this._parent && (this._setInitialAttributes(this._parent, this._getChildren()), F.on(this._element, as, (t3) => this._keydown(t3)));
    }
    static get NAME() {
      return "tab";
    }
    show() {
      const t2 = this._element;
      if (this._elemIsActive(t2)) return;
      const e2 = this._getActiveElem(), i2 = e2 ? F.trigger(e2, is, { relatedTarget: t2 }) : null;
      F.trigger(t2, ns, { relatedTarget: e2 }).defaultPrevented || i2 && i2.defaultPrevented || (this._deactivate(e2, t2), this._activate(t2, e2));
    }
    _activate(t2, e2) {
      t2 && (t2.classList.add(fs), this._activate(V.getElementFromSelector(t2)), this._queueCallback(() => {
        "tab" === t2.getAttribute("role") ? (t2.removeAttribute("tabindex"), t2.setAttribute("aria-selected", true), this._toggleDropDown(t2, true), F.trigger(t2, os, { relatedTarget: e2 })) : t2.classList.add(ps);
      }, t2, t2.classList.contains(ms)));
    }
    _deactivate(t2, e2) {
      t2 && (t2.classList.remove(fs), t2.blur(), this._deactivate(V.getElementFromSelector(t2)), this._queueCallback(() => {
        "tab" === t2.getAttribute("role") ? (t2.setAttribute("aria-selected", false), t2.setAttribute("tabindex", "-1"), this._toggleDropDown(t2, false), F.trigger(t2, ss, { relatedTarget: e2 })) : t2.classList.remove(ps);
      }, t2, t2.classList.contains(ms)));
    }
    _keydown(t2) {
      if (![cs, hs, ds, us, _s, gs].includes(t2.key)) return;
      t2.stopPropagation(), t2.preventDefault();
      const e2 = this._getChildren().filter((t3) => !u(t3));
      let i2;
      if ([_s, gs].includes(t2.key)) i2 = e2[t2.key === _s ? 0 : e2.length - 1];
      else {
        const s2 = [hs, us].includes(t2.key);
        i2 = A(e2, t2.target, s2, true);
      }
      i2 && (i2.focus({ preventScroll: true }), Es.getOrCreateInstance(i2).show());
    }
    _getChildren() {
      return V.find(ws, this._parent);
    }
    _getActiveElem() {
      return this._getChildren().find((t2) => this._elemIsActive(t2)) || null;
    }
    _setInitialAttributes(t2, e2) {
      this._setAttributeIfNotExists(t2, "role", "tablist");
      for (const t3 of e2) this._setInitialAttributesOnChild(t3);
    }
    _setInitialAttributesOnChild(t2) {
      t2 = this._getInnerElement(t2);
      const e2 = this._elemIsActive(t2), i2 = this._getOuterElement(t2);
      t2.setAttribute("aria-selected", e2), i2 !== t2 && this._setAttributeIfNotExists(i2, "role", "presentation"), e2 || t2.setAttribute("tabindex", "-1"), this._setAttributeIfNotExists(t2, "role", "tab"), this._setInitialAttributesOnTargetPanel(t2);
    }
    _setInitialAttributesOnTargetPanel(t2) {
      const e2 = V.getElementFromSelector(t2);
      e2 && (this._setAttributeIfNotExists(e2, "role", "tabpanel"), t2.id && this._setAttributeIfNotExists(e2, "aria-labelledby", `${t2.id}`));
    }
    _toggleDropDown(t2, e2) {
      const i2 = this._getOuterElement(t2);
      if (!i2.classList.contains("dropdown")) return;
      const s2 = (t3, s3) => {
        const n2 = V.findOne(t3, i2);
        n2 && n2.classList.toggle(s3, e2);
      };
      s2(bs, fs), s2(".dropdown-menu", ps), i2.setAttribute("aria-expanded", e2);
    }
    _setAttributeIfNotExists(t2, e2, i2) {
      t2.hasAttribute(e2) || t2.setAttribute(e2, i2);
    }
    _elemIsActive(t2) {
      return t2.classList.contains(fs);
    }
    _getInnerElement(t2) {
      return t2.matches(ws) ? t2 : V.findOne(ws, t2);
    }
    _getOuterElement(t2) {
      return t2.closest(".nav-item, .list-group-item") || t2;
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Es.getOrCreateInstance(this);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2] || t2.startsWith("_") || "constructor" === t2) throw new TypeError(`No method named "${t2}"`);
          e2[t2]();
        }
      });
    }
  }
  F.on(document, rs, ys, function(t2) {
    ["A", "AREA"].includes(this.tagName) && t2.preventDefault(), u(this) || Es.getOrCreateInstance(this).show();
  }), F.on(window, ls, () => {
    for (const t2 of V.find(As)) Es.getOrCreateInstance(t2);
  }), v(Es);
  const Cs = ".bs.toast", Ts = `mouseover${Cs}`, ks = `mouseout${Cs}`, $s = `focusin${Cs}`, Ss = `focusout${Cs}`, Ls = `hide${Cs}`, Os = `hidden${Cs}`, Is = `show${Cs}`, Ds = `shown${Cs}`, Ns = "hide", Ps = "show", xs = "showing", Ms = { animation: "boolean", autohide: "boolean", delay: "number" }, js = { animation: true, autohide: true, delay: 5e3 };
  class Fs extends R {
    constructor(t2, e2) {
      super(t2, e2), this._timeout = null, this._hasMouseInteraction = false, this._hasKeyboardInteraction = false, this._setListeners();
    }
    static get Default() {
      return js;
    }
    static get DefaultType() {
      return Ms;
    }
    static get NAME() {
      return "toast";
    }
    show() {
      F.trigger(this._element, Is).defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(Ns), f(this._element), this._element.classList.add(Ps, xs), this._queueCallback(() => {
        this._element.classList.remove(xs), F.trigger(this._element, Ds), this._maybeScheduleHide();
      }, this._element, this._config.animation));
    }
    hide() {
      this.isShown() && (F.trigger(this._element, Ls).defaultPrevented || (this._element.classList.add(xs), this._queueCallback(() => {
        this._element.classList.add(Ns), this._element.classList.remove(xs, Ps), F.trigger(this._element, Os);
      }, this._element, this._config.animation)));
    }
    dispose() {
      this._clearTimeout(), this.isShown() && this._element.classList.remove(Ps), super.dispose();
    }
    isShown() {
      return this._element.classList.contains(Ps);
    }
    _maybeScheduleHide() {
      this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
        this.hide();
      }, this._config.delay)));
    }
    _onInteraction(t2, e2) {
      switch (t2.type) {
        case "mouseover":
        case "mouseout":
          this._hasMouseInteraction = e2;
          break;
        case "focusin":
        case "focusout":
          this._hasKeyboardInteraction = e2;
      }
      if (e2) return void this._clearTimeout();
      const i2 = t2.relatedTarget;
      this._element === i2 || this._element.contains(i2) || this._maybeScheduleHide();
    }
    _setListeners() {
      F.on(this._element, Ts, (t2) => this._onInteraction(t2, true)), F.on(this._element, ks, (t2) => this._onInteraction(t2, false)), F.on(this._element, $s, (t2) => this._onInteraction(t2, true)), F.on(this._element, Ss, (t2) => this._onInteraction(t2, false));
    }
    _clearTimeout() {
      clearTimeout(this._timeout), this._timeout = null;
    }
    static jQueryInterface(t2) {
      return this.each(function() {
        const e2 = Fs.getOrCreateInstance(this, t2);
        if ("string" == typeof t2) {
          if (void 0 === e2[t2]) throw new TypeError(`No method named "${t2}"`);
          e2[t2](this);
        }
      });
    }
  }
  return Q(Fs), v(Fs), { Alert: G, Button: Z, Carousel: Nt, Collapse: Qt, Dropdown: be, Modal: Ze, Offcanvas: pi, Popover: Wi, ScrollSpy: ts, Tab: Es, Toast: Fs, Tooltip: Fi };
});
!(function(e, t) {
  "object" == typeof exports && "undefined" != typeof module ? t(exports) : "function" == typeof define && define.amd ? define(["exports"], t) : t((e = "undefined" != typeof globalThis ? globalThis : e || self).Popper = {});
})(this, (function(e) {
  "use strict";
  function t(e2) {
    if (null == e2) return window;
    if ("[object Window]" !== e2.toString()) {
      var t2 = e2.ownerDocument;
      return t2 && t2.defaultView || window;
    }
    return e2;
  }
  function n(e2) {
    return e2 instanceof t(e2).Element || e2 instanceof Element;
  }
  function r(e2) {
    return e2 instanceof t(e2).HTMLElement || e2 instanceof HTMLElement;
  }
  function o(e2) {
    return "undefined" != typeof ShadowRoot && (e2 instanceof t(e2).ShadowRoot || e2 instanceof ShadowRoot);
  }
  var i = Math.max, a = Math.min, s = Math.round;
  function f() {
    var e2 = navigator.userAgentData;
    return null != e2 && e2.brands && Array.isArray(e2.brands) ? e2.brands.map((function(e3) {
      return e3.brand + "/" + e3.version;
    })).join(" ") : navigator.userAgent;
  }
  function c() {
    return !/^((?!chrome|android).)*safari/i.test(f());
  }
  function p(e2, o2, i2) {
    void 0 === o2 && (o2 = false), void 0 === i2 && (i2 = false);
    var a2 = e2.getBoundingClientRect(), f2 = 1, p2 = 1;
    o2 && r(e2) && (f2 = e2.offsetWidth > 0 && s(a2.width) / e2.offsetWidth || 1, p2 = e2.offsetHeight > 0 && s(a2.height) / e2.offsetHeight || 1);
    var u2 = (n(e2) ? t(e2) : window).visualViewport, l2 = !c() && i2, d2 = (a2.left + (l2 && u2 ? u2.offsetLeft : 0)) / f2, h2 = (a2.top + (l2 && u2 ? u2.offsetTop : 0)) / p2, m2 = a2.width / f2, v2 = a2.height / p2;
    return { width: m2, height: v2, top: h2, right: d2 + m2, bottom: h2 + v2, left: d2, x: d2, y: h2 };
  }
  function u(e2) {
    var n2 = t(e2);
    return { scrollLeft: n2.pageXOffset, scrollTop: n2.pageYOffset };
  }
  function l(e2) {
    return e2 ? (e2.nodeName || "").toLowerCase() : null;
  }
  function d(e2) {
    return ((n(e2) ? e2.ownerDocument : e2.document) || window.document).documentElement;
  }
  function h(e2) {
    return p(d(e2)).left + u(e2).scrollLeft;
  }
  function m(e2) {
    return t(e2).getComputedStyle(e2);
  }
  function v(e2) {
    var t2 = m(e2), n2 = t2.overflow, r2 = t2.overflowX, o2 = t2.overflowY;
    return /auto|scroll|overlay|hidden/.test(n2 + o2 + r2);
  }
  function y(e2, n2, o2) {
    void 0 === o2 && (o2 = false);
    var i2, a2, f2 = r(n2), c2 = r(n2) && (function(e3) {
      var t2 = e3.getBoundingClientRect(), n3 = s(t2.width) / e3.offsetWidth || 1, r2 = s(t2.height) / e3.offsetHeight || 1;
      return 1 !== n3 || 1 !== r2;
    })(n2), m2 = d(n2), y2 = p(e2, c2, o2), g2 = { scrollLeft: 0, scrollTop: 0 }, b2 = { x: 0, y: 0 };
    return (f2 || !f2 && !o2) && (("body" !== l(n2) || v(m2)) && (g2 = (i2 = n2) !== t(i2) && r(i2) ? { scrollLeft: (a2 = i2).scrollLeft, scrollTop: a2.scrollTop } : u(i2)), r(n2) ? ((b2 = p(n2, true)).x += n2.clientLeft, b2.y += n2.clientTop) : m2 && (b2.x = h(m2))), { x: y2.left + g2.scrollLeft - b2.x, y: y2.top + g2.scrollTop - b2.y, width: y2.width, height: y2.height };
  }
  function g(e2) {
    var t2 = p(e2), n2 = e2.offsetWidth, r2 = e2.offsetHeight;
    return Math.abs(t2.width - n2) <= 1 && (n2 = t2.width), Math.abs(t2.height - r2) <= 1 && (r2 = t2.height), { x: e2.offsetLeft, y: e2.offsetTop, width: n2, height: r2 };
  }
  function b(e2) {
    return "html" === l(e2) ? e2 : e2.assignedSlot || e2.parentNode || (o(e2) ? e2.host : null) || d(e2);
  }
  function x(e2) {
    return ["html", "body", "#document"].indexOf(l(e2)) >= 0 ? e2.ownerDocument.body : r(e2) && v(e2) ? e2 : x(b(e2));
  }
  function w(e2, n2) {
    var r2;
    void 0 === n2 && (n2 = []);
    var o2 = x(e2), i2 = o2 === (null == (r2 = e2.ownerDocument) ? void 0 : r2.body), a2 = t(o2), s2 = i2 ? [a2].concat(a2.visualViewport || [], v(o2) ? o2 : []) : o2, f2 = n2.concat(s2);
    return i2 ? f2 : f2.concat(w(b(s2)));
  }
  function O(e2) {
    return ["table", "td", "th"].indexOf(l(e2)) >= 0;
  }
  function j(e2) {
    return r(e2) && "fixed" !== m(e2).position ? e2.offsetParent : null;
  }
  function E(e2) {
    for (var n2 = t(e2), i2 = j(e2); i2 && O(i2) && "static" === m(i2).position; ) i2 = j(i2);
    return i2 && ("html" === l(i2) || "body" === l(i2) && "static" === m(i2).position) ? n2 : i2 || (function(e3) {
      var t2 = /firefox/i.test(f());
      if (/Trident/i.test(f()) && r(e3) && "fixed" === m(e3).position) return null;
      var n3 = b(e3);
      for (o(n3) && (n3 = n3.host); r(n3) && ["html", "body"].indexOf(l(n3)) < 0; ) {
        var i3 = m(n3);
        if ("none" !== i3.transform || "none" !== i3.perspective || "paint" === i3.contain || -1 !== ["transform", "perspective"].indexOf(i3.willChange) || t2 && "filter" === i3.willChange || t2 && i3.filter && "none" !== i3.filter) return n3;
        n3 = n3.parentNode;
      }
      return null;
    })(e2) || n2;
  }
  var D = "top", A = "bottom", L = "right", P = "left", M = "auto", k = [D, A, L, P], W = "start", B = "end", H = "viewport", T = "popper", R = k.reduce((function(e2, t2) {
    return e2.concat([t2 + "-" + W, t2 + "-" + B]);
  }), []), S = [].concat(k, [M]).reduce((function(e2, t2) {
    return e2.concat([t2, t2 + "-" + W, t2 + "-" + B]);
  }), []), V = ["beforeRead", "read", "afterRead", "beforeMain", "main", "afterMain", "beforeWrite", "write", "afterWrite"];
  function q(e2) {
    var t2 = /* @__PURE__ */ new Map(), n2 = /* @__PURE__ */ new Set(), r2 = [];
    function o2(e3) {
      n2.add(e3.name), [].concat(e3.requires || [], e3.requiresIfExists || []).forEach((function(e4) {
        if (!n2.has(e4)) {
          var r3 = t2.get(e4);
          r3 && o2(r3);
        }
      })), r2.push(e3);
    }
    return e2.forEach((function(e3) {
      t2.set(e3.name, e3);
    })), e2.forEach((function(e3) {
      n2.has(e3.name) || o2(e3);
    })), r2;
  }
  function C(e2, t2) {
    var n2 = t2.getRootNode && t2.getRootNode();
    if (e2.contains(t2)) return true;
    if (n2 && o(n2)) {
      var r2 = t2;
      do {
        if (r2 && e2.isSameNode(r2)) return true;
        r2 = r2.parentNode || r2.host;
      } while (r2);
    }
    return false;
  }
  function N(e2) {
    return Object.assign({}, e2, { left: e2.x, top: e2.y, right: e2.x + e2.width, bottom: e2.y + e2.height });
  }
  function I(e2, r2, o2) {
    return r2 === H ? N((function(e3, n2) {
      var r3 = t(e3), o3 = d(e3), i2 = r3.visualViewport, a2 = o3.clientWidth, s2 = o3.clientHeight, f2 = 0, p2 = 0;
      if (i2) {
        a2 = i2.width, s2 = i2.height;
        var u2 = c();
        (u2 || !u2 && "fixed" === n2) && (f2 = i2.offsetLeft, p2 = i2.offsetTop);
      }
      return { width: a2, height: s2, x: f2 + h(e3), y: p2 };
    })(e2, o2)) : n(r2) ? (function(e3, t2) {
      var n2 = p(e3, false, "fixed" === t2);
      return n2.top = n2.top + e3.clientTop, n2.left = n2.left + e3.clientLeft, n2.bottom = n2.top + e3.clientHeight, n2.right = n2.left + e3.clientWidth, n2.width = e3.clientWidth, n2.height = e3.clientHeight, n2.x = n2.left, n2.y = n2.top, n2;
    })(r2, o2) : N((function(e3) {
      var t2, n2 = d(e3), r3 = u(e3), o3 = null == (t2 = e3.ownerDocument) ? void 0 : t2.body, a2 = i(n2.scrollWidth, n2.clientWidth, o3 ? o3.scrollWidth : 0, o3 ? o3.clientWidth : 0), s2 = i(n2.scrollHeight, n2.clientHeight, o3 ? o3.scrollHeight : 0, o3 ? o3.clientHeight : 0), f2 = -r3.scrollLeft + h(e3), c2 = -r3.scrollTop;
      return "rtl" === m(o3 || n2).direction && (f2 += i(n2.clientWidth, o3 ? o3.clientWidth : 0) - a2), { width: a2, height: s2, x: f2, y: c2 };
    })(d(e2)));
  }
  function _(e2, t2, o2, s2) {
    var f2 = "clippingParents" === t2 ? (function(e3) {
      var t3 = w(b(e3)), o3 = ["absolute", "fixed"].indexOf(m(e3).position) >= 0 && r(e3) ? E(e3) : e3;
      return n(o3) ? t3.filter((function(e4) {
        return n(e4) && C(e4, o3) && "body" !== l(e4);
      })) : [];
    })(e2) : [].concat(t2), c2 = [].concat(f2, [o2]), p2 = c2[0], u2 = c2.reduce((function(t3, n2) {
      var r2 = I(e2, n2, s2);
      return t3.top = i(r2.top, t3.top), t3.right = a(r2.right, t3.right), t3.bottom = a(r2.bottom, t3.bottom), t3.left = i(r2.left, t3.left), t3;
    }), I(e2, p2, s2));
    return u2.width = u2.right - u2.left, u2.height = u2.bottom - u2.top, u2.x = u2.left, u2.y = u2.top, u2;
  }
  function F(e2) {
    return e2.split("-")[0];
  }
  function U(e2) {
    return e2.split("-")[1];
  }
  function z(e2) {
    return ["top", "bottom"].indexOf(e2) >= 0 ? "x" : "y";
  }
  function X(e2) {
    var t2, n2 = e2.reference, r2 = e2.element, o2 = e2.placement, i2 = o2 ? F(o2) : null, a2 = o2 ? U(o2) : null, s2 = n2.x + n2.width / 2 - r2.width / 2, f2 = n2.y + n2.height / 2 - r2.height / 2;
    switch (i2) {
      case D:
        t2 = { x: s2, y: n2.y - r2.height };
        break;
      case A:
        t2 = { x: s2, y: n2.y + n2.height };
        break;
      case L:
        t2 = { x: n2.x + n2.width, y: f2 };
        break;
      case P:
        t2 = { x: n2.x - r2.width, y: f2 };
        break;
      default:
        t2 = { x: n2.x, y: n2.y };
    }
    var c2 = i2 ? z(i2) : null;
    if (null != c2) {
      var p2 = "y" === c2 ? "height" : "width";
      switch (a2) {
        case W:
          t2[c2] = t2[c2] - (n2[p2] / 2 - r2[p2] / 2);
          break;
        case B:
          t2[c2] = t2[c2] + (n2[p2] / 2 - r2[p2] / 2);
      }
    }
    return t2;
  }
  function Y(e2) {
    return Object.assign({}, { top: 0, right: 0, bottom: 0, left: 0 }, e2);
  }
  function G(e2, t2) {
    return t2.reduce((function(t3, n2) {
      return t3[n2] = e2, t3;
    }), {});
  }
  function J(e2, t2) {
    void 0 === t2 && (t2 = {});
    var r2 = t2, o2 = r2.placement, i2 = void 0 === o2 ? e2.placement : o2, a2 = r2.strategy, s2 = void 0 === a2 ? e2.strategy : a2, f2 = r2.boundary, c2 = void 0 === f2 ? "clippingParents" : f2, u2 = r2.rootBoundary, l2 = void 0 === u2 ? H : u2, h2 = r2.elementContext, m2 = void 0 === h2 ? T : h2, v2 = r2.altBoundary, y2 = void 0 !== v2 && v2, g2 = r2.padding, b2 = void 0 === g2 ? 0 : g2, x2 = Y("number" != typeof b2 ? b2 : G(b2, k)), w2 = m2 === T ? "reference" : T, O2 = e2.rects.popper, j2 = e2.elements[y2 ? w2 : m2], E2 = _(n(j2) ? j2 : j2.contextElement || d(e2.elements.popper), c2, l2, s2), P2 = p(e2.elements.reference), M2 = X({ reference: P2, element: O2, strategy: "absolute", placement: i2 }), W2 = N(Object.assign({}, O2, M2)), B2 = m2 === T ? W2 : P2, R2 = { top: E2.top - B2.top + x2.top, bottom: B2.bottom - E2.bottom + x2.bottom, left: E2.left - B2.left + x2.left, right: B2.right - E2.right + x2.right }, S2 = e2.modifiersData.offset;
    if (m2 === T && S2) {
      var V2 = S2[i2];
      Object.keys(R2).forEach((function(e3) {
        var t3 = [L, A].indexOf(e3) >= 0 ? 1 : -1, n2 = [D, A].indexOf(e3) >= 0 ? "y" : "x";
        R2[e3] += V2[n2] * t3;
      }));
    }
    return R2;
  }
  var K = { placement: "bottom", modifiers: [], strategy: "absolute" };
  function Q() {
    for (var e2 = arguments.length, t2 = new Array(e2), n2 = 0; n2 < e2; n2++) t2[n2] = arguments[n2];
    return !t2.some((function(e3) {
      return !(e3 && "function" == typeof e3.getBoundingClientRect);
    }));
  }
  function Z(e2) {
    void 0 === e2 && (e2 = {});
    var t2 = e2, r2 = t2.defaultModifiers, o2 = void 0 === r2 ? [] : r2, i2 = t2.defaultOptions, a2 = void 0 === i2 ? K : i2;
    return function(e3, t3, r3) {
      void 0 === r3 && (r3 = a2);
      var i3, s2, f2 = { placement: "bottom", orderedModifiers: [], options: Object.assign({}, K, a2), modifiersData: {}, elements: { reference: e3, popper: t3 }, attributes: {}, styles: {} }, c2 = [], p2 = false, u2 = { state: f2, setOptions: function(r4) {
        var i4 = "function" == typeof r4 ? r4(f2.options) : r4;
        l2(), f2.options = Object.assign({}, a2, f2.options, i4), f2.scrollParents = { reference: n(e3) ? w(e3) : e3.contextElement ? w(e3.contextElement) : [], popper: w(t3) };
        var s3, p3, d2 = (function(e4) {
          var t4 = q(e4);
          return V.reduce((function(e5, n2) {
            return e5.concat(t4.filter((function(e6) {
              return e6.phase === n2;
            })));
          }), []);
        })((s3 = [].concat(o2, f2.options.modifiers), p3 = s3.reduce((function(e4, t4) {
          var n2 = e4[t4.name];
          return e4[t4.name] = n2 ? Object.assign({}, n2, t4, { options: Object.assign({}, n2.options, t4.options), data: Object.assign({}, n2.data, t4.data) }) : t4, e4;
        }), {}), Object.keys(p3).map((function(e4) {
          return p3[e4];
        }))));
        return f2.orderedModifiers = d2.filter((function(e4) {
          return e4.enabled;
        })), f2.orderedModifiers.forEach((function(e4) {
          var t4 = e4.name, n2 = e4.options, r5 = void 0 === n2 ? {} : n2, o3 = e4.effect;
          if ("function" == typeof o3) {
            var i5 = o3({ state: f2, name: t4, instance: u2, options: r5 }), a3 = function() {
            };
            c2.push(i5 || a3);
          }
        })), u2.update();
      }, forceUpdate: function() {
        if (!p2) {
          var e4 = f2.elements, t4 = e4.reference, n2 = e4.popper;
          if (Q(t4, n2)) {
            f2.rects = { reference: y(t4, E(n2), "fixed" === f2.options.strategy), popper: g(n2) }, f2.reset = false, f2.placement = f2.options.placement, f2.orderedModifiers.forEach((function(e5) {
              return f2.modifiersData[e5.name] = Object.assign({}, e5.data);
            }));
            for (var r4 = 0; r4 < f2.orderedModifiers.length; r4++) if (true !== f2.reset) {
              var o3 = f2.orderedModifiers[r4], i4 = o3.fn, a3 = o3.options, s3 = void 0 === a3 ? {} : a3, c3 = o3.name;
              "function" == typeof i4 && (f2 = i4({ state: f2, options: s3, name: c3, instance: u2 }) || f2);
            } else f2.reset = false, r4 = -1;
          }
        }
      }, update: (i3 = function() {
        return new Promise((function(e4) {
          u2.forceUpdate(), e4(f2);
        }));
      }, function() {
        return s2 || (s2 = new Promise((function(e4) {
          Promise.resolve().then((function() {
            s2 = void 0, e4(i3());
          }));
        }))), s2;
      }), destroy: function() {
        l2(), p2 = true;
      } };
      if (!Q(e3, t3)) return u2;
      function l2() {
        c2.forEach((function(e4) {
          return e4();
        })), c2 = [];
      }
      return u2.setOptions(r3).then((function(e4) {
        !p2 && r3.onFirstUpdate && r3.onFirstUpdate(e4);
      })), u2;
    };
  }
  var $ = { passive: true };
  var ee = { name: "eventListeners", enabled: true, phase: "write", fn: function() {
  }, effect: function(e2) {
    var n2 = e2.state, r2 = e2.instance, o2 = e2.options, i2 = o2.scroll, a2 = void 0 === i2 || i2, s2 = o2.resize, f2 = void 0 === s2 || s2, c2 = t(n2.elements.popper), p2 = [].concat(n2.scrollParents.reference, n2.scrollParents.popper);
    return a2 && p2.forEach((function(e3) {
      e3.addEventListener("scroll", r2.update, $);
    })), f2 && c2.addEventListener("resize", r2.update, $), function() {
      a2 && p2.forEach((function(e3) {
        e3.removeEventListener("scroll", r2.update, $);
      })), f2 && c2.removeEventListener("resize", r2.update, $);
    };
  }, data: {} };
  var te = { name: "popperOffsets", enabled: true, phase: "read", fn: function(e2) {
    var t2 = e2.state, n2 = e2.name;
    t2.modifiersData[n2] = X({ reference: t2.rects.reference, element: t2.rects.popper, strategy: "absolute", placement: t2.placement });
  }, data: {} }, ne = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
  function re(e2) {
    var n2, r2 = e2.popper, o2 = e2.popperRect, i2 = e2.placement, a2 = e2.variation, f2 = e2.offsets, c2 = e2.position, p2 = e2.gpuAcceleration, u2 = e2.adaptive, l2 = e2.roundOffsets, h2 = e2.isFixed, v2 = f2.x, y2 = void 0 === v2 ? 0 : v2, g2 = f2.y, b2 = void 0 === g2 ? 0 : g2, x2 = "function" == typeof l2 ? l2({ x: y2, y: b2 }) : { x: y2, y: b2 };
    y2 = x2.x, b2 = x2.y;
    var w2 = f2.hasOwnProperty("x"), O2 = f2.hasOwnProperty("y"), j2 = P, M2 = D, k2 = window;
    if (u2) {
      var W2 = E(r2), H2 = "clientHeight", T2 = "clientWidth";
      if (W2 === t(r2) && "static" !== m(W2 = d(r2)).position && "absolute" === c2 && (H2 = "scrollHeight", T2 = "scrollWidth"), W2 = W2, i2 === D || (i2 === P || i2 === L) && a2 === B) M2 = A, b2 -= (h2 && W2 === k2 && k2.visualViewport ? k2.visualViewport.height : W2[H2]) - o2.height, b2 *= p2 ? 1 : -1;
      if (i2 === P || (i2 === D || i2 === A) && a2 === B) j2 = L, y2 -= (h2 && W2 === k2 && k2.visualViewport ? k2.visualViewport.width : W2[T2]) - o2.width, y2 *= p2 ? 1 : -1;
    }
    var R2, S2 = Object.assign({ position: c2 }, u2 && ne), V2 = true === l2 ? (function(e3, t2) {
      var n3 = e3.x, r3 = e3.y, o3 = t2.devicePixelRatio || 1;
      return { x: s(n3 * o3) / o3 || 0, y: s(r3 * o3) / o3 || 0 };
    })({ x: y2, y: b2 }, t(r2)) : { x: y2, y: b2 };
    return y2 = V2.x, b2 = V2.y, p2 ? Object.assign({}, S2, ((R2 = {})[M2] = O2 ? "0" : "", R2[j2] = w2 ? "0" : "", R2.transform = (k2.devicePixelRatio || 1) <= 1 ? "translate(" + y2 + "px, " + b2 + "px)" : "translate3d(" + y2 + "px, " + b2 + "px, 0)", R2)) : Object.assign({}, S2, ((n2 = {})[M2] = O2 ? b2 + "px" : "", n2[j2] = w2 ? y2 + "px" : "", n2.transform = "", n2));
  }
  var oe = { name: "computeStyles", enabled: true, phase: "beforeWrite", fn: function(e2) {
    var t2 = e2.state, n2 = e2.options, r2 = n2.gpuAcceleration, o2 = void 0 === r2 || r2, i2 = n2.adaptive, a2 = void 0 === i2 || i2, s2 = n2.roundOffsets, f2 = void 0 === s2 || s2, c2 = { placement: F(t2.placement), variation: U(t2.placement), popper: t2.elements.popper, popperRect: t2.rects.popper, gpuAcceleration: o2, isFixed: "fixed" === t2.options.strategy };
    null != t2.modifiersData.popperOffsets && (t2.styles.popper = Object.assign({}, t2.styles.popper, re(Object.assign({}, c2, { offsets: t2.modifiersData.popperOffsets, position: t2.options.strategy, adaptive: a2, roundOffsets: f2 })))), null != t2.modifiersData.arrow && (t2.styles.arrow = Object.assign({}, t2.styles.arrow, re(Object.assign({}, c2, { offsets: t2.modifiersData.arrow, position: "absolute", adaptive: false, roundOffsets: f2 })))), t2.attributes.popper = Object.assign({}, t2.attributes.popper, { "data-popper-placement": t2.placement });
  }, data: {} };
  var ie = { name: "applyStyles", enabled: true, phase: "write", fn: function(e2) {
    var t2 = e2.state;
    Object.keys(t2.elements).forEach((function(e3) {
      var n2 = t2.styles[e3] || {}, o2 = t2.attributes[e3] || {}, i2 = t2.elements[e3];
      r(i2) && l(i2) && (Object.assign(i2.style, n2), Object.keys(o2).forEach((function(e4) {
        var t3 = o2[e4];
        false === t3 ? i2.removeAttribute(e4) : i2.setAttribute(e4, true === t3 ? "" : t3);
      })));
    }));
  }, effect: function(e2) {
    var t2 = e2.state, n2 = { popper: { position: t2.options.strategy, left: "0", top: "0", margin: "0" }, arrow: { position: "absolute" }, reference: {} };
    return Object.assign(t2.elements.popper.style, n2.popper), t2.styles = n2, t2.elements.arrow && Object.assign(t2.elements.arrow.style, n2.arrow), function() {
      Object.keys(t2.elements).forEach((function(e3) {
        var o2 = t2.elements[e3], i2 = t2.attributes[e3] || {}, a2 = Object.keys(t2.styles.hasOwnProperty(e3) ? t2.styles[e3] : n2[e3]).reduce((function(e4, t3) {
          return e4[t3] = "", e4;
        }), {});
        r(o2) && l(o2) && (Object.assign(o2.style, a2), Object.keys(i2).forEach((function(e4) {
          o2.removeAttribute(e4);
        })));
      }));
    };
  }, requires: ["computeStyles"] };
  var ae = { name: "offset", enabled: true, phase: "main", requires: ["popperOffsets"], fn: function(e2) {
    var t2 = e2.state, n2 = e2.options, r2 = e2.name, o2 = n2.offset, i2 = void 0 === o2 ? [0, 0] : o2, a2 = S.reduce((function(e3, n3) {
      return e3[n3] = (function(e4, t3, n4) {
        var r3 = F(e4), o3 = [P, D].indexOf(r3) >= 0 ? -1 : 1, i3 = "function" == typeof n4 ? n4(Object.assign({}, t3, { placement: e4 })) : n4, a3 = i3[0], s3 = i3[1];
        return a3 = a3 || 0, s3 = (s3 || 0) * o3, [P, L].indexOf(r3) >= 0 ? { x: s3, y: a3 } : { x: a3, y: s3 };
      })(n3, t2.rects, i2), e3;
    }), {}), s2 = a2[t2.placement], f2 = s2.x, c2 = s2.y;
    null != t2.modifiersData.popperOffsets && (t2.modifiersData.popperOffsets.x += f2, t2.modifiersData.popperOffsets.y += c2), t2.modifiersData[r2] = a2;
  } }, se = { left: "right", right: "left", bottom: "top", top: "bottom" };
  function fe(e2) {
    return e2.replace(/left|right|bottom|top/g, (function(e3) {
      return se[e3];
    }));
  }
  var ce = { start: "end", end: "start" };
  function pe(e2) {
    return e2.replace(/start|end/g, (function(e3) {
      return ce[e3];
    }));
  }
  function ue(e2, t2) {
    void 0 === t2 && (t2 = {});
    var n2 = t2, r2 = n2.placement, o2 = n2.boundary, i2 = n2.rootBoundary, a2 = n2.padding, s2 = n2.flipVariations, f2 = n2.allowedAutoPlacements, c2 = void 0 === f2 ? S : f2, p2 = U(r2), u2 = p2 ? s2 ? R : R.filter((function(e3) {
      return U(e3) === p2;
    })) : k, l2 = u2.filter((function(e3) {
      return c2.indexOf(e3) >= 0;
    }));
    0 === l2.length && (l2 = u2);
    var d2 = l2.reduce((function(t3, n3) {
      return t3[n3] = J(e2, { placement: n3, boundary: o2, rootBoundary: i2, padding: a2 })[F(n3)], t3;
    }), {});
    return Object.keys(d2).sort((function(e3, t3) {
      return d2[e3] - d2[t3];
    }));
  }
  var le = { name: "flip", enabled: true, phase: "main", fn: function(e2) {
    var t2 = e2.state, n2 = e2.options, r2 = e2.name;
    if (!t2.modifiersData[r2]._skip) {
      for (var o2 = n2.mainAxis, i2 = void 0 === o2 || o2, a2 = n2.altAxis, s2 = void 0 === a2 || a2, f2 = n2.fallbackPlacements, c2 = n2.padding, p2 = n2.boundary, u2 = n2.rootBoundary, l2 = n2.altBoundary, d2 = n2.flipVariations, h2 = void 0 === d2 || d2, m2 = n2.allowedAutoPlacements, v2 = t2.options.placement, y2 = F(v2), g2 = f2 || (y2 === v2 || !h2 ? [fe(v2)] : (function(e3) {
        if (F(e3) === M) return [];
        var t3 = fe(e3);
        return [pe(e3), t3, pe(t3)];
      })(v2)), b2 = [v2].concat(g2).reduce((function(e3, n3) {
        return e3.concat(F(n3) === M ? ue(t2, { placement: n3, boundary: p2, rootBoundary: u2, padding: c2, flipVariations: h2, allowedAutoPlacements: m2 }) : n3);
      }), []), x2 = t2.rects.reference, w2 = t2.rects.popper, O2 = /* @__PURE__ */ new Map(), j2 = true, E2 = b2[0], k2 = 0; k2 < b2.length; k2++) {
        var B2 = b2[k2], H2 = F(B2), T2 = U(B2) === W, R2 = [D, A].indexOf(H2) >= 0, S2 = R2 ? "width" : "height", V2 = J(t2, { placement: B2, boundary: p2, rootBoundary: u2, altBoundary: l2, padding: c2 }), q2 = R2 ? T2 ? L : P : T2 ? A : D;
        x2[S2] > w2[S2] && (q2 = fe(q2));
        var C2 = fe(q2), N2 = [];
        if (i2 && N2.push(V2[H2] <= 0), s2 && N2.push(V2[q2] <= 0, V2[C2] <= 0), N2.every((function(e3) {
          return e3;
        }))) {
          E2 = B2, j2 = false;
          break;
        }
        O2.set(B2, N2);
      }
      if (j2) for (var I2 = function(e3) {
        var t3 = b2.find((function(t4) {
          var n3 = O2.get(t4);
          if (n3) return n3.slice(0, e3).every((function(e4) {
            return e4;
          }));
        }));
        if (t3) return E2 = t3, "break";
      }, _2 = h2 ? 3 : 1; _2 > 0; _2--) {
        if ("break" === I2(_2)) break;
      }
      t2.placement !== E2 && (t2.modifiersData[r2]._skip = true, t2.placement = E2, t2.reset = true);
    }
  }, requiresIfExists: ["offset"], data: { _skip: false } };
  function de(e2, t2, n2) {
    return i(e2, a(t2, n2));
  }
  var he = { name: "preventOverflow", enabled: true, phase: "main", fn: function(e2) {
    var t2 = e2.state, n2 = e2.options, r2 = e2.name, o2 = n2.mainAxis, s2 = void 0 === o2 || o2, f2 = n2.altAxis, c2 = void 0 !== f2 && f2, p2 = n2.boundary, u2 = n2.rootBoundary, l2 = n2.altBoundary, d2 = n2.padding, h2 = n2.tether, m2 = void 0 === h2 || h2, v2 = n2.tetherOffset, y2 = void 0 === v2 ? 0 : v2, b2 = J(t2, { boundary: p2, rootBoundary: u2, padding: d2, altBoundary: l2 }), x2 = F(t2.placement), w2 = U(t2.placement), O2 = !w2, j2 = z(x2), M2 = "x" === j2 ? "y" : "x", k2 = t2.modifiersData.popperOffsets, B2 = t2.rects.reference, H2 = t2.rects.popper, T2 = "function" == typeof y2 ? y2(Object.assign({}, t2.rects, { placement: t2.placement })) : y2, R2 = "number" == typeof T2 ? { mainAxis: T2, altAxis: T2 } : Object.assign({ mainAxis: 0, altAxis: 0 }, T2), S2 = t2.modifiersData.offset ? t2.modifiersData.offset[t2.placement] : null, V2 = { x: 0, y: 0 };
    if (k2) {
      if (s2) {
        var q2, C2 = "y" === j2 ? D : P, N2 = "y" === j2 ? A : L, I2 = "y" === j2 ? "height" : "width", _2 = k2[j2], X2 = _2 + b2[C2], Y2 = _2 - b2[N2], G2 = m2 ? -H2[I2] / 2 : 0, K2 = w2 === W ? B2[I2] : H2[I2], Q2 = w2 === W ? -H2[I2] : -B2[I2], Z2 = t2.elements.arrow, $2 = m2 && Z2 ? g(Z2) : { width: 0, height: 0 }, ee2 = t2.modifiersData["arrow#persistent"] ? t2.modifiersData["arrow#persistent"].padding : { top: 0, right: 0, bottom: 0, left: 0 }, te2 = ee2[C2], ne2 = ee2[N2], re2 = de(0, B2[I2], $2[I2]), oe2 = O2 ? B2[I2] / 2 - G2 - re2 - te2 - R2.mainAxis : K2 - re2 - te2 - R2.mainAxis, ie2 = O2 ? -B2[I2] / 2 + G2 + re2 + ne2 + R2.mainAxis : Q2 + re2 + ne2 + R2.mainAxis, ae2 = t2.elements.arrow && E(t2.elements.arrow), se2 = ae2 ? "y" === j2 ? ae2.clientTop || 0 : ae2.clientLeft || 0 : 0, fe2 = null != (q2 = null == S2 ? void 0 : S2[j2]) ? q2 : 0, ce2 = _2 + ie2 - fe2, pe2 = de(m2 ? a(X2, _2 + oe2 - fe2 - se2) : X2, _2, m2 ? i(Y2, ce2) : Y2);
        k2[j2] = pe2, V2[j2] = pe2 - _2;
      }
      if (c2) {
        var ue2, le2 = "x" === j2 ? D : P, he2 = "x" === j2 ? A : L, me2 = k2[M2], ve2 = "y" === M2 ? "height" : "width", ye2 = me2 + b2[le2], ge2 = me2 - b2[he2], be2 = -1 !== [D, P].indexOf(x2), xe2 = null != (ue2 = null == S2 ? void 0 : S2[M2]) ? ue2 : 0, we2 = be2 ? ye2 : me2 - B2[ve2] - H2[ve2] - xe2 + R2.altAxis, Oe = be2 ? me2 + B2[ve2] + H2[ve2] - xe2 - R2.altAxis : ge2, je = m2 && be2 ? (function(e3, t3, n3) {
          var r3 = de(e3, t3, n3);
          return r3 > n3 ? n3 : r3;
        })(we2, me2, Oe) : de(m2 ? we2 : ye2, me2, m2 ? Oe : ge2);
        k2[M2] = je, V2[M2] = je - me2;
      }
      t2.modifiersData[r2] = V2;
    }
  }, requiresIfExists: ["offset"] };
  var me = { name: "arrow", enabled: true, phase: "main", fn: function(e2) {
    var t2, n2 = e2.state, r2 = e2.name, o2 = e2.options, i2 = n2.elements.arrow, a2 = n2.modifiersData.popperOffsets, s2 = F(n2.placement), f2 = z(s2), c2 = [P, L].indexOf(s2) >= 0 ? "height" : "width";
    if (i2 && a2) {
      var p2 = (function(e3, t3) {
        return Y("number" != typeof (e3 = "function" == typeof e3 ? e3(Object.assign({}, t3.rects, { placement: t3.placement })) : e3) ? e3 : G(e3, k));
      })(o2.padding, n2), u2 = g(i2), l2 = "y" === f2 ? D : P, d2 = "y" === f2 ? A : L, h2 = n2.rects.reference[c2] + n2.rects.reference[f2] - a2[f2] - n2.rects.popper[c2], m2 = a2[f2] - n2.rects.reference[f2], v2 = E(i2), y2 = v2 ? "y" === f2 ? v2.clientHeight || 0 : v2.clientWidth || 0 : 0, b2 = h2 / 2 - m2 / 2, x2 = p2[l2], w2 = y2 - u2[c2] - p2[d2], O2 = y2 / 2 - u2[c2] / 2 + b2, j2 = de(x2, O2, w2), M2 = f2;
      n2.modifiersData[r2] = ((t2 = {})[M2] = j2, t2.centerOffset = j2 - O2, t2);
    }
  }, effect: function(e2) {
    var t2 = e2.state, n2 = e2.options.element, r2 = void 0 === n2 ? "[data-popper-arrow]" : n2;
    null != r2 && ("string" != typeof r2 || (r2 = t2.elements.popper.querySelector(r2))) && C(t2.elements.popper, r2) && (t2.elements.arrow = r2);
  }, requires: ["popperOffsets"], requiresIfExists: ["preventOverflow"] };
  function ve(e2, t2, n2) {
    return void 0 === n2 && (n2 = { x: 0, y: 0 }), { top: e2.top - t2.height - n2.y, right: e2.right - t2.width + n2.x, bottom: e2.bottom - t2.height + n2.y, left: e2.left - t2.width - n2.x };
  }
  function ye(e2) {
    return [D, L, A, P].some((function(t2) {
      return e2[t2] >= 0;
    }));
  }
  var ge = { name: "hide", enabled: true, phase: "main", requiresIfExists: ["preventOverflow"], fn: function(e2) {
    var t2 = e2.state, n2 = e2.name, r2 = t2.rects.reference, o2 = t2.rects.popper, i2 = t2.modifiersData.preventOverflow, a2 = J(t2, { elementContext: "reference" }), s2 = J(t2, { altBoundary: true }), f2 = ve(a2, r2), c2 = ve(s2, o2, i2), p2 = ye(f2), u2 = ye(c2);
    t2.modifiersData[n2] = { referenceClippingOffsets: f2, popperEscapeOffsets: c2, isReferenceHidden: p2, hasPopperEscaped: u2 }, t2.attributes.popper = Object.assign({}, t2.attributes.popper, { "data-popper-reference-hidden": p2, "data-popper-escaped": u2 });
  } }, be = Z({ defaultModifiers: [ee, te, oe, ie] }), xe = [ee, te, oe, ie, ae, le, he, me, ge], we = Z({ defaultModifiers: xe });
  e.applyStyles = ie, e.arrow = me, e.computeStyles = oe, e.createPopper = we, e.createPopperLite = be, e.defaultModifiers = xe, e.detectOverflow = J, e.eventListeners = ee, e.flip = le, e.hide = ge, e.offset = ae, e.popperGenerator = Z, e.popperOffsets = te, e.preventOverflow = he, Object.defineProperty(e, "__esModule", { value: true });
}));


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuZ3VsYXI6c2NyaXB0L2dsb2JhbDpzY3JpcHRzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICAqIEJvb3RzdHJhcCB2NS4zLjggKGh0dHBzOi8vZ2V0Ym9vdHN0cmFwLmNvbS8pXG4gICogQ29weXJpZ2h0IDIwMTEtMjAyNSBUaGUgQm9vdHN0cmFwIEF1dGhvcnMgKGh0dHBzOi8vZ2l0aHViLmNvbS90d2JzL2Jvb3RzdHJhcC9ncmFwaHMvY29udHJpYnV0b3JzKVxuICAqIExpY2Vuc2VkIHVuZGVyIE1JVCAoaHR0cHM6Ly9naXRodWIuY29tL3R3YnMvYm9vdHN0cmFwL2Jsb2IvbWFpbi9MSUNFTlNFKVxuICAqL1xuIWZ1bmN0aW9uKHQsZSl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9ZShyZXF1aXJlKFwiQHBvcHBlcmpzL2NvcmVcIikpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoW1wiQHBvcHBlcmpzL2NvcmVcIl0sZSk6KHQ9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbFRoaXM/Z2xvYmFsVGhpczp0fHxzZWxmKS5ib290c3RyYXA9ZSh0LlBvcHBlcil9KHRoaXMsZnVuY3Rpb24odCl7XCJ1c2Ugc3RyaWN0XCI7ZnVuY3Rpb24gZSh0KXtjb25zdCBlPU9iamVjdC5jcmVhdGUobnVsbCx7W1N5bWJvbC50b1N0cmluZ1RhZ106e3ZhbHVlOlwiTW9kdWxlXCJ9fSk7aWYodClmb3IoY29uc3QgaSBpbiB0KWlmKFwiZGVmYXVsdFwiIT09aSl7Y29uc3Qgcz1PYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsaSk7T2JqZWN0LmRlZmluZVByb3BlcnR5KGUsaSxzLmdldD9zOntlbnVtZXJhYmxlOiEwLGdldDooKT0+dFtpXX0pfXJldHVybiBlLmRlZmF1bHQ9dCxPYmplY3QuZnJlZXplKGUpfWNvbnN0IGk9ZSh0KSxzPW5ldyBNYXAsbj17c2V0KHQsZSxpKXtzLmhhcyh0KXx8cy5zZXQodCxuZXcgTWFwKTtjb25zdCBuPXMuZ2V0KHQpO24uaGFzKGUpfHwwPT09bi5zaXplP24uc2V0KGUsaSk6Y29uc29sZS5lcnJvcihgQm9vdHN0cmFwIGRvZXNuJ3QgYWxsb3cgbW9yZSB0aGFuIG9uZSBpbnN0YW5jZSBwZXIgZWxlbWVudC4gQm91bmQgaW5zdGFuY2U6ICR7QXJyYXkuZnJvbShuLmtleXMoKSlbMF19LmApfSxnZXQ6KHQsZSk9PnMuaGFzKHQpJiZzLmdldCh0KS5nZXQoZSl8fG51bGwscmVtb3ZlKHQsZSl7aWYoIXMuaGFzKHQpKXJldHVybjtjb25zdCBpPXMuZ2V0KHQpO2kuZGVsZXRlKGUpLDA9PT1pLnNpemUmJnMuZGVsZXRlKHQpfX0sbz1cInRyYW5zaXRpb25lbmRcIixyPXQ9Pih0JiZ3aW5kb3cuQ1NTJiZ3aW5kb3cuQ1NTLmVzY2FwZSYmKHQ9dC5yZXBsYWNlKC8jKFteXFxzXCIjJ10rKS9nLCh0LGUpPT5gIyR7Q1NTLmVzY2FwZShlKX1gKSksdCksYT10PT5udWxsPT10P2Ake3R9YDpPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodCkubWF0Y2goL1xccyhbYS16XSspL2kpWzFdLnRvTG93ZXJDYXNlKCksbD10PT57dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChvKSl9LGM9dD0+ISghdHx8XCJvYmplY3RcIiE9dHlwZW9mIHQpJiYodm9pZCAwIT09dC5qcXVlcnkmJih0PXRbMF0pLHZvaWQgMCE9PXQubm9kZVR5cGUpLGg9dD0+Yyh0KT90LmpxdWVyeT90WzBdOnQ6XCJzdHJpbmdcIj09dHlwZW9mIHQmJnQubGVuZ3RoPjA/ZG9jdW1lbnQucXVlcnlTZWxlY3RvcihyKHQpKTpudWxsLGQ9dD0+e2lmKCFjKHQpfHwwPT09dC5nZXRDbGllbnRSZWN0cygpLmxlbmd0aClyZXR1cm4hMTtjb25zdCBlPVwidmlzaWJsZVwiPT09Z2V0Q29tcHV0ZWRTdHlsZSh0KS5nZXRQcm9wZXJ0eVZhbHVlKFwidmlzaWJpbGl0eVwiKSxpPXQuY2xvc2VzdChcImRldGFpbHM6bm90KFtvcGVuXSlcIik7aWYoIWkpcmV0dXJuIGU7aWYoaSE9PXQpe2NvbnN0IGU9dC5jbG9zZXN0KFwic3VtbWFyeVwiKTtpZihlJiZlLnBhcmVudE5vZGUhPT1pKXJldHVybiExO2lmKG51bGw9PT1lKXJldHVybiExfXJldHVybiBlfSx1PXQ9PiF0fHx0Lm5vZGVUeXBlIT09Tm9kZS5FTEVNRU5UX05PREV8fCEhdC5jbGFzc0xpc3QuY29udGFpbnMoXCJkaXNhYmxlZFwiKXx8KHZvaWQgMCE9PXQuZGlzYWJsZWQ/dC5kaXNhYmxlZDp0Lmhhc0F0dHJpYnV0ZShcImRpc2FibGVkXCIpJiZcImZhbHNlXCIhPT10LmdldEF0dHJpYnV0ZShcImRpc2FibGVkXCIpKSxfPXQ9PntpZighZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmF0dGFjaFNoYWRvdylyZXR1cm4gbnVsbDtpZihcImZ1bmN0aW9uXCI9PXR5cGVvZiB0LmdldFJvb3ROb2RlKXtjb25zdCBlPXQuZ2V0Um9vdE5vZGUoKTtyZXR1cm4gZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3Q/ZTpudWxsfXJldHVybiB0IGluc3RhbmNlb2YgU2hhZG93Um9vdD90OnQucGFyZW50Tm9kZT9fKHQucGFyZW50Tm9kZSk6bnVsbH0sZz0oKT0+e30sZj10PT57dC5vZmZzZXRIZWlnaHR9LG09KCk9PndpbmRvdy5qUXVlcnkmJiFkb2N1bWVudC5ib2R5Lmhhc0F0dHJpYnV0ZShcImRhdGEtYnMtbm8tanF1ZXJ5XCIpP3dpbmRvdy5qUXVlcnk6bnVsbCxwPVtdLGI9KCk9PlwicnRsXCI9PT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGlyLHY9dD0+e3ZhciBlO2U9KCk9Pntjb25zdCBlPW0oKTtpZihlKXtjb25zdCBpPXQuTkFNRSxzPWUuZm5baV07ZS5mbltpXT10LmpRdWVyeUludGVyZmFjZSxlLmZuW2ldLkNvbnN0cnVjdG9yPXQsZS5mbltpXS5ub0NvbmZsaWN0PSgpPT4oZS5mbltpXT1zLHQualF1ZXJ5SW50ZXJmYWNlKX19LFwibG9hZGluZ1wiPT09ZG9jdW1lbnQucmVhZHlTdGF0ZT8ocC5sZW5ndGh8fGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsKCk9Pntmb3IoY29uc3QgdCBvZiBwKXQoKX0pLHAucHVzaChlKSk6ZSgpfSx5PSh0LGU9W10saT10KT0+XCJmdW5jdGlvblwiPT10eXBlb2YgdD90LmNhbGwoLi4uZSk6aSx3PSh0LGUsaT0hMCk9PntpZighaSlyZXR1cm4gdm9pZCB5KHQpO2NvbnN0IHM9KHQ9PntpZighdClyZXR1cm4gMDtsZXR7dHJhbnNpdGlvbkR1cmF0aW9uOmUsdHJhbnNpdGlvbkRlbGF5Oml9PXdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHQpO2NvbnN0IHM9TnVtYmVyLnBhcnNlRmxvYXQoZSksbj1OdW1iZXIucGFyc2VGbG9hdChpKTtyZXR1cm4gc3x8bj8oZT1lLnNwbGl0KFwiLFwiKVswXSxpPWkuc3BsaXQoXCIsXCIpWzBdLDFlMyooTnVtYmVyLnBhcnNlRmxvYXQoZSkrTnVtYmVyLnBhcnNlRmxvYXQoaSkpKTowfSkoZSkrNTtsZXQgbj0hMTtjb25zdCByPSh7dGFyZ2V0Oml9KT0+e2k9PT1lJiYobj0hMCxlLnJlbW92ZUV2ZW50TGlzdGVuZXIobyxyKSx5KHQpKX07ZS5hZGRFdmVudExpc3RlbmVyKG8sciksc2V0VGltZW91dCgoKT0+e258fGwoZSl9LHMpfSxBPSh0LGUsaSxzKT0+e2NvbnN0IG49dC5sZW5ndGg7bGV0IG89dC5pbmRleE9mKGUpO3JldHVybi0xPT09bz8haSYmcz90W24tMV06dFswXToobys9aT8xOi0xLHMmJihvPShvK24pJW4pLHRbTWF0aC5tYXgoMCxNYXRoLm1pbihvLG4tMSkpXSl9LEU9L1teLl0qKD89XFwuLiopXFwufC4qLyxDPS9cXC4uKi8sVD0vOjpcXGQrJC8saz17fTtsZXQgJD0xO2NvbnN0IFM9e21vdXNlZW50ZXI6XCJtb3VzZW92ZXJcIixtb3VzZWxlYXZlOlwibW91c2VvdXRcIn0sTD1uZXcgU2V0KFtcImNsaWNrXCIsXCJkYmxjbGlja1wiLFwibW91c2V1cFwiLFwibW91c2Vkb3duXCIsXCJjb250ZXh0bWVudVwiLFwibW91c2V3aGVlbFwiLFwiRE9NTW91c2VTY3JvbGxcIixcIm1vdXNlb3ZlclwiLFwibW91c2VvdXRcIixcIm1vdXNlbW92ZVwiLFwic2VsZWN0c3RhcnRcIixcInNlbGVjdGVuZFwiLFwia2V5ZG93blwiLFwia2V5cHJlc3NcIixcImtleXVwXCIsXCJvcmllbnRhdGlvbmNoYW5nZVwiLFwidG91Y2hzdGFydFwiLFwidG91Y2htb3ZlXCIsXCJ0b3VjaGVuZFwiLFwidG91Y2hjYW5jZWxcIixcInBvaW50ZXJkb3duXCIsXCJwb2ludGVybW92ZVwiLFwicG9pbnRlcnVwXCIsXCJwb2ludGVybGVhdmVcIixcInBvaW50ZXJjYW5jZWxcIixcImdlc3R1cmVzdGFydFwiLFwiZ2VzdHVyZWNoYW5nZVwiLFwiZ2VzdHVyZWVuZFwiLFwiZm9jdXNcIixcImJsdXJcIixcImNoYW5nZVwiLFwicmVzZXRcIixcInNlbGVjdFwiLFwic3VibWl0XCIsXCJmb2N1c2luXCIsXCJmb2N1c291dFwiLFwibG9hZFwiLFwidW5sb2FkXCIsXCJiZWZvcmV1bmxvYWRcIixcInJlc2l6ZVwiLFwibW92ZVwiLFwiRE9NQ29udGVudExvYWRlZFwiLFwicmVhZHlzdGF0ZWNoYW5nZVwiLFwiZXJyb3JcIixcImFib3J0XCIsXCJzY3JvbGxcIl0pO2Z1bmN0aW9uIE8odCxlKXtyZXR1cm4gZSYmYCR7ZX06OiR7JCsrfWB8fHQudWlkRXZlbnR8fCQrK31mdW5jdGlvbiBJKHQpe2NvbnN0IGU9Tyh0KTtyZXR1cm4gdC51aWRFdmVudD1lLGtbZV09a1tlXXx8e30sa1tlXX1mdW5jdGlvbiBEKHQsZSxpPW51bGwpe3JldHVybiBPYmplY3QudmFsdWVzKHQpLmZpbmQodD0+dC5jYWxsYWJsZT09PWUmJnQuZGVsZWdhdGlvblNlbGVjdG9yPT09aSl9ZnVuY3Rpb24gTih0LGUsaSl7Y29uc3Qgcz1cInN0cmluZ1wiPT10eXBlb2YgZSxuPXM/aTplfHxpO2xldCBvPWoodCk7cmV0dXJuIEwuaGFzKG8pfHwobz10KSxbcyxuLG9dfWZ1bmN0aW9uIFAodCxlLGkscyxuKXtpZihcInN0cmluZ1wiIT10eXBlb2YgZXx8IXQpcmV0dXJuO2xldFtvLHIsYV09TihlLGkscyk7aWYoZSBpbiBTKXtjb25zdCB0PXQ9PmZ1bmN0aW9uKGUpe2lmKCFlLnJlbGF0ZWRUYXJnZXR8fGUucmVsYXRlZFRhcmdldCE9PWUuZGVsZWdhdGVUYXJnZXQmJiFlLmRlbGVnYXRlVGFyZ2V0LmNvbnRhaW5zKGUucmVsYXRlZFRhcmdldCkpcmV0dXJuIHQuY2FsbCh0aGlzLGUpfTtyPXQocil9Y29uc3QgbD1JKHQpLGM9bFthXXx8KGxbYV09e30pLGg9RChjLHIsbz9pOm51bGwpO2lmKGgpcmV0dXJuIHZvaWQoaC5vbmVPZmY9aC5vbmVPZmYmJm4pO2NvbnN0IGQ9TyhyLGUucmVwbGFjZShFLFwiXCIpKSx1PW8/ZnVuY3Rpb24odCxlLGkpe3JldHVybiBmdW5jdGlvbiBzKG4pe2NvbnN0IG89dC5xdWVyeVNlbGVjdG9yQWxsKGUpO2ZvcihsZXR7dGFyZ2V0OnJ9PW47ciYmciE9PXRoaXM7cj1yLnBhcmVudE5vZGUpZm9yKGNvbnN0IGEgb2YgbylpZihhPT09cilyZXR1cm4geihuLHtkZWxlZ2F0ZVRhcmdldDpyfSkscy5vbmVPZmYmJkYub2ZmKHQsbi50eXBlLGUsaSksaS5hcHBseShyLFtuXSl9fSh0LGkscik6ZnVuY3Rpb24odCxlKXtyZXR1cm4gZnVuY3Rpb24gaShzKXtyZXR1cm4geihzLHtkZWxlZ2F0ZVRhcmdldDp0fSksaS5vbmVPZmYmJkYub2ZmKHQscy50eXBlLGUpLGUuYXBwbHkodCxbc10pfX0odCxyKTt1LmRlbGVnYXRpb25TZWxlY3Rvcj1vP2k6bnVsbCx1LmNhbGxhYmxlPXIsdS5vbmVPZmY9bix1LnVpZEV2ZW50PWQsY1tkXT11LHQuYWRkRXZlbnRMaXN0ZW5lcihhLHUsbyl9ZnVuY3Rpb24geCh0LGUsaSxzLG4pe2NvbnN0IG89RChlW2ldLHMsbik7byYmKHQucmVtb3ZlRXZlbnRMaXN0ZW5lcihpLG8sQm9vbGVhbihuKSksZGVsZXRlIGVbaV1bby51aWRFdmVudF0pfWZ1bmN0aW9uIE0odCxlLGkscyl7Y29uc3Qgbj1lW2ldfHx7fTtmb3IoY29uc3RbbyxyXW9mIE9iamVjdC5lbnRyaWVzKG4pKW8uaW5jbHVkZXMocykmJngodCxlLGksci5jYWxsYWJsZSxyLmRlbGVnYXRpb25TZWxlY3Rvcil9ZnVuY3Rpb24gaih0KXtyZXR1cm4gdD10LnJlcGxhY2UoQyxcIlwiKSxTW3RdfHx0fWNvbnN0IEY9e29uKHQsZSxpLHMpe1AodCxlLGkscywhMSl9LG9uZSh0LGUsaSxzKXtQKHQsZSxpLHMsITApfSxvZmYodCxlLGkscyl7aWYoXCJzdHJpbmdcIiE9dHlwZW9mIGV8fCF0KXJldHVybjtjb25zdFtuLG8scl09TihlLGkscyksYT1yIT09ZSxsPUkodCksYz1sW3JdfHx7fSxoPWUuc3RhcnRzV2l0aChcIi5cIik7aWYodm9pZCAwPT09byl7aWYoaClmb3IoY29uc3QgaSBvZiBPYmplY3Qua2V5cyhsKSlNKHQsbCxpLGUuc2xpY2UoMSkpO2Zvcihjb25zdFtpLHNdb2YgT2JqZWN0LmVudHJpZXMoYykpe2NvbnN0IG49aS5yZXBsYWNlKFQsXCJcIik7YSYmIWUuaW5jbHVkZXMobil8fHgodCxsLHIscy5jYWxsYWJsZSxzLmRlbGVnYXRpb25TZWxlY3Rvcil9fWVsc2V7aWYoIU9iamVjdC5rZXlzKGMpLmxlbmd0aClyZXR1cm47eCh0LGwscixvLG4/aTpudWxsKX19LHRyaWdnZXIodCxlLGkpe2lmKFwic3RyaW5nXCIhPXR5cGVvZiBlfHwhdClyZXR1cm4gbnVsbDtjb25zdCBzPW0oKTtsZXQgbj1udWxsLG89ITAscj0hMCxhPSExO2UhPT1qKGUpJiZzJiYobj1zLkV2ZW50KGUsaSkscyh0KS50cmlnZ2VyKG4pLG89IW4uaXNQcm9wYWdhdGlvblN0b3BwZWQoKSxyPSFuLmlzSW1tZWRpYXRlUHJvcGFnYXRpb25TdG9wcGVkKCksYT1uLmlzRGVmYXVsdFByZXZlbnRlZCgpKTtjb25zdCBsPXoobmV3IEV2ZW50KGUse2J1YmJsZXM6byxjYW5jZWxhYmxlOiEwfSksaSk7cmV0dXJuIGEmJmwucHJldmVudERlZmF1bHQoKSxyJiZ0LmRpc3BhdGNoRXZlbnQobCksbC5kZWZhdWx0UHJldmVudGVkJiZuJiZuLnByZXZlbnREZWZhdWx0KCksbH19O2Z1bmN0aW9uIHoodCxlPXt9KXtmb3IoY29uc3RbaSxzXW9mIE9iamVjdC5lbnRyaWVzKGUpKXRyeXt0W2ldPXN9Y2F0Y2goZSl7T2JqZWN0LmRlZmluZVByb3BlcnR5KHQsaSx7Y29uZmlndXJhYmxlOiEwLGdldDooKT0+c30pfXJldHVybiB0fWZ1bmN0aW9uIEgodCl7aWYoXCJ0cnVlXCI9PT10KXJldHVybiEwO2lmKFwiZmFsc2VcIj09PXQpcmV0dXJuITE7aWYodD09PU51bWJlcih0KS50b1N0cmluZygpKXJldHVybiBOdW1iZXIodCk7aWYoXCJcIj09PXR8fFwibnVsbFwiPT09dClyZXR1cm4gbnVsbDtpZihcInN0cmluZ1wiIT10eXBlb2YgdClyZXR1cm4gdDt0cnl7cmV0dXJuIEpTT04ucGFyc2UoZGVjb2RlVVJJQ29tcG9uZW50KHQpKX1jYXRjaChlKXtyZXR1cm4gdH19ZnVuY3Rpb24gQih0KXtyZXR1cm4gdC5yZXBsYWNlKC9bQS1aXS9nLHQ9PmAtJHt0LnRvTG93ZXJDYXNlKCl9YCl9Y29uc3QgcT17c2V0RGF0YUF0dHJpYnV0ZSh0LGUsaSl7dC5zZXRBdHRyaWJ1dGUoYGRhdGEtYnMtJHtCKGUpfWAsaSl9LHJlbW92ZURhdGFBdHRyaWJ1dGUodCxlKXt0LnJlbW92ZUF0dHJpYnV0ZShgZGF0YS1icy0ke0IoZSl9YCl9LGdldERhdGFBdHRyaWJ1dGVzKHQpe2lmKCF0KXJldHVybnt9O2NvbnN0IGU9e30saT1PYmplY3Qua2V5cyh0LmRhdGFzZXQpLmZpbHRlcih0PT50LnN0YXJ0c1dpdGgoXCJic1wiKSYmIXQuc3RhcnRzV2l0aChcImJzQ29uZmlnXCIpKTtmb3IoY29uc3QgcyBvZiBpKXtsZXQgaT1zLnJlcGxhY2UoL15icy8sXCJcIik7aT1pLmNoYXJBdCgwKS50b0xvd2VyQ2FzZSgpK2kuc2xpY2UoMSksZVtpXT1IKHQuZGF0YXNldFtzXSl9cmV0dXJuIGV9LGdldERhdGFBdHRyaWJ1dGU6KHQsZSk9PkgodC5nZXRBdHRyaWJ1dGUoYGRhdGEtYnMtJHtCKGUpfWApKX07Y2xhc3MgV3tzdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm57fX1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJue319c3RhdGljIGdldCBOQU1FKCl7dGhyb3cgbmV3IEVycm9yKCdZb3UgaGF2ZSB0byBpbXBsZW1lbnQgdGhlIHN0YXRpYyBtZXRob2QgXCJOQU1FXCIsIGZvciBlYWNoIGNvbXBvbmVudCEnKX1fZ2V0Q29uZmlnKHQpe3JldHVybiB0PXRoaXMuX21lcmdlQ29uZmlnT2JqKHQpLHQ9dGhpcy5fY29uZmlnQWZ0ZXJNZXJnZSh0KSx0aGlzLl90eXBlQ2hlY2tDb25maWcodCksdH1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdH1fbWVyZ2VDb25maWdPYmoodCxlKXtjb25zdCBpPWMoZSk/cS5nZXREYXRhQXR0cmlidXRlKGUsXCJjb25maWdcIik6e307cmV0dXJuey4uLnRoaXMuY29uc3RydWN0b3IuRGVmYXVsdCwuLi5cIm9iamVjdFwiPT10eXBlb2YgaT9pOnt9LC4uLmMoZSk/cS5nZXREYXRhQXR0cmlidXRlcyhlKTp7fSwuLi5cIm9iamVjdFwiPT10eXBlb2YgdD90Ont9fX1fdHlwZUNoZWNrQ29uZmlnKHQsZT10aGlzLmNvbnN0cnVjdG9yLkRlZmF1bHRUeXBlKXtmb3IoY29uc3RbaSxzXW9mIE9iamVjdC5lbnRyaWVzKGUpKXtjb25zdCBlPXRbaV0sbj1jKGUpP1wiZWxlbWVudFwiOmEoZSk7aWYoIW5ldyBSZWdFeHAocykudGVzdChuKSl0aHJvdyBuZXcgVHlwZUVycm9yKGAke3RoaXMuY29uc3RydWN0b3IuTkFNRS50b1VwcGVyQ2FzZSgpfTogT3B0aW9uIFwiJHtpfVwiIHByb3ZpZGVkIHR5cGUgXCIke259XCIgYnV0IGV4cGVjdGVkIHR5cGUgXCIke3N9XCIuYCl9fX1jbGFzcyBSIGV4dGVuZHMgV3tjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKCksKHQ9aCh0KSkmJih0aGlzLl9lbGVtZW50PXQsdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhlKSxuLnNldCh0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVksdGhpcykpfWRpc3Bvc2UoKXtuLnJlbW92ZSh0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVkpLEYub2ZmKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5FVkVOVF9LRVkpO2Zvcihjb25zdCB0IG9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMpKXRoaXNbdF09bnVsbH1fcXVldWVDYWxsYmFjayh0LGUsaT0hMCl7dyh0LGUsaSl9X2dldENvbmZpZyh0KXtyZXR1cm4gdD10aGlzLl9tZXJnZUNvbmZpZ09iaih0LHRoaXMuX2VsZW1lbnQpLHQ9dGhpcy5fY29uZmlnQWZ0ZXJNZXJnZSh0KSx0aGlzLl90eXBlQ2hlY2tDb25maWcodCksdH1zdGF0aWMgZ2V0SW5zdGFuY2UodCl7cmV0dXJuIG4uZ2V0KGgodCksdGhpcy5EQVRBX0tFWSl9c3RhdGljIGdldE9yQ3JlYXRlSW5zdGFuY2UodCxlPXt9KXtyZXR1cm4gdGhpcy5nZXRJbnN0YW5jZSh0KXx8bmV3IHRoaXModCxcIm9iamVjdFwiPT10eXBlb2YgZT9lOm51bGwpfXN0YXRpYyBnZXQgVkVSU0lPTigpe3JldHVyblwiNS4zLjhcIn1zdGF0aWMgZ2V0IERBVEFfS0VZKCl7cmV0dXJuYGJzLiR7dGhpcy5OQU1FfWB9c3RhdGljIGdldCBFVkVOVF9LRVkoKXtyZXR1cm5gLiR7dGhpcy5EQVRBX0tFWX1gfXN0YXRpYyBldmVudE5hbWUodCl7cmV0dXJuYCR7dH0ke3RoaXMuRVZFTlRfS0VZfWB9fWNvbnN0IEs9dD0+e2xldCBlPXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy10YXJnZXRcIik7aWYoIWV8fFwiI1wiPT09ZSl7bGV0IGk9dC5nZXRBdHRyaWJ1dGUoXCJocmVmXCIpO2lmKCFpfHwhaS5pbmNsdWRlcyhcIiNcIikmJiFpLnN0YXJ0c1dpdGgoXCIuXCIpKXJldHVybiBudWxsO2kuaW5jbHVkZXMoXCIjXCIpJiYhaS5zdGFydHNXaXRoKFwiI1wiKSYmKGk9YCMke2kuc3BsaXQoXCIjXCIpWzFdfWApLGU9aSYmXCIjXCIhPT1pP2kudHJpbSgpOm51bGx9cmV0dXJuIGU/ZS5zcGxpdChcIixcIikubWFwKHQ9PnIodCkpLmpvaW4oXCIsXCIpOm51bGx9LFY9e2ZpbmQ6KHQsZT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpPT5bXS5jb25jYXQoLi4uRWxlbWVudC5wcm90b3R5cGUucXVlcnlTZWxlY3RvckFsbC5jYWxsKGUsdCkpLGZpbmRPbmU6KHQsZT1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpPT5FbGVtZW50LnByb3RvdHlwZS5xdWVyeVNlbGVjdG9yLmNhbGwoZSx0KSxjaGlsZHJlbjoodCxlKT0+W10uY29uY2F0KC4uLnQuY2hpbGRyZW4pLmZpbHRlcih0PT50Lm1hdGNoZXMoZSkpLHBhcmVudHModCxlKXtjb25zdCBpPVtdO2xldCBzPXQucGFyZW50Tm9kZS5jbG9zZXN0KGUpO2Zvcig7czspaS5wdXNoKHMpLHM9cy5wYXJlbnROb2RlLmNsb3Nlc3QoZSk7cmV0dXJuIGl9LHByZXYodCxlKXtsZXQgaT10LnByZXZpb3VzRWxlbWVudFNpYmxpbmc7Zm9yKDtpOyl7aWYoaS5tYXRjaGVzKGUpKXJldHVybltpXTtpPWkucHJldmlvdXNFbGVtZW50U2libGluZ31yZXR1cm5bXX0sbmV4dCh0LGUpe2xldCBpPXQubmV4dEVsZW1lbnRTaWJsaW5nO2Zvcig7aTspe2lmKGkubWF0Y2hlcyhlKSlyZXR1cm5baV07aT1pLm5leHRFbGVtZW50U2libGluZ31yZXR1cm5bXX0sZm9jdXNhYmxlQ2hpbGRyZW4odCl7Y29uc3QgZT1bXCJhXCIsXCJidXR0b25cIixcImlucHV0XCIsXCJ0ZXh0YXJlYVwiLFwic2VsZWN0XCIsXCJkZXRhaWxzXCIsXCJbdGFiaW5kZXhdXCIsJ1tjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdJ10ubWFwKHQ9PmAke3R9Om5vdChbdGFiaW5kZXhePVwiLVwiXSlgKS5qb2luKFwiLFwiKTtyZXR1cm4gdGhpcy5maW5kKGUsdCkuZmlsdGVyKHQ9PiF1KHQpJiZkKHQpKX0sZ2V0U2VsZWN0b3JGcm9tRWxlbWVudCh0KXtjb25zdCBlPUsodCk7cmV0dXJuIGUmJlYuZmluZE9uZShlKT9lOm51bGx9LGdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCl7Y29uc3QgZT1LKHQpO3JldHVybiBlP1YuZmluZE9uZShlKTpudWxsfSxnZXRNdWx0aXBsZUVsZW1lbnRzRnJvbVNlbGVjdG9yKHQpe2NvbnN0IGU9Syh0KTtyZXR1cm4gZT9WLmZpbmQoZSk6W119fSxRPSh0LGU9XCJoaWRlXCIpPT57Y29uc3QgaT1gY2xpY2suZGlzbWlzcyR7dC5FVkVOVF9LRVl9YCxzPXQuTkFNRTtGLm9uKGRvY3VtZW50LGksYFtkYXRhLWJzLWRpc21pc3M9XCIke3N9XCJdYCxmdW5jdGlvbihpKXtpZihbXCJBXCIsXCJBUkVBXCJdLmluY2x1ZGVzKHRoaXMudGFnTmFtZSkmJmkucHJldmVudERlZmF1bHQoKSx1KHRoaXMpKXJldHVybjtjb25zdCBuPVYuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0aGlzKXx8dGhpcy5jbG9zZXN0KGAuJHtzfWApO3QuZ2V0T3JDcmVhdGVJbnN0YW5jZShuKVtlXSgpfSl9LFg9XCIuYnMuYWxlcnRcIixZPWBjbG9zZSR7WH1gLFU9YGNsb3NlZCR7WH1gO2NsYXNzIEcgZXh0ZW5kcyBSe3N0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiYWxlcnRcIn1jbG9zZSgpe2lmKEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LFkpLmRlZmF1bHRQcmV2ZW50ZWQpcmV0dXJuO3RoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShcInNob3dcIik7Y29uc3QgdD10aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcImZhZGVcIik7dGhpcy5fcXVldWVDYWxsYmFjaygoKT0+dGhpcy5fZGVzdHJveUVsZW1lbnQoKSx0aGlzLl9lbGVtZW50LHQpfV9kZXN0cm95RWxlbWVudCgpe3RoaXMuX2VsZW1lbnQucmVtb3ZlKCksRi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsVSksdGhpcy5kaXNwb3NlKCl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1HLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF18fHQuc3RhcnRzV2l0aChcIl9cIil8fFwiY29uc3RydWN0b3JcIj09PXQpdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSh0aGlzKX19KX19UShHLFwiY2xvc2VcIiksdihHKTtjb25zdCBKPSdbZGF0YS1icy10b2dnbGU9XCJidXR0b25cIl0nO2NsYXNzIFogZXh0ZW5kcyBSe3N0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiYnV0dG9uXCJ9dG9nZ2xlKCl7dGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLXByZXNzZWRcIix0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC50b2dnbGUoXCJhY3RpdmVcIikpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9Wi5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMpO1widG9nZ2xlXCI9PT10JiZlW3RdKCl9KX19Ri5vbihkb2N1bWVudCxcImNsaWNrLmJzLmJ1dHRvbi5kYXRhLWFwaVwiLEosdD0+e3QucHJldmVudERlZmF1bHQoKTtjb25zdCBlPXQudGFyZ2V0LmNsb3Nlc3QoSik7Wi5nZXRPckNyZWF0ZUluc3RhbmNlKGUpLnRvZ2dsZSgpfSksdihaKTtjb25zdCB0dD1cIi5icy5zd2lwZVwiLGV0PWB0b3VjaHN0YXJ0JHt0dH1gLGl0PWB0b3VjaG1vdmUke3R0fWAsc3Q9YHRvdWNoZW5kJHt0dH1gLG50PWBwb2ludGVyZG93biR7dHR9YCxvdD1gcG9pbnRlcnVwJHt0dH1gLHJ0PXtlbmRDYWxsYmFjazpudWxsLGxlZnRDYWxsYmFjazpudWxsLHJpZ2h0Q2FsbGJhY2s6bnVsbH0sYXQ9e2VuZENhbGxiYWNrOlwiKGZ1bmN0aW9ufG51bGwpXCIsbGVmdENhbGxiYWNrOlwiKGZ1bmN0aW9ufG51bGwpXCIscmlnaHRDYWxsYmFjazpcIihmdW5jdGlvbnxudWxsKVwifTtjbGFzcyBsdCBleHRlbmRzIFd7Y29uc3RydWN0b3IodCxlKXtzdXBlcigpLHRoaXMuX2VsZW1lbnQ9dCx0JiZsdC5pc1N1cHBvcnRlZCgpJiYodGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhlKSx0aGlzLl9kZWx0YVg9MCx0aGlzLl9zdXBwb3J0UG9pbnRlckV2ZW50cz1Cb29sZWFuKHdpbmRvdy5Qb2ludGVyRXZlbnQpLHRoaXMuX2luaXRFdmVudHMoKSl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIHJ0fXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gYXR9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJzd2lwZVwifWRpc3Bvc2UoKXtGLm9mZih0aGlzLl9lbGVtZW50LHR0KX1fc3RhcnQodCl7dGhpcy5fc3VwcG9ydFBvaW50ZXJFdmVudHM/dGhpcy5fZXZlbnRJc1BvaW50ZXJQZW5Ub3VjaCh0KSYmKHRoaXMuX2RlbHRhWD10LmNsaWVudFgpOnRoaXMuX2RlbHRhWD10LnRvdWNoZXNbMF0uY2xpZW50WH1fZW5kKHQpe3RoaXMuX2V2ZW50SXNQb2ludGVyUGVuVG91Y2godCkmJih0aGlzLl9kZWx0YVg9dC5jbGllbnRYLXRoaXMuX2RlbHRhWCksdGhpcy5faGFuZGxlU3dpcGUoKSx5KHRoaXMuX2NvbmZpZy5lbmRDYWxsYmFjayl9X21vdmUodCl7dGhpcy5fZGVsdGFYPXQudG91Y2hlcyYmdC50b3VjaGVzLmxlbmd0aD4xPzA6dC50b3VjaGVzWzBdLmNsaWVudFgtdGhpcy5fZGVsdGFYfV9oYW5kbGVTd2lwZSgpe2NvbnN0IHQ9TWF0aC5hYnModGhpcy5fZGVsdGFYKTtpZih0PD00MClyZXR1cm47Y29uc3QgZT10L3RoaXMuX2RlbHRhWDt0aGlzLl9kZWx0YVg9MCxlJiZ5KGU+MD90aGlzLl9jb25maWcucmlnaHRDYWxsYmFjazp0aGlzLl9jb25maWcubGVmdENhbGxiYWNrKX1faW5pdEV2ZW50cygpe3RoaXMuX3N1cHBvcnRQb2ludGVyRXZlbnRzPyhGLm9uKHRoaXMuX2VsZW1lbnQsbnQsdD0+dGhpcy5fc3RhcnQodCkpLEYub24odGhpcy5fZWxlbWVudCxvdCx0PT50aGlzLl9lbmQodCkpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChcInBvaW50ZXItZXZlbnRcIikpOihGLm9uKHRoaXMuX2VsZW1lbnQsZXQsdD0+dGhpcy5fc3RhcnQodCkpLEYub24odGhpcy5fZWxlbWVudCxpdCx0PT50aGlzLl9tb3ZlKHQpKSxGLm9uKHRoaXMuX2VsZW1lbnQsc3QsdD0+dGhpcy5fZW5kKHQpKSl9X2V2ZW50SXNQb2ludGVyUGVuVG91Y2godCl7cmV0dXJuIHRoaXMuX3N1cHBvcnRQb2ludGVyRXZlbnRzJiYoXCJwZW5cIj09PXQucG9pbnRlclR5cGV8fFwidG91Y2hcIj09PXQucG9pbnRlclR5cGUpfXN0YXRpYyBpc1N1cHBvcnRlZCgpe3JldHVyblwib250b3VjaHN0YXJ0XCJpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnR8fG5hdmlnYXRvci5tYXhUb3VjaFBvaW50cz4wfX1jb25zdCBjdD1cIi5icy5jYXJvdXNlbFwiLGh0PVwiLmRhdGEtYXBpXCIsZHQ9XCJBcnJvd0xlZnRcIix1dD1cIkFycm93UmlnaHRcIixfdD1cIm5leHRcIixndD1cInByZXZcIixmdD1cImxlZnRcIixtdD1cInJpZ2h0XCIscHQ9YHNsaWRlJHtjdH1gLGJ0PWBzbGlkJHtjdH1gLHZ0PWBrZXlkb3duJHtjdH1gLHl0PWBtb3VzZWVudGVyJHtjdH1gLHd0PWBtb3VzZWxlYXZlJHtjdH1gLEF0PWBkcmFnc3RhcnQke2N0fWAsRXQ9YGxvYWQke2N0fSR7aHR9YCxDdD1gY2xpY2ske2N0fSR7aHR9YCxUdD1cImNhcm91c2VsXCIsa3Q9XCJhY3RpdmVcIiwkdD1cIi5hY3RpdmVcIixTdD1cIi5jYXJvdXNlbC1pdGVtXCIsTHQ9JHQrU3QsT3Q9e1tkdF06bXQsW3V0XTpmdH0sSXQ9e2ludGVydmFsOjVlMyxrZXlib2FyZDohMCxwYXVzZTpcImhvdmVyXCIscmlkZTohMSx0b3VjaDohMCx3cmFwOiEwfSxEdD17aW50ZXJ2YWw6XCIobnVtYmVyfGJvb2xlYW4pXCIsa2V5Ym9hcmQ6XCJib29sZWFuXCIscGF1c2U6XCIoc3RyaW5nfGJvb2xlYW4pXCIscmlkZTpcIihib29sZWFufHN0cmluZylcIix0b3VjaDpcImJvb2xlYW5cIix3cmFwOlwiYm9vbGVhblwifTtjbGFzcyBOdCBleHRlbmRzIFJ7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX2ludGVydmFsPW51bGwsdGhpcy5fYWN0aXZlRWxlbWVudD1udWxsLHRoaXMuX2lzU2xpZGluZz0hMSx0aGlzLnRvdWNoVGltZW91dD1udWxsLHRoaXMuX3N3aXBlSGVscGVyPW51bGwsdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQ9Vi5maW5kT25lKFwiLmNhcm91c2VsLWluZGljYXRvcnNcIix0aGlzLl9lbGVtZW50KSx0aGlzLl9hZGRFdmVudExpc3RlbmVycygpLHRoaXMuX2NvbmZpZy5yaWRlPT09VHQmJnRoaXMuY3ljbGUoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gSXR9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBEdH1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cImNhcm91c2VsXCJ9bmV4dCgpe3RoaXMuX3NsaWRlKF90KX1uZXh0V2hlblZpc2libGUoKXshZG9jdW1lbnQuaGlkZGVuJiZkKHRoaXMuX2VsZW1lbnQpJiZ0aGlzLm5leHQoKX1wcmV2KCl7dGhpcy5fc2xpZGUoZ3QpfXBhdXNlKCl7dGhpcy5faXNTbGlkaW5nJiZsKHRoaXMuX2VsZW1lbnQpLHRoaXMuX2NsZWFySW50ZXJ2YWwoKX1jeWNsZSgpe3RoaXMuX2NsZWFySW50ZXJ2YWwoKSx0aGlzLl91cGRhdGVJbnRlcnZhbCgpLHRoaXMuX2ludGVydmFsPXNldEludGVydmFsKCgpPT50aGlzLm5leHRXaGVuVmlzaWJsZSgpLHRoaXMuX2NvbmZpZy5pbnRlcnZhbCl9X21heWJlRW5hYmxlQ3ljbGUoKXt0aGlzLl9jb25maWcucmlkZSYmKHRoaXMuX2lzU2xpZGluZz9GLm9uZSh0aGlzLl9lbGVtZW50LGJ0LCgpPT50aGlzLmN5Y2xlKCkpOnRoaXMuY3ljbGUoKSl9dG8odCl7Y29uc3QgZT10aGlzLl9nZXRJdGVtcygpO2lmKHQ+ZS5sZW5ndGgtMXx8dDwwKXJldHVybjtpZih0aGlzLl9pc1NsaWRpbmcpcmV0dXJuIHZvaWQgRi5vbmUodGhpcy5fZWxlbWVudCxidCwoKT0+dGhpcy50byh0KSk7Y29uc3QgaT10aGlzLl9nZXRJdGVtSW5kZXgodGhpcy5fZ2V0QWN0aXZlKCkpO2lmKGk9PT10KXJldHVybjtjb25zdCBzPXQ+aT9fdDpndDt0aGlzLl9zbGlkZShzLGVbdF0pfWRpc3Bvc2UoKXt0aGlzLl9zd2lwZUhlbHBlciYmdGhpcy5fc3dpcGVIZWxwZXIuZGlzcG9zZSgpLHN1cGVyLmRpc3Bvc2UoKX1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC5kZWZhdWx0SW50ZXJ2YWw9dC5pbnRlcnZhbCx0fV9hZGRFdmVudExpc3RlbmVycygpe3RoaXMuX2NvbmZpZy5rZXlib2FyZCYmRi5vbih0aGlzLl9lbGVtZW50LHZ0LHQ9PnRoaXMuX2tleWRvd24odCkpLFwiaG92ZXJcIj09PXRoaXMuX2NvbmZpZy5wYXVzZSYmKEYub24odGhpcy5fZWxlbWVudCx5dCwoKT0+dGhpcy5wYXVzZSgpKSxGLm9uKHRoaXMuX2VsZW1lbnQsd3QsKCk9PnRoaXMuX21heWJlRW5hYmxlQ3ljbGUoKSkpLHRoaXMuX2NvbmZpZy50b3VjaCYmbHQuaXNTdXBwb3J0ZWQoKSYmdGhpcy5fYWRkVG91Y2hFdmVudExpc3RlbmVycygpfV9hZGRUb3VjaEV2ZW50TGlzdGVuZXJzKCl7Zm9yKGNvbnN0IHQgb2YgVi5maW5kKFwiLmNhcm91c2VsLWl0ZW0gaW1nXCIsdGhpcy5fZWxlbWVudCkpRi5vbih0LEF0LHQ9PnQucHJldmVudERlZmF1bHQoKSk7Y29uc3QgdD17bGVmdENhbGxiYWNrOigpPT50aGlzLl9zbGlkZSh0aGlzLl9kaXJlY3Rpb25Ub09yZGVyKGZ0KSkscmlnaHRDYWxsYmFjazooKT0+dGhpcy5fc2xpZGUodGhpcy5fZGlyZWN0aW9uVG9PcmRlcihtdCkpLGVuZENhbGxiYWNrOigpPT57XCJob3ZlclwiPT09dGhpcy5fY29uZmlnLnBhdXNlJiYodGhpcy5wYXVzZSgpLHRoaXMudG91Y2hUaW1lb3V0JiZjbGVhclRpbWVvdXQodGhpcy50b3VjaFRpbWVvdXQpLHRoaXMudG91Y2hUaW1lb3V0PXNldFRpbWVvdXQoKCk9PnRoaXMuX21heWJlRW5hYmxlQ3ljbGUoKSw1MDArdGhpcy5fY29uZmlnLmludGVydmFsKSl9fTt0aGlzLl9zd2lwZUhlbHBlcj1uZXcgbHQodGhpcy5fZWxlbWVudCx0KX1fa2V5ZG93bih0KXtpZigvaW5wdXR8dGV4dGFyZWEvaS50ZXN0KHQudGFyZ2V0LnRhZ05hbWUpKXJldHVybjtjb25zdCBlPU90W3Qua2V5XTtlJiYodC5wcmV2ZW50RGVmYXVsdCgpLHRoaXMuX3NsaWRlKHRoaXMuX2RpcmVjdGlvblRvT3JkZXIoZSkpKX1fZ2V0SXRlbUluZGV4KHQpe3JldHVybiB0aGlzLl9nZXRJdGVtcygpLmluZGV4T2YodCl9X3NldEFjdGl2ZUluZGljYXRvckVsZW1lbnQodCl7aWYoIXRoaXMuX2luZGljYXRvcnNFbGVtZW50KXJldHVybjtjb25zdCBlPVYuZmluZE9uZSgkdCx0aGlzLl9pbmRpY2F0b3JzRWxlbWVudCk7ZS5jbGFzc0xpc3QucmVtb3ZlKGt0KSxlLnJlbW92ZUF0dHJpYnV0ZShcImFyaWEtY3VycmVudFwiKTtjb25zdCBpPVYuZmluZE9uZShgW2RhdGEtYnMtc2xpZGUtdG89XCIke3R9XCJdYCx0aGlzLl9pbmRpY2F0b3JzRWxlbWVudCk7aSYmKGkuY2xhc3NMaXN0LmFkZChrdCksaS5zZXRBdHRyaWJ1dGUoXCJhcmlhLWN1cnJlbnRcIixcInRydWVcIikpfV91cGRhdGVJbnRlcnZhbCgpe2NvbnN0IHQ9dGhpcy5fYWN0aXZlRWxlbWVudHx8dGhpcy5fZ2V0QWN0aXZlKCk7aWYoIXQpcmV0dXJuO2NvbnN0IGU9TnVtYmVyLnBhcnNlSW50KHQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy1pbnRlcnZhbFwiKSwxMCk7dGhpcy5fY29uZmlnLmludGVydmFsPWV8fHRoaXMuX2NvbmZpZy5kZWZhdWx0SW50ZXJ2YWx9X3NsaWRlKHQsZT1udWxsKXtpZih0aGlzLl9pc1NsaWRpbmcpcmV0dXJuO2NvbnN0IGk9dGhpcy5fZ2V0QWN0aXZlKCkscz10PT09X3Qsbj1lfHxBKHRoaXMuX2dldEl0ZW1zKCksaSxzLHRoaXMuX2NvbmZpZy53cmFwKTtpZihuPT09aSlyZXR1cm47Y29uc3Qgbz10aGlzLl9nZXRJdGVtSW5kZXgobikscj1lPT5GLnRyaWdnZXIodGhpcy5fZWxlbWVudCxlLHtyZWxhdGVkVGFyZ2V0Om4sZGlyZWN0aW9uOnRoaXMuX29yZGVyVG9EaXJlY3Rpb24odCksZnJvbTp0aGlzLl9nZXRJdGVtSW5kZXgoaSksdG86b30pO2lmKHIocHQpLmRlZmF1bHRQcmV2ZW50ZWQpcmV0dXJuO2lmKCFpfHwhbilyZXR1cm47Y29uc3QgYT1Cb29sZWFuKHRoaXMuX2ludGVydmFsKTt0aGlzLnBhdXNlKCksdGhpcy5faXNTbGlkaW5nPSEwLHRoaXMuX3NldEFjdGl2ZUluZGljYXRvckVsZW1lbnQobyksdGhpcy5fYWN0aXZlRWxlbWVudD1uO2NvbnN0IGw9cz9cImNhcm91c2VsLWl0ZW0tc3RhcnRcIjpcImNhcm91c2VsLWl0ZW0tZW5kXCIsYz1zP1wiY2Fyb3VzZWwtaXRlbS1uZXh0XCI6XCJjYXJvdXNlbC1pdGVtLXByZXZcIjtuLmNsYXNzTGlzdC5hZGQoYyksZihuKSxpLmNsYXNzTGlzdC5hZGQobCksbi5jbGFzc0xpc3QuYWRkKGwpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9PntuLmNsYXNzTGlzdC5yZW1vdmUobCxjKSxuLmNsYXNzTGlzdC5hZGQoa3QpLGkuY2xhc3NMaXN0LnJlbW92ZShrdCxjLGwpLHRoaXMuX2lzU2xpZGluZz0hMSxyKGJ0KX0saSx0aGlzLl9pc0FuaW1hdGVkKCkpLGEmJnRoaXMuY3ljbGUoKX1faXNBbmltYXRlZCgpe3JldHVybiB0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcInNsaWRlXCIpfV9nZXRBY3RpdmUoKXtyZXR1cm4gVi5maW5kT25lKEx0LHRoaXMuX2VsZW1lbnQpfV9nZXRJdGVtcygpe3JldHVybiBWLmZpbmQoU3QsdGhpcy5fZWxlbWVudCl9X2NsZWFySW50ZXJ2YWwoKXt0aGlzLl9pbnRlcnZhbCYmKGNsZWFySW50ZXJ2YWwodGhpcy5faW50ZXJ2YWwpLHRoaXMuX2ludGVydmFsPW51bGwpfV9kaXJlY3Rpb25Ub09yZGVyKHQpe3JldHVybiBiKCk/dD09PWZ0P2d0Ol90OnQ9PT1mdD9fdDpndH1fb3JkZXJUb0RpcmVjdGlvbih0KXtyZXR1cm4gYigpP3Q9PT1ndD9mdDptdDp0PT09Z3Q/bXQ6ZnR9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1OdC5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJudW1iZXJcIiE9dHlwZW9mIHQpe2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdfHx0LnN0YXJ0c1dpdGgoXCJfXCIpfHxcImNvbnN0cnVjdG9yXCI9PT10KXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0oKX19ZWxzZSBlLnRvKHQpfSl9fUYub24oZG9jdW1lbnQsQ3QsXCJbZGF0YS1icy1zbGlkZV0sIFtkYXRhLWJzLXNsaWRlLXRvXVwiLGZ1bmN0aW9uKHQpe2NvbnN0IGU9Vi5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHRoaXMpO2lmKCFlfHwhZS5jbGFzc0xpc3QuY29udGFpbnMoVHQpKXJldHVybjt0LnByZXZlbnREZWZhdWx0KCk7Y29uc3QgaT1OdC5nZXRPckNyZWF0ZUluc3RhbmNlKGUpLHM9dGhpcy5nZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLXNsaWRlLXRvXCIpO3JldHVybiBzPyhpLnRvKHMpLHZvaWQgaS5fbWF5YmVFbmFibGVDeWNsZSgpKTpcIm5leHRcIj09PXEuZ2V0RGF0YUF0dHJpYnV0ZSh0aGlzLFwic2xpZGVcIik/KGkubmV4dCgpLHZvaWQgaS5fbWF5YmVFbmFibGVDeWNsZSgpKTooaS5wcmV2KCksdm9pZCBpLl9tYXliZUVuYWJsZUN5Y2xlKCkpfSksRi5vbih3aW5kb3csRXQsKCk9Pntjb25zdCB0PVYuZmluZCgnW2RhdGEtYnMtcmlkZT1cImNhcm91c2VsXCJdJyk7Zm9yKGNvbnN0IGUgb2YgdClOdC5nZXRPckNyZWF0ZUluc3RhbmNlKGUpfSksdihOdCk7Y29uc3QgUHQ9XCIuYnMuY29sbGFwc2VcIix4dD1gc2hvdyR7UHR9YCxNdD1gc2hvd24ke1B0fWAsanQ9YGhpZGUke1B0fWAsRnQ9YGhpZGRlbiR7UHR9YCx6dD1gY2xpY2ske1B0fS5kYXRhLWFwaWAsSHQ9XCJzaG93XCIsQnQ9XCJjb2xsYXBzZVwiLHF0PVwiY29sbGFwc2luZ1wiLFd0PWA6c2NvcGUgLiR7QnR9IC4ke0J0fWAsUnQ9J1tkYXRhLWJzLXRvZ2dsZT1cImNvbGxhcHNlXCJdJyxLdD17cGFyZW50Om51bGwsdG9nZ2xlOiEwfSxWdD17cGFyZW50OlwiKG51bGx8ZWxlbWVudClcIix0b2dnbGU6XCJib29sZWFuXCJ9O2NsYXNzIFF0IGV4dGVuZHMgUntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX3RyaWdnZXJBcnJheT1bXTtjb25zdCBpPVYuZmluZChSdCk7Zm9yKGNvbnN0IHQgb2YgaSl7Y29uc3QgZT1WLmdldFNlbGVjdG9yRnJvbUVsZW1lbnQodCksaT1WLmZpbmQoZSkuZmlsdGVyKHQ9PnQ9PT10aGlzLl9lbGVtZW50KTtudWxsIT09ZSYmaS5sZW5ndGgmJnRoaXMuX3RyaWdnZXJBcnJheS5wdXNoKHQpfXRoaXMuX2luaXRpYWxpemVDaGlsZHJlbigpLHRoaXMuX2NvbmZpZy5wYXJlbnR8fHRoaXMuX2FkZEFyaWFBbmRDb2xsYXBzZWRDbGFzcyh0aGlzLl90cmlnZ2VyQXJyYXksdGhpcy5faXNTaG93bigpKSx0aGlzLl9jb25maWcudG9nZ2xlJiZ0aGlzLnRvZ2dsZSgpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBLdH1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIFZ0fXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwiY29sbGFwc2VcIn10b2dnbGUoKXt0aGlzLl9pc1Nob3duKCk/dGhpcy5oaWRlKCk6dGhpcy5zaG93KCl9c2hvdygpe2lmKHRoaXMuX2lzVHJhbnNpdGlvbmluZ3x8dGhpcy5faXNTaG93bigpKXJldHVybjtsZXQgdD1bXTtpZih0aGlzLl9jb25maWcucGFyZW50JiYodD10aGlzLl9nZXRGaXJzdExldmVsQ2hpbGRyZW4oXCIuY29sbGFwc2Uuc2hvdywgLmNvbGxhcHNlLmNvbGxhcHNpbmdcIikuZmlsdGVyKHQ9PnQhPT10aGlzLl9lbGVtZW50KS5tYXAodD0+UXQuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0LHt0b2dnbGU6ITF9KSkpLHQubGVuZ3RoJiZ0WzBdLl9pc1RyYW5zaXRpb25pbmcpcmV0dXJuO2lmKEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LHh0KS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtmb3IoY29uc3QgZSBvZiB0KWUuaGlkZSgpO2NvbnN0IGU9dGhpcy5fZ2V0RGltZW5zaW9uKCk7dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKEJ0KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQocXQpLHRoaXMuX2VsZW1lbnQuc3R5bGVbZV09MCx0aGlzLl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3ModGhpcy5fdHJpZ2dlckFycmF5LCEwKSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITA7Y29uc3QgaT1gc2Nyb2xsJHtlWzBdLnRvVXBwZXJDYXNlKCkrZS5zbGljZSgxKX1gO3RoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKHF0KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoQnQsSHQpLHRoaXMuX2VsZW1lbnQuc3R5bGVbZV09XCJcIixGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxNdCl9LHRoaXMuX2VsZW1lbnQsITApLHRoaXMuX2VsZW1lbnQuc3R5bGVbZV09YCR7dGhpcy5fZWxlbWVudFtpXX1weGB9aGlkZSgpe2lmKHRoaXMuX2lzVHJhbnNpdGlvbmluZ3x8IXRoaXMuX2lzU2hvd24oKSlyZXR1cm47aWYoRi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsanQpLmRlZmF1bHRQcmV2ZW50ZWQpcmV0dXJuO2NvbnN0IHQ9dGhpcy5fZ2V0RGltZW5zaW9uKCk7dGhpcy5fZWxlbWVudC5zdHlsZVt0XT1gJHt0aGlzLl9lbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpW3RdfXB4YCxmKHRoaXMuX2VsZW1lbnQpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChxdCksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKEJ0LEh0KTtmb3IoY29uc3QgdCBvZiB0aGlzLl90cmlnZ2VyQXJyYXkpe2NvbnN0IGU9Vi5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHQpO2UmJiF0aGlzLl9pc1Nob3duKGUpJiZ0aGlzLl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3MoW3RdLCExKX10aGlzLl9pc1RyYW5zaXRpb25pbmc9ITAsdGhpcy5fZWxlbWVudC5zdHlsZVt0XT1cIlwiLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKHF0KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoQnQpLEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LEZ0KX0sdGhpcy5fZWxlbWVudCwhMCl9X2lzU2hvd24odD10aGlzLl9lbGVtZW50KXtyZXR1cm4gdC5jbGFzc0xpc3QuY29udGFpbnMoSHQpfV9jb25maWdBZnRlck1lcmdlKHQpe3JldHVybiB0LnRvZ2dsZT1Cb29sZWFuKHQudG9nZ2xlKSx0LnBhcmVudD1oKHQucGFyZW50KSx0fV9nZXREaW1lbnNpb24oKXtyZXR1cm4gdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJjb2xsYXBzZS1ob3Jpem9udGFsXCIpP1wid2lkdGhcIjpcImhlaWdodFwifV9pbml0aWFsaXplQ2hpbGRyZW4oKXtpZighdGhpcy5fY29uZmlnLnBhcmVudClyZXR1cm47Y29uc3QgdD10aGlzLl9nZXRGaXJzdExldmVsQ2hpbGRyZW4oUnQpO2Zvcihjb25zdCBlIG9mIHQpe2NvbnN0IHQ9Vi5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKGUpO3QmJnRoaXMuX2FkZEFyaWFBbmRDb2xsYXBzZWRDbGFzcyhbZV0sdGhpcy5faXNTaG93bih0KSl9fV9nZXRGaXJzdExldmVsQ2hpbGRyZW4odCl7Y29uc3QgZT1WLmZpbmQoV3QsdGhpcy5fY29uZmlnLnBhcmVudCk7cmV0dXJuIFYuZmluZCh0LHRoaXMuX2NvbmZpZy5wYXJlbnQpLmZpbHRlcih0PT4hZS5pbmNsdWRlcyh0KSl9X2FkZEFyaWFBbmRDb2xsYXBzZWRDbGFzcyh0LGUpe2lmKHQubGVuZ3RoKWZvcihjb25zdCBpIG9mIHQpaS5jbGFzc0xpc3QudG9nZ2xlKFwiY29sbGFwc2VkXCIsIWUpLGkuc2V0QXR0cmlidXRlKFwiYXJpYS1leHBhbmRlZFwiLGUpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7Y29uc3QgZT17fTtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdCYmL3Nob3d8aGlkZS8udGVzdCh0KSYmKGUudG9nZ2xlPSExKSx0aGlzLmVhY2goZnVuY3Rpb24oKXtjb25zdCBpPVF0LmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyxlKTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09aVt0XSl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtpW3RdKCl9fSl9fUYub24oZG9jdW1lbnQsenQsUnQsZnVuY3Rpb24odCl7KFwiQVwiPT09dC50YXJnZXQudGFnTmFtZXx8dC5kZWxlZ2F0ZVRhcmdldCYmXCJBXCI9PT10LmRlbGVnYXRlVGFyZ2V0LnRhZ05hbWUpJiZ0LnByZXZlbnREZWZhdWx0KCk7Zm9yKGNvbnN0IHQgb2YgVi5nZXRNdWx0aXBsZUVsZW1lbnRzRnJvbVNlbGVjdG9yKHRoaXMpKVF0LmdldE9yQ3JlYXRlSW5zdGFuY2UodCx7dG9nZ2xlOiExfSkudG9nZ2xlKCl9KSx2KFF0KTtjb25zdCBYdD1cImRyb3Bkb3duXCIsWXQ9XCIuYnMuZHJvcGRvd25cIixVdD1cIi5kYXRhLWFwaVwiLEd0PVwiQXJyb3dVcFwiLEp0PVwiQXJyb3dEb3duXCIsWnQ9YGhpZGUke1l0fWAsdGU9YGhpZGRlbiR7WXR9YCxlZT1gc2hvdyR7WXR9YCxpZT1gc2hvd24ke1l0fWAsc2U9YGNsaWNrJHtZdH0ke1V0fWAsbmU9YGtleWRvd24ke1l0fSR7VXR9YCxvZT1ga2V5dXAke1l0fSR7VXR9YCxyZT1cInNob3dcIixhZT0nW2RhdGEtYnMtdG9nZ2xlPVwiZHJvcGRvd25cIl06bm90KC5kaXNhYmxlZCk6bm90KDpkaXNhYmxlZCknLGxlPWAke2FlfS4ke3JlfWAsY2U9XCIuZHJvcGRvd24tbWVudVwiLGhlPWIoKT9cInRvcC1lbmRcIjpcInRvcC1zdGFydFwiLGRlPWIoKT9cInRvcC1zdGFydFwiOlwidG9wLWVuZFwiLHVlPWIoKT9cImJvdHRvbS1lbmRcIjpcImJvdHRvbS1zdGFydFwiLF9lPWIoKT9cImJvdHRvbS1zdGFydFwiOlwiYm90dG9tLWVuZFwiLGdlPWIoKT9cImxlZnQtc3RhcnRcIjpcInJpZ2h0LXN0YXJ0XCIsZmU9YigpP1wicmlnaHQtc3RhcnRcIjpcImxlZnQtc3RhcnRcIixtZT17YXV0b0Nsb3NlOiEwLGJvdW5kYXJ5OlwiY2xpcHBpbmdQYXJlbnRzXCIsZGlzcGxheTpcImR5bmFtaWNcIixvZmZzZXQ6WzAsMl0scG9wcGVyQ29uZmlnOm51bGwscmVmZXJlbmNlOlwidG9nZ2xlXCJ9LHBlPXthdXRvQ2xvc2U6XCIoYm9vbGVhbnxzdHJpbmcpXCIsYm91bmRhcnk6XCIoc3RyaW5nfGVsZW1lbnQpXCIsZGlzcGxheTpcInN0cmluZ1wiLG9mZnNldDpcIihhcnJheXxzdHJpbmd8ZnVuY3Rpb24pXCIscG9wcGVyQ29uZmlnOlwiKG51bGx8b2JqZWN0fGZ1bmN0aW9uKVwiLHJlZmVyZW5jZTpcIihzdHJpbmd8ZWxlbWVudHxvYmplY3QpXCJ9O2NsYXNzIGJlIGV4dGVuZHMgUntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fcG9wcGVyPW51bGwsdGhpcy5fcGFyZW50PXRoaXMuX2VsZW1lbnQucGFyZW50Tm9kZSx0aGlzLl9tZW51PVYubmV4dCh0aGlzLl9lbGVtZW50LGNlKVswXXx8Vi5wcmV2KHRoaXMuX2VsZW1lbnQsY2UpWzBdfHxWLmZpbmRPbmUoY2UsdGhpcy5fcGFyZW50KSx0aGlzLl9pbk5hdmJhcj10aGlzLl9kZXRlY3ROYXZiYXIoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gbWV9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBwZX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm4gWHR9dG9nZ2xlKCl7cmV0dXJuIHRoaXMuX2lzU2hvd24oKT90aGlzLmhpZGUoKTp0aGlzLnNob3coKX1zaG93KCl7aWYodSh0aGlzLl9lbGVtZW50KXx8dGhpcy5faXNTaG93bigpKXJldHVybjtjb25zdCB0PXtyZWxhdGVkVGFyZ2V0OnRoaXMuX2VsZW1lbnR9O2lmKCFGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxlZSx0KS5kZWZhdWx0UHJldmVudGVkKXtpZih0aGlzLl9jcmVhdGVQb3BwZXIoKSxcIm9udG91Y2hzdGFydFwiaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50JiYhdGhpcy5fcGFyZW50LmNsb3Nlc3QoXCIubmF2YmFyLW5hdlwiKSlmb3IoY29uc3QgdCBvZltdLmNvbmNhdCguLi5kb2N1bWVudC5ib2R5LmNoaWxkcmVuKSlGLm9uKHQsXCJtb3VzZW92ZXJcIixnKTt0aGlzLl9lbGVtZW50LmZvY3VzKCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsITApLHRoaXMuX21lbnUuY2xhc3NMaXN0LmFkZChyZSksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKHJlKSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxpZSx0KX19aGlkZSgpe2lmKHUodGhpcy5fZWxlbWVudCl8fCF0aGlzLl9pc1Nob3duKCkpcmV0dXJuO2NvbnN0IHQ9e3JlbGF0ZWRUYXJnZXQ6dGhpcy5fZWxlbWVudH07dGhpcy5fY29tcGxldGVIaWRlKHQpfWRpc3Bvc2UoKXt0aGlzLl9wb3BwZXImJnRoaXMuX3BvcHBlci5kZXN0cm95KCksc3VwZXIuZGlzcG9zZSgpfXVwZGF0ZSgpe3RoaXMuX2luTmF2YmFyPXRoaXMuX2RldGVjdE5hdmJhcigpLHRoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLnVwZGF0ZSgpfV9jb21wbGV0ZUhpZGUodCl7aWYoIUYudHJpZ2dlcih0aGlzLl9lbGVtZW50LFp0LHQpLmRlZmF1bHRQcmV2ZW50ZWQpe2lmKFwib250b3VjaHN0YXJ0XCJpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpZm9yKGNvbnN0IHQgb2ZbXS5jb25jYXQoLi4uZG9jdW1lbnQuYm9keS5jaGlsZHJlbikpRi5vZmYodCxcIm1vdXNlb3ZlclwiLGcpO3RoaXMuX3BvcHBlciYmdGhpcy5fcG9wcGVyLmRlc3Ryb3koKSx0aGlzLl9tZW51LmNsYXNzTGlzdC5yZW1vdmUocmUpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShyZSksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsXCJmYWxzZVwiKSxxLnJlbW92ZURhdGFBdHRyaWJ1dGUodGhpcy5fbWVudSxcInBvcHBlclwiKSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCx0ZSx0KX19X2dldENvbmZpZyh0KXtpZihcIm9iamVjdFwiPT10eXBlb2YodD1zdXBlci5fZ2V0Q29uZmlnKHQpKS5yZWZlcmVuY2UmJiFjKHQucmVmZXJlbmNlKSYmXCJmdW5jdGlvblwiIT10eXBlb2YgdC5yZWZlcmVuY2UuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KXRocm93IG5ldyBUeXBlRXJyb3IoYCR7WHQudG9VcHBlckNhc2UoKX06IE9wdGlvbiBcInJlZmVyZW5jZVwiIHByb3ZpZGVkIHR5cGUgXCJvYmplY3RcIiB3aXRob3V0IGEgcmVxdWlyZWQgXCJnZXRCb3VuZGluZ0NsaWVudFJlY3RcIiBtZXRob2QuYCk7cmV0dXJuIHR9X2NyZWF0ZVBvcHBlcigpe2lmKHZvaWQgMD09PWkpdGhyb3cgbmV3IFR5cGVFcnJvcihcIkJvb3RzdHJhcCdzIGRyb3Bkb3ducyByZXF1aXJlIFBvcHBlciAoaHR0cHM6Ly9wb3BwZXIuanMub3JnL2RvY3MvdjIvKVwiKTtsZXQgdD10aGlzLl9lbGVtZW50O1wicGFyZW50XCI9PT10aGlzLl9jb25maWcucmVmZXJlbmNlP3Q9dGhpcy5fcGFyZW50OmModGhpcy5fY29uZmlnLnJlZmVyZW5jZSk/dD1oKHRoaXMuX2NvbmZpZy5yZWZlcmVuY2UpOlwib2JqZWN0XCI9PXR5cGVvZiB0aGlzLl9jb25maWcucmVmZXJlbmNlJiYodD10aGlzLl9jb25maWcucmVmZXJlbmNlKTtjb25zdCBlPXRoaXMuX2dldFBvcHBlckNvbmZpZygpO3RoaXMuX3BvcHBlcj1pLmNyZWF0ZVBvcHBlcih0LHRoaXMuX21lbnUsZSl9X2lzU2hvd24oKXtyZXR1cm4gdGhpcy5fbWVudS5jbGFzc0xpc3QuY29udGFpbnMocmUpfV9nZXRQbGFjZW1lbnQoKXtjb25zdCB0PXRoaXMuX3BhcmVudDtpZih0LmNsYXNzTGlzdC5jb250YWlucyhcImRyb3BlbmRcIikpcmV0dXJuIGdlO2lmKHQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZHJvcHN0YXJ0XCIpKXJldHVybiBmZTtpZih0LmNsYXNzTGlzdC5jb250YWlucyhcImRyb3B1cC1jZW50ZXJcIikpcmV0dXJuXCJ0b3BcIjtpZih0LmNsYXNzTGlzdC5jb250YWlucyhcImRyb3Bkb3duLWNlbnRlclwiKSlyZXR1cm5cImJvdHRvbVwiO2NvbnN0IGU9XCJlbmRcIj09PWdldENvbXB1dGVkU3R5bGUodGhpcy5fbWVudSkuZ2V0UHJvcGVydHlWYWx1ZShcIi0tYnMtcG9zaXRpb25cIikudHJpbSgpO3JldHVybiB0LmNsYXNzTGlzdC5jb250YWlucyhcImRyb3B1cFwiKT9lP2RlOmhlOmU/X2U6dWV9X2RldGVjdE5hdmJhcigpe3JldHVybiBudWxsIT09dGhpcy5fZWxlbWVudC5jbG9zZXN0KFwiLm5hdmJhclwiKX1fZ2V0T2Zmc2V0KCl7Y29uc3R7b2Zmc2V0OnR9PXRoaXMuX2NvbmZpZztyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdD90LnNwbGl0KFwiLFwiKS5tYXAodD0+TnVtYmVyLnBhcnNlSW50KHQsMTApKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiB0P2U9PnQoZSx0aGlzLl9lbGVtZW50KTp0fV9nZXRQb3BwZXJDb25maWcoKXtjb25zdCB0PXtwbGFjZW1lbnQ6dGhpcy5fZ2V0UGxhY2VtZW50KCksbW9kaWZpZXJzOlt7bmFtZTpcInByZXZlbnRPdmVyZmxvd1wiLG9wdGlvbnM6e2JvdW5kYXJ5OnRoaXMuX2NvbmZpZy5ib3VuZGFyeX19LHtuYW1lOlwib2Zmc2V0XCIsb3B0aW9uczp7b2Zmc2V0OnRoaXMuX2dldE9mZnNldCgpfX1dfTtyZXR1cm4odGhpcy5faW5OYXZiYXJ8fFwic3RhdGljXCI9PT10aGlzLl9jb25maWcuZGlzcGxheSkmJihxLnNldERhdGFBdHRyaWJ1dGUodGhpcy5fbWVudSxcInBvcHBlclwiLFwic3RhdGljXCIpLHQubW9kaWZpZXJzPVt7bmFtZTpcImFwcGx5U3R5bGVzXCIsZW5hYmxlZDohMX1dKSx7Li4udCwuLi55KHRoaXMuX2NvbmZpZy5wb3BwZXJDb25maWcsW3ZvaWQgMCx0XSl9fV9zZWxlY3RNZW51SXRlbSh7a2V5OnQsdGFyZ2V0OmV9KXtjb25zdCBpPVYuZmluZChcIi5kcm9wZG93bi1tZW51IC5kcm9wZG93bi1pdGVtOm5vdCguZGlzYWJsZWQpOm5vdCg6ZGlzYWJsZWQpXCIsdGhpcy5fbWVudSkuZmlsdGVyKHQ9PmQodCkpO2kubGVuZ3RoJiZBKGksZSx0PT09SnQsIWkuaW5jbHVkZXMoZSkpLmZvY3VzKCl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1iZS5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSgpfX0pfXN0YXRpYyBjbGVhck1lbnVzKHQpe2lmKDI9PT10LmJ1dHRvbnx8XCJrZXl1cFwiPT09dC50eXBlJiZcIlRhYlwiIT09dC5rZXkpcmV0dXJuO2NvbnN0IGU9Vi5maW5kKGxlKTtmb3IoY29uc3QgaSBvZiBlKXtjb25zdCBlPWJlLmdldEluc3RhbmNlKGkpO2lmKCFlfHwhMT09PWUuX2NvbmZpZy5hdXRvQ2xvc2UpY29udGludWU7Y29uc3Qgcz10LmNvbXBvc2VkUGF0aCgpLG49cy5pbmNsdWRlcyhlLl9tZW51KTtpZihzLmluY2x1ZGVzKGUuX2VsZW1lbnQpfHxcImluc2lkZVwiPT09ZS5fY29uZmlnLmF1dG9DbG9zZSYmIW58fFwib3V0c2lkZVwiPT09ZS5fY29uZmlnLmF1dG9DbG9zZSYmbiljb250aW51ZTtpZihlLl9tZW51LmNvbnRhaW5zKHQudGFyZ2V0KSYmKFwia2V5dXBcIj09PXQudHlwZSYmXCJUYWJcIj09PXQua2V5fHwvaW5wdXR8c2VsZWN0fG9wdGlvbnx0ZXh0YXJlYXxmb3JtL2kudGVzdCh0LnRhcmdldC50YWdOYW1lKSkpY29udGludWU7Y29uc3Qgbz17cmVsYXRlZFRhcmdldDplLl9lbGVtZW50fTtcImNsaWNrXCI9PT10LnR5cGUmJihvLmNsaWNrRXZlbnQ9dCksZS5fY29tcGxldGVIaWRlKG8pfX1zdGF0aWMgZGF0YUFwaUtleWRvd25IYW5kbGVyKHQpe2NvbnN0IGU9L2lucHV0fHRleHRhcmVhL2kudGVzdCh0LnRhcmdldC50YWdOYW1lKSxpPVwiRXNjYXBlXCI9PT10LmtleSxzPVtHdCxKdF0uaW5jbHVkZXModC5rZXkpO2lmKCFzJiYhaSlyZXR1cm47aWYoZSYmIWkpcmV0dXJuO3QucHJldmVudERlZmF1bHQoKTtjb25zdCBuPXRoaXMubWF0Y2hlcyhhZSk/dGhpczpWLnByZXYodGhpcyxhZSlbMF18fFYubmV4dCh0aGlzLGFlKVswXXx8Vi5maW5kT25lKGFlLHQuZGVsZWdhdGVUYXJnZXQucGFyZW50Tm9kZSksbz1iZS5nZXRPckNyZWF0ZUluc3RhbmNlKG4pO2lmKHMpcmV0dXJuIHQuc3RvcFByb3BhZ2F0aW9uKCksby5zaG93KCksdm9pZCBvLl9zZWxlY3RNZW51SXRlbSh0KTtvLl9pc1Nob3duKCkmJih0LnN0b3BQcm9wYWdhdGlvbigpLG8uaGlkZSgpLG4uZm9jdXMoKSl9fUYub24oZG9jdW1lbnQsbmUsYWUsYmUuZGF0YUFwaUtleWRvd25IYW5kbGVyKSxGLm9uKGRvY3VtZW50LG5lLGNlLGJlLmRhdGFBcGlLZXlkb3duSGFuZGxlciksRi5vbihkb2N1bWVudCxzZSxiZS5jbGVhck1lbnVzKSxGLm9uKGRvY3VtZW50LG9lLGJlLmNsZWFyTWVudXMpLEYub24oZG9jdW1lbnQsc2UsYWUsZnVuY3Rpb24odCl7dC5wcmV2ZW50RGVmYXVsdCgpLGJlLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcykudG9nZ2xlKCl9KSx2KGJlKTtjb25zdCB2ZT1cImJhY2tkcm9wXCIseWU9XCJzaG93XCIsd2U9YG1vdXNlZG93bi5icy4ke3ZlfWAsQWU9e2NsYXNzTmFtZTpcIm1vZGFsLWJhY2tkcm9wXCIsY2xpY2tDYWxsYmFjazpudWxsLGlzQW5pbWF0ZWQ6ITEsaXNWaXNpYmxlOiEwLHJvb3RFbGVtZW50OlwiYm9keVwifSxFZT17Y2xhc3NOYW1lOlwic3RyaW5nXCIsY2xpY2tDYWxsYmFjazpcIihmdW5jdGlvbnxudWxsKVwiLGlzQW5pbWF0ZWQ6XCJib29sZWFuXCIsaXNWaXNpYmxlOlwiYm9vbGVhblwiLHJvb3RFbGVtZW50OlwiKGVsZW1lbnR8c3RyaW5nKVwifTtjbGFzcyBDZSBleHRlbmRzIFd7Y29uc3RydWN0b3IodCl7c3VwZXIoKSx0aGlzLl9jb25maWc9dGhpcy5fZ2V0Q29uZmlnKHQpLHRoaXMuX2lzQXBwZW5kZWQ9ITEsdGhpcy5fZWxlbWVudD1udWxsfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBBZX1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIEVlfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVybiB2ZX1zaG93KHQpe2lmKCF0aGlzLl9jb25maWcuaXNWaXNpYmxlKXJldHVybiB2b2lkIHkodCk7dGhpcy5fYXBwZW5kKCk7Y29uc3QgZT10aGlzLl9nZXRFbGVtZW50KCk7dGhpcy5fY29uZmlnLmlzQW5pbWF0ZWQmJmYoZSksZS5jbGFzc0xpc3QuYWRkKHllKSx0aGlzLl9lbXVsYXRlQW5pbWF0aW9uKCgpPT57eSh0KX0pfWhpZGUodCl7dGhpcy5fY29uZmlnLmlzVmlzaWJsZT8odGhpcy5fZ2V0RWxlbWVudCgpLmNsYXNzTGlzdC5yZW1vdmUoeWUpLHRoaXMuX2VtdWxhdGVBbmltYXRpb24oKCk9Pnt0aGlzLmRpc3Bvc2UoKSx5KHQpfSkpOnkodCl9ZGlzcG9zZSgpe3RoaXMuX2lzQXBwZW5kZWQmJihGLm9mZih0aGlzLl9lbGVtZW50LHdlKSx0aGlzLl9lbGVtZW50LnJlbW92ZSgpLHRoaXMuX2lzQXBwZW5kZWQ9ITEpfV9nZXRFbGVtZW50KCl7aWYoIXRoaXMuX2VsZW1lbnQpe2NvbnN0IHQ9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTt0LmNsYXNzTmFtZT10aGlzLl9jb25maWcuY2xhc3NOYW1lLHRoaXMuX2NvbmZpZy5pc0FuaW1hdGVkJiZ0LmNsYXNzTGlzdC5hZGQoXCJmYWRlXCIpLHRoaXMuX2VsZW1lbnQ9dH1yZXR1cm4gdGhpcy5fZWxlbWVudH1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC5yb290RWxlbWVudD1oKHQucm9vdEVsZW1lbnQpLHR9X2FwcGVuZCgpe2lmKHRoaXMuX2lzQXBwZW5kZWQpcmV0dXJuO2NvbnN0IHQ9dGhpcy5fZ2V0RWxlbWVudCgpO3RoaXMuX2NvbmZpZy5yb290RWxlbWVudC5hcHBlbmQodCksRi5vbih0LHdlLCgpPT57eSh0aGlzLl9jb25maWcuY2xpY2tDYWxsYmFjayl9KSx0aGlzLl9pc0FwcGVuZGVkPSEwfV9lbXVsYXRlQW5pbWF0aW9uKHQpe3codCx0aGlzLl9nZXRFbGVtZW50KCksdGhpcy5fY29uZmlnLmlzQW5pbWF0ZWQpfX1jb25zdCBUZT1cIi5icy5mb2N1c3RyYXBcIixrZT1gZm9jdXNpbiR7VGV9YCwkZT1ga2V5ZG93bi50YWIke1RlfWAsU2U9XCJiYWNrd2FyZFwiLExlPXthdXRvZm9jdXM6ITAsdHJhcEVsZW1lbnQ6bnVsbH0sT2U9e2F1dG9mb2N1czpcImJvb2xlYW5cIix0cmFwRWxlbWVudDpcImVsZW1lbnRcIn07Y2xhc3MgSWUgZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQpe3N1cGVyKCksdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyh0KSx0aGlzLl9pc0FjdGl2ZT0hMSx0aGlzLl9sYXN0VGFiTmF2RGlyZWN0aW9uPW51bGx9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIExlfXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gT2V9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJmb2N1c3RyYXBcIn1hY3RpdmF0ZSgpe3RoaXMuX2lzQWN0aXZlfHwodGhpcy5fY29uZmlnLmF1dG9mb2N1cyYmdGhpcy5fY29uZmlnLnRyYXBFbGVtZW50LmZvY3VzKCksRi5vZmYoZG9jdW1lbnQsVGUpLEYub24oZG9jdW1lbnQsa2UsdD0+dGhpcy5faGFuZGxlRm9jdXNpbih0KSksRi5vbihkb2N1bWVudCwkZSx0PT50aGlzLl9oYW5kbGVLZXlkb3duKHQpKSx0aGlzLl9pc0FjdGl2ZT0hMCl9ZGVhY3RpdmF0ZSgpe3RoaXMuX2lzQWN0aXZlJiYodGhpcy5faXNBY3RpdmU9ITEsRi5vZmYoZG9jdW1lbnQsVGUpKX1faGFuZGxlRm9jdXNpbih0KXtjb25zdHt0cmFwRWxlbWVudDplfT10aGlzLl9jb25maWc7aWYodC50YXJnZXQ9PT1kb2N1bWVudHx8dC50YXJnZXQ9PT1lfHxlLmNvbnRhaW5zKHQudGFyZ2V0KSlyZXR1cm47Y29uc3QgaT1WLmZvY3VzYWJsZUNoaWxkcmVuKGUpOzA9PT1pLmxlbmd0aD9lLmZvY3VzKCk6dGhpcy5fbGFzdFRhYk5hdkRpcmVjdGlvbj09PVNlP2lbaS5sZW5ndGgtMV0uZm9jdXMoKTppWzBdLmZvY3VzKCl9X2hhbmRsZUtleWRvd24odCl7XCJUYWJcIj09PXQua2V5JiYodGhpcy5fbGFzdFRhYk5hdkRpcmVjdGlvbj10LnNoaWZ0S2V5P1NlOlwiZm9yd2FyZFwiKX19Y29uc3QgRGU9XCIuZml4ZWQtdG9wLCAuZml4ZWQtYm90dG9tLCAuaXMtZml4ZWQsIC5zdGlja3ktdG9wXCIsTmU9XCIuc3RpY2t5LXRvcFwiLFBlPVwicGFkZGluZy1yaWdodFwiLHhlPVwibWFyZ2luLXJpZ2h0XCI7Y2xhc3MgTWV7Y29uc3RydWN0b3IoKXt0aGlzLl9lbGVtZW50PWRvY3VtZW50LmJvZHl9Z2V0V2lkdGgoKXtjb25zdCB0PWRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aDtyZXR1cm4gTWF0aC5hYnMod2luZG93LmlubmVyV2lkdGgtdCl9aGlkZSgpe2NvbnN0IHQ9dGhpcy5nZXRXaWR0aCgpO3RoaXMuX2Rpc2FibGVPdmVyRmxvdygpLHRoaXMuX3NldEVsZW1lbnRBdHRyaWJ1dGVzKHRoaXMuX2VsZW1lbnQsUGUsZT0+ZSt0KSx0aGlzLl9zZXRFbGVtZW50QXR0cmlidXRlcyhEZSxQZSxlPT5lK3QpLHRoaXMuX3NldEVsZW1lbnRBdHRyaWJ1dGVzKE5lLHhlLGU9PmUtdCl9cmVzZXQoKXt0aGlzLl9yZXNldEVsZW1lbnRBdHRyaWJ1dGVzKHRoaXMuX2VsZW1lbnQsXCJvdmVyZmxvd1wiKSx0aGlzLl9yZXNldEVsZW1lbnRBdHRyaWJ1dGVzKHRoaXMuX2VsZW1lbnQsUGUpLHRoaXMuX3Jlc2V0RWxlbWVudEF0dHJpYnV0ZXMoRGUsUGUpLHRoaXMuX3Jlc2V0RWxlbWVudEF0dHJpYnV0ZXMoTmUseGUpfWlzT3ZlcmZsb3dpbmcoKXtyZXR1cm4gdGhpcy5nZXRXaWR0aCgpPjB9X2Rpc2FibGVPdmVyRmxvdygpe3RoaXMuX3NhdmVJbml0aWFsQXR0cmlidXRlKHRoaXMuX2VsZW1lbnQsXCJvdmVyZmxvd1wiKSx0aGlzLl9lbGVtZW50LnN0eWxlLm92ZXJmbG93PVwiaGlkZGVuXCJ9X3NldEVsZW1lbnRBdHRyaWJ1dGVzKHQsZSxpKXtjb25zdCBzPXRoaXMuZ2V0V2lkdGgoKTt0aGlzLl9hcHBseU1hbmlwdWxhdGlvbkNhbGxiYWNrKHQsdD0+e2lmKHQhPT10aGlzLl9lbGVtZW50JiZ3aW5kb3cuaW5uZXJXaWR0aD50LmNsaWVudFdpZHRoK3MpcmV0dXJuO3RoaXMuX3NhdmVJbml0aWFsQXR0cmlidXRlKHQsZSk7Y29uc3Qgbj13aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZSh0KS5nZXRQcm9wZXJ0eVZhbHVlKGUpO3Quc3R5bGUuc2V0UHJvcGVydHkoZSxgJHtpKE51bWJlci5wYXJzZUZsb2F0KG4pKX1weGApfSl9X3NhdmVJbml0aWFsQXR0cmlidXRlKHQsZSl7Y29uc3QgaT10LnN0eWxlLmdldFByb3BlcnR5VmFsdWUoZSk7aSYmcS5zZXREYXRhQXR0cmlidXRlKHQsZSxpKX1fcmVzZXRFbGVtZW50QXR0cmlidXRlcyh0LGUpe3RoaXMuX2FwcGx5TWFuaXB1bGF0aW9uQ2FsbGJhY2sodCx0PT57Y29uc3QgaT1xLmdldERhdGFBdHRyaWJ1dGUodCxlKTtudWxsIT09aT8ocS5yZW1vdmVEYXRhQXR0cmlidXRlKHQsZSksdC5zdHlsZS5zZXRQcm9wZXJ0eShlLGkpKTp0LnN0eWxlLnJlbW92ZVByb3BlcnR5KGUpfSl9X2FwcGx5TWFuaXB1bGF0aW9uQ2FsbGJhY2sodCxlKXtpZihjKHQpKWUodCk7ZWxzZSBmb3IoY29uc3QgaSBvZiBWLmZpbmQodCx0aGlzLl9lbGVtZW50KSllKGkpfX1jb25zdCBqZT1cIi5icy5tb2RhbFwiLEZlPWBoaWRlJHtqZX1gLHplPWBoaWRlUHJldmVudGVkJHtqZX1gLEhlPWBoaWRkZW4ke2plfWAsQmU9YHNob3cke2plfWAscWU9YHNob3duJHtqZX1gLFdlPWByZXNpemUke2plfWAsUmU9YGNsaWNrLmRpc21pc3Mke2plfWAsS2U9YG1vdXNlZG93bi5kaXNtaXNzJHtqZX1gLFZlPWBrZXlkb3duLmRpc21pc3Mke2plfWAsUWU9YGNsaWNrJHtqZX0uZGF0YS1hcGlgLFhlPVwibW9kYWwtb3BlblwiLFllPVwic2hvd1wiLFVlPVwibW9kYWwtc3RhdGljXCIsR2U9e2JhY2tkcm9wOiEwLGZvY3VzOiEwLGtleWJvYXJkOiEwfSxKZT17YmFja2Ryb3A6XCIoYm9vbGVhbnxzdHJpbmcpXCIsZm9jdXM6XCJib29sZWFuXCIsa2V5Ym9hcmQ6XCJib29sZWFuXCJ9O2NsYXNzIFplIGV4dGVuZHMgUntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5fZGlhbG9nPVYuZmluZE9uZShcIi5tb2RhbC1kaWFsb2dcIix0aGlzLl9lbGVtZW50KSx0aGlzLl9iYWNrZHJvcD10aGlzLl9pbml0aWFsaXplQmFja0Ryb3AoKSx0aGlzLl9mb2N1c3RyYXA9dGhpcy5faW5pdGlhbGl6ZUZvY3VzVHJhcCgpLHRoaXMuX2lzU2hvd249ITEsdGhpcy5faXNUcmFuc2l0aW9uaW5nPSExLHRoaXMuX3Njcm9sbEJhcj1uZXcgTWUsdGhpcy5fYWRkRXZlbnRMaXN0ZW5lcnMoKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gR2V9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBKZX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cIm1vZGFsXCJ9dG9nZ2xlKHQpe3JldHVybiB0aGlzLl9pc1Nob3duP3RoaXMuaGlkZSgpOnRoaXMuc2hvdyh0KX1zaG93KHQpe3RoaXMuX2lzU2hvd258fHRoaXMuX2lzVHJhbnNpdGlvbmluZ3x8Ri50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsQmUse3JlbGF0ZWRUYXJnZXQ6dH0pLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9pc1Nob3duPSEwLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMCx0aGlzLl9zY3JvbGxCYXIuaGlkZSgpLGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZChYZSksdGhpcy5fYWRqdXN0RGlhbG9nKCksdGhpcy5fYmFja2Ryb3Auc2hvdygoKT0+dGhpcy5fc2hvd0VsZW1lbnQodCkpKX1oaWRlKCl7dGhpcy5faXNTaG93biYmIXRoaXMuX2lzVHJhbnNpdGlvbmluZyYmKEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LEZlKS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5faXNTaG93bj0hMSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITAsdGhpcy5fZm9jdXN0cmFwLmRlYWN0aXZhdGUoKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoWWUpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9PnRoaXMuX2hpZGVNb2RhbCgpLHRoaXMuX2VsZW1lbnQsdGhpcy5faXNBbmltYXRlZCgpKSkpfWRpc3Bvc2UoKXtGLm9mZih3aW5kb3csamUpLEYub2ZmKHRoaXMuX2RpYWxvZyxqZSksdGhpcy5fYmFja2Ryb3AuZGlzcG9zZSgpLHRoaXMuX2ZvY3VzdHJhcC5kZWFjdGl2YXRlKCksc3VwZXIuZGlzcG9zZSgpfWhhbmRsZVVwZGF0ZSgpe3RoaXMuX2FkanVzdERpYWxvZygpfV9pbml0aWFsaXplQmFja0Ryb3AoKXtyZXR1cm4gbmV3IENlKHtpc1Zpc2libGU6Qm9vbGVhbih0aGlzLl9jb25maWcuYmFja2Ryb3ApLGlzQW5pbWF0ZWQ6dGhpcy5faXNBbmltYXRlZCgpfSl9X2luaXRpYWxpemVGb2N1c1RyYXAoKXtyZXR1cm4gbmV3IEllKHt0cmFwRWxlbWVudDp0aGlzLl9lbGVtZW50fSl9X3Nob3dFbGVtZW50KHQpe2RvY3VtZW50LmJvZHkuY29udGFpbnModGhpcy5fZWxlbWVudCl8fGRvY3VtZW50LmJvZHkuYXBwZW5kKHRoaXMuX2VsZW1lbnQpLHRoaXMuX2VsZW1lbnQuc3R5bGUuZGlzcGxheT1cImJsb2NrXCIsdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLWhpZGRlblwiKSx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtbW9kYWxcIiwhMCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsXCJkaWFsb2dcIiksdGhpcy5fZWxlbWVudC5zY3JvbGxUb3A9MDtjb25zdCBlPVYuZmluZE9uZShcIi5tb2RhbC1ib2R5XCIsdGhpcy5fZGlhbG9nKTtlJiYoZS5zY3JvbGxUb3A9MCksZih0aGlzLl9lbGVtZW50KSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5hZGQoWWUpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9jb25maWcuZm9jdXMmJnRoaXMuX2ZvY3VzdHJhcC5hY3RpdmF0ZSgpLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxxZSx7cmVsYXRlZFRhcmdldDp0fSl9LHRoaXMuX2RpYWxvZyx0aGlzLl9pc0FuaW1hdGVkKCkpfV9hZGRFdmVudExpc3RlbmVycygpe0Yub24odGhpcy5fZWxlbWVudCxWZSx0PT57XCJFc2NhcGVcIj09PXQua2V5JiYodGhpcy5fY29uZmlnLmtleWJvYXJkP3RoaXMuaGlkZSgpOnRoaXMuX3RyaWdnZXJCYWNrZHJvcFRyYW5zaXRpb24oKSl9KSxGLm9uKHdpbmRvdyxXZSwoKT0+e3RoaXMuX2lzU2hvd24mJiF0aGlzLl9pc1RyYW5zaXRpb25pbmcmJnRoaXMuX2FkanVzdERpYWxvZygpfSksRi5vbih0aGlzLl9lbGVtZW50LEtlLHQ9PntGLm9uZSh0aGlzLl9lbGVtZW50LFJlLGU9Pnt0aGlzLl9lbGVtZW50PT09dC50YXJnZXQmJnRoaXMuX2VsZW1lbnQ9PT1lLnRhcmdldCYmKFwic3RhdGljXCIhPT10aGlzLl9jb25maWcuYmFja2Ryb3A/dGhpcy5fY29uZmlnLmJhY2tkcm9wJiZ0aGlzLmhpZGUoKTp0aGlzLl90cmlnZ2VyQmFja2Ryb3BUcmFuc2l0aW9uKCkpfSl9KX1faGlkZU1vZGFsKCl7dGhpcy5fZWxlbWVudC5zdHlsZS5kaXNwbGF5PVwibm9uZVwiLHRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwhMCksdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLW1vZGFsXCIpLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwicm9sZVwiKSx0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITEsdGhpcy5fYmFja2Ryb3AuaGlkZSgoKT0+e2RvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZShYZSksdGhpcy5fcmVzZXRBZGp1c3RtZW50cygpLHRoaXMuX3Njcm9sbEJhci5yZXNldCgpLEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LEhlKX0pfV9pc0FuaW1hdGVkKCl7cmV0dXJuIHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZmFkZVwiKX1fdHJpZ2dlckJhY2tkcm9wVHJhbnNpdGlvbigpe2lmKEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LHplKS5kZWZhdWx0UHJldmVudGVkKXJldHVybjtjb25zdCB0PXRoaXMuX2VsZW1lbnQuc2Nyb2xsSGVpZ2h0PmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQsZT10aGlzLl9lbGVtZW50LnN0eWxlLm92ZXJmbG93WTtcImhpZGRlblwiPT09ZXx8dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoVWUpfHwodHx8KHRoaXMuX2VsZW1lbnQuc3R5bGUub3ZlcmZsb3dZPVwiaGlkZGVuXCIpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChVZSksdGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e3RoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShVZSksdGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e3RoaXMuX2VsZW1lbnQuc3R5bGUub3ZlcmZsb3dZPWV9LHRoaXMuX2RpYWxvZyl9LHRoaXMuX2RpYWxvZyksdGhpcy5fZWxlbWVudC5mb2N1cygpKX1fYWRqdXN0RGlhbG9nKCl7Y29uc3QgdD10aGlzLl9lbGVtZW50LnNjcm9sbEhlaWdodD5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0LGU9dGhpcy5fc2Nyb2xsQmFyLmdldFdpZHRoKCksaT1lPjA7aWYoaSYmIXQpe2NvbnN0IHQ9YigpP1wicGFkZGluZ0xlZnRcIjpcInBhZGRpbmdSaWdodFwiO3RoaXMuX2VsZW1lbnQuc3R5bGVbdF09YCR7ZX1weGB9aWYoIWkmJnQpe2NvbnN0IHQ9YigpP1wicGFkZGluZ1JpZ2h0XCI6XCJwYWRkaW5nTGVmdFwiO3RoaXMuX2VsZW1lbnQuc3R5bGVbdF09YCR7ZX1weGB9fV9yZXNldEFkanVzdG1lbnRzKCl7dGhpcy5fZWxlbWVudC5zdHlsZS5wYWRkaW5nTGVmdD1cIlwiLHRoaXMuX2VsZW1lbnQuc3R5bGUucGFkZGluZ1JpZ2h0PVwiXCJ9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0LGUpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXtjb25zdCBpPVplLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyx0KTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09aVt0XSl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtpW3RdKGUpfX0pfX1GLm9uKGRvY3VtZW50LFFlLCdbZGF0YS1icy10b2dnbGU9XCJtb2RhbFwiXScsZnVuY3Rpb24odCl7Y29uc3QgZT1WLmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodGhpcyk7W1wiQVwiLFwiQVJFQVwiXS5pbmNsdWRlcyh0aGlzLnRhZ05hbWUpJiZ0LnByZXZlbnREZWZhdWx0KCksRi5vbmUoZSxCZSx0PT57dC5kZWZhdWx0UHJldmVudGVkfHxGLm9uZShlLEhlLCgpPT57ZCh0aGlzKSYmdGhpcy5mb2N1cygpfSl9KTtjb25zdCBpPVYuZmluZE9uZShcIi5tb2RhbC5zaG93XCIpO2kmJlplLmdldEluc3RhbmNlKGkpLmhpZGUoKSxaZS5nZXRPckNyZWF0ZUluc3RhbmNlKGUpLnRvZ2dsZSh0aGlzKX0pLFEoWmUpLHYoWmUpO2NvbnN0IHRpPVwiLmJzLm9mZmNhbnZhc1wiLGVpPVwiLmRhdGEtYXBpXCIsaWk9YGxvYWQke3RpfSR7ZWl9YCxzaT1cInNob3dcIixuaT1cInNob3dpbmdcIixvaT1cImhpZGluZ1wiLHJpPVwiLm9mZmNhbnZhcy5zaG93XCIsYWk9YHNob3cke3RpfWAsbGk9YHNob3duJHt0aX1gLGNpPWBoaWRlJHt0aX1gLGhpPWBoaWRlUHJldmVudGVkJHt0aX1gLGRpPWBoaWRkZW4ke3RpfWAsdWk9YHJlc2l6ZSR7dGl9YCxfaT1gY2xpY2ske3RpfSR7ZWl9YCxnaT1ga2V5ZG93bi5kaXNtaXNzJHt0aX1gLGZpPXtiYWNrZHJvcDohMCxrZXlib2FyZDohMCxzY3JvbGw6ITF9LG1pPXtiYWNrZHJvcDpcIihib29sZWFufHN0cmluZylcIixrZXlib2FyZDpcImJvb2xlYW5cIixzY3JvbGw6XCJib29sZWFuXCJ9O2NsYXNzIHBpIGV4dGVuZHMgUntjb25zdHJ1Y3Rvcih0LGUpe3N1cGVyKHQsZSksdGhpcy5faXNTaG93bj0hMSx0aGlzLl9iYWNrZHJvcD10aGlzLl9pbml0aWFsaXplQmFja0Ryb3AoKSx0aGlzLl9mb2N1c3RyYXA9dGhpcy5faW5pdGlhbGl6ZUZvY3VzVHJhcCgpLHRoaXMuX2FkZEV2ZW50TGlzdGVuZXJzKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIGZpfXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gbWl9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJvZmZjYW52YXNcIn10b2dnbGUodCl7cmV0dXJuIHRoaXMuX2lzU2hvd24/dGhpcy5oaWRlKCk6dGhpcy5zaG93KHQpfXNob3codCl7dGhpcy5faXNTaG93bnx8Ri50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsYWkse3JlbGF0ZWRUYXJnZXQ6dH0pLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9pc1Nob3duPSEwLHRoaXMuX2JhY2tkcm9wLnNob3coKSx0aGlzLl9jb25maWcuc2Nyb2xsfHwobmV3IE1lKS5oaWRlKCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLW1vZGFsXCIsITApLHRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwicm9sZVwiLFwiZGlhbG9nXCIpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChuaSksdGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e3RoaXMuX2NvbmZpZy5zY3JvbGwmJiF0aGlzLl9jb25maWcuYmFja2Ryb3B8fHRoaXMuX2ZvY3VzdHJhcC5hY3RpdmF0ZSgpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChzaSksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKG5pKSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxsaSx7cmVsYXRlZFRhcmdldDp0fSl9LHRoaXMuX2VsZW1lbnQsITApKX1oaWRlKCl7dGhpcy5faXNTaG93biYmKEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LGNpKS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5fZm9jdXN0cmFwLmRlYWN0aXZhdGUoKSx0aGlzLl9lbGVtZW50LmJsdXIoKSx0aGlzLl9pc1Nob3duPSExLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChvaSksdGhpcy5fYmFja2Ryb3AuaGlkZSgpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9Pnt0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoc2ksb2kpLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1tb2RhbFwiKSx0aGlzLl9lbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcInJvbGVcIiksdGhpcy5fY29uZmlnLnNjcm9sbHx8KG5ldyBNZSkucmVzZXQoKSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxkaSl9LHRoaXMuX2VsZW1lbnQsITApKSl9ZGlzcG9zZSgpe3RoaXMuX2JhY2tkcm9wLmRpc3Bvc2UoKSx0aGlzLl9mb2N1c3RyYXAuZGVhY3RpdmF0ZSgpLHN1cGVyLmRpc3Bvc2UoKX1faW5pdGlhbGl6ZUJhY2tEcm9wKCl7Y29uc3QgdD1Cb29sZWFuKHRoaXMuX2NvbmZpZy5iYWNrZHJvcCk7cmV0dXJuIG5ldyBDZSh7Y2xhc3NOYW1lOlwib2ZmY2FudmFzLWJhY2tkcm9wXCIsaXNWaXNpYmxlOnQsaXNBbmltYXRlZDohMCxyb290RWxlbWVudDp0aGlzLl9lbGVtZW50LnBhcmVudE5vZGUsY2xpY2tDYWxsYmFjazp0PygpPT57XCJzdGF0aWNcIiE9PXRoaXMuX2NvbmZpZy5iYWNrZHJvcD90aGlzLmhpZGUoKTpGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxoaSl9Om51bGx9KX1faW5pdGlhbGl6ZUZvY3VzVHJhcCgpe3JldHVybiBuZXcgSWUoe3RyYXBFbGVtZW50OnRoaXMuX2VsZW1lbnR9KX1fYWRkRXZlbnRMaXN0ZW5lcnMoKXtGLm9uKHRoaXMuX2VsZW1lbnQsZ2ksdD0+e1wiRXNjYXBlXCI9PT10LmtleSYmKHRoaXMuX2NvbmZpZy5rZXlib2FyZD90aGlzLmhpZGUoKTpGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxoaSkpfSl9c3RhdGljIGpRdWVyeUludGVyZmFjZSh0KXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7Y29uc3QgZT1waS5nZXRPckNyZWF0ZUluc3RhbmNlKHRoaXMsdCk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF18fHQuc3RhcnRzV2l0aChcIl9cIil8fFwiY29uc3RydWN0b3JcIj09PXQpdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSh0aGlzKX19KX19Ri5vbihkb2N1bWVudCxfaSwnW2RhdGEtYnMtdG9nZ2xlPVwib2ZmY2FudmFzXCJdJyxmdW5jdGlvbih0KXtjb25zdCBlPVYuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0aGlzKTtpZihbXCJBXCIsXCJBUkVBXCJdLmluY2x1ZGVzKHRoaXMudGFnTmFtZSkmJnQucHJldmVudERlZmF1bHQoKSx1KHRoaXMpKXJldHVybjtGLm9uZShlLGRpLCgpPT57ZCh0aGlzKSYmdGhpcy5mb2N1cygpfSk7Y29uc3QgaT1WLmZpbmRPbmUocmkpO2kmJmkhPT1lJiZwaS5nZXRJbnN0YW5jZShpKS5oaWRlKCkscGkuZ2V0T3JDcmVhdGVJbnN0YW5jZShlKS50b2dnbGUodGhpcyl9KSxGLm9uKHdpbmRvdyxpaSwoKT0+e2Zvcihjb25zdCB0IG9mIFYuZmluZChyaSkpcGkuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0KS5zaG93KCl9KSxGLm9uKHdpbmRvdyx1aSwoKT0+e2Zvcihjb25zdCB0IG9mIFYuZmluZChcIlthcmlhLW1vZGFsXVtjbGFzcyo9c2hvd11bY2xhc3MqPW9mZmNhbnZhcy1dXCIpKVwiZml4ZWRcIiE9PWdldENvbXB1dGVkU3R5bGUodCkucG9zaXRpb24mJnBpLmdldE9yQ3JlYXRlSW5zdGFuY2UodCkuaGlkZSgpfSksUShwaSksdihwaSk7Y29uc3QgYmk9e1wiKlwiOltcImNsYXNzXCIsXCJkaXJcIixcImlkXCIsXCJsYW5nXCIsXCJyb2xlXCIsL15hcmlhLVtcXHctXSokL2ldLGE6W1widGFyZ2V0XCIsXCJocmVmXCIsXCJ0aXRsZVwiLFwicmVsXCJdLGFyZWE6W10sYjpbXSxicjpbXSxjb2w6W10sY29kZTpbXSxkZDpbXSxkaXY6W10sZGw6W10sZHQ6W10sZW06W10saHI6W10saDE6W10saDI6W10saDM6W10saDQ6W10saDU6W10saDY6W10saTpbXSxpbWc6W1wic3JjXCIsXCJzcmNzZXRcIixcImFsdFwiLFwidGl0bGVcIixcIndpZHRoXCIsXCJoZWlnaHRcIl0sbGk6W10sb2w6W10scDpbXSxwcmU6W10sczpbXSxzbWFsbDpbXSxzcGFuOltdLHN1YjpbXSxzdXA6W10sc3Ryb25nOltdLHU6W10sdWw6W119LHZpPW5ldyBTZXQoW1wiYmFja2dyb3VuZFwiLFwiY2l0ZVwiLFwiaHJlZlwiLFwiaXRlbXR5cGVcIixcImxvbmdkZXNjXCIsXCJwb3N0ZXJcIixcInNyY1wiLFwieGxpbms6aHJlZlwiXSkseWk9L14oPyFqYXZhc2NyaXB0OikoPzpbYS16MC05Ky4tXSs6fFteJjovPyNdKig/OlsvPyNdfCQpKS9pLHdpPSh0LGUpPT57Y29uc3QgaT10Lm5vZGVOYW1lLnRvTG93ZXJDYXNlKCk7cmV0dXJuIGUuaW5jbHVkZXMoaSk/IXZpLmhhcyhpKXx8Qm9vbGVhbih5aS50ZXN0KHQubm9kZVZhbHVlKSk6ZS5maWx0ZXIodD0+dCBpbnN0YW5jZW9mIFJlZ0V4cCkuc29tZSh0PT50LnRlc3QoaSkpfSxBaT17YWxsb3dMaXN0OmJpLGNvbnRlbnQ6e30sZXh0cmFDbGFzczpcIlwiLGh0bWw6ITEsc2FuaXRpemU6ITAsc2FuaXRpemVGbjpudWxsLHRlbXBsYXRlOlwiPGRpdj48L2Rpdj5cIn0sRWk9e2FsbG93TGlzdDpcIm9iamVjdFwiLGNvbnRlbnQ6XCJvYmplY3RcIixleHRyYUNsYXNzOlwiKHN0cmluZ3xmdW5jdGlvbilcIixodG1sOlwiYm9vbGVhblwiLHNhbml0aXplOlwiYm9vbGVhblwiLHNhbml0aXplRm46XCIobnVsbHxmdW5jdGlvbilcIix0ZW1wbGF0ZTpcInN0cmluZ1wifSxDaT17ZW50cnk6XCIoc3RyaW5nfGVsZW1lbnR8ZnVuY3Rpb258bnVsbClcIixzZWxlY3RvcjpcIihzdHJpbmd8ZWxlbWVudClcIn07Y2xhc3MgVGkgZXh0ZW5kcyBXe2NvbnN0cnVjdG9yKHQpe3N1cGVyKCksdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyh0KX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gQWl9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBFaX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cIlRlbXBsYXRlRmFjdG9yeVwifWdldENvbnRlbnQoKXtyZXR1cm4gT2JqZWN0LnZhbHVlcyh0aGlzLl9jb25maWcuY29udGVudCkubWFwKHQ9PnRoaXMuX3Jlc29sdmVQb3NzaWJsZUZ1bmN0aW9uKHQpKS5maWx0ZXIoQm9vbGVhbil9aGFzQ29udGVudCgpe3JldHVybiB0aGlzLmdldENvbnRlbnQoKS5sZW5ndGg+MH1jaGFuZ2VDb250ZW50KHQpe3JldHVybiB0aGlzLl9jaGVja0NvbnRlbnQodCksdGhpcy5fY29uZmlnLmNvbnRlbnQ9ey4uLnRoaXMuX2NvbmZpZy5jb250ZW50LC4uLnR9LHRoaXN9dG9IdG1sKCl7Y29uc3QgdD1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO3QuaW5uZXJIVE1MPXRoaXMuX21heWJlU2FuaXRpemUodGhpcy5fY29uZmlnLnRlbXBsYXRlKTtmb3IoY29uc3RbZSxpXW9mIE9iamVjdC5lbnRyaWVzKHRoaXMuX2NvbmZpZy5jb250ZW50KSl0aGlzLl9zZXRDb250ZW50KHQsaSxlKTtjb25zdCBlPXQuY2hpbGRyZW5bMF0saT10aGlzLl9yZXNvbHZlUG9zc2libGVGdW5jdGlvbih0aGlzLl9jb25maWcuZXh0cmFDbGFzcyk7cmV0dXJuIGkmJmUuY2xhc3NMaXN0LmFkZCguLi5pLnNwbGl0KFwiIFwiKSksZX1fdHlwZUNoZWNrQ29uZmlnKHQpe3N1cGVyLl90eXBlQ2hlY2tDb25maWcodCksdGhpcy5fY2hlY2tDb250ZW50KHQuY29udGVudCl9X2NoZWNrQ29udGVudCh0KXtmb3IoY29uc3RbZSxpXW9mIE9iamVjdC5lbnRyaWVzKHQpKXN1cGVyLl90eXBlQ2hlY2tDb25maWcoe3NlbGVjdG9yOmUsZW50cnk6aX0sQ2kpfV9zZXRDb250ZW50KHQsZSxpKXtjb25zdCBzPVYuZmluZE9uZShpLHQpO3MmJigoZT10aGlzLl9yZXNvbHZlUG9zc2libGVGdW5jdGlvbihlKSk/YyhlKT90aGlzLl9wdXRFbGVtZW50SW5UZW1wbGF0ZShoKGUpLHMpOnRoaXMuX2NvbmZpZy5odG1sP3MuaW5uZXJIVE1MPXRoaXMuX21heWJlU2FuaXRpemUoZSk6cy50ZXh0Q29udGVudD1lOnMucmVtb3ZlKCkpfV9tYXliZVNhbml0aXplKHQpe3JldHVybiB0aGlzLl9jb25maWcuc2FuaXRpemU/ZnVuY3Rpb24odCxlLGkpe2lmKCF0Lmxlbmd0aClyZXR1cm4gdDtpZihpJiZcImZ1bmN0aW9uXCI9PXR5cGVvZiBpKXJldHVybiBpKHQpO2NvbnN0IHM9KG5ldyB3aW5kb3cuRE9NUGFyc2VyKS5wYXJzZUZyb21TdHJpbmcodCxcInRleHQvaHRtbFwiKSxuPVtdLmNvbmNhdCguLi5zLmJvZHkucXVlcnlTZWxlY3RvckFsbChcIipcIikpO2Zvcihjb25zdCB0IG9mIG4pe2NvbnN0IGk9dC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpO2lmKCFPYmplY3Qua2V5cyhlKS5pbmNsdWRlcyhpKSl7dC5yZW1vdmUoKTtjb250aW51ZX1jb25zdCBzPVtdLmNvbmNhdCguLi50LmF0dHJpYnV0ZXMpLG49W10uY29uY2F0KGVbXCIqXCJdfHxbXSxlW2ldfHxbXSk7Zm9yKGNvbnN0IGUgb2Ygcyl3aShlLG4pfHx0LnJlbW92ZUF0dHJpYnV0ZShlLm5vZGVOYW1lKX1yZXR1cm4gcy5ib2R5LmlubmVySFRNTH0odCx0aGlzLl9jb25maWcuYWxsb3dMaXN0LHRoaXMuX2NvbmZpZy5zYW5pdGl6ZUZuKTp0fV9yZXNvbHZlUG9zc2libGVGdW5jdGlvbih0KXtyZXR1cm4geSh0LFt2b2lkIDAsdGhpc10pfV9wdXRFbGVtZW50SW5UZW1wbGF0ZSh0LGUpe2lmKHRoaXMuX2NvbmZpZy5odG1sKXJldHVybiBlLmlubmVySFRNTD1cIlwiLHZvaWQgZS5hcHBlbmQodCk7ZS50ZXh0Q29udGVudD10LnRleHRDb250ZW50fX1jb25zdCBraT1uZXcgU2V0KFtcInNhbml0aXplXCIsXCJhbGxvd0xpc3RcIixcInNhbml0aXplRm5cIl0pLCRpPVwiZmFkZVwiLFNpPVwic2hvd1wiLExpPVwiLnRvb2x0aXAtaW5uZXJcIixPaT1cIi5tb2RhbFwiLElpPVwiaGlkZS5icy5tb2RhbFwiLERpPVwiaG92ZXJcIixOaT1cImZvY3VzXCIsUGk9XCJjbGlja1wiLHhpPXtBVVRPOlwiYXV0b1wiLFRPUDpcInRvcFwiLFJJR0hUOmIoKT9cImxlZnRcIjpcInJpZ2h0XCIsQk9UVE9NOlwiYm90dG9tXCIsTEVGVDpiKCk/XCJyaWdodFwiOlwibGVmdFwifSxNaT17YWxsb3dMaXN0OmJpLGFuaW1hdGlvbjohMCxib3VuZGFyeTpcImNsaXBwaW5nUGFyZW50c1wiLGNvbnRhaW5lcjohMSxjdXN0b21DbGFzczpcIlwiLGRlbGF5OjAsZmFsbGJhY2tQbGFjZW1lbnRzOltcInRvcFwiLFwicmlnaHRcIixcImJvdHRvbVwiLFwibGVmdFwiXSxodG1sOiExLG9mZnNldDpbMCw2XSxwbGFjZW1lbnQ6XCJ0b3BcIixwb3BwZXJDb25maWc6bnVsbCxzYW5pdGl6ZTohMCxzYW5pdGl6ZUZuOm51bGwsc2VsZWN0b3I6ITEsdGVtcGxhdGU6JzxkaXYgY2xhc3M9XCJ0b29sdGlwXCIgcm9sZT1cInRvb2x0aXBcIj48ZGl2IGNsYXNzPVwidG9vbHRpcC1hcnJvd1wiPjwvZGl2PjxkaXYgY2xhc3M9XCJ0b29sdGlwLWlubmVyXCI+PC9kaXY+PC9kaXY+Jyx0aXRsZTpcIlwiLHRyaWdnZXI6XCJob3ZlciBmb2N1c1wifSxqaT17YWxsb3dMaXN0Olwib2JqZWN0XCIsYW5pbWF0aW9uOlwiYm9vbGVhblwiLGJvdW5kYXJ5OlwiKHN0cmluZ3xlbGVtZW50KVwiLGNvbnRhaW5lcjpcIihzdHJpbmd8ZWxlbWVudHxib29sZWFuKVwiLGN1c3RvbUNsYXNzOlwiKHN0cmluZ3xmdW5jdGlvbilcIixkZWxheTpcIihudW1iZXJ8b2JqZWN0KVwiLGZhbGxiYWNrUGxhY2VtZW50czpcImFycmF5XCIsaHRtbDpcImJvb2xlYW5cIixvZmZzZXQ6XCIoYXJyYXl8c3RyaW5nfGZ1bmN0aW9uKVwiLHBsYWNlbWVudDpcIihzdHJpbmd8ZnVuY3Rpb24pXCIscG9wcGVyQ29uZmlnOlwiKG51bGx8b2JqZWN0fGZ1bmN0aW9uKVwiLHNhbml0aXplOlwiYm9vbGVhblwiLHNhbml0aXplRm46XCIobnVsbHxmdW5jdGlvbilcIixzZWxlY3RvcjpcIihzdHJpbmd8Ym9vbGVhbilcIix0ZW1wbGF0ZTpcInN0cmluZ1wiLHRpdGxlOlwiKHN0cmluZ3xlbGVtZW50fGZ1bmN0aW9uKVwiLHRyaWdnZXI6XCJzdHJpbmdcIn07Y2xhc3MgRmkgZXh0ZW5kcyBSe2NvbnN0cnVjdG9yKHQsZSl7aWYodm9pZCAwPT09aSl0aHJvdyBuZXcgVHlwZUVycm9yKFwiQm9vdHN0cmFwJ3MgdG9vbHRpcHMgcmVxdWlyZSBQb3BwZXIgKGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyLylcIik7c3VwZXIodCxlKSx0aGlzLl9pc0VuYWJsZWQ9ITAsdGhpcy5fdGltZW91dD0wLHRoaXMuX2lzSG92ZXJlZD1udWxsLHRoaXMuX2FjdGl2ZVRyaWdnZXI9e30sdGhpcy5fcG9wcGVyPW51bGwsdGhpcy5fdGVtcGxhdGVGYWN0b3J5PW51bGwsdGhpcy5fbmV3Q29udGVudD1udWxsLHRoaXMudGlwPW51bGwsdGhpcy5fc2V0TGlzdGVuZXJzKCksdGhpcy5fY29uZmlnLnNlbGVjdG9yfHx0aGlzLl9maXhUaXRsZSgpfXN0YXRpYyBnZXQgRGVmYXVsdCgpe3JldHVybiBNaX1zdGF0aWMgZ2V0IERlZmF1bHRUeXBlKCl7cmV0dXJuIGppfXN0YXRpYyBnZXQgTkFNRSgpe3JldHVyblwidG9vbHRpcFwifWVuYWJsZSgpe3RoaXMuX2lzRW5hYmxlZD0hMH1kaXNhYmxlKCl7dGhpcy5faXNFbmFibGVkPSExfXRvZ2dsZUVuYWJsZWQoKXt0aGlzLl9pc0VuYWJsZWQ9IXRoaXMuX2lzRW5hYmxlZH10b2dnbGUoKXt0aGlzLl9pc0VuYWJsZWQmJih0aGlzLl9pc1Nob3duKCk/dGhpcy5fbGVhdmUoKTp0aGlzLl9lbnRlcigpKX1kaXNwb3NlKCl7Y2xlYXJUaW1lb3V0KHRoaXMuX3RpbWVvdXQpLEYub2ZmKHRoaXMuX2VsZW1lbnQuY2xvc2VzdChPaSksSWksdGhpcy5faGlkZU1vZGFsSGFuZGxlciksdGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLW9yaWdpbmFsLXRpdGxlXCIpJiZ0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcInRpdGxlXCIsdGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLW9yaWdpbmFsLXRpdGxlXCIpKSx0aGlzLl9kaXNwb3NlUG9wcGVyKCksc3VwZXIuZGlzcG9zZSgpfXNob3coKXtpZihcIm5vbmVcIj09PXRoaXMuX2VsZW1lbnQuc3R5bGUuZGlzcGxheSl0aHJvdyBuZXcgRXJyb3IoXCJQbGVhc2UgdXNlIHNob3cgb24gdmlzaWJsZSBlbGVtZW50c1wiKTtpZighdGhpcy5faXNXaXRoQ29udGVudCgpfHwhdGhpcy5faXNFbmFibGVkKXJldHVybjtjb25zdCB0PUYudHJpZ2dlcih0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwic2hvd1wiKSksZT0oXyh0aGlzLl9lbGVtZW50KXx8dGhpcy5fZWxlbWVudC5vd25lckRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuY29udGFpbnModGhpcy5fZWxlbWVudCk7aWYodC5kZWZhdWx0UHJldmVudGVkfHwhZSlyZXR1cm47dGhpcy5fZGlzcG9zZVBvcHBlcigpO2NvbnN0IGk9dGhpcy5fZ2V0VGlwRWxlbWVudCgpO3RoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwiYXJpYS1kZXNjcmliZWRieVwiLGkuZ2V0QXR0cmlidXRlKFwiaWRcIikpO2NvbnN0e2NvbnRhaW5lcjpzfT10aGlzLl9jb25maWc7aWYodGhpcy5fZWxlbWVudC5vd25lckRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jb250YWlucyh0aGlzLnRpcCl8fChzLmFwcGVuZChpKSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImluc2VydGVkXCIpKSksdGhpcy5fcG9wcGVyPXRoaXMuX2NyZWF0ZVBvcHBlcihpKSxpLmNsYXNzTGlzdC5hZGQoU2kpLFwib250b3VjaHN0YXJ0XCJpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpZm9yKGNvbnN0IHQgb2ZbXS5jb25jYXQoLi4uZG9jdW1lbnQuYm9keS5jaGlsZHJlbikpRi5vbih0LFwibW91c2VvdmVyXCIsZyk7dGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e0YudHJpZ2dlcih0aGlzLl9lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwic2hvd25cIikpLCExPT09dGhpcy5faXNIb3ZlcmVkJiZ0aGlzLl9sZWF2ZSgpLHRoaXMuX2lzSG92ZXJlZD0hMX0sdGhpcy50aXAsdGhpcy5faXNBbmltYXRlZCgpKX1oaWRlKCl7aWYodGhpcy5faXNTaG93bigpJiYhRi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsdGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJoaWRlXCIpKS5kZWZhdWx0UHJldmVudGVkKXtpZih0aGlzLl9nZXRUaXBFbGVtZW50KCkuY2xhc3NMaXN0LnJlbW92ZShTaSksXCJvbnRvdWNoc3RhcnRcImluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudClmb3IoY29uc3QgdCBvZltdLmNvbmNhdCguLi5kb2N1bWVudC5ib2R5LmNoaWxkcmVuKSlGLm9mZih0LFwibW91c2VvdmVyXCIsZyk7dGhpcy5fYWN0aXZlVHJpZ2dlcltQaV09ITEsdGhpcy5fYWN0aXZlVHJpZ2dlcltOaV09ITEsdGhpcy5fYWN0aXZlVHJpZ2dlcltEaV09ITEsdGhpcy5faXNIb3ZlcmVkPW51bGwsdGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e3RoaXMuX2lzV2l0aEFjdGl2ZVRyaWdnZXIoKXx8KHRoaXMuX2lzSG92ZXJlZHx8dGhpcy5fZGlzcG9zZVBvcHBlcigpLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1kZXNjcmliZWRieVwiKSxGLnRyaWdnZXIodGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImhpZGRlblwiKSkpfSx0aGlzLnRpcCx0aGlzLl9pc0FuaW1hdGVkKCkpfX11cGRhdGUoKXt0aGlzLl9wb3BwZXImJnRoaXMuX3BvcHBlci51cGRhdGUoKX1faXNXaXRoQ29udGVudCgpe3JldHVybiBCb29sZWFuKHRoaXMuX2dldFRpdGxlKCkpfV9nZXRUaXBFbGVtZW50KCl7cmV0dXJuIHRoaXMudGlwfHwodGhpcy50aXA9dGhpcy5fY3JlYXRlVGlwRWxlbWVudCh0aGlzLl9uZXdDb250ZW50fHx0aGlzLl9nZXRDb250ZW50Rm9yVGVtcGxhdGUoKSkpLHRoaXMudGlwfV9jcmVhdGVUaXBFbGVtZW50KHQpe2NvbnN0IGU9dGhpcy5fZ2V0VGVtcGxhdGVGYWN0b3J5KHQpLnRvSHRtbCgpO2lmKCFlKXJldHVybiBudWxsO2UuY2xhc3NMaXN0LnJlbW92ZSgkaSxTaSksZS5jbGFzc0xpc3QuYWRkKGBicy0ke3RoaXMuY29uc3RydWN0b3IuTkFNRX0tYXV0b2ApO2NvbnN0IGk9KHQ9Pntkb3t0Kz1NYXRoLmZsb29yKDFlNipNYXRoLnJhbmRvbSgpKX13aGlsZShkb2N1bWVudC5nZXRFbGVtZW50QnlJZCh0KSk7cmV0dXJuIHR9KSh0aGlzLmNvbnN0cnVjdG9yLk5BTUUpLnRvU3RyaW5nKCk7cmV0dXJuIGUuc2V0QXR0cmlidXRlKFwiaWRcIixpKSx0aGlzLl9pc0FuaW1hdGVkKCkmJmUuY2xhc3NMaXN0LmFkZCgkaSksZX1zZXRDb250ZW50KHQpe3RoaXMuX25ld0NvbnRlbnQ9dCx0aGlzLl9pc1Nob3duKCkmJih0aGlzLl9kaXNwb3NlUG9wcGVyKCksdGhpcy5zaG93KCkpfV9nZXRUZW1wbGF0ZUZhY3RvcnkodCl7cmV0dXJuIHRoaXMuX3RlbXBsYXRlRmFjdG9yeT90aGlzLl90ZW1wbGF0ZUZhY3RvcnkuY2hhbmdlQ29udGVudCh0KTp0aGlzLl90ZW1wbGF0ZUZhY3Rvcnk9bmV3IFRpKHsuLi50aGlzLl9jb25maWcsY29udGVudDp0LGV4dHJhQ2xhc3M6dGhpcy5fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odGhpcy5fY29uZmlnLmN1c3RvbUNsYXNzKX0pLHRoaXMuX3RlbXBsYXRlRmFjdG9yeX1fZ2V0Q29udGVudEZvclRlbXBsYXRlKCl7cmV0dXJue1tMaV06dGhpcy5fZ2V0VGl0bGUoKX19X2dldFRpdGxlKCl7cmV0dXJuIHRoaXMuX3Jlc29sdmVQb3NzaWJsZUZ1bmN0aW9uKHRoaXMuX2NvbmZpZy50aXRsZSl8fHRoaXMuX2VsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS1icy1vcmlnaW5hbC10aXRsZVwiKX1faW5pdGlhbGl6ZU9uRGVsZWdhdGVkVGFyZ2V0KHQpe3JldHVybiB0aGlzLmNvbnN0cnVjdG9yLmdldE9yQ3JlYXRlSW5zdGFuY2UodC5kZWxlZ2F0ZVRhcmdldCx0aGlzLl9nZXREZWxlZ2F0ZUNvbmZpZygpKX1faXNBbmltYXRlZCgpe3JldHVybiB0aGlzLl9jb25maWcuYW5pbWF0aW9ufHx0aGlzLnRpcCYmdGhpcy50aXAuY2xhc3NMaXN0LmNvbnRhaW5zKCRpKX1faXNTaG93bigpe3JldHVybiB0aGlzLnRpcCYmdGhpcy50aXAuY2xhc3NMaXN0LmNvbnRhaW5zKFNpKX1fY3JlYXRlUG9wcGVyKHQpe2NvbnN0IGU9eSh0aGlzLl9jb25maWcucGxhY2VtZW50LFt0aGlzLHQsdGhpcy5fZWxlbWVudF0pLHM9eGlbZS50b1VwcGVyQ2FzZSgpXTtyZXR1cm4gaS5jcmVhdGVQb3BwZXIodGhpcy5fZWxlbWVudCx0LHRoaXMuX2dldFBvcHBlckNvbmZpZyhzKSl9X2dldE9mZnNldCgpe2NvbnN0e29mZnNldDp0fT10aGlzLl9jb25maWc7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHQ/dC5zcGxpdChcIixcIikubWFwKHQ9Pk51bWJlci5wYXJzZUludCh0LDEwKSk6XCJmdW5jdGlvblwiPT10eXBlb2YgdD9lPT50KGUsdGhpcy5fZWxlbWVudCk6dH1fcmVzb2x2ZVBvc3NpYmxlRnVuY3Rpb24odCl7cmV0dXJuIHkodCxbdGhpcy5fZWxlbWVudCx0aGlzLl9lbGVtZW50XSl9X2dldFBvcHBlckNvbmZpZyh0KXtjb25zdCBlPXtwbGFjZW1lbnQ6dCxtb2RpZmllcnM6W3tuYW1lOlwiZmxpcFwiLG9wdGlvbnM6e2ZhbGxiYWNrUGxhY2VtZW50czp0aGlzLl9jb25maWcuZmFsbGJhY2tQbGFjZW1lbnRzfX0se25hbWU6XCJvZmZzZXRcIixvcHRpb25zOntvZmZzZXQ6dGhpcy5fZ2V0T2Zmc2V0KCl9fSx7bmFtZTpcInByZXZlbnRPdmVyZmxvd1wiLG9wdGlvbnM6e2JvdW5kYXJ5OnRoaXMuX2NvbmZpZy5ib3VuZGFyeX19LHtuYW1lOlwiYXJyb3dcIixvcHRpb25zOntlbGVtZW50OmAuJHt0aGlzLmNvbnN0cnVjdG9yLk5BTUV9LWFycm93YH19LHtuYW1lOlwicHJlU2V0UGxhY2VtZW50XCIsZW5hYmxlZDohMCxwaGFzZTpcImJlZm9yZU1haW5cIixmbjp0PT57dGhpcy5fZ2V0VGlwRWxlbWVudCgpLnNldEF0dHJpYnV0ZShcImRhdGEtcG9wcGVyLXBsYWNlbWVudFwiLHQuc3RhdGUucGxhY2VtZW50KX19XX07cmV0dXJuey4uLmUsLi4ueSh0aGlzLl9jb25maWcucG9wcGVyQ29uZmlnLFt2b2lkIDAsZV0pfX1fc2V0TGlzdGVuZXJzKCl7Y29uc3QgdD10aGlzLl9jb25maWcudHJpZ2dlci5zcGxpdChcIiBcIik7Zm9yKGNvbnN0IGUgb2YgdClpZihcImNsaWNrXCI9PT1lKUYub24odGhpcy5fZWxlbWVudCx0aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcImNsaWNrXCIpLHRoaXMuX2NvbmZpZy5zZWxlY3Rvcix0PT57Y29uc3QgZT10aGlzLl9pbml0aWFsaXplT25EZWxlZ2F0ZWRUYXJnZXQodCk7ZS5fYWN0aXZlVHJpZ2dlcltQaV09IShlLl9pc1Nob3duKCkmJmUuX2FjdGl2ZVRyaWdnZXJbUGldKSxlLnRvZ2dsZSgpfSk7ZWxzZSBpZihcIm1hbnVhbFwiIT09ZSl7Y29uc3QgdD1lPT09RGk/dGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJtb3VzZWVudGVyXCIpOnRoaXMuY29uc3RydWN0b3IuZXZlbnROYW1lKFwiZm9jdXNpblwiKSxpPWU9PT1EaT90aGlzLmNvbnN0cnVjdG9yLmV2ZW50TmFtZShcIm1vdXNlbGVhdmVcIik6dGhpcy5jb25zdHJ1Y3Rvci5ldmVudE5hbWUoXCJmb2N1c291dFwiKTtGLm9uKHRoaXMuX2VsZW1lbnQsdCx0aGlzLl9jb25maWcuc2VsZWN0b3IsdD0+e2NvbnN0IGU9dGhpcy5faW5pdGlhbGl6ZU9uRGVsZWdhdGVkVGFyZ2V0KHQpO2UuX2FjdGl2ZVRyaWdnZXJbXCJmb2N1c2luXCI9PT10LnR5cGU/Tmk6RGldPSEwLGUuX2VudGVyKCl9KSxGLm9uKHRoaXMuX2VsZW1lbnQsaSx0aGlzLl9jb25maWcuc2VsZWN0b3IsdD0+e2NvbnN0IGU9dGhpcy5faW5pdGlhbGl6ZU9uRGVsZWdhdGVkVGFyZ2V0KHQpO2UuX2FjdGl2ZVRyaWdnZXJbXCJmb2N1c291dFwiPT09dC50eXBlP05pOkRpXT1lLl9lbGVtZW50LmNvbnRhaW5zKHQucmVsYXRlZFRhcmdldCksZS5fbGVhdmUoKX0pfXRoaXMuX2hpZGVNb2RhbEhhbmRsZXI9KCk9Pnt0aGlzLl9lbGVtZW50JiZ0aGlzLmhpZGUoKX0sRi5vbih0aGlzLl9lbGVtZW50LmNsb3Nlc3QoT2kpLElpLHRoaXMuX2hpZGVNb2RhbEhhbmRsZXIpfV9maXhUaXRsZSgpe2NvbnN0IHQ9dGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKTt0JiYodGhpcy5fZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpfHx0aGlzLl9lbGVtZW50LnRleHRDb250ZW50LnRyaW0oKXx8dGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsdCksdGhpcy5fZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJkYXRhLWJzLW9yaWdpbmFsLXRpdGxlXCIsdCksdGhpcy5fZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoXCJ0aXRsZVwiKSl9X2VudGVyKCl7dGhpcy5faXNTaG93bigpfHx0aGlzLl9pc0hvdmVyZWQ/dGhpcy5faXNIb3ZlcmVkPSEwOih0aGlzLl9pc0hvdmVyZWQ9ITAsdGhpcy5fc2V0VGltZW91dCgoKT0+e3RoaXMuX2lzSG92ZXJlZCYmdGhpcy5zaG93KCl9LHRoaXMuX2NvbmZpZy5kZWxheS5zaG93KSl9X2xlYXZlKCl7dGhpcy5faXNXaXRoQWN0aXZlVHJpZ2dlcigpfHwodGhpcy5faXNIb3ZlcmVkPSExLHRoaXMuX3NldFRpbWVvdXQoKCk9Pnt0aGlzLl9pc0hvdmVyZWR8fHRoaXMuaGlkZSgpfSx0aGlzLl9jb25maWcuZGVsYXkuaGlkZSkpfV9zZXRUaW1lb3V0KHQsZSl7Y2xlYXJUaW1lb3V0KHRoaXMuX3RpbWVvdXQpLHRoaXMuX3RpbWVvdXQ9c2V0VGltZW91dCh0LGUpfV9pc1dpdGhBY3RpdmVUcmlnZ2VyKCl7cmV0dXJuIE9iamVjdC52YWx1ZXModGhpcy5fYWN0aXZlVHJpZ2dlcikuaW5jbHVkZXMoITApfV9nZXRDb25maWcodCl7Y29uc3QgZT1xLmdldERhdGFBdHRyaWJ1dGVzKHRoaXMuX2VsZW1lbnQpO2Zvcihjb25zdCB0IG9mIE9iamVjdC5rZXlzKGUpKWtpLmhhcyh0KSYmZGVsZXRlIGVbdF07cmV0dXJuIHQ9ey4uLmUsLi4uXCJvYmplY3RcIj09dHlwZW9mIHQmJnQ/dDp7fX0sdD10aGlzLl9tZXJnZUNvbmZpZ09iaih0KSx0PXRoaXMuX2NvbmZpZ0FmdGVyTWVyZ2UodCksdGhpcy5fdHlwZUNoZWNrQ29uZmlnKHQpLHR9X2NvbmZpZ0FmdGVyTWVyZ2UodCl7cmV0dXJuIHQuY29udGFpbmVyPSExPT09dC5jb250YWluZXI/ZG9jdW1lbnQuYm9keTpoKHQuY29udGFpbmVyKSxcIm51bWJlclwiPT10eXBlb2YgdC5kZWxheSYmKHQuZGVsYXk9e3Nob3c6dC5kZWxheSxoaWRlOnQuZGVsYXl9KSxcIm51bWJlclwiPT10eXBlb2YgdC50aXRsZSYmKHQudGl0bGU9dC50aXRsZS50b1N0cmluZygpKSxcIm51bWJlclwiPT10eXBlb2YgdC5jb250ZW50JiYodC5jb250ZW50PXQuY29udGVudC50b1N0cmluZygpKSx0fV9nZXREZWxlZ2F0ZUNvbmZpZygpe2NvbnN0IHQ9e307Zm9yKGNvbnN0W2UsaV1vZiBPYmplY3QuZW50cmllcyh0aGlzLl9jb25maWcpKXRoaXMuY29uc3RydWN0b3IuRGVmYXVsdFtlXSE9PWkmJih0W2VdPWkpO3JldHVybiB0LnNlbGVjdG9yPSExLHQudHJpZ2dlcj1cIm1hbnVhbFwiLHR9X2Rpc3Bvc2VQb3BwZXIoKXt0aGlzLl9wb3BwZXImJih0aGlzLl9wb3BwZXIuZGVzdHJveSgpLHRoaXMuX3BvcHBlcj1udWxsKSx0aGlzLnRpcCYmKHRoaXMudGlwLnJlbW92ZSgpLHRoaXMudGlwPW51bGwpfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9RmkuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdKXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0oKX19KX19dihGaSk7Y29uc3Qgemk9XCIucG9wb3Zlci1oZWFkZXJcIixIaT1cIi5wb3BvdmVyLWJvZHlcIixCaT17Li4uRmkuRGVmYXVsdCxjb250ZW50OlwiXCIsb2Zmc2V0OlswLDhdLHBsYWNlbWVudDpcInJpZ2h0XCIsdGVtcGxhdGU6JzxkaXYgY2xhc3M9XCJwb3BvdmVyXCIgcm9sZT1cInRvb2x0aXBcIj48ZGl2IGNsYXNzPVwicG9wb3Zlci1hcnJvd1wiPjwvZGl2PjxoMyBjbGFzcz1cInBvcG92ZXItaGVhZGVyXCI+PC9oMz48ZGl2IGNsYXNzPVwicG9wb3Zlci1ib2R5XCI+PC9kaXY+PC9kaXY+Jyx0cmlnZ2VyOlwiY2xpY2tcIn0scWk9ey4uLkZpLkRlZmF1bHRUeXBlLGNvbnRlbnQ6XCIobnVsbHxzdHJpbmd8ZWxlbWVudHxmdW5jdGlvbilcIn07Y2xhc3MgV2kgZXh0ZW5kcyBGaXtzdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gQml9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBxaX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInBvcG92ZXJcIn1faXNXaXRoQ29udGVudCgpe3JldHVybiB0aGlzLl9nZXRUaXRsZSgpfHx0aGlzLl9nZXRDb250ZW50KCl9X2dldENvbnRlbnRGb3JUZW1wbGF0ZSgpe3JldHVybntbemldOnRoaXMuX2dldFRpdGxlKCksW0hpXTp0aGlzLl9nZXRDb250ZW50KCl9fV9nZXRDb250ZW50KCl7cmV0dXJuIHRoaXMuX3Jlc29sdmVQb3NzaWJsZUZ1bmN0aW9uKHRoaXMuX2NvbmZpZy5jb250ZW50KX1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXtjb25zdCBlPVdpLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyx0KTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XSl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fSl9fXYoV2kpO2NvbnN0IFJpPVwiLmJzLnNjcm9sbHNweVwiLEtpPWBhY3RpdmF0ZSR7Uml9YCxWaT1gY2xpY2ske1JpfWAsUWk9YGxvYWQke1JpfS5kYXRhLWFwaWAsWGk9XCJhY3RpdmVcIixZaT1cIltocmVmXVwiLFVpPVwiLm5hdi1saW5rXCIsR2k9YCR7VWl9LCAubmF2LWl0ZW0gPiAke1VpfSwgLmxpc3QtZ3JvdXAtaXRlbWAsSmk9e29mZnNldDpudWxsLHJvb3RNYXJnaW46XCIwcHggMHB4IC0yNSVcIixzbW9vdGhTY3JvbGw6ITEsdGFyZ2V0Om51bGwsdGhyZXNob2xkOlsuMSwuNSwxXX0sWmk9e29mZnNldDpcIihudW1iZXJ8bnVsbClcIixyb290TWFyZ2luOlwic3RyaW5nXCIsc21vb3RoU2Nyb2xsOlwiYm9vbGVhblwiLHRhcmdldDpcImVsZW1lbnRcIix0aHJlc2hvbGQ6XCJhcnJheVwifTtjbGFzcyB0cyBleHRlbmRzIFJ7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX3RhcmdldExpbmtzPW5ldyBNYXAsdGhpcy5fb2JzZXJ2YWJsZVNlY3Rpb25zPW5ldyBNYXAsdGhpcy5fcm9vdEVsZW1lbnQ9XCJ2aXNpYmxlXCI9PT1nZXRDb21wdXRlZFN0eWxlKHRoaXMuX2VsZW1lbnQpLm92ZXJmbG93WT9udWxsOnRoaXMuX2VsZW1lbnQsdGhpcy5fYWN0aXZlVGFyZ2V0PW51bGwsdGhpcy5fb2JzZXJ2ZXI9bnVsbCx0aGlzLl9wcmV2aW91c1Njcm9sbERhdGE9e3Zpc2libGVFbnRyeVRvcDowLHBhcmVudFNjcm9sbFRvcDowfSx0aGlzLnJlZnJlc2goKX1zdGF0aWMgZ2V0IERlZmF1bHQoKXtyZXR1cm4gSml9c3RhdGljIGdldCBEZWZhdWx0VHlwZSgpe3JldHVybiBaaX1zdGF0aWMgZ2V0IE5BTUUoKXtyZXR1cm5cInNjcm9sbHNweVwifXJlZnJlc2goKXt0aGlzLl9pbml0aWFsaXplVGFyZ2V0c0FuZE9ic2VydmFibGVzKCksdGhpcy5fbWF5YmVFbmFibGVTbW9vdGhTY3JvbGwoKSx0aGlzLl9vYnNlcnZlcj90aGlzLl9vYnNlcnZlci5kaXNjb25uZWN0KCk6dGhpcy5fb2JzZXJ2ZXI9dGhpcy5fZ2V0TmV3T2JzZXJ2ZXIoKTtmb3IoY29uc3QgdCBvZiB0aGlzLl9vYnNlcnZhYmxlU2VjdGlvbnMudmFsdWVzKCkpdGhpcy5fb2JzZXJ2ZXIub2JzZXJ2ZSh0KX1kaXNwb3NlKCl7dGhpcy5fb2JzZXJ2ZXIuZGlzY29ubmVjdCgpLHN1cGVyLmRpc3Bvc2UoKX1fY29uZmlnQWZ0ZXJNZXJnZSh0KXtyZXR1cm4gdC50YXJnZXQ9aCh0LnRhcmdldCl8fGRvY3VtZW50LmJvZHksdC5yb290TWFyZ2luPXQub2Zmc2V0P2Ake3Qub2Zmc2V0fXB4IDBweCAtMzAlYDp0LnJvb3RNYXJnaW4sXCJzdHJpbmdcIj09dHlwZW9mIHQudGhyZXNob2xkJiYodC50aHJlc2hvbGQ9dC50aHJlc2hvbGQuc3BsaXQoXCIsXCIpLm1hcCh0PT5OdW1iZXIucGFyc2VGbG9hdCh0KSkpLHR9X21heWJlRW5hYmxlU21vb3RoU2Nyb2xsKCl7dGhpcy5fY29uZmlnLnNtb290aFNjcm9sbCYmKEYub2ZmKHRoaXMuX2NvbmZpZy50YXJnZXQsVmkpLEYub24odGhpcy5fY29uZmlnLnRhcmdldCxWaSxZaSx0PT57Y29uc3QgZT10aGlzLl9vYnNlcnZhYmxlU2VjdGlvbnMuZ2V0KHQudGFyZ2V0Lmhhc2gpO2lmKGUpe3QucHJldmVudERlZmF1bHQoKTtjb25zdCBpPXRoaXMuX3Jvb3RFbGVtZW50fHx3aW5kb3cscz1lLm9mZnNldFRvcC10aGlzLl9lbGVtZW50Lm9mZnNldFRvcDtpZihpLnNjcm9sbFRvKXJldHVybiB2b2lkIGkuc2Nyb2xsVG8oe3RvcDpzLGJlaGF2aW9yOlwic21vb3RoXCJ9KTtpLnNjcm9sbFRvcD1zfX0pKX1fZ2V0TmV3T2JzZXJ2ZXIoKXtjb25zdCB0PXtyb290OnRoaXMuX3Jvb3RFbGVtZW50LHRocmVzaG9sZDp0aGlzLl9jb25maWcudGhyZXNob2xkLHJvb3RNYXJnaW46dGhpcy5fY29uZmlnLnJvb3RNYXJnaW59O3JldHVybiBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIodD0+dGhpcy5fb2JzZXJ2ZXJDYWxsYmFjayh0KSx0KX1fb2JzZXJ2ZXJDYWxsYmFjayh0KXtjb25zdCBlPXQ9PnRoaXMuX3RhcmdldExpbmtzLmdldChgIyR7dC50YXJnZXQuaWR9YCksaT10PT57dGhpcy5fcHJldmlvdXNTY3JvbGxEYXRhLnZpc2libGVFbnRyeVRvcD10LnRhcmdldC5vZmZzZXRUb3AsdGhpcy5fcHJvY2VzcyhlKHQpKX0scz0odGhpcy5fcm9vdEVsZW1lbnR8fGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuc2Nyb2xsVG9wLG49cz49dGhpcy5fcHJldmlvdXNTY3JvbGxEYXRhLnBhcmVudFNjcm9sbFRvcDt0aGlzLl9wcmV2aW91c1Njcm9sbERhdGEucGFyZW50U2Nyb2xsVG9wPXM7Zm9yKGNvbnN0IG8gb2YgdCl7aWYoIW8uaXNJbnRlcnNlY3Rpbmcpe3RoaXMuX2FjdGl2ZVRhcmdldD1udWxsLHRoaXMuX2NsZWFyQWN0aXZlQ2xhc3MoZShvKSk7Y29udGludWV9Y29uc3QgdD1vLnRhcmdldC5vZmZzZXRUb3A+PXRoaXMuX3ByZXZpb3VzU2Nyb2xsRGF0YS52aXNpYmxlRW50cnlUb3A7aWYobiYmdCl7aWYoaShvKSwhcylyZXR1cm59ZWxzZSBufHx0fHxpKG8pfX1faW5pdGlhbGl6ZVRhcmdldHNBbmRPYnNlcnZhYmxlcygpe3RoaXMuX3RhcmdldExpbmtzPW5ldyBNYXAsdGhpcy5fb2JzZXJ2YWJsZVNlY3Rpb25zPW5ldyBNYXA7Y29uc3QgdD1WLmZpbmQoWWksdGhpcy5fY29uZmlnLnRhcmdldCk7Zm9yKGNvbnN0IGUgb2YgdCl7aWYoIWUuaGFzaHx8dShlKSljb250aW51ZTtjb25zdCB0PVYuZmluZE9uZShkZWNvZGVVUkkoZS5oYXNoKSx0aGlzLl9lbGVtZW50KTtkKHQpJiYodGhpcy5fdGFyZ2V0TGlua3Muc2V0KGRlY29kZVVSSShlLmhhc2gpLGUpLHRoaXMuX29ic2VydmFibGVTZWN0aW9ucy5zZXQoZS5oYXNoLHQpKX19X3Byb2Nlc3ModCl7dGhpcy5fYWN0aXZlVGFyZ2V0IT09dCYmKHRoaXMuX2NsZWFyQWN0aXZlQ2xhc3ModGhpcy5fY29uZmlnLnRhcmdldCksdGhpcy5fYWN0aXZlVGFyZ2V0PXQsdC5jbGFzc0xpc3QuYWRkKFhpKSx0aGlzLl9hY3RpdmF0ZVBhcmVudHModCksRi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsS2kse3JlbGF0ZWRUYXJnZXQ6dH0pKX1fYWN0aXZhdGVQYXJlbnRzKHQpe2lmKHQuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZHJvcGRvd24taXRlbVwiKSlWLmZpbmRPbmUoXCIuZHJvcGRvd24tdG9nZ2xlXCIsdC5jbG9zZXN0KFwiLmRyb3Bkb3duXCIpKS5jbGFzc0xpc3QuYWRkKFhpKTtlbHNlIGZvcihjb25zdCBlIG9mIFYucGFyZW50cyh0LFwiLm5hdiwgLmxpc3QtZ3JvdXBcIikpZm9yKGNvbnN0IHQgb2YgVi5wcmV2KGUsR2kpKXQuY2xhc3NMaXN0LmFkZChYaSl9X2NsZWFyQWN0aXZlQ2xhc3ModCl7dC5jbGFzc0xpc3QucmVtb3ZlKFhpKTtjb25zdCBlPVYuZmluZChgJHtZaX0uJHtYaX1gLHQpO2Zvcihjb25zdCB0IG9mIGUpdC5jbGFzc0xpc3QucmVtb3ZlKFhpKX1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXtjb25zdCBlPXRzLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyx0KTtpZihcInN0cmluZ1wiPT10eXBlb2YgdCl7aWYodm9pZCAwPT09ZVt0XXx8dC5zdGFydHNXaXRoKFwiX1wiKXx8XCJjb25zdHJ1Y3RvclwiPT09dCl0aHJvdyBuZXcgVHlwZUVycm9yKGBObyBtZXRob2QgbmFtZWQgXCIke3R9XCJgKTtlW3RdKCl9fSl9fUYub24od2luZG93LFFpLCgpPT57Zm9yKGNvbnN0IHQgb2YgVi5maW5kKCdbZGF0YS1icy1zcHk9XCJzY3JvbGxcIl0nKSl0cy5nZXRPckNyZWF0ZUluc3RhbmNlKHQpfSksdih0cyk7Y29uc3QgZXM9XCIuYnMudGFiXCIsaXM9YGhpZGUke2VzfWAsc3M9YGhpZGRlbiR7ZXN9YCxucz1gc2hvdyR7ZXN9YCxvcz1gc2hvd24ke2VzfWAscnM9YGNsaWNrJHtlc31gLGFzPWBrZXlkb3duJHtlc31gLGxzPWBsb2FkJHtlc31gLGNzPVwiQXJyb3dMZWZ0XCIsaHM9XCJBcnJvd1JpZ2h0XCIsZHM9XCJBcnJvd1VwXCIsdXM9XCJBcnJvd0Rvd25cIixfcz1cIkhvbWVcIixncz1cIkVuZFwiLGZzPVwiYWN0aXZlXCIsbXM9XCJmYWRlXCIscHM9XCJzaG93XCIsYnM9XCIuZHJvcGRvd24tdG9nZ2xlXCIsdnM9YDpub3QoJHtic30pYCx5cz0nW2RhdGEtYnMtdG9nZ2xlPVwidGFiXCJdLCBbZGF0YS1icy10b2dnbGU9XCJwaWxsXCJdLCBbZGF0YS1icy10b2dnbGU9XCJsaXN0XCJdJyx3cz1gLm5hdi1saW5rJHt2c30sIC5saXN0LWdyb3VwLWl0ZW0ke3ZzfSwgW3JvbGU9XCJ0YWJcIl0ke3ZzfSwgJHt5c31gLEFzPWAuJHtmc31bZGF0YS1icy10b2dnbGU9XCJ0YWJcIl0sIC4ke2ZzfVtkYXRhLWJzLXRvZ2dsZT1cInBpbGxcIl0sIC4ke2ZzfVtkYXRhLWJzLXRvZ2dsZT1cImxpc3RcIl1gO2NsYXNzIEVzIGV4dGVuZHMgUntjb25zdHJ1Y3Rvcih0KXtzdXBlcih0KSx0aGlzLl9wYXJlbnQ9dGhpcy5fZWxlbWVudC5jbG9zZXN0KCcubGlzdC1ncm91cCwgLm5hdiwgW3JvbGU9XCJ0YWJsaXN0XCJdJyksdGhpcy5fcGFyZW50JiYodGhpcy5fc2V0SW5pdGlhbEF0dHJpYnV0ZXModGhpcy5fcGFyZW50LHRoaXMuX2dldENoaWxkcmVuKCkpLEYub24odGhpcy5fZWxlbWVudCxhcyx0PT50aGlzLl9rZXlkb3duKHQpKSl9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJ0YWJcIn1zaG93KCl7Y29uc3QgdD10aGlzLl9lbGVtZW50O2lmKHRoaXMuX2VsZW1Jc0FjdGl2ZSh0KSlyZXR1cm47Y29uc3QgZT10aGlzLl9nZXRBY3RpdmVFbGVtKCksaT1lP0YudHJpZ2dlcihlLGlzLHtyZWxhdGVkVGFyZ2V0OnR9KTpudWxsO0YudHJpZ2dlcih0LG5zLHtyZWxhdGVkVGFyZ2V0OmV9KS5kZWZhdWx0UHJldmVudGVkfHxpJiZpLmRlZmF1bHRQcmV2ZW50ZWR8fCh0aGlzLl9kZWFjdGl2YXRlKGUsdCksdGhpcy5fYWN0aXZhdGUodCxlKSl9X2FjdGl2YXRlKHQsZSl7dCYmKHQuY2xhc3NMaXN0LmFkZChmcyksdGhpcy5fYWN0aXZhdGUoVi5nZXRFbGVtZW50RnJvbVNlbGVjdG9yKHQpKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57XCJ0YWJcIj09PXQuZ2V0QXR0cmlidXRlKFwicm9sZVwiKT8odC5yZW1vdmVBdHRyaWJ1dGUoXCJ0YWJpbmRleFwiKSx0LnNldEF0dHJpYnV0ZShcImFyaWEtc2VsZWN0ZWRcIiwhMCksdGhpcy5fdG9nZ2xlRHJvcERvd24odCwhMCksRi50cmlnZ2VyKHQsb3Mse3JlbGF0ZWRUYXJnZXQ6ZX0pKTp0LmNsYXNzTGlzdC5hZGQocHMpfSx0LHQuY2xhc3NMaXN0LmNvbnRhaW5zKG1zKSkpfV9kZWFjdGl2YXRlKHQsZSl7dCYmKHQuY2xhc3NMaXN0LnJlbW92ZShmcyksdC5ibHVyKCksdGhpcy5fZGVhY3RpdmF0ZShWLmdldEVsZW1lbnRGcm9tU2VsZWN0b3IodCkpLHRoaXMuX3F1ZXVlQ2FsbGJhY2soKCk9PntcInRhYlwiPT09dC5nZXRBdHRyaWJ1dGUoXCJyb2xlXCIpPyh0LnNldEF0dHJpYnV0ZShcImFyaWEtc2VsZWN0ZWRcIiwhMSksdC5zZXRBdHRyaWJ1dGUoXCJ0YWJpbmRleFwiLFwiLTFcIiksdGhpcy5fdG9nZ2xlRHJvcERvd24odCwhMSksRi50cmlnZ2VyKHQsc3Mse3JlbGF0ZWRUYXJnZXQ6ZX0pKTp0LmNsYXNzTGlzdC5yZW1vdmUocHMpfSx0LHQuY2xhc3NMaXN0LmNvbnRhaW5zKG1zKSkpfV9rZXlkb3duKHQpe2lmKCFbY3MsaHMsZHMsdXMsX3MsZ3NdLmluY2x1ZGVzKHQua2V5KSlyZXR1cm47dC5zdG9wUHJvcGFnYXRpb24oKSx0LnByZXZlbnREZWZhdWx0KCk7Y29uc3QgZT10aGlzLl9nZXRDaGlsZHJlbigpLmZpbHRlcih0PT4hdSh0KSk7bGV0IGk7aWYoW19zLGdzXS5pbmNsdWRlcyh0LmtleSkpaT1lW3Qua2V5PT09X3M/MDplLmxlbmd0aC0xXTtlbHNle2NvbnN0IHM9W2hzLHVzXS5pbmNsdWRlcyh0LmtleSk7aT1BKGUsdC50YXJnZXQscywhMCl9aSYmKGkuZm9jdXMoe3ByZXZlbnRTY3JvbGw6ITB9KSxFcy5nZXRPckNyZWF0ZUluc3RhbmNlKGkpLnNob3coKSl9X2dldENoaWxkcmVuKCl7cmV0dXJuIFYuZmluZCh3cyx0aGlzLl9wYXJlbnQpfV9nZXRBY3RpdmVFbGVtKCl7cmV0dXJuIHRoaXMuX2dldENoaWxkcmVuKCkuZmluZCh0PT50aGlzLl9lbGVtSXNBY3RpdmUodCkpfHxudWxsfV9zZXRJbml0aWFsQXR0cmlidXRlcyh0LGUpe3RoaXMuX3NldEF0dHJpYnV0ZUlmTm90RXhpc3RzKHQsXCJyb2xlXCIsXCJ0YWJsaXN0XCIpO2Zvcihjb25zdCB0IG9mIGUpdGhpcy5fc2V0SW5pdGlhbEF0dHJpYnV0ZXNPbkNoaWxkKHQpfV9zZXRJbml0aWFsQXR0cmlidXRlc09uQ2hpbGQodCl7dD10aGlzLl9nZXRJbm5lckVsZW1lbnQodCk7Y29uc3QgZT10aGlzLl9lbGVtSXNBY3RpdmUodCksaT10aGlzLl9nZXRPdXRlckVsZW1lbnQodCk7dC5zZXRBdHRyaWJ1dGUoXCJhcmlhLXNlbGVjdGVkXCIsZSksaSE9PXQmJnRoaXMuX3NldEF0dHJpYnV0ZUlmTm90RXhpc3RzKGksXCJyb2xlXCIsXCJwcmVzZW50YXRpb25cIiksZXx8dC5zZXRBdHRyaWJ1dGUoXCJ0YWJpbmRleFwiLFwiLTFcIiksdGhpcy5fc2V0QXR0cmlidXRlSWZOb3RFeGlzdHModCxcInJvbGVcIixcInRhYlwiKSx0aGlzLl9zZXRJbml0aWFsQXR0cmlidXRlc09uVGFyZ2V0UGFuZWwodCl9X3NldEluaXRpYWxBdHRyaWJ1dGVzT25UYXJnZXRQYW5lbCh0KXtjb25zdCBlPVYuZ2V0RWxlbWVudEZyb21TZWxlY3Rvcih0KTtlJiYodGhpcy5fc2V0QXR0cmlidXRlSWZOb3RFeGlzdHMoZSxcInJvbGVcIixcInRhYnBhbmVsXCIpLHQuaWQmJnRoaXMuX3NldEF0dHJpYnV0ZUlmTm90RXhpc3RzKGUsXCJhcmlhLWxhYmVsbGVkYnlcIixgJHt0LmlkfWApKX1fdG9nZ2xlRHJvcERvd24odCxlKXtjb25zdCBpPXRoaXMuX2dldE91dGVyRWxlbWVudCh0KTtpZighaS5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wZG93blwiKSlyZXR1cm47Y29uc3Qgcz0odCxzKT0+e2NvbnN0IG49Vi5maW5kT25lKHQsaSk7biYmbi5jbGFzc0xpc3QudG9nZ2xlKHMsZSl9O3MoYnMsZnMpLHMoXCIuZHJvcGRvd24tbWVudVwiLHBzKSxpLnNldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIixlKX1fc2V0QXR0cmlidXRlSWZOb3RFeGlzdHModCxlLGkpe3QuaGFzQXR0cmlidXRlKGUpfHx0LnNldEF0dHJpYnV0ZShlLGkpfV9lbGVtSXNBY3RpdmUodCl7cmV0dXJuIHQuY2xhc3NMaXN0LmNvbnRhaW5zKGZzKX1fZ2V0SW5uZXJFbGVtZW50KHQpe3JldHVybiB0Lm1hdGNoZXMod3MpP3Q6Vi5maW5kT25lKHdzLHQpfV9nZXRPdXRlckVsZW1lbnQodCl7cmV0dXJuIHQuY2xvc2VzdChcIi5uYXYtaXRlbSwgLmxpc3QtZ3JvdXAtaXRlbVwiKXx8dH1zdGF0aWMgalF1ZXJ5SW50ZXJmYWNlKHQpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXtjb25zdCBlPUVzLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcyk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHQpe2lmKHZvaWQgMD09PWVbdF18fHQuc3RhcnRzV2l0aChcIl9cIil8fFwiY29uc3RydWN0b3JcIj09PXQpdGhyb3cgbmV3IFR5cGVFcnJvcihgTm8gbWV0aG9kIG5hbWVkIFwiJHt0fVwiYCk7ZVt0XSgpfX0pfX1GLm9uKGRvY3VtZW50LHJzLHlzLGZ1bmN0aW9uKHQpe1tcIkFcIixcIkFSRUFcIl0uaW5jbHVkZXModGhpcy50YWdOYW1lKSYmdC5wcmV2ZW50RGVmYXVsdCgpLHUodGhpcyl8fEVzLmdldE9yQ3JlYXRlSW5zdGFuY2UodGhpcykuc2hvdygpfSksRi5vbih3aW5kb3csbHMsKCk9Pntmb3IoY29uc3QgdCBvZiBWLmZpbmQoQXMpKUVzLmdldE9yQ3JlYXRlSW5zdGFuY2UodCl9KSx2KEVzKTtjb25zdCBDcz1cIi5icy50b2FzdFwiLFRzPWBtb3VzZW92ZXIke0NzfWAsa3M9YG1vdXNlb3V0JHtDc31gLCRzPWBmb2N1c2luJHtDc31gLFNzPWBmb2N1c291dCR7Q3N9YCxMcz1gaGlkZSR7Q3N9YCxPcz1gaGlkZGVuJHtDc31gLElzPWBzaG93JHtDc31gLERzPWBzaG93biR7Q3N9YCxOcz1cImhpZGVcIixQcz1cInNob3dcIix4cz1cInNob3dpbmdcIixNcz17YW5pbWF0aW9uOlwiYm9vbGVhblwiLGF1dG9oaWRlOlwiYm9vbGVhblwiLGRlbGF5OlwibnVtYmVyXCJ9LGpzPXthbmltYXRpb246ITAsYXV0b2hpZGU6ITAsZGVsYXk6NWUzfTtjbGFzcyBGcyBleHRlbmRzIFJ7Y29uc3RydWN0b3IodCxlKXtzdXBlcih0LGUpLHRoaXMuX3RpbWVvdXQ9bnVsbCx0aGlzLl9oYXNNb3VzZUludGVyYWN0aW9uPSExLHRoaXMuX2hhc0tleWJvYXJkSW50ZXJhY3Rpb249ITEsdGhpcy5fc2V0TGlzdGVuZXJzKCl9c3RhdGljIGdldCBEZWZhdWx0KCl7cmV0dXJuIGpzfXN0YXRpYyBnZXQgRGVmYXVsdFR5cGUoKXtyZXR1cm4gTXN9c3RhdGljIGdldCBOQU1FKCl7cmV0dXJuXCJ0b2FzdFwifXNob3coKXtGLnRyaWdnZXIodGhpcy5fZWxlbWVudCxJcykuZGVmYXVsdFByZXZlbnRlZHx8KHRoaXMuX2NsZWFyVGltZW91dCgpLHRoaXMuX2NvbmZpZy5hbmltYXRpb24mJnRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChcImZhZGVcIiksdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKE5zKSxmKHRoaXMuX2VsZW1lbnQpLHRoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChQcyx4cyksdGhpcy5fcXVldWVDYWxsYmFjaygoKT0+e3RoaXMuX2VsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSh4cyksRi50cmlnZ2VyKHRoaXMuX2VsZW1lbnQsRHMpLHRoaXMuX21heWJlU2NoZWR1bGVIaWRlKCl9LHRoaXMuX2VsZW1lbnQsdGhpcy5fY29uZmlnLmFuaW1hdGlvbikpfWhpZGUoKXt0aGlzLmlzU2hvd24oKSYmKEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LExzKS5kZWZhdWx0UHJldmVudGVkfHwodGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKHhzKSx0aGlzLl9xdWV1ZUNhbGxiYWNrKCgpPT57dGhpcy5fZWxlbWVudC5jbGFzc0xpc3QuYWRkKE5zKSx0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoeHMsUHMpLEYudHJpZ2dlcih0aGlzLl9lbGVtZW50LE9zKX0sdGhpcy5fZWxlbWVudCx0aGlzLl9jb25maWcuYW5pbWF0aW9uKSkpfWRpc3Bvc2UoKXt0aGlzLl9jbGVhclRpbWVvdXQoKSx0aGlzLmlzU2hvd24oKSYmdGhpcy5fZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKFBzKSxzdXBlci5kaXNwb3NlKCl9aXNTaG93bigpe3JldHVybiB0aGlzLl9lbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhQcyl9X21heWJlU2NoZWR1bGVIaWRlKCl7dGhpcy5fY29uZmlnLmF1dG9oaWRlJiYodGhpcy5faGFzTW91c2VJbnRlcmFjdGlvbnx8dGhpcy5faGFzS2V5Ym9hcmRJbnRlcmFjdGlvbnx8KHRoaXMuX3RpbWVvdXQ9c2V0VGltZW91dCgoKT0+e3RoaXMuaGlkZSgpfSx0aGlzLl9jb25maWcuZGVsYXkpKSl9X29uSW50ZXJhY3Rpb24odCxlKXtzd2l0Y2godC50eXBlKXtjYXNlXCJtb3VzZW92ZXJcIjpjYXNlXCJtb3VzZW91dFwiOnRoaXMuX2hhc01vdXNlSW50ZXJhY3Rpb249ZTticmVhaztjYXNlXCJmb2N1c2luXCI6Y2FzZVwiZm9jdXNvdXRcIjp0aGlzLl9oYXNLZXlib2FyZEludGVyYWN0aW9uPWV9aWYoZSlyZXR1cm4gdm9pZCB0aGlzLl9jbGVhclRpbWVvdXQoKTtjb25zdCBpPXQucmVsYXRlZFRhcmdldDt0aGlzLl9lbGVtZW50PT09aXx8dGhpcy5fZWxlbWVudC5jb250YWlucyhpKXx8dGhpcy5fbWF5YmVTY2hlZHVsZUhpZGUoKX1fc2V0TGlzdGVuZXJzKCl7Ri5vbih0aGlzLl9lbGVtZW50LFRzLHQ9PnRoaXMuX29uSW50ZXJhY3Rpb24odCwhMCkpLEYub24odGhpcy5fZWxlbWVudCxrcyx0PT50aGlzLl9vbkludGVyYWN0aW9uKHQsITEpKSxGLm9uKHRoaXMuX2VsZW1lbnQsJHMsdD0+dGhpcy5fb25JbnRlcmFjdGlvbih0LCEwKSksRi5vbih0aGlzLl9lbGVtZW50LFNzLHQ9PnRoaXMuX29uSW50ZXJhY3Rpb24odCwhMSkpfV9jbGVhclRpbWVvdXQoKXtjbGVhclRpbWVvdXQodGhpcy5fdGltZW91dCksdGhpcy5fdGltZW91dD1udWxsfXN0YXRpYyBqUXVlcnlJbnRlcmZhY2UodCl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe2NvbnN0IGU9RnMuZ2V0T3JDcmVhdGVJbnN0YW5jZSh0aGlzLHQpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXtpZih2b2lkIDA9PT1lW3RdKXRocm93IG5ldyBUeXBlRXJyb3IoYE5vIG1ldGhvZCBuYW1lZCBcIiR7dH1cImApO2VbdF0odGhpcyl9fSl9fXJldHVybiBRKEZzKSx2KEZzKSx7QWxlcnQ6RyxCdXR0b246WixDYXJvdXNlbDpOdCxDb2xsYXBzZTpRdCxEcm9wZG93bjpiZSxNb2RhbDpaZSxPZmZjYW52YXM6cGksUG9wb3ZlcjpXaSxTY3JvbGxTcHk6dHMsVGFiOkVzLFRvYXN0OkZzLFRvb2x0aXA6Rml9fSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ib290c3RyYXAubWluLmpzLm1hcFxuLyoqXG4gKiBAcG9wcGVyanMvY29yZSB2Mi4xMS44IC0gTUlUIExpY2Vuc2VcbiAqL1xuXG4hZnVuY3Rpb24oZSx0KXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT90KGV4cG9ydHMpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoW1wiZXhwb3J0c1wiXSx0KTp0KChlPVwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWxUaGlzP2dsb2JhbFRoaXM6ZXx8c2VsZikuUG9wcGVyPXt9KX0odGhpcywoZnVuY3Rpb24oZSl7XCJ1c2Ugc3RyaWN0XCI7ZnVuY3Rpb24gdChlKXtpZihudWxsPT1lKXJldHVybiB3aW5kb3c7aWYoXCJbb2JqZWN0IFdpbmRvd11cIiE9PWUudG9TdHJpbmcoKSl7dmFyIHQ9ZS5vd25lckRvY3VtZW50O3JldHVybiB0JiZ0LmRlZmF1bHRWaWV3fHx3aW5kb3d9cmV0dXJuIGV9ZnVuY3Rpb24gbihlKXtyZXR1cm4gZSBpbnN0YW5jZW9mIHQoZSkuRWxlbWVudHx8ZSBpbnN0YW5jZW9mIEVsZW1lbnR9ZnVuY3Rpb24gcihlKXtyZXR1cm4gZSBpbnN0YW5jZW9mIHQoZSkuSFRNTEVsZW1lbnR8fGUgaW5zdGFuY2VvZiBIVE1MRWxlbWVudH1mdW5jdGlvbiBvKGUpe3JldHVyblwidW5kZWZpbmVkXCIhPXR5cGVvZiBTaGFkb3dSb290JiYoZSBpbnN0YW5jZW9mIHQoZSkuU2hhZG93Um9vdHx8ZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3QpfXZhciBpPU1hdGgubWF4LGE9TWF0aC5taW4scz1NYXRoLnJvdW5kO2Z1bmN0aW9uIGYoKXt2YXIgZT1uYXZpZ2F0b3IudXNlckFnZW50RGF0YTtyZXR1cm4gbnVsbCE9ZSYmZS5icmFuZHMmJkFycmF5LmlzQXJyYXkoZS5icmFuZHMpP2UuYnJhbmRzLm1hcCgoZnVuY3Rpb24oZSl7cmV0dXJuIGUuYnJhbmQrXCIvXCIrZS52ZXJzaW9ufSkpLmpvaW4oXCIgXCIpOm5hdmlnYXRvci51c2VyQWdlbnR9ZnVuY3Rpb24gYygpe3JldHVybiEvXigoPyFjaHJvbWV8YW5kcm9pZCkuKSpzYWZhcmkvaS50ZXN0KGYoKSl9ZnVuY3Rpb24gcChlLG8saSl7dm9pZCAwPT09byYmKG89ITEpLHZvaWQgMD09PWkmJihpPSExKTt2YXIgYT1lLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLGY9MSxwPTE7byYmcihlKSYmKGY9ZS5vZmZzZXRXaWR0aD4wJiZzKGEud2lkdGgpL2Uub2Zmc2V0V2lkdGh8fDEscD1lLm9mZnNldEhlaWdodD4wJiZzKGEuaGVpZ2h0KS9lLm9mZnNldEhlaWdodHx8MSk7dmFyIHU9KG4oZSk/dChlKTp3aW5kb3cpLnZpc3VhbFZpZXdwb3J0LGw9IWMoKSYmaSxkPShhLmxlZnQrKGwmJnU/dS5vZmZzZXRMZWZ0OjApKS9mLGg9KGEudG9wKyhsJiZ1P3Uub2Zmc2V0VG9wOjApKS9wLG09YS53aWR0aC9mLHY9YS5oZWlnaHQvcDtyZXR1cm57d2lkdGg6bSxoZWlnaHQ6dix0b3A6aCxyaWdodDpkK20sYm90dG9tOmgrdixsZWZ0OmQseDpkLHk6aH19ZnVuY3Rpb24gdShlKXt2YXIgbj10KGUpO3JldHVybntzY3JvbGxMZWZ0Om4ucGFnZVhPZmZzZXQsc2Nyb2xsVG9wOm4ucGFnZVlPZmZzZXR9fWZ1bmN0aW9uIGwoZSl7cmV0dXJuIGU/KGUubm9kZU5hbWV8fFwiXCIpLnRvTG93ZXJDYXNlKCk6bnVsbH1mdW5jdGlvbiBkKGUpe3JldHVybigobihlKT9lLm93bmVyRG9jdW1lbnQ6ZS5kb2N1bWVudCl8fHdpbmRvdy5kb2N1bWVudCkuZG9jdW1lbnRFbGVtZW50fWZ1bmN0aW9uIGgoZSl7cmV0dXJuIHAoZChlKSkubGVmdCt1KGUpLnNjcm9sbExlZnR9ZnVuY3Rpb24gbShlKXtyZXR1cm4gdChlKS5nZXRDb21wdXRlZFN0eWxlKGUpfWZ1bmN0aW9uIHYoZSl7dmFyIHQ9bShlKSxuPXQub3ZlcmZsb3cscj10Lm92ZXJmbG93WCxvPXQub3ZlcmZsb3dZO3JldHVybi9hdXRvfHNjcm9sbHxvdmVybGF5fGhpZGRlbi8udGVzdChuK28rcil9ZnVuY3Rpb24geShlLG4sbyl7dm9pZCAwPT09byYmKG89ITEpO3ZhciBpLGEsZj1yKG4pLGM9cihuKSYmZnVuY3Rpb24oZSl7dmFyIHQ9ZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxuPXModC53aWR0aCkvZS5vZmZzZXRXaWR0aHx8MSxyPXModC5oZWlnaHQpL2Uub2Zmc2V0SGVpZ2h0fHwxO3JldHVybiAxIT09bnx8MSE9PXJ9KG4pLG09ZChuKSx5PXAoZSxjLG8pLGc9e3Njcm9sbExlZnQ6MCxzY3JvbGxUb3A6MH0sYj17eDowLHk6MH07cmV0dXJuKGZ8fCFmJiYhbykmJigoXCJib2R5XCIhPT1sKG4pfHx2KG0pKSYmKGc9KGk9bikhPT10KGkpJiZyKGkpP3tzY3JvbGxMZWZ0OihhPWkpLnNjcm9sbExlZnQsc2Nyb2xsVG9wOmEuc2Nyb2xsVG9wfTp1KGkpKSxyKG4pPygoYj1wKG4sITApKS54Kz1uLmNsaWVudExlZnQsYi55Kz1uLmNsaWVudFRvcCk6bSYmKGIueD1oKG0pKSkse3g6eS5sZWZ0K2cuc2Nyb2xsTGVmdC1iLngseTp5LnRvcCtnLnNjcm9sbFRvcC1iLnksd2lkdGg6eS53aWR0aCxoZWlnaHQ6eS5oZWlnaHR9fWZ1bmN0aW9uIGcoZSl7dmFyIHQ9cChlKSxuPWUub2Zmc2V0V2lkdGgscj1lLm9mZnNldEhlaWdodDtyZXR1cm4gTWF0aC5hYnModC53aWR0aC1uKTw9MSYmKG49dC53aWR0aCksTWF0aC5hYnModC5oZWlnaHQtcik8PTEmJihyPXQuaGVpZ2h0KSx7eDplLm9mZnNldExlZnQseTplLm9mZnNldFRvcCx3aWR0aDpuLGhlaWdodDpyfX1mdW5jdGlvbiBiKGUpe3JldHVyblwiaHRtbFwiPT09bChlKT9lOmUuYXNzaWduZWRTbG90fHxlLnBhcmVudE5vZGV8fChvKGUpP2UuaG9zdDpudWxsKXx8ZChlKX1mdW5jdGlvbiB4KGUpe3JldHVybltcImh0bWxcIixcImJvZHlcIixcIiNkb2N1bWVudFwiXS5pbmRleE9mKGwoZSkpPj0wP2Uub3duZXJEb2N1bWVudC5ib2R5OnIoZSkmJnYoZSk/ZTp4KGIoZSkpfWZ1bmN0aW9uIHcoZSxuKXt2YXIgcjt2b2lkIDA9PT1uJiYobj1bXSk7dmFyIG89eChlKSxpPW89PT0obnVsbD09KHI9ZS5vd25lckRvY3VtZW50KT92b2lkIDA6ci5ib2R5KSxhPXQobykscz1pP1thXS5jb25jYXQoYS52aXN1YWxWaWV3cG9ydHx8W10sdihvKT9vOltdKTpvLGY9bi5jb25jYXQocyk7cmV0dXJuIGk/ZjpmLmNvbmNhdCh3KGIocykpKX1mdW5jdGlvbiBPKGUpe3JldHVybltcInRhYmxlXCIsXCJ0ZFwiLFwidGhcIl0uaW5kZXhPZihsKGUpKT49MH1mdW5jdGlvbiBqKGUpe3JldHVybiByKGUpJiZcImZpeGVkXCIhPT1tKGUpLnBvc2l0aW9uP2Uub2Zmc2V0UGFyZW50Om51bGx9ZnVuY3Rpb24gRShlKXtmb3IodmFyIG49dChlKSxpPWooZSk7aSYmTyhpKSYmXCJzdGF0aWNcIj09PW0oaSkucG9zaXRpb247KWk9aihpKTtyZXR1cm4gaSYmKFwiaHRtbFwiPT09bChpKXx8XCJib2R5XCI9PT1sKGkpJiZcInN0YXRpY1wiPT09bShpKS5wb3NpdGlvbik/bjppfHxmdW5jdGlvbihlKXt2YXIgdD0vZmlyZWZveC9pLnRlc3QoZigpKTtpZigvVHJpZGVudC9pLnRlc3QoZigpKSYmcihlKSYmXCJmaXhlZFwiPT09bShlKS5wb3NpdGlvbilyZXR1cm4gbnVsbDt2YXIgbj1iKGUpO2ZvcihvKG4pJiYobj1uLmhvc3QpO3IobikmJltcImh0bWxcIixcImJvZHlcIl0uaW5kZXhPZihsKG4pKTwwOyl7dmFyIGk9bShuKTtpZihcIm5vbmVcIiE9PWkudHJhbnNmb3JtfHxcIm5vbmVcIiE9PWkucGVyc3BlY3RpdmV8fFwicGFpbnRcIj09PWkuY29udGFpbnx8LTEhPT1bXCJ0cmFuc2Zvcm1cIixcInBlcnNwZWN0aXZlXCJdLmluZGV4T2YoaS53aWxsQ2hhbmdlKXx8dCYmXCJmaWx0ZXJcIj09PWkud2lsbENoYW5nZXx8dCYmaS5maWx0ZXImJlwibm9uZVwiIT09aS5maWx0ZXIpcmV0dXJuIG47bj1uLnBhcmVudE5vZGV9cmV0dXJuIG51bGx9KGUpfHxufXZhciBEPVwidG9wXCIsQT1cImJvdHRvbVwiLEw9XCJyaWdodFwiLFA9XCJsZWZ0XCIsTT1cImF1dG9cIixrPVtELEEsTCxQXSxXPVwic3RhcnRcIixCPVwiZW5kXCIsSD1cInZpZXdwb3J0XCIsVD1cInBvcHBlclwiLFI9ay5yZWR1Y2UoKGZ1bmN0aW9uKGUsdCl7cmV0dXJuIGUuY29uY2F0KFt0K1wiLVwiK1csdCtcIi1cIitCXSl9KSxbXSksUz1bXS5jb25jYXQoayxbTV0pLnJlZHVjZSgoZnVuY3Rpb24oZSx0KXtyZXR1cm4gZS5jb25jYXQoW3QsdCtcIi1cIitXLHQrXCItXCIrQl0pfSksW10pLFY9W1wiYmVmb3JlUmVhZFwiLFwicmVhZFwiLFwiYWZ0ZXJSZWFkXCIsXCJiZWZvcmVNYWluXCIsXCJtYWluXCIsXCJhZnRlck1haW5cIixcImJlZm9yZVdyaXRlXCIsXCJ3cml0ZVwiLFwiYWZ0ZXJXcml0ZVwiXTtmdW5jdGlvbiBxKGUpe3ZhciB0PW5ldyBNYXAsbj1uZXcgU2V0LHI9W107ZnVuY3Rpb24gbyhlKXtuLmFkZChlLm5hbWUpLFtdLmNvbmNhdChlLnJlcXVpcmVzfHxbXSxlLnJlcXVpcmVzSWZFeGlzdHN8fFtdKS5mb3JFYWNoKChmdW5jdGlvbihlKXtpZighbi5oYXMoZSkpe3ZhciByPXQuZ2V0KGUpO3ImJm8ocil9fSkpLHIucHVzaChlKX1yZXR1cm4gZS5mb3JFYWNoKChmdW5jdGlvbihlKXt0LnNldChlLm5hbWUsZSl9KSksZS5mb3JFYWNoKChmdW5jdGlvbihlKXtuLmhhcyhlLm5hbWUpfHxvKGUpfSkpLHJ9ZnVuY3Rpb24gQyhlLHQpe3ZhciBuPXQuZ2V0Um9vdE5vZGUmJnQuZ2V0Um9vdE5vZGUoKTtpZihlLmNvbnRhaW5zKHQpKXJldHVybiEwO2lmKG4mJm8obikpe3ZhciByPXQ7ZG97aWYociYmZS5pc1NhbWVOb2RlKHIpKXJldHVybiEwO3I9ci5wYXJlbnROb2RlfHxyLmhvc3R9d2hpbGUocil9cmV0dXJuITF9ZnVuY3Rpb24gTihlKXtyZXR1cm4gT2JqZWN0LmFzc2lnbih7fSxlLHtsZWZ0OmUueCx0b3A6ZS55LHJpZ2h0OmUueCtlLndpZHRoLGJvdHRvbTplLnkrZS5oZWlnaHR9KX1mdW5jdGlvbiBJKGUscixvKXtyZXR1cm4gcj09PUg/TihmdW5jdGlvbihlLG4pe3ZhciByPXQoZSksbz1kKGUpLGk9ci52aXN1YWxWaWV3cG9ydCxhPW8uY2xpZW50V2lkdGgscz1vLmNsaWVudEhlaWdodCxmPTAscD0wO2lmKGkpe2E9aS53aWR0aCxzPWkuaGVpZ2h0O3ZhciB1PWMoKTsodXx8IXUmJlwiZml4ZWRcIj09PW4pJiYoZj1pLm9mZnNldExlZnQscD1pLm9mZnNldFRvcCl9cmV0dXJue3dpZHRoOmEsaGVpZ2h0OnMseDpmK2goZSkseTpwfX0oZSxvKSk6bihyKT9mdW5jdGlvbihlLHQpe3ZhciBuPXAoZSwhMSxcImZpeGVkXCI9PT10KTtyZXR1cm4gbi50b3A9bi50b3ArZS5jbGllbnRUb3Asbi5sZWZ0PW4ubGVmdCtlLmNsaWVudExlZnQsbi5ib3R0b209bi50b3ArZS5jbGllbnRIZWlnaHQsbi5yaWdodD1uLmxlZnQrZS5jbGllbnRXaWR0aCxuLndpZHRoPWUuY2xpZW50V2lkdGgsbi5oZWlnaHQ9ZS5jbGllbnRIZWlnaHQsbi54PW4ubGVmdCxuLnk9bi50b3Asbn0ocixvKTpOKGZ1bmN0aW9uKGUpe3ZhciB0LG49ZChlKSxyPXUoZSksbz1udWxsPT0odD1lLm93bmVyRG9jdW1lbnQpP3ZvaWQgMDp0LmJvZHksYT1pKG4uc2Nyb2xsV2lkdGgsbi5jbGllbnRXaWR0aCxvP28uc2Nyb2xsV2lkdGg6MCxvP28uY2xpZW50V2lkdGg6MCkscz1pKG4uc2Nyb2xsSGVpZ2h0LG4uY2xpZW50SGVpZ2h0LG8/by5zY3JvbGxIZWlnaHQ6MCxvP28uY2xpZW50SGVpZ2h0OjApLGY9LXIuc2Nyb2xsTGVmdCtoKGUpLGM9LXIuc2Nyb2xsVG9wO3JldHVyblwicnRsXCI9PT1tKG98fG4pLmRpcmVjdGlvbiYmKGYrPWkobi5jbGllbnRXaWR0aCxvP28uY2xpZW50V2lkdGg6MCktYSkse3dpZHRoOmEsaGVpZ2h0OnMseDpmLHk6Y319KGQoZSkpKX1mdW5jdGlvbiBfKGUsdCxvLHMpe3ZhciBmPVwiY2xpcHBpbmdQYXJlbnRzXCI9PT10P2Z1bmN0aW9uKGUpe3ZhciB0PXcoYihlKSksbz1bXCJhYnNvbHV0ZVwiLFwiZml4ZWRcIl0uaW5kZXhPZihtKGUpLnBvc2l0aW9uKT49MCYmcihlKT9FKGUpOmU7cmV0dXJuIG4obyk/dC5maWx0ZXIoKGZ1bmN0aW9uKGUpe3JldHVybiBuKGUpJiZDKGUsbykmJlwiYm9keVwiIT09bChlKX0pKTpbXX0oZSk6W10uY29uY2F0KHQpLGM9W10uY29uY2F0KGYsW29dKSxwPWNbMF0sdT1jLnJlZHVjZSgoZnVuY3Rpb24odCxuKXt2YXIgcj1JKGUsbixzKTtyZXR1cm4gdC50b3A9aShyLnRvcCx0LnRvcCksdC5yaWdodD1hKHIucmlnaHQsdC5yaWdodCksdC5ib3R0b209YShyLmJvdHRvbSx0LmJvdHRvbSksdC5sZWZ0PWkoci5sZWZ0LHQubGVmdCksdH0pLEkoZSxwLHMpKTtyZXR1cm4gdS53aWR0aD11LnJpZ2h0LXUubGVmdCx1LmhlaWdodD11LmJvdHRvbS11LnRvcCx1Lng9dS5sZWZ0LHUueT11LnRvcCx1fWZ1bmN0aW9uIEYoZSl7cmV0dXJuIGUuc3BsaXQoXCItXCIpWzBdfWZ1bmN0aW9uIFUoZSl7cmV0dXJuIGUuc3BsaXQoXCItXCIpWzFdfWZ1bmN0aW9uIHooZSl7cmV0dXJuW1widG9wXCIsXCJib3R0b21cIl0uaW5kZXhPZihlKT49MD9cInhcIjpcInlcIn1mdW5jdGlvbiBYKGUpe3ZhciB0LG49ZS5yZWZlcmVuY2Uscj1lLmVsZW1lbnQsbz1lLnBsYWNlbWVudCxpPW8/RihvKTpudWxsLGE9bz9VKG8pOm51bGwscz1uLngrbi53aWR0aC8yLXIud2lkdGgvMixmPW4ueStuLmhlaWdodC8yLXIuaGVpZ2h0LzI7c3dpdGNoKGkpe2Nhc2UgRDp0PXt4OnMseTpuLnktci5oZWlnaHR9O2JyZWFrO2Nhc2UgQTp0PXt4OnMseTpuLnkrbi5oZWlnaHR9O2JyZWFrO2Nhc2UgTDp0PXt4Om4ueCtuLndpZHRoLHk6Zn07YnJlYWs7Y2FzZSBQOnQ9e3g6bi54LXIud2lkdGgseTpmfTticmVhaztkZWZhdWx0OnQ9e3g6bi54LHk6bi55fX12YXIgYz1pP3ooaSk6bnVsbDtpZihudWxsIT1jKXt2YXIgcD1cInlcIj09PWM/XCJoZWlnaHRcIjpcIndpZHRoXCI7c3dpdGNoKGEpe2Nhc2UgVzp0W2NdPXRbY10tKG5bcF0vMi1yW3BdLzIpO2JyZWFrO2Nhc2UgQjp0W2NdPXRbY10rKG5bcF0vMi1yW3BdLzIpfX1yZXR1cm4gdH1mdW5jdGlvbiBZKGUpe3JldHVybiBPYmplY3QuYXNzaWduKHt9LHt0b3A6MCxyaWdodDowLGJvdHRvbTowLGxlZnQ6MH0sZSl9ZnVuY3Rpb24gRyhlLHQpe3JldHVybiB0LnJlZHVjZSgoZnVuY3Rpb24odCxuKXtyZXR1cm4gdFtuXT1lLHR9KSx7fSl9ZnVuY3Rpb24gSihlLHQpe3ZvaWQgMD09PXQmJih0PXt9KTt2YXIgcj10LG89ci5wbGFjZW1lbnQsaT12b2lkIDA9PT1vP2UucGxhY2VtZW50Om8sYT1yLnN0cmF0ZWd5LHM9dm9pZCAwPT09YT9lLnN0cmF0ZWd5OmEsZj1yLmJvdW5kYXJ5LGM9dm9pZCAwPT09Zj9cImNsaXBwaW5nUGFyZW50c1wiOmYsdT1yLnJvb3RCb3VuZGFyeSxsPXZvaWQgMD09PXU/SDp1LGg9ci5lbGVtZW50Q29udGV4dCxtPXZvaWQgMD09PWg/VDpoLHY9ci5hbHRCb3VuZGFyeSx5PXZvaWQgMCE9PXYmJnYsZz1yLnBhZGRpbmcsYj12b2lkIDA9PT1nPzA6Zyx4PVkoXCJudW1iZXJcIiE9dHlwZW9mIGI/YjpHKGIsaykpLHc9bT09PVQ/XCJyZWZlcmVuY2VcIjpULE89ZS5yZWN0cy5wb3BwZXIsaj1lLmVsZW1lbnRzW3k/dzptXSxFPV8obihqKT9qOmouY29udGV4dEVsZW1lbnR8fGQoZS5lbGVtZW50cy5wb3BwZXIpLGMsbCxzKSxQPXAoZS5lbGVtZW50cy5yZWZlcmVuY2UpLE09WCh7cmVmZXJlbmNlOlAsZWxlbWVudDpPLHN0cmF0ZWd5OlwiYWJzb2x1dGVcIixwbGFjZW1lbnQ6aX0pLFc9TihPYmplY3QuYXNzaWduKHt9LE8sTSkpLEI9bT09PVQ/VzpQLFI9e3RvcDpFLnRvcC1CLnRvcCt4LnRvcCxib3R0b206Qi5ib3R0b20tRS5ib3R0b20reC5ib3R0b20sbGVmdDpFLmxlZnQtQi5sZWZ0K3gubGVmdCxyaWdodDpCLnJpZ2h0LUUucmlnaHQreC5yaWdodH0sUz1lLm1vZGlmaWVyc0RhdGEub2Zmc2V0O2lmKG09PT1UJiZTKXt2YXIgVj1TW2ldO09iamVjdC5rZXlzKFIpLmZvckVhY2goKGZ1bmN0aW9uKGUpe3ZhciB0PVtMLEFdLmluZGV4T2YoZSk+PTA/MTotMSxuPVtELEFdLmluZGV4T2YoZSk+PTA/XCJ5XCI6XCJ4XCI7UltlXSs9VltuXSp0fSkpfXJldHVybiBSfXZhciBLPXtwbGFjZW1lbnQ6XCJib3R0b21cIixtb2RpZmllcnM6W10sc3RyYXRlZ3k6XCJhYnNvbHV0ZVwifTtmdW5jdGlvbiBRKCl7Zm9yKHZhciBlPWFyZ3VtZW50cy5sZW5ndGgsdD1uZXcgQXJyYXkoZSksbj0wO248ZTtuKyspdFtuXT1hcmd1bWVudHNbbl07cmV0dXJuIXQuc29tZSgoZnVuY3Rpb24oZSl7cmV0dXJuIShlJiZcImZ1bmN0aW9uXCI9PXR5cGVvZiBlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCl9KSl9ZnVuY3Rpb24gWihlKXt2b2lkIDA9PT1lJiYoZT17fSk7dmFyIHQ9ZSxyPXQuZGVmYXVsdE1vZGlmaWVycyxvPXZvaWQgMD09PXI/W106cixpPXQuZGVmYXVsdE9wdGlvbnMsYT12b2lkIDA9PT1pP0s6aTtyZXR1cm4gZnVuY3Rpb24oZSx0LHIpe3ZvaWQgMD09PXImJihyPWEpO3ZhciBpLHMsZj17cGxhY2VtZW50OlwiYm90dG9tXCIsb3JkZXJlZE1vZGlmaWVyczpbXSxvcHRpb25zOk9iamVjdC5hc3NpZ24oe30sSyxhKSxtb2RpZmllcnNEYXRhOnt9LGVsZW1lbnRzOntyZWZlcmVuY2U6ZSxwb3BwZXI6dH0sYXR0cmlidXRlczp7fSxzdHlsZXM6e319LGM9W10scD0hMSx1PXtzdGF0ZTpmLHNldE9wdGlvbnM6ZnVuY3Rpb24ocil7dmFyIGk9XCJmdW5jdGlvblwiPT10eXBlb2Ygcj9yKGYub3B0aW9ucyk6cjtsKCksZi5vcHRpb25zPU9iamVjdC5hc3NpZ24oe30sYSxmLm9wdGlvbnMsaSksZi5zY3JvbGxQYXJlbnRzPXtyZWZlcmVuY2U6bihlKT93KGUpOmUuY29udGV4dEVsZW1lbnQ/dyhlLmNvbnRleHRFbGVtZW50KTpbXSxwb3BwZXI6dyh0KX07dmFyIHMscCxkPWZ1bmN0aW9uKGUpe3ZhciB0PXEoZSk7cmV0dXJuIFYucmVkdWNlKChmdW5jdGlvbihlLG4pe3JldHVybiBlLmNvbmNhdCh0LmZpbHRlcigoZnVuY3Rpb24oZSl7cmV0dXJuIGUucGhhc2U9PT1ufSkpKX0pLFtdKX0oKHM9W10uY29uY2F0KG8sZi5vcHRpb25zLm1vZGlmaWVycykscD1zLnJlZHVjZSgoZnVuY3Rpb24oZSx0KXt2YXIgbj1lW3QubmFtZV07cmV0dXJuIGVbdC5uYW1lXT1uP09iamVjdC5hc3NpZ24oe30sbix0LHtvcHRpb25zOk9iamVjdC5hc3NpZ24oe30sbi5vcHRpb25zLHQub3B0aW9ucyksZGF0YTpPYmplY3QuYXNzaWduKHt9LG4uZGF0YSx0LmRhdGEpfSk6dCxlfSkse30pLE9iamVjdC5rZXlzKHApLm1hcCgoZnVuY3Rpb24oZSl7cmV0dXJuIHBbZV19KSkpKTtyZXR1cm4gZi5vcmRlcmVkTW9kaWZpZXJzPWQuZmlsdGVyKChmdW5jdGlvbihlKXtyZXR1cm4gZS5lbmFibGVkfSkpLGYub3JkZXJlZE1vZGlmaWVycy5mb3JFYWNoKChmdW5jdGlvbihlKXt2YXIgdD1lLm5hbWUsbj1lLm9wdGlvbnMscj12b2lkIDA9PT1uP3t9Om4sbz1lLmVmZmVjdDtpZihcImZ1bmN0aW9uXCI9PXR5cGVvZiBvKXt2YXIgaT1vKHtzdGF0ZTpmLG5hbWU6dCxpbnN0YW5jZTp1LG9wdGlvbnM6cn0pLGE9ZnVuY3Rpb24oKXt9O2MucHVzaChpfHxhKX19KSksdS51cGRhdGUoKX0sZm9yY2VVcGRhdGU6ZnVuY3Rpb24oKXtpZighcCl7dmFyIGU9Zi5lbGVtZW50cyx0PWUucmVmZXJlbmNlLG49ZS5wb3BwZXI7aWYoUSh0LG4pKXtmLnJlY3RzPXtyZWZlcmVuY2U6eSh0LEUobiksXCJmaXhlZFwiPT09Zi5vcHRpb25zLnN0cmF0ZWd5KSxwb3BwZXI6ZyhuKX0sZi5yZXNldD0hMSxmLnBsYWNlbWVudD1mLm9wdGlvbnMucGxhY2VtZW50LGYub3JkZXJlZE1vZGlmaWVycy5mb3JFYWNoKChmdW5jdGlvbihlKXtyZXR1cm4gZi5tb2RpZmllcnNEYXRhW2UubmFtZV09T2JqZWN0LmFzc2lnbih7fSxlLmRhdGEpfSkpO2Zvcih2YXIgcj0wO3I8Zi5vcmRlcmVkTW9kaWZpZXJzLmxlbmd0aDtyKyspaWYoITAhPT1mLnJlc2V0KXt2YXIgbz1mLm9yZGVyZWRNb2RpZmllcnNbcl0saT1vLmZuLGE9by5vcHRpb25zLHM9dm9pZCAwPT09YT97fTphLGM9by5uYW1lO1wiZnVuY3Rpb25cIj09dHlwZW9mIGkmJihmPWkoe3N0YXRlOmYsb3B0aW9uczpzLG5hbWU6YyxpbnN0YW5jZTp1fSl8fGYpfWVsc2UgZi5yZXNldD0hMSxyPS0xfX19LHVwZGF0ZTooaT1mdW5jdGlvbigpe3JldHVybiBuZXcgUHJvbWlzZSgoZnVuY3Rpb24oZSl7dS5mb3JjZVVwZGF0ZSgpLGUoZil9KSl9LGZ1bmN0aW9uKCl7cmV0dXJuIHN8fChzPW5ldyBQcm9taXNlKChmdW5jdGlvbihlKXtQcm9taXNlLnJlc29sdmUoKS50aGVuKChmdW5jdGlvbigpe3M9dm9pZCAwLGUoaSgpKX0pKX0pKSksc30pLGRlc3Ryb3k6ZnVuY3Rpb24oKXtsKCkscD0hMH19O2lmKCFRKGUsdCkpcmV0dXJuIHU7ZnVuY3Rpb24gbCgpe2MuZm9yRWFjaCgoZnVuY3Rpb24oZSl7cmV0dXJuIGUoKX0pKSxjPVtdfXJldHVybiB1LnNldE9wdGlvbnMocikudGhlbigoZnVuY3Rpb24oZSl7IXAmJnIub25GaXJzdFVwZGF0ZSYmci5vbkZpcnN0VXBkYXRlKGUpfSkpLHV9fXZhciAkPXtwYXNzaXZlOiEwfTt2YXIgZWU9e25hbWU6XCJldmVudExpc3RlbmVyc1wiLGVuYWJsZWQ6ITAscGhhc2U6XCJ3cml0ZVwiLGZuOmZ1bmN0aW9uKCl7fSxlZmZlY3Q6ZnVuY3Rpb24oZSl7dmFyIG49ZS5zdGF0ZSxyPWUuaW5zdGFuY2Usbz1lLm9wdGlvbnMsaT1vLnNjcm9sbCxhPXZvaWQgMD09PWl8fGkscz1vLnJlc2l6ZSxmPXZvaWQgMD09PXN8fHMsYz10KG4uZWxlbWVudHMucG9wcGVyKSxwPVtdLmNvbmNhdChuLnNjcm9sbFBhcmVudHMucmVmZXJlbmNlLG4uc2Nyb2xsUGFyZW50cy5wb3BwZXIpO3JldHVybiBhJiZwLmZvckVhY2goKGZ1bmN0aW9uKGUpe2UuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLHIudXBkYXRlLCQpfSkpLGYmJmMuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLHIudXBkYXRlLCQpLGZ1bmN0aW9uKCl7YSYmcC5mb3JFYWNoKChmdW5jdGlvbihlKXtlLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIixyLnVwZGF0ZSwkKX0pKSxmJiZjLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIixyLnVwZGF0ZSwkKX19LGRhdGE6e319O3ZhciB0ZT17bmFtZTpcInBvcHBlck9mZnNldHNcIixlbmFibGVkOiEwLHBoYXNlOlwicmVhZFwiLGZuOmZ1bmN0aW9uKGUpe3ZhciB0PWUuc3RhdGUsbj1lLm5hbWU7dC5tb2RpZmllcnNEYXRhW25dPVgoe3JlZmVyZW5jZTp0LnJlY3RzLnJlZmVyZW5jZSxlbGVtZW50OnQucmVjdHMucG9wcGVyLHN0cmF0ZWd5OlwiYWJzb2x1dGVcIixwbGFjZW1lbnQ6dC5wbGFjZW1lbnR9KX0sZGF0YTp7fX0sbmU9e3RvcDpcImF1dG9cIixyaWdodDpcImF1dG9cIixib3R0b206XCJhdXRvXCIsbGVmdDpcImF1dG9cIn07ZnVuY3Rpb24gcmUoZSl7dmFyIG4scj1lLnBvcHBlcixvPWUucG9wcGVyUmVjdCxpPWUucGxhY2VtZW50LGE9ZS52YXJpYXRpb24sZj1lLm9mZnNldHMsYz1lLnBvc2l0aW9uLHA9ZS5ncHVBY2NlbGVyYXRpb24sdT1lLmFkYXB0aXZlLGw9ZS5yb3VuZE9mZnNldHMsaD1lLmlzRml4ZWQsdj1mLngseT12b2lkIDA9PT12PzA6dixnPWYueSxiPXZvaWQgMD09PWc/MDpnLHg9XCJmdW5jdGlvblwiPT10eXBlb2YgbD9sKHt4OnkseTpifSk6e3g6eSx5OmJ9O3k9eC54LGI9eC55O3ZhciB3PWYuaGFzT3duUHJvcGVydHkoXCJ4XCIpLE89Zi5oYXNPd25Qcm9wZXJ0eShcInlcIiksaj1QLE09RCxrPXdpbmRvdztpZih1KXt2YXIgVz1FKHIpLEg9XCJjbGllbnRIZWlnaHRcIixUPVwiY2xpZW50V2lkdGhcIjtpZihXPT09dChyKSYmXCJzdGF0aWNcIiE9PW0oVz1kKHIpKS5wb3NpdGlvbiYmXCJhYnNvbHV0ZVwiPT09YyYmKEg9XCJzY3JvbGxIZWlnaHRcIixUPVwic2Nyb2xsV2lkdGhcIiksVz1XLGk9PT1EfHwoaT09PVB8fGk9PT1MKSYmYT09PUIpTT1BLGItPShoJiZXPT09ayYmay52aXN1YWxWaWV3cG9ydD9rLnZpc3VhbFZpZXdwb3J0LmhlaWdodDpXW0hdKS1vLmhlaWdodCxiKj1wPzE6LTE7aWYoaT09PVB8fChpPT09RHx8aT09PUEpJiZhPT09QilqPUwseS09KGgmJlc9PT1rJiZrLnZpc3VhbFZpZXdwb3J0P2sudmlzdWFsVmlld3BvcnQud2lkdGg6V1tUXSktby53aWR0aCx5Kj1wPzE6LTF9dmFyIFIsUz1PYmplY3QuYXNzaWduKHtwb3NpdGlvbjpjfSx1JiZuZSksVj0hMD09PWw/ZnVuY3Rpb24oZSx0KXt2YXIgbj1lLngscj1lLnksbz10LmRldmljZVBpeGVsUmF0aW98fDE7cmV0dXJue3g6cyhuKm8pL298fDAseTpzKHIqbykvb3x8MH19KHt4OnkseTpifSx0KHIpKTp7eDp5LHk6Yn07cmV0dXJuIHk9Vi54LGI9Vi55LHA/T2JqZWN0LmFzc2lnbih7fSxTLCgoUj17fSlbTV09Tz9cIjBcIjpcIlwiLFJbal09dz9cIjBcIjpcIlwiLFIudHJhbnNmb3JtPShrLmRldmljZVBpeGVsUmF0aW98fDEpPD0xP1widHJhbnNsYXRlKFwiK3krXCJweCwgXCIrYitcInB4KVwiOlwidHJhbnNsYXRlM2QoXCIreStcInB4LCBcIitiK1wicHgsIDApXCIsUikpOk9iamVjdC5hc3NpZ24oe30sUywoKG49e30pW01dPU8/YitcInB4XCI6XCJcIixuW2pdPXc/eStcInB4XCI6XCJcIixuLnRyYW5zZm9ybT1cIlwiLG4pKX12YXIgb2U9e25hbWU6XCJjb21wdXRlU3R5bGVzXCIsZW5hYmxlZDohMCxwaGFzZTpcImJlZm9yZVdyaXRlXCIsZm46ZnVuY3Rpb24oZSl7dmFyIHQ9ZS5zdGF0ZSxuPWUub3B0aW9ucyxyPW4uZ3B1QWNjZWxlcmF0aW9uLG89dm9pZCAwPT09cnx8cixpPW4uYWRhcHRpdmUsYT12b2lkIDA9PT1pfHxpLHM9bi5yb3VuZE9mZnNldHMsZj12b2lkIDA9PT1zfHxzLGM9e3BsYWNlbWVudDpGKHQucGxhY2VtZW50KSx2YXJpYXRpb246VSh0LnBsYWNlbWVudCkscG9wcGVyOnQuZWxlbWVudHMucG9wcGVyLHBvcHBlclJlY3Q6dC5yZWN0cy5wb3BwZXIsZ3B1QWNjZWxlcmF0aW9uOm8saXNGaXhlZDpcImZpeGVkXCI9PT10Lm9wdGlvbnMuc3RyYXRlZ3l9O251bGwhPXQubW9kaWZpZXJzRGF0YS5wb3BwZXJPZmZzZXRzJiYodC5zdHlsZXMucG9wcGVyPU9iamVjdC5hc3NpZ24oe30sdC5zdHlsZXMucG9wcGVyLHJlKE9iamVjdC5hc3NpZ24oe30sYyx7b2Zmc2V0czp0Lm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cyxwb3NpdGlvbjp0Lm9wdGlvbnMuc3RyYXRlZ3ksYWRhcHRpdmU6YSxyb3VuZE9mZnNldHM6Zn0pKSkpLG51bGwhPXQubW9kaWZpZXJzRGF0YS5hcnJvdyYmKHQuc3R5bGVzLmFycm93PU9iamVjdC5hc3NpZ24oe30sdC5zdHlsZXMuYXJyb3cscmUoT2JqZWN0LmFzc2lnbih7fSxjLHtvZmZzZXRzOnQubW9kaWZpZXJzRGF0YS5hcnJvdyxwb3NpdGlvbjpcImFic29sdXRlXCIsYWRhcHRpdmU6ITEscm91bmRPZmZzZXRzOmZ9KSkpKSx0LmF0dHJpYnV0ZXMucG9wcGVyPU9iamVjdC5hc3NpZ24oe30sdC5hdHRyaWJ1dGVzLnBvcHBlcix7XCJkYXRhLXBvcHBlci1wbGFjZW1lbnRcIjp0LnBsYWNlbWVudH0pfSxkYXRhOnt9fTt2YXIgaWU9e25hbWU6XCJhcHBseVN0eWxlc1wiLGVuYWJsZWQ6ITAscGhhc2U6XCJ3cml0ZVwiLGZuOmZ1bmN0aW9uKGUpe3ZhciB0PWUuc3RhdGU7T2JqZWN0LmtleXModC5lbGVtZW50cykuZm9yRWFjaCgoZnVuY3Rpb24oZSl7dmFyIG49dC5zdHlsZXNbZV18fHt9LG89dC5hdHRyaWJ1dGVzW2VdfHx7fSxpPXQuZWxlbWVudHNbZV07cihpKSYmbChpKSYmKE9iamVjdC5hc3NpZ24oaS5zdHlsZSxuKSxPYmplY3Qua2V5cyhvKS5mb3JFYWNoKChmdW5jdGlvbihlKXt2YXIgdD1vW2VdOyExPT09dD9pLnJlbW92ZUF0dHJpYnV0ZShlKTppLnNldEF0dHJpYnV0ZShlLCEwPT09dD9cIlwiOnQpfSkpKX0pKX0sZWZmZWN0OmZ1bmN0aW9uKGUpe3ZhciB0PWUuc3RhdGUsbj17cG9wcGVyOntwb3NpdGlvbjp0Lm9wdGlvbnMuc3RyYXRlZ3ksbGVmdDpcIjBcIix0b3A6XCIwXCIsbWFyZ2luOlwiMFwifSxhcnJvdzp7cG9zaXRpb246XCJhYnNvbHV0ZVwifSxyZWZlcmVuY2U6e319O3JldHVybiBPYmplY3QuYXNzaWduKHQuZWxlbWVudHMucG9wcGVyLnN0eWxlLG4ucG9wcGVyKSx0LnN0eWxlcz1uLHQuZWxlbWVudHMuYXJyb3cmJk9iamVjdC5hc3NpZ24odC5lbGVtZW50cy5hcnJvdy5zdHlsZSxuLmFycm93KSxmdW5jdGlvbigpe09iamVjdC5rZXlzKHQuZWxlbWVudHMpLmZvckVhY2goKGZ1bmN0aW9uKGUpe3ZhciBvPXQuZWxlbWVudHNbZV0saT10LmF0dHJpYnV0ZXNbZV18fHt9LGE9T2JqZWN0LmtleXModC5zdHlsZXMuaGFzT3duUHJvcGVydHkoZSk/dC5zdHlsZXNbZV06bltlXSkucmVkdWNlKChmdW5jdGlvbihlLHQpe3JldHVybiBlW3RdPVwiXCIsZX0pLHt9KTtyKG8pJiZsKG8pJiYoT2JqZWN0LmFzc2lnbihvLnN0eWxlLGEpLE9iamVjdC5rZXlzKGkpLmZvckVhY2goKGZ1bmN0aW9uKGUpe28ucmVtb3ZlQXR0cmlidXRlKGUpfSkpKX0pKX19LHJlcXVpcmVzOltcImNvbXB1dGVTdHlsZXNcIl19O3ZhciBhZT17bmFtZTpcIm9mZnNldFwiLGVuYWJsZWQ6ITAscGhhc2U6XCJtYWluXCIscmVxdWlyZXM6W1wicG9wcGVyT2Zmc2V0c1wiXSxmbjpmdW5jdGlvbihlKXt2YXIgdD1lLnN0YXRlLG49ZS5vcHRpb25zLHI9ZS5uYW1lLG89bi5vZmZzZXQsaT12b2lkIDA9PT1vP1swLDBdOm8sYT1TLnJlZHVjZSgoZnVuY3Rpb24oZSxuKXtyZXR1cm4gZVtuXT1mdW5jdGlvbihlLHQsbil7dmFyIHI9RihlKSxvPVtQLERdLmluZGV4T2Yocik+PTA/LTE6MSxpPVwiZnVuY3Rpb25cIj09dHlwZW9mIG4/bihPYmplY3QuYXNzaWduKHt9LHQse3BsYWNlbWVudDplfSkpOm4sYT1pWzBdLHM9aVsxXTtyZXR1cm4gYT1hfHwwLHM9KHN8fDApKm8sW1AsTF0uaW5kZXhPZihyKT49MD97eDpzLHk6YX06e3g6YSx5OnN9fShuLHQucmVjdHMsaSksZX0pLHt9KSxzPWFbdC5wbGFjZW1lbnRdLGY9cy54LGM9cy55O251bGwhPXQubW9kaWZpZXJzRGF0YS5wb3BwZXJPZmZzZXRzJiYodC5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMueCs9Zix0Lm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cy55Kz1jKSx0Lm1vZGlmaWVyc0RhdGFbcl09YX19LHNlPXtsZWZ0OlwicmlnaHRcIixyaWdodDpcImxlZnRcIixib3R0b206XCJ0b3BcIix0b3A6XCJib3R0b21cIn07ZnVuY3Rpb24gZmUoZSl7cmV0dXJuIGUucmVwbGFjZSgvbGVmdHxyaWdodHxib3R0b218dG9wL2csKGZ1bmN0aW9uKGUpe3JldHVybiBzZVtlXX0pKX12YXIgY2U9e3N0YXJ0OlwiZW5kXCIsZW5kOlwic3RhcnRcIn07ZnVuY3Rpb24gcGUoZSl7cmV0dXJuIGUucmVwbGFjZSgvc3RhcnR8ZW5kL2csKGZ1bmN0aW9uKGUpe3JldHVybiBjZVtlXX0pKX1mdW5jdGlvbiB1ZShlLHQpe3ZvaWQgMD09PXQmJih0PXt9KTt2YXIgbj10LHI9bi5wbGFjZW1lbnQsbz1uLmJvdW5kYXJ5LGk9bi5yb290Qm91bmRhcnksYT1uLnBhZGRpbmcscz1uLmZsaXBWYXJpYXRpb25zLGY9bi5hbGxvd2VkQXV0b1BsYWNlbWVudHMsYz12b2lkIDA9PT1mP1M6ZixwPVUociksdT1wP3M/UjpSLmZpbHRlcigoZnVuY3Rpb24oZSl7cmV0dXJuIFUoZSk9PT1wfSkpOmssbD11LmZpbHRlcigoZnVuY3Rpb24oZSl7cmV0dXJuIGMuaW5kZXhPZihlKT49MH0pKTswPT09bC5sZW5ndGgmJihsPXUpO3ZhciBkPWwucmVkdWNlKChmdW5jdGlvbih0LG4pe3JldHVybiB0W25dPUooZSx7cGxhY2VtZW50Om4sYm91bmRhcnk6byxyb290Qm91bmRhcnk6aSxwYWRkaW5nOmF9KVtGKG4pXSx0fSkse30pO3JldHVybiBPYmplY3Qua2V5cyhkKS5zb3J0KChmdW5jdGlvbihlLHQpe3JldHVybiBkW2VdLWRbdF19KSl9dmFyIGxlPXtuYW1lOlwiZmxpcFwiLGVuYWJsZWQ6ITAscGhhc2U6XCJtYWluXCIsZm46ZnVuY3Rpb24oZSl7dmFyIHQ9ZS5zdGF0ZSxuPWUub3B0aW9ucyxyPWUubmFtZTtpZighdC5tb2RpZmllcnNEYXRhW3JdLl9za2lwKXtmb3IodmFyIG89bi5tYWluQXhpcyxpPXZvaWQgMD09PW98fG8sYT1uLmFsdEF4aXMscz12b2lkIDA9PT1hfHxhLGY9bi5mYWxsYmFja1BsYWNlbWVudHMsYz1uLnBhZGRpbmcscD1uLmJvdW5kYXJ5LHU9bi5yb290Qm91bmRhcnksbD1uLmFsdEJvdW5kYXJ5LGQ9bi5mbGlwVmFyaWF0aW9ucyxoPXZvaWQgMD09PWR8fGQsbT1uLmFsbG93ZWRBdXRvUGxhY2VtZW50cyx2PXQub3B0aW9ucy5wbGFjZW1lbnQseT1GKHYpLGc9Znx8KHk9PT12fHwhaD9bZmUodildOmZ1bmN0aW9uKGUpe2lmKEYoZSk9PT1NKXJldHVybltdO3ZhciB0PWZlKGUpO3JldHVybltwZShlKSx0LHBlKHQpXX0odikpLGI9W3ZdLmNvbmNhdChnKS5yZWR1Y2UoKGZ1bmN0aW9uKGUsbil7cmV0dXJuIGUuY29uY2F0KEYobik9PT1NP3VlKHQse3BsYWNlbWVudDpuLGJvdW5kYXJ5OnAscm9vdEJvdW5kYXJ5OnUscGFkZGluZzpjLGZsaXBWYXJpYXRpb25zOmgsYWxsb3dlZEF1dG9QbGFjZW1lbnRzOm19KTpuKX0pLFtdKSx4PXQucmVjdHMucmVmZXJlbmNlLHc9dC5yZWN0cy5wb3BwZXIsTz1uZXcgTWFwLGo9ITAsRT1iWzBdLGs9MDtrPGIubGVuZ3RoO2srKyl7dmFyIEI9YltrXSxIPUYoQiksVD1VKEIpPT09VyxSPVtELEFdLmluZGV4T2YoSCk+PTAsUz1SP1wid2lkdGhcIjpcImhlaWdodFwiLFY9Sih0LHtwbGFjZW1lbnQ6Qixib3VuZGFyeTpwLHJvb3RCb3VuZGFyeTp1LGFsdEJvdW5kYXJ5OmwscGFkZGluZzpjfSkscT1SP1Q/TDpQOlQ/QTpEO3hbU10+d1tTXSYmKHE9ZmUocSkpO3ZhciBDPWZlKHEpLE49W107aWYoaSYmTi5wdXNoKFZbSF08PTApLHMmJk4ucHVzaChWW3FdPD0wLFZbQ108PTApLE4uZXZlcnkoKGZ1bmN0aW9uKGUpe3JldHVybiBlfSkpKXtFPUIsaj0hMTticmVha31PLnNldChCLE4pfWlmKGopZm9yKHZhciBJPWZ1bmN0aW9uKGUpe3ZhciB0PWIuZmluZCgoZnVuY3Rpb24odCl7dmFyIG49Ty5nZXQodCk7aWYobilyZXR1cm4gbi5zbGljZSgwLGUpLmV2ZXJ5KChmdW5jdGlvbihlKXtyZXR1cm4gZX0pKX0pKTtpZih0KXJldHVybiBFPXQsXCJicmVha1wifSxfPWg/MzoxO18+MDtfLS0pe2lmKFwiYnJlYWtcIj09PUkoXykpYnJlYWt9dC5wbGFjZW1lbnQhPT1FJiYodC5tb2RpZmllcnNEYXRhW3JdLl9za2lwPSEwLHQucGxhY2VtZW50PUUsdC5yZXNldD0hMCl9fSxyZXF1aXJlc0lmRXhpc3RzOltcIm9mZnNldFwiXSxkYXRhOntfc2tpcDohMX19O2Z1bmN0aW9uIGRlKGUsdCxuKXtyZXR1cm4gaShlLGEodCxuKSl9dmFyIGhlPXtuYW1lOlwicHJldmVudE92ZXJmbG93XCIsZW5hYmxlZDohMCxwaGFzZTpcIm1haW5cIixmbjpmdW5jdGlvbihlKXt2YXIgdD1lLnN0YXRlLG49ZS5vcHRpb25zLHI9ZS5uYW1lLG89bi5tYWluQXhpcyxzPXZvaWQgMD09PW98fG8sZj1uLmFsdEF4aXMsYz12b2lkIDAhPT1mJiZmLHA9bi5ib3VuZGFyeSx1PW4ucm9vdEJvdW5kYXJ5LGw9bi5hbHRCb3VuZGFyeSxkPW4ucGFkZGluZyxoPW4udGV0aGVyLG09dm9pZCAwPT09aHx8aCx2PW4udGV0aGVyT2Zmc2V0LHk9dm9pZCAwPT09dj8wOnYsYj1KKHQse2JvdW5kYXJ5OnAscm9vdEJvdW5kYXJ5OnUscGFkZGluZzpkLGFsdEJvdW5kYXJ5Omx9KSx4PUYodC5wbGFjZW1lbnQpLHc9VSh0LnBsYWNlbWVudCksTz0hdyxqPXooeCksTT1cInhcIj09PWo/XCJ5XCI6XCJ4XCIsaz10Lm1vZGlmaWVyc0RhdGEucG9wcGVyT2Zmc2V0cyxCPXQucmVjdHMucmVmZXJlbmNlLEg9dC5yZWN0cy5wb3BwZXIsVD1cImZ1bmN0aW9uXCI9PXR5cGVvZiB5P3koT2JqZWN0LmFzc2lnbih7fSx0LnJlY3RzLHtwbGFjZW1lbnQ6dC5wbGFjZW1lbnR9KSk6eSxSPVwibnVtYmVyXCI9PXR5cGVvZiBUP3ttYWluQXhpczpULGFsdEF4aXM6VH06T2JqZWN0LmFzc2lnbih7bWFpbkF4aXM6MCxhbHRBeGlzOjB9LFQpLFM9dC5tb2RpZmllcnNEYXRhLm9mZnNldD90Lm1vZGlmaWVyc0RhdGEub2Zmc2V0W3QucGxhY2VtZW50XTpudWxsLFY9e3g6MCx5OjB9O2lmKGspe2lmKHMpe3ZhciBxLEM9XCJ5XCI9PT1qP0Q6UCxOPVwieVwiPT09aj9BOkwsST1cInlcIj09PWo/XCJoZWlnaHRcIjpcIndpZHRoXCIsXz1rW2pdLFg9XytiW0NdLFk9Xy1iW05dLEc9bT8tSFtJXS8yOjAsSz13PT09Vz9CW0ldOkhbSV0sUT13PT09Vz8tSFtJXTotQltJXSxaPXQuZWxlbWVudHMuYXJyb3csJD1tJiZaP2coWik6e3dpZHRoOjAsaGVpZ2h0OjB9LGVlPXQubW9kaWZpZXJzRGF0YVtcImFycm93I3BlcnNpc3RlbnRcIl0/dC5tb2RpZmllcnNEYXRhW1wiYXJyb3cjcGVyc2lzdGVudFwiXS5wYWRkaW5nOnt0b3A6MCxyaWdodDowLGJvdHRvbTowLGxlZnQ6MH0sdGU9ZWVbQ10sbmU9ZWVbTl0scmU9ZGUoMCxCW0ldLCRbSV0pLG9lPU8/QltJXS8yLUctcmUtdGUtUi5tYWluQXhpczpLLXJlLXRlLVIubWFpbkF4aXMsaWU9Tz8tQltJXS8yK0crcmUrbmUrUi5tYWluQXhpczpRK3JlK25lK1IubWFpbkF4aXMsYWU9dC5lbGVtZW50cy5hcnJvdyYmRSh0LmVsZW1lbnRzLmFycm93KSxzZT1hZT9cInlcIj09PWo/YWUuY2xpZW50VG9wfHwwOmFlLmNsaWVudExlZnR8fDA6MCxmZT1udWxsIT0ocT1udWxsPT1TP3ZvaWQgMDpTW2pdKT9xOjAsY2U9XytpZS1mZSxwZT1kZShtP2EoWCxfK29lLWZlLXNlKTpYLF8sbT9pKFksY2UpOlkpO2tbal09cGUsVltqXT1wZS1ffWlmKGMpe3ZhciB1ZSxsZT1cInhcIj09PWo/RDpQLGhlPVwieFwiPT09aj9BOkwsbWU9a1tNXSx2ZT1cInlcIj09PU0/XCJoZWlnaHRcIjpcIndpZHRoXCIseWU9bWUrYltsZV0sZ2U9bWUtYltoZV0sYmU9LTEhPT1bRCxQXS5pbmRleE9mKHgpLHhlPW51bGwhPSh1ZT1udWxsPT1TP3ZvaWQgMDpTW01dKT91ZTowLHdlPWJlP3llOm1lLUJbdmVdLUhbdmVdLXhlK1IuYWx0QXhpcyxPZT1iZT9tZStCW3ZlXStIW3ZlXS14ZS1SLmFsdEF4aXM6Z2UsamU9bSYmYmU/ZnVuY3Rpb24oZSx0LG4pe3ZhciByPWRlKGUsdCxuKTtyZXR1cm4gcj5uP246cn0od2UsbWUsT2UpOmRlKG0/d2U6eWUsbWUsbT9PZTpnZSk7a1tNXT1qZSxWW01dPWplLW1lfXQubW9kaWZpZXJzRGF0YVtyXT1WfX0scmVxdWlyZXNJZkV4aXN0czpbXCJvZmZzZXRcIl19O3ZhciBtZT17bmFtZTpcImFycm93XCIsZW5hYmxlZDohMCxwaGFzZTpcIm1haW5cIixmbjpmdW5jdGlvbihlKXt2YXIgdCxuPWUuc3RhdGUscj1lLm5hbWUsbz1lLm9wdGlvbnMsaT1uLmVsZW1lbnRzLmFycm93LGE9bi5tb2RpZmllcnNEYXRhLnBvcHBlck9mZnNldHMscz1GKG4ucGxhY2VtZW50KSxmPXoocyksYz1bUCxMXS5pbmRleE9mKHMpPj0wP1wiaGVpZ2h0XCI6XCJ3aWR0aFwiO2lmKGkmJmEpe3ZhciBwPWZ1bmN0aW9uKGUsdCl7cmV0dXJuIFkoXCJudW1iZXJcIiE9dHlwZW9mKGU9XCJmdW5jdGlvblwiPT10eXBlb2YgZT9lKE9iamVjdC5hc3NpZ24oe30sdC5yZWN0cyx7cGxhY2VtZW50OnQucGxhY2VtZW50fSkpOmUpP2U6RyhlLGspKX0oby5wYWRkaW5nLG4pLHU9ZyhpKSxsPVwieVwiPT09Zj9EOlAsZD1cInlcIj09PWY/QTpMLGg9bi5yZWN0cy5yZWZlcmVuY2VbY10rbi5yZWN0cy5yZWZlcmVuY2VbZl0tYVtmXS1uLnJlY3RzLnBvcHBlcltjXSxtPWFbZl0tbi5yZWN0cy5yZWZlcmVuY2VbZl0sdj1FKGkpLHk9dj9cInlcIj09PWY/di5jbGllbnRIZWlnaHR8fDA6di5jbGllbnRXaWR0aHx8MDowLGI9aC8yLW0vMix4PXBbbF0sdz15LXVbY10tcFtkXSxPPXkvMi11W2NdLzIrYixqPWRlKHgsTyx3KSxNPWY7bi5tb2RpZmllcnNEYXRhW3JdPSgodD17fSlbTV09aix0LmNlbnRlck9mZnNldD1qLU8sdCl9fSxlZmZlY3Q6ZnVuY3Rpb24oZSl7dmFyIHQ9ZS5zdGF0ZSxuPWUub3B0aW9ucy5lbGVtZW50LHI9dm9pZCAwPT09bj9cIltkYXRhLXBvcHBlci1hcnJvd11cIjpuO251bGwhPXImJihcInN0cmluZ1wiIT10eXBlb2Ygcnx8KHI9dC5lbGVtZW50cy5wb3BwZXIucXVlcnlTZWxlY3RvcihyKSkpJiZDKHQuZWxlbWVudHMucG9wcGVyLHIpJiYodC5lbGVtZW50cy5hcnJvdz1yKX0scmVxdWlyZXM6W1wicG9wcGVyT2Zmc2V0c1wiXSxyZXF1aXJlc0lmRXhpc3RzOltcInByZXZlbnRPdmVyZmxvd1wiXX07ZnVuY3Rpb24gdmUoZSx0LG4pe3JldHVybiB2b2lkIDA9PT1uJiYobj17eDowLHk6MH0pLHt0b3A6ZS50b3AtdC5oZWlnaHQtbi55LHJpZ2h0OmUucmlnaHQtdC53aWR0aCtuLngsYm90dG9tOmUuYm90dG9tLXQuaGVpZ2h0K24ueSxsZWZ0OmUubGVmdC10LndpZHRoLW4ueH19ZnVuY3Rpb24geWUoZSl7cmV0dXJuW0QsTCxBLFBdLnNvbWUoKGZ1bmN0aW9uKHQpe3JldHVybiBlW3RdPj0wfSkpfXZhciBnZT17bmFtZTpcImhpZGVcIixlbmFibGVkOiEwLHBoYXNlOlwibWFpblwiLHJlcXVpcmVzSWZFeGlzdHM6W1wicHJldmVudE92ZXJmbG93XCJdLGZuOmZ1bmN0aW9uKGUpe3ZhciB0PWUuc3RhdGUsbj1lLm5hbWUscj10LnJlY3RzLnJlZmVyZW5jZSxvPXQucmVjdHMucG9wcGVyLGk9dC5tb2RpZmllcnNEYXRhLnByZXZlbnRPdmVyZmxvdyxhPUoodCx7ZWxlbWVudENvbnRleHQ6XCJyZWZlcmVuY2VcIn0pLHM9Sih0LHthbHRCb3VuZGFyeTohMH0pLGY9dmUoYSxyKSxjPXZlKHMsbyxpKSxwPXllKGYpLHU9eWUoYyk7dC5tb2RpZmllcnNEYXRhW25dPXtyZWZlcmVuY2VDbGlwcGluZ09mZnNldHM6Zixwb3BwZXJFc2NhcGVPZmZzZXRzOmMsaXNSZWZlcmVuY2VIaWRkZW46cCxoYXNQb3BwZXJFc2NhcGVkOnV9LHQuYXR0cmlidXRlcy5wb3BwZXI9T2JqZWN0LmFzc2lnbih7fSx0LmF0dHJpYnV0ZXMucG9wcGVyLHtcImRhdGEtcG9wcGVyLXJlZmVyZW5jZS1oaWRkZW5cIjpwLFwiZGF0YS1wb3BwZXItZXNjYXBlZFwiOnV9KX19LGJlPVooe2RlZmF1bHRNb2RpZmllcnM6W2VlLHRlLG9lLGllXX0pLHhlPVtlZSx0ZSxvZSxpZSxhZSxsZSxoZSxtZSxnZV0sd2U9Wih7ZGVmYXVsdE1vZGlmaWVyczp4ZX0pO2UuYXBwbHlTdHlsZXM9aWUsZS5hcnJvdz1tZSxlLmNvbXB1dGVTdHlsZXM9b2UsZS5jcmVhdGVQb3BwZXI9d2UsZS5jcmVhdGVQb3BwZXJMaXRlPWJlLGUuZGVmYXVsdE1vZGlmaWVycz14ZSxlLmRldGVjdE92ZXJmbG93PUosZS5ldmVudExpc3RlbmVycz1lZSxlLmZsaXA9bGUsZS5oaWRlPWdlLGUub2Zmc2V0PWFlLGUucG9wcGVyR2VuZXJhdG9yPVosZS5wb3BwZXJPZmZzZXRzPXRlLGUucHJldmVudE92ZXJmbG93PWhlLE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLFwiX19lc01vZHVsZVwiLHt2YWx1ZTohMH0pfSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cG9wcGVyLm1pbi5qcy5tYXBcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtBLEVBQUMsU0FBUyxHQUFFLEdBQUU7QUFBQyxjQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxRQUFRLGdCQUFnQixDQUFDLElBQUUsY0FBWSxPQUFPLFVBQVEsT0FBTyxNQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsR0FBRSxDQUFDLEtBQUcsSUFBRSxlQUFhLE9BQU8sYUFBVyxhQUFXLEtBQUcsTUFBTSxZQUFVLEVBQUUsRUFBRSxNQUFNO0FBQUMsR0FBRSxNQUFLLFNBQVMsR0FBRTtBQUFDO0FBQWEsV0FBUyxFQUFFQSxJQUFFO0FBQUMsVUFBTUMsS0FBRSxPQUFPLE9BQU8sTUFBSyxFQUFDLENBQUMsT0FBTyxXQUFXLEdBQUUsRUFBQyxPQUFNLFNBQVEsRUFBQyxDQUFDO0FBQUUsUUFBR0Q7QUFBRSxpQkFBVUUsTUFBS0YsR0FBRSxLQUFHLGNBQVlFLElBQUU7QUFBQyxjQUFNQyxLQUFFLE9BQU8seUJBQXlCSCxJQUFFRSxFQUFDO0FBQUUsZUFBTyxlQUFlRCxJQUFFQyxJQUFFQyxHQUFFLE1BQUlBLEtBQUUsRUFBQyxZQUFXLE1BQUcsS0FBSSxNQUFJSCxHQUFFRSxFQUFDLEVBQUMsQ0FBQztBQUFBLE1BQUM7QUFBQTtBQUFDLFdBQU9ELEdBQUUsVUFBUUQsSUFBRSxPQUFPLE9BQU9DLEVBQUM7QUFBQSxFQUFDO0FBQUMsUUFBTSxJQUFFLEVBQUUsQ0FBQyxHQUFFLElBQUUsb0JBQUksT0FBSSxJQUFFLEVBQUMsSUFBSUQsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLE1BQUUsSUFBSUYsRUFBQyxLQUFHLEVBQUUsSUFBSUEsSUFBRSxvQkFBSSxLQUFHO0FBQUUsVUFBTUksS0FBRSxFQUFFLElBQUlKLEVBQUM7QUFBRSxJQUFBSSxHQUFFLElBQUlILEVBQUMsS0FBRyxNQUFJRyxHQUFFLE9BQUtBLEdBQUUsSUFBSUgsSUFBRUMsRUFBQyxJQUFFLFFBQVEsTUFBTSwrRUFBK0UsTUFBTSxLQUFLRSxHQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHO0FBQUEsRUFBQyxHQUFFLEtBQUksQ0FBQ0osSUFBRUMsT0FBSSxFQUFFLElBQUlELEVBQUMsS0FBRyxFQUFFLElBQUlBLEVBQUMsRUFBRSxJQUFJQyxFQUFDLEtBQUcsTUFBSyxPQUFPRCxJQUFFQyxJQUFFO0FBQUMsUUFBRyxDQUFDLEVBQUUsSUFBSUQsRUFBQyxFQUFFO0FBQU8sVUFBTUUsS0FBRSxFQUFFLElBQUlGLEVBQUM7QUFBRSxJQUFBRSxHQUFFLE9BQU9ELEVBQUMsR0FBRSxNQUFJQyxHQUFFLFFBQU0sRUFBRSxPQUFPRixFQUFDO0FBQUEsRUFBQyxFQUFDLEdBQUUsSUFBRSxpQkFBZ0IsSUFBRSxDQUFBQSxRQUFJQSxNQUFHLE9BQU8sT0FBSyxPQUFPLElBQUksV0FBU0EsS0FBRUEsR0FBRSxRQUFRLGlCQUFnQixDQUFDQSxJQUFFQyxPQUFJLElBQUksSUFBSSxPQUFPQSxFQUFDLENBQUMsRUFBRSxJQUFHRCxLQUFHLElBQUUsQ0FBQUEsT0FBRyxRQUFNQSxLQUFFLEdBQUdBLEVBQUMsS0FBRyxPQUFPLFVBQVUsU0FBUyxLQUFLQSxFQUFDLEVBQUUsTUFBTSxhQUFhLEVBQUUsQ0FBQyxFQUFFLFlBQVksR0FBRSxJQUFFLENBQUFBLE9BQUc7QUFBQyxJQUFBQSxHQUFFLGNBQWMsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQUMsR0FBRSxJQUFFLENBQUFBLE9BQUcsRUFBRSxDQUFDQSxNQUFHLFlBQVUsT0FBT0EsUUFBSyxXQUFTQSxHQUFFLFdBQVNBLEtBQUVBLEdBQUUsQ0FBQyxJQUFHLFdBQVNBLEdBQUUsV0FBVSxJQUFFLENBQUFBLE9BQUcsRUFBRUEsRUFBQyxJQUFFQSxHQUFFLFNBQU9BLEdBQUUsQ0FBQyxJQUFFQSxLQUFFLFlBQVUsT0FBT0EsTUFBR0EsR0FBRSxTQUFPLElBQUUsU0FBUyxjQUFjLEVBQUVBLEVBQUMsQ0FBQyxJQUFFLE1BQUssSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBRyxDQUFDLEVBQUVBLEVBQUMsS0FBRyxNQUFJQSxHQUFFLGVBQWUsRUFBRSxPQUFPLFFBQU07QUFBRyxVQUFNQyxLQUFFLGNBQVksaUJBQWlCRCxFQUFDLEVBQUUsaUJBQWlCLFlBQVksR0FBRUUsS0FBRUYsR0FBRSxRQUFRLHFCQUFxQjtBQUFFLFFBQUcsQ0FBQ0UsR0FBRSxRQUFPRDtBQUFFLFFBQUdDLE9BQUlGLElBQUU7QUFBQyxZQUFNQyxLQUFFRCxHQUFFLFFBQVEsU0FBUztBQUFFLFVBQUdDLE1BQUdBLEdBQUUsZUFBYUMsR0FBRSxRQUFNO0FBQUcsVUFBRyxTQUFPRCxHQUFFLFFBQU07QUFBQSxJQUFFO0FBQUMsV0FBT0E7QUFBQSxFQUFDLEdBQUUsSUFBRSxDQUFBRCxPQUFHLENBQUNBLE1BQUdBLEdBQUUsYUFBVyxLQUFLLGdCQUFjLENBQUMsQ0FBQ0EsR0FBRSxVQUFVLFNBQVMsVUFBVSxNQUFJLFdBQVNBLEdBQUUsV0FBU0EsR0FBRSxXQUFTQSxHQUFFLGFBQWEsVUFBVSxLQUFHLFlBQVVBLEdBQUUsYUFBYSxVQUFVLElBQUcsSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBRyxDQUFDLFNBQVMsZ0JBQWdCLGFBQWEsUUFBTztBQUFLLFFBQUcsY0FBWSxPQUFPQSxHQUFFLGFBQVk7QUFBQyxZQUFNQyxLQUFFRCxHQUFFLFlBQVk7QUFBRSxhQUFPQyxjQUFhLGFBQVdBLEtBQUU7QUFBQSxJQUFJO0FBQUMsV0FBT0QsY0FBYSxhQUFXQSxLQUFFQSxHQUFFLGFBQVcsRUFBRUEsR0FBRSxVQUFVLElBQUU7QUFBQSxFQUFJLEdBQUUsSUFBRSxNQUFJO0FBQUEsRUFBQyxHQUFFLElBQUUsQ0FBQUEsT0FBRztBQUFDLElBQUFBLEdBQUU7QUFBQSxFQUFZLEdBQUUsSUFBRSxNQUFJLE9BQU8sVUFBUSxDQUFDLFNBQVMsS0FBSyxhQUFhLG1CQUFtQixJQUFFLE9BQU8sU0FBTyxNQUFLLElBQUUsQ0FBQyxHQUFFLElBQUUsTUFBSSxVQUFRLFNBQVMsZ0JBQWdCLEtBQUksSUFBRSxDQUFBQSxPQUFHO0FBQUMsUUFBSUM7QUFBRSxJQUFBQSxLQUFFLE1BQUk7QUFBQyxZQUFNQSxLQUFFLEVBQUU7QUFBRSxVQUFHQSxJQUFFO0FBQUMsY0FBTUMsS0FBRUYsR0FBRSxNQUFLRyxLQUFFRixHQUFFLEdBQUdDLEVBQUM7QUFBRSxRQUFBRCxHQUFFLEdBQUdDLEVBQUMsSUFBRUYsR0FBRSxpQkFBZ0JDLEdBQUUsR0FBR0MsRUFBQyxFQUFFLGNBQVlGLElBQUVDLEdBQUUsR0FBR0MsRUFBQyxFQUFFLGFBQVcsT0FBS0QsR0FBRSxHQUFHQyxFQUFDLElBQUVDLElBQUVILEdBQUU7QUFBQSxNQUFnQjtBQUFBLElBQUMsR0FBRSxjQUFZLFNBQVMsY0FBWSxFQUFFLFVBQVEsU0FBUyxpQkFBaUIsb0JBQW1CLE1BQUk7QUFBQyxpQkFBVUEsTUFBSyxFQUFFLENBQUFBLEdBQUU7QUFBQSxJQUFDLENBQUMsR0FBRSxFQUFFLEtBQUtDLEVBQUMsS0FBR0EsR0FBRTtBQUFBLEVBQUMsR0FBRSxJQUFFLENBQUNELElBQUVDLEtBQUUsQ0FBQyxHQUFFQyxLQUFFRixPQUFJLGNBQVksT0FBT0EsS0FBRUEsR0FBRSxLQUFLLEdBQUdDLEVBQUMsSUFBRUMsSUFBRSxJQUFFLENBQUNGLElBQUVDLElBQUVDLEtBQUUsU0FBSztBQUFDLFFBQUcsQ0FBQ0EsR0FBRSxRQUFPLEtBQUssRUFBRUYsRUFBQztBQUFFLFVBQU1HLE1BQUcsQ0FBQUgsT0FBRztBQUFDLFVBQUcsQ0FBQ0EsR0FBRSxRQUFPO0FBQUUsVUFBRyxFQUFDLG9CQUFtQkMsSUFBRSxpQkFBZ0JDLEdBQUMsSUFBRSxPQUFPLGlCQUFpQkYsRUFBQztBQUFFLFlBQU1HLEtBQUUsT0FBTyxXQUFXRixFQUFDLEdBQUVHLEtBQUUsT0FBTyxXQUFXRixFQUFDO0FBQUUsYUFBT0MsTUFBR0MsTUFBR0gsS0FBRUEsR0FBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLEdBQUVDLEtBQUVBLEdBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFFLE9BQUssT0FBTyxXQUFXRCxFQUFDLElBQUUsT0FBTyxXQUFXQyxFQUFDLE1BQUk7QUFBQSxJQUFDLEdBQUdELEVBQUMsSUFBRTtBQUFFLFFBQUlHLEtBQUU7QUFBRyxVQUFNQyxLQUFFLENBQUMsRUFBQyxRQUFPSCxHQUFDLE1BQUk7QUFBQyxNQUFBQSxPQUFJRCxPQUFJRyxLQUFFLE1BQUdILEdBQUUsb0JBQW9CLEdBQUVJLEVBQUMsR0FBRSxFQUFFTCxFQUFDO0FBQUEsSUFBRTtBQUFFLElBQUFDLEdBQUUsaUJBQWlCLEdBQUVJLEVBQUMsR0FBRSxXQUFXLE1BQUk7QUFBQyxNQUFBRCxNQUFHLEVBQUVILEVBQUM7QUFBQSxJQUFDLEdBQUVFLEVBQUM7QUFBQSxFQUFDLEdBQUUsSUFBRSxDQUFDSCxJQUFFQyxJQUFFQyxJQUFFQyxPQUFJO0FBQUMsVUFBTUMsS0FBRUosR0FBRTtBQUFPLFFBQUlNLEtBQUVOLEdBQUUsUUFBUUMsRUFBQztBQUFFLFdBQU0sT0FBS0ssS0FBRSxDQUFDSixNQUFHQyxLQUFFSCxHQUFFSSxLQUFFLENBQUMsSUFBRUosR0FBRSxDQUFDLEtBQUdNLE1BQUdKLEtBQUUsSUFBRSxJQUFHQyxPQUFJRyxNQUFHQSxLQUFFRixNQUFHQSxLQUFHSixHQUFFLEtBQUssSUFBSSxHQUFFLEtBQUssSUFBSU0sSUFBRUYsS0FBRSxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQUUsR0FBRSxJQUFFLHNCQUFxQixJQUFFLFFBQU8sSUFBRSxVQUFTLElBQUUsQ0FBQztBQUFFLE1BQUksSUFBRTtBQUFFLFFBQU0sSUFBRSxFQUFDLFlBQVcsYUFBWSxZQUFXLFdBQVUsR0FBRSxJQUFFLG9CQUFJLElBQUksQ0FBQyxTQUFRLFlBQVcsV0FBVSxhQUFZLGVBQWMsY0FBYSxrQkFBaUIsYUFBWSxZQUFXLGFBQVksZUFBYyxhQUFZLFdBQVUsWUFBVyxTQUFRLHFCQUFvQixjQUFhLGFBQVksWUFBVyxlQUFjLGVBQWMsZUFBYyxhQUFZLGdCQUFlLGlCQUFnQixnQkFBZSxpQkFBZ0IsY0FBYSxTQUFRLFFBQU8sVUFBUyxTQUFRLFVBQVMsVUFBUyxXQUFVLFlBQVcsUUFBTyxVQUFTLGdCQUFlLFVBQVMsUUFBTyxvQkFBbUIsb0JBQW1CLFNBQVEsU0FBUSxRQUFRLENBQUM7QUFBRSxXQUFTLEVBQUVKLElBQUVDLElBQUU7QUFBQyxXQUFPQSxNQUFHLEdBQUdBLEVBQUMsS0FBSyxHQUFHLE1BQUlELEdBQUUsWUFBVTtBQUFBLEVBQUc7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxVQUFNQyxLQUFFLEVBQUVELEVBQUM7QUFBRSxXQUFPQSxHQUFFLFdBQVNDLElBQUUsRUFBRUEsRUFBQyxJQUFFLEVBQUVBLEVBQUMsS0FBRyxDQUFDLEdBQUUsRUFBRUEsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVELElBQUVDLElBQUVDLEtBQUUsTUFBSztBQUFDLFdBQU8sT0FBTyxPQUFPRixFQUFDLEVBQUUsS0FBSyxDQUFBQSxPQUFHQSxHQUFFLGFBQVdDLE1BQUdELEdBQUUsdUJBQXFCRSxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUYsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLFVBQU1DLEtBQUUsWUFBVSxPQUFPRixJQUFFRyxLQUFFRCxLQUFFRCxLQUFFRCxNQUFHQztBQUFFLFFBQUlJLEtBQUUsRUFBRU4sRUFBQztBQUFFLFdBQU8sRUFBRSxJQUFJTSxFQUFDLE1BQUlBLEtBQUVOLEtBQUcsQ0FBQ0csSUFBRUMsSUFBRUUsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVOLElBQUVDLElBQUVDLElBQUVDLElBQUVDLElBQUU7QUFBQyxRQUFHLFlBQVUsT0FBT0gsTUFBRyxDQUFDRCxHQUFFO0FBQU8sUUFBRyxDQUFDTSxJQUFFRCxJQUFFRSxFQUFDLElBQUUsRUFBRU4sSUFBRUMsSUFBRUMsRUFBQztBQUFFLFFBQUdGLE1BQUssR0FBRTtBQUFDLFlBQU1ELEtBQUUsQ0FBQUEsT0FBRyxTQUFTQyxJQUFFO0FBQUMsWUFBRyxDQUFDQSxHQUFFLGlCQUFlQSxHQUFFLGtCQUFnQkEsR0FBRSxrQkFBZ0IsQ0FBQ0EsR0FBRSxlQUFlLFNBQVNBLEdBQUUsYUFBYSxFQUFFLFFBQU9ELEdBQUUsS0FBSyxNQUFLQyxFQUFDO0FBQUEsTUFBQztBQUFFLE1BQUFJLEtBQUVMLEdBQUVLLEVBQUM7QUFBQSxJQUFDO0FBQUMsVUFBTUcsS0FBRSxFQUFFUixFQUFDLEdBQUVTLEtBQUVELEdBQUVELEVBQUMsTUFBSUMsR0FBRUQsRUFBQyxJQUFFLENBQUMsSUFBR0csS0FBRSxFQUFFRCxJQUFFSixJQUFFQyxLQUFFSixLQUFFLElBQUk7QUFBRSxRQUFHUSxHQUFFLFFBQU8sTUFBS0EsR0FBRSxTQUFPQSxHQUFFLFVBQVFOO0FBQUcsVUFBTU8sS0FBRSxFQUFFTixJQUFFSixHQUFFLFFBQVEsR0FBRSxFQUFFLENBQUMsR0FBRVcsS0FBRU4sS0FBRSwwQkFBU04sSUFBRUMsSUFBRUMsSUFBRTtBQUFDLGFBQU8sU0FBU0MsR0FBRUMsSUFBRTtBQUFDLGNBQU1FLEtBQUVOLEdBQUUsaUJBQWlCQyxFQUFDO0FBQUUsaUJBQU8sRUFBQyxRQUFPSSxHQUFDLElBQUVELElBQUVDLE1BQUdBLE9BQUksTUFBS0EsS0FBRUEsR0FBRSxXQUFXLFlBQVVFLE1BQUtELEdBQUUsS0FBR0MsT0FBSUYsR0FBRSxRQUFPLEVBQUVELElBQUUsRUFBQyxnQkFBZUMsR0FBQyxDQUFDLEdBQUVGLEdBQUUsVUFBUSxFQUFFLElBQUlILElBQUVJLEdBQUUsTUFBS0gsSUFBRUMsRUFBQyxHQUFFQSxHQUFFLE1BQU1HLElBQUUsQ0FBQ0QsRUFBQyxDQUFDO0FBQUEsTUFBQztBQUFBLElBQUMsR0FBRUosSUFBRUUsSUFBRUcsRUFBQyxJQUFFLDBCQUFTTCxJQUFFQyxJQUFFO0FBQUMsYUFBTyxTQUFTQyxHQUFFQyxJQUFFO0FBQUMsZUFBTyxFQUFFQSxJQUFFLEVBQUMsZ0JBQWVILEdBQUMsQ0FBQyxHQUFFRSxHQUFFLFVBQVEsRUFBRSxJQUFJRixJQUFFRyxHQUFFLE1BQUtGLEVBQUMsR0FBRUEsR0FBRSxNQUFNRCxJQUFFLENBQUNHLEVBQUMsQ0FBQztBQUFBLE1BQUM7QUFBQSxJQUFDLEdBQUVILElBQUVLLEVBQUM7QUFBRSxJQUFBTyxHQUFFLHFCQUFtQk4sS0FBRUosS0FBRSxNQUFLVSxHQUFFLFdBQVNQLElBQUVPLEdBQUUsU0FBT1IsSUFBRVEsR0FBRSxXQUFTRCxJQUFFRixHQUFFRSxFQUFDLElBQUVDLElBQUVaLEdBQUUsaUJBQWlCTyxJQUFFSyxJQUFFTixFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRU4sSUFBRUMsSUFBRUMsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLFVBQU1FLEtBQUUsRUFBRUwsR0FBRUMsRUFBQyxHQUFFQyxJQUFFQyxFQUFDO0FBQUUsSUFBQUUsT0FBSU4sR0FBRSxvQkFBb0JFLElBQUVJLElBQUUsUUFBUUYsRUFBQyxDQUFDLEdBQUUsT0FBT0gsR0FBRUMsRUFBQyxFQUFFSSxHQUFFLFFBQVE7QUFBQSxFQUFFO0FBQUMsV0FBUyxFQUFFTixJQUFFQyxJQUFFQyxJQUFFQyxJQUFFO0FBQUMsVUFBTUMsS0FBRUgsR0FBRUMsRUFBQyxLQUFHLENBQUM7QUFBRSxlQUFTLENBQUNJLElBQUVELEVBQUMsS0FBSSxPQUFPLFFBQVFELEVBQUMsRUFBRSxDQUFBRSxHQUFFLFNBQVNILEVBQUMsS0FBRyxFQUFFSCxJQUFFQyxJQUFFQyxJQUFFRyxHQUFFLFVBQVNBLEdBQUUsa0JBQWtCO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUwsSUFBRTtBQUFDLFdBQU9BLEtBQUVBLEdBQUUsUUFBUSxHQUFFLEVBQUUsR0FBRSxFQUFFQSxFQUFDLEtBQUdBO0FBQUEsRUFBQztBQUFDLFFBQU0sSUFBRSxFQUFDLEdBQUdBLElBQUVDLElBQUVDLElBQUVDLElBQUU7QUFBQyxNQUFFSCxJQUFFQyxJQUFFQyxJQUFFQyxJQUFFLEtBQUU7QUFBQSxFQUFDLEdBQUUsSUFBSUgsSUFBRUMsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLE1BQUVILElBQUVDLElBQUVDLElBQUVDLElBQUUsSUFBRTtBQUFBLEVBQUMsR0FBRSxJQUFJSCxJQUFFQyxJQUFFQyxJQUFFQyxJQUFFO0FBQUMsUUFBRyxZQUFVLE9BQU9GLE1BQUcsQ0FBQ0QsR0FBRTtBQUFPLFVBQUssQ0FBQ0ksSUFBRUUsSUFBRUQsRUFBQyxJQUFFLEVBQUVKLElBQUVDLElBQUVDLEVBQUMsR0FBRUksS0FBRUYsT0FBSUosSUFBRU8sS0FBRSxFQUFFUixFQUFDLEdBQUVTLEtBQUVELEdBQUVILEVBQUMsS0FBRyxDQUFDLEdBQUVLLEtBQUVULEdBQUUsV0FBVyxHQUFHO0FBQUUsUUFBRyxXQUFTSyxJQUFFO0FBQUMsVUFBR0ksR0FBRSxZQUFVUixNQUFLLE9BQU8sS0FBS00sRUFBQyxFQUFFLEdBQUVSLElBQUVRLElBQUVOLElBQUVELEdBQUUsTUFBTSxDQUFDLENBQUM7QUFBRSxpQkFBUyxDQUFDQyxJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRTSxFQUFDLEdBQUU7QUFBQyxjQUFNTCxLQUFFRixHQUFFLFFBQVEsR0FBRSxFQUFFO0FBQUUsUUFBQUssTUFBRyxDQUFDTixHQUFFLFNBQVNHLEVBQUMsS0FBRyxFQUFFSixJQUFFUSxJQUFFSCxJQUFFRixHQUFFLFVBQVNBLEdBQUUsa0JBQWtCO0FBQUEsTUFBQztBQUFBLElBQUMsT0FBSztBQUFDLFVBQUcsQ0FBQyxPQUFPLEtBQUtNLEVBQUMsRUFBRSxPQUFPO0FBQU8sUUFBRVQsSUFBRVEsSUFBRUgsSUFBRUMsSUFBRUYsS0FBRUYsS0FBRSxJQUFJO0FBQUEsSUFBQztBQUFBLEVBQUMsR0FBRSxRQUFRRixJQUFFQyxJQUFFQyxJQUFFO0FBQUMsUUFBRyxZQUFVLE9BQU9ELE1BQUcsQ0FBQ0QsR0FBRSxRQUFPO0FBQUssVUFBTUcsS0FBRSxFQUFFO0FBQUUsUUFBSUMsS0FBRSxNQUFLRSxLQUFFLE1BQUdELEtBQUUsTUFBR0UsS0FBRTtBQUFHLElBQUFOLE9BQUksRUFBRUEsRUFBQyxLQUFHRSxPQUFJQyxLQUFFRCxHQUFFLE1BQU1GLElBQUVDLEVBQUMsR0FBRUMsR0FBRUgsRUFBQyxFQUFFLFFBQVFJLEVBQUMsR0FBRUUsS0FBRSxDQUFDRixHQUFFLHFCQUFxQixHQUFFQyxLQUFFLENBQUNELEdBQUUsOEJBQThCLEdBQUVHLEtBQUVILEdBQUUsbUJBQW1CO0FBQUcsVUFBTUksS0FBRSxFQUFFLElBQUksTUFBTVAsSUFBRSxFQUFDLFNBQVFLLElBQUUsWUFBVyxLQUFFLENBQUMsR0FBRUosRUFBQztBQUFFLFdBQU9LLE1BQUdDLEdBQUUsZUFBZSxHQUFFSCxNQUFHTCxHQUFFLGNBQWNRLEVBQUMsR0FBRUEsR0FBRSxvQkFBa0JKLE1BQUdBLEdBQUUsZUFBZSxHQUFFSTtBQUFBLEVBQUMsRUFBQztBQUFFLFdBQVMsRUFBRVIsSUFBRUMsS0FBRSxDQUFDLEdBQUU7QUFBQyxlQUFTLENBQUNDLElBQUVDLEVBQUMsS0FBSSxPQUFPLFFBQVFGLEVBQUMsRUFBRSxLQUFHO0FBQUMsTUFBQUQsR0FBRUUsRUFBQyxJQUFFQztBQUFBLElBQUMsU0FBT0YsSUFBRTtBQUFDLGFBQU8sZUFBZUQsSUFBRUUsSUFBRSxFQUFDLGNBQWEsTUFBRyxLQUFJLE1BQUlDLEdBQUMsQ0FBQztBQUFBLElBQUM7QUFBQyxXQUFPSDtBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxRQUFHLFdBQVNBLEdBQUUsUUFBTTtBQUFHLFFBQUcsWUFBVUEsR0FBRSxRQUFNO0FBQUcsUUFBR0EsT0FBSSxPQUFPQSxFQUFDLEVBQUUsU0FBUyxFQUFFLFFBQU8sT0FBT0EsRUFBQztBQUFFLFFBQUcsT0FBS0EsTUFBRyxXQUFTQSxHQUFFLFFBQU87QUFBSyxRQUFHLFlBQVUsT0FBT0EsR0FBRSxRQUFPQTtBQUFFLFFBQUc7QUFBQyxhQUFPLEtBQUssTUFBTSxtQkFBbUJBLEVBQUMsQ0FBQztBQUFBLElBQUMsU0FBT0MsSUFBRTtBQUFDLGFBQU9EO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxXQUFPQSxHQUFFLFFBQVEsVUFBUyxDQUFBQSxPQUFHLElBQUlBLEdBQUUsWUFBWSxDQUFDLEVBQUU7QUFBQSxFQUFDO0FBQUMsUUFBTSxJQUFFLEVBQUMsaUJBQWlCQSxJQUFFQyxJQUFFQyxJQUFFO0FBQUMsSUFBQUYsR0FBRSxhQUFhLFdBQVcsRUFBRUMsRUFBQyxDQUFDLElBQUdDLEVBQUM7QUFBQSxFQUFDLEdBQUUsb0JBQW9CRixJQUFFQyxJQUFFO0FBQUMsSUFBQUQsR0FBRSxnQkFBZ0IsV0FBVyxFQUFFQyxFQUFDLENBQUMsRUFBRTtBQUFBLEVBQUMsR0FBRSxrQkFBa0JELElBQUU7QUFBQyxRQUFHLENBQUNBLEdBQUUsUUFBTSxDQUFDO0FBQUUsVUFBTUMsS0FBRSxDQUFDLEdBQUVDLEtBQUUsT0FBTyxLQUFLRixHQUFFLE9BQU8sRUFBRSxPQUFPLENBQUFBLE9BQUdBLEdBQUUsV0FBVyxJQUFJLEtBQUcsQ0FBQ0EsR0FBRSxXQUFXLFVBQVUsQ0FBQztBQUFFLGVBQVVHLE1BQUtELElBQUU7QUFBQyxVQUFJQSxLQUFFQyxHQUFFLFFBQVEsT0FBTSxFQUFFO0FBQUUsTUFBQUQsS0FBRUEsR0FBRSxPQUFPLENBQUMsRUFBRSxZQUFZLElBQUVBLEdBQUUsTUFBTSxDQUFDLEdBQUVELEdBQUVDLEVBQUMsSUFBRSxFQUFFRixHQUFFLFFBQVFHLEVBQUMsQ0FBQztBQUFBLElBQUM7QUFBQyxXQUFPRjtBQUFBLEVBQUMsR0FBRSxrQkFBaUIsQ0FBQ0QsSUFBRUMsT0FBSSxFQUFFRCxHQUFFLGFBQWEsV0FBVyxFQUFFQyxFQUFDLENBQUMsRUFBRSxDQUFDLEVBQUM7QUFBQSxFQUFFLE1BQU0sRUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsWUFBTSxJQUFJLE1BQU0scUVBQXFFO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBV0QsSUFBRTtBQUFDLGFBQU9BLEtBQUUsS0FBSyxnQkFBZ0JBLEVBQUMsR0FBRUEsS0FBRSxLQUFLLGtCQUFrQkEsRUFBQyxHQUFFLEtBQUssaUJBQWlCQSxFQUFDLEdBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsYUFBT0E7QUFBQSxJQUFDO0FBQUEsSUFBQyxnQkFBZ0JBLElBQUVDLElBQUU7QUFBQyxZQUFNQyxLQUFFLEVBQUVELEVBQUMsSUFBRSxFQUFFLGlCQUFpQkEsSUFBRSxRQUFRLElBQUUsQ0FBQztBQUFFLGFBQU0sRUFBQyxHQUFHLEtBQUssWUFBWSxTQUFRLEdBQUcsWUFBVSxPQUFPQyxLQUFFQSxLQUFFLENBQUMsR0FBRSxHQUFHLEVBQUVELEVBQUMsSUFBRSxFQUFFLGtCQUFrQkEsRUFBQyxJQUFFLENBQUMsR0FBRSxHQUFHLFlBQVUsT0FBT0QsS0FBRUEsS0FBRSxDQUFDLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJBLElBQUVDLEtBQUUsS0FBSyxZQUFZLGFBQVk7QUFBQyxpQkFBUyxDQUFDQyxJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRRixFQUFDLEdBQUU7QUFBQyxjQUFNQSxLQUFFRCxHQUFFRSxFQUFDLEdBQUVFLEtBQUUsRUFBRUgsRUFBQyxJQUFFLFlBQVUsRUFBRUEsRUFBQztBQUFFLFlBQUcsQ0FBQyxJQUFJLE9BQU9FLEVBQUMsRUFBRSxLQUFLQyxFQUFDLEVBQUUsT0FBTSxJQUFJLFVBQVUsR0FBRyxLQUFLLFlBQVksS0FBSyxZQUFZLENBQUMsYUFBYUYsRUFBQyxvQkFBb0JFLEVBQUMsd0JBQXdCRCxFQUFDLElBQUk7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQSxFQUFDLE1BQU0sVUFBVSxFQUFDO0FBQUEsSUFBQyxZQUFZSCxJQUFFQyxJQUFFO0FBQUMsWUFBTSxJQUFHRCxLQUFFLEVBQUVBLEVBQUMsT0FBSyxLQUFLLFdBQVNBLElBQUUsS0FBSyxVQUFRLEtBQUssV0FBV0MsRUFBQyxHQUFFLEVBQUUsSUFBSSxLQUFLLFVBQVMsS0FBSyxZQUFZLFVBQVMsSUFBSTtBQUFBLElBQUU7QUFBQSxJQUFDLFVBQVM7QUFBQyxRQUFFLE9BQU8sS0FBSyxVQUFTLEtBQUssWUFBWSxRQUFRLEdBQUUsRUFBRSxJQUFJLEtBQUssVUFBUyxLQUFLLFlBQVksU0FBUztBQUFFLGlCQUFVRCxNQUFLLE9BQU8sb0JBQW9CLElBQUksRUFBRSxNQUFLQSxFQUFDLElBQUU7QUFBQSxJQUFJO0FBQUEsSUFBQyxlQUFlQSxJQUFFQyxJQUFFQyxLQUFFLE1BQUc7QUFBQyxRQUFFRixJQUFFQyxJQUFFQyxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBV0YsSUFBRTtBQUFDLGFBQU9BLEtBQUUsS0FBSyxnQkFBZ0JBLElBQUUsS0FBSyxRQUFRLEdBQUVBLEtBQUUsS0FBSyxrQkFBa0JBLEVBQUMsR0FBRSxLQUFLLGlCQUFpQkEsRUFBQyxHQUFFQTtBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sWUFBWUEsSUFBRTtBQUFDLGFBQU8sRUFBRSxJQUFJLEVBQUVBLEVBQUMsR0FBRSxLQUFLLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLG9CQUFvQkEsSUFBRUMsS0FBRSxDQUFDLEdBQUU7QUFBQyxhQUFPLEtBQUssWUFBWUQsRUFBQyxLQUFHLElBQUksS0FBS0EsSUFBRSxZQUFVLE9BQU9DLEtBQUVBLEtBQUUsSUFBSTtBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU07QUFBQSxJQUFPO0FBQUEsSUFBQyxXQUFXLFdBQVU7QUFBQyxhQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxZQUFXO0FBQUMsYUFBTSxJQUFJLEtBQUssUUFBUTtBQUFBLElBQUU7QUFBQSxJQUFDLE9BQU8sVUFBVUQsSUFBRTtBQUFDLGFBQU0sR0FBR0EsRUFBQyxHQUFHLEtBQUssU0FBUztBQUFBLElBQUU7QUFBQSxFQUFDO0FBQUMsUUFBTSxJQUFFLENBQUFBLE9BQUc7QUFBQyxRQUFJQyxLQUFFRCxHQUFFLGFBQWEsZ0JBQWdCO0FBQUUsUUFBRyxDQUFDQyxNQUFHLFFBQU1BLElBQUU7QUFBQyxVQUFJQyxLQUFFRixHQUFFLGFBQWEsTUFBTTtBQUFFLFVBQUcsQ0FBQ0UsTUFBRyxDQUFDQSxHQUFFLFNBQVMsR0FBRyxLQUFHLENBQUNBLEdBQUUsV0FBVyxHQUFHLEVBQUUsUUFBTztBQUFLLE1BQUFBLEdBQUUsU0FBUyxHQUFHLEtBQUcsQ0FBQ0EsR0FBRSxXQUFXLEdBQUcsTUFBSUEsS0FBRSxJQUFJQSxHQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFJRCxLQUFFQyxNQUFHLFFBQU1BLEtBQUVBLEdBQUUsS0FBSyxJQUFFO0FBQUEsSUFBSTtBQUFDLFdBQU9ELEtBQUVBLEdBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFBRCxPQUFHLEVBQUVBLEVBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRyxJQUFFO0FBQUEsRUFBSSxHQUFFLElBQUUsRUFBQyxNQUFLLENBQUNBLElBQUVDLEtBQUUsU0FBUyxvQkFBa0IsQ0FBQyxFQUFFLE9BQU8sR0FBRyxRQUFRLFVBQVUsaUJBQWlCLEtBQUtBLElBQUVELEVBQUMsQ0FBQyxHQUFFLFNBQVEsQ0FBQ0EsSUFBRUMsS0FBRSxTQUFTLG9CQUFrQixRQUFRLFVBQVUsY0FBYyxLQUFLQSxJQUFFRCxFQUFDLEdBQUUsVUFBUyxDQUFDQSxJQUFFQyxPQUFJLENBQUMsRUFBRSxPQUFPLEdBQUdELEdBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQUEsT0FBR0EsR0FBRSxRQUFRQyxFQUFDLENBQUMsR0FBRSxRQUFRRCxJQUFFQyxJQUFFO0FBQUMsVUFBTUMsS0FBRSxDQUFDO0FBQUUsUUFBSUMsS0FBRUgsR0FBRSxXQUFXLFFBQVFDLEVBQUM7QUFBRSxXQUFLRSxLQUFHLENBQUFELEdBQUUsS0FBS0MsRUFBQyxHQUFFQSxLQUFFQSxHQUFFLFdBQVcsUUFBUUYsRUFBQztBQUFFLFdBQU9DO0FBQUEsRUFBQyxHQUFFLEtBQUtGLElBQUVDLElBQUU7QUFBQyxRQUFJQyxLQUFFRixHQUFFO0FBQXVCLFdBQUtFLE1BQUc7QUFBQyxVQUFHQSxHQUFFLFFBQVFELEVBQUMsRUFBRSxRQUFNLENBQUNDLEVBQUM7QUFBRSxNQUFBQSxLQUFFQSxHQUFFO0FBQUEsSUFBc0I7QUFBQyxXQUFNLENBQUM7QUFBQSxFQUFDLEdBQUUsS0FBS0YsSUFBRUMsSUFBRTtBQUFDLFFBQUlDLEtBQUVGLEdBQUU7QUFBbUIsV0FBS0UsTUFBRztBQUFDLFVBQUdBLEdBQUUsUUFBUUQsRUFBQyxFQUFFLFFBQU0sQ0FBQ0MsRUFBQztBQUFFLE1BQUFBLEtBQUVBLEdBQUU7QUFBQSxJQUFrQjtBQUFDLFdBQU0sQ0FBQztBQUFBLEVBQUMsR0FBRSxrQkFBa0JGLElBQUU7QUFBQyxVQUFNQyxLQUFFLENBQUMsS0FBSSxVQUFTLFNBQVEsWUFBVyxVQUFTLFdBQVUsY0FBYSwwQkFBMEIsRUFBRSxJQUFJLENBQUFELE9BQUcsR0FBR0EsRUFBQyx1QkFBdUIsRUFBRSxLQUFLLEdBQUc7QUFBRSxXQUFPLEtBQUssS0FBS0MsSUFBRUQsRUFBQyxFQUFFLE9BQU8sQ0FBQUEsT0FBRyxDQUFDLEVBQUVBLEVBQUMsS0FBRyxFQUFFQSxFQUFDLENBQUM7QUFBQSxFQUFDLEdBQUUsdUJBQXVCQSxJQUFFO0FBQUMsVUFBTUMsS0FBRSxFQUFFRCxFQUFDO0FBQUUsV0FBT0MsTUFBRyxFQUFFLFFBQVFBLEVBQUMsSUFBRUEsS0FBRTtBQUFBLEVBQUksR0FBRSx1QkFBdUJELElBQUU7QUFBQyxVQUFNQyxLQUFFLEVBQUVELEVBQUM7QUFBRSxXQUFPQyxLQUFFLEVBQUUsUUFBUUEsRUFBQyxJQUFFO0FBQUEsRUFBSSxHQUFFLGdDQUFnQ0QsSUFBRTtBQUFDLFVBQU1DLEtBQUUsRUFBRUQsRUFBQztBQUFFLFdBQU9DLEtBQUUsRUFBRSxLQUFLQSxFQUFDLElBQUUsQ0FBQztBQUFBLEVBQUMsRUFBQyxHQUFFLElBQUUsQ0FBQ0QsSUFBRUMsS0FBRSxXQUFTO0FBQUMsVUFBTUMsS0FBRSxnQkFBZ0JGLEdBQUUsU0FBUyxJQUFHRyxLQUFFSCxHQUFFO0FBQUssTUFBRSxHQUFHLFVBQVNFLElBQUUscUJBQXFCQyxFQUFDLE1BQUssU0FBU0QsSUFBRTtBQUFDLFVBQUcsQ0FBQyxLQUFJLE1BQU0sRUFBRSxTQUFTLEtBQUssT0FBTyxLQUFHQSxHQUFFLGVBQWUsR0FBRSxFQUFFLElBQUksRUFBRTtBQUFPLFlBQU1FLEtBQUUsRUFBRSx1QkFBdUIsSUFBSSxLQUFHLEtBQUssUUFBUSxJQUFJRCxFQUFDLEVBQUU7QUFBRSxNQUFBSCxHQUFFLG9CQUFvQkksRUFBQyxFQUFFSCxFQUFDLEVBQUU7QUFBQSxJQUFDLENBQUM7QUFBQSxFQUFDLEdBQUUsSUFBRSxhQUFZLElBQUUsUUFBUSxDQUFDLElBQUcsSUFBRSxTQUFTLENBQUM7QUFBQSxFQUFHLE1BQU0sVUFBVSxFQUFDO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBTztBQUFBLElBQUMsUUFBTztBQUFDLFVBQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxDQUFDLEVBQUUsaUJBQWlCO0FBQU8sV0FBSyxTQUFTLFVBQVUsT0FBTyxNQUFNO0FBQUUsWUFBTUQsS0FBRSxLQUFLLFNBQVMsVUFBVSxTQUFTLE1BQU07QUFBRSxXQUFLLGVBQWUsTUFBSSxLQUFLLGdCQUFnQixHQUFFLEtBQUssVUFBU0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLGtCQUFpQjtBQUFDLFdBQUssU0FBUyxPQUFPLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxDQUFDLEdBQUUsS0FBSyxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxnQkFBZ0JBLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBSyxXQUFVO0FBQUMsY0FBTUMsS0FBRSxFQUFFLG9CQUFvQixJQUFJO0FBQUUsWUFBRyxZQUFVLE9BQU9ELElBQUU7QUFBQyxjQUFHLFdBQVNDLEdBQUVELEVBQUMsS0FBR0EsR0FBRSxXQUFXLEdBQUcsS0FBRyxrQkFBZ0JBLEdBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBQyxHQUFFRCxFQUFDLEVBQUUsSUFBSTtBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsR0FBRSxPQUFPLEdBQUUsRUFBRSxDQUFDO0FBQUUsUUFBTSxJQUFFO0FBQUEsRUFBNEIsTUFBTSxVQUFVLEVBQUM7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFRO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxTQUFTLGFBQWEsZ0JBQWUsS0FBSyxTQUFTLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFLLFdBQVU7QUFBQyxjQUFNQyxLQUFFLEVBQUUsb0JBQW9CLElBQUk7QUFBRSxxQkFBV0QsTUFBR0MsR0FBRUQsRUFBQyxFQUFFO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyw0QkFBMkIsR0FBRSxDQUFBQSxPQUFHO0FBQUMsSUFBQUEsR0FBRSxlQUFlO0FBQUUsVUFBTUMsS0FBRUQsR0FBRSxPQUFPLFFBQVEsQ0FBQztBQUFFLE1BQUUsb0JBQW9CQyxFQUFDLEVBQUUsT0FBTztBQUFBLEVBQUMsQ0FBQyxHQUFFLEVBQUUsQ0FBQztBQUFFLFFBQU0sS0FBRyxhQUFZLEtBQUcsYUFBYSxFQUFFLElBQUcsS0FBRyxZQUFZLEVBQUUsSUFBRyxLQUFHLFdBQVcsRUFBRSxJQUFHLEtBQUcsY0FBYyxFQUFFLElBQUcsS0FBRyxZQUFZLEVBQUUsSUFBRyxLQUFHLEVBQUMsYUFBWSxNQUFLLGNBQWEsTUFBSyxlQUFjLEtBQUksR0FBRSxLQUFHLEVBQUMsYUFBWSxtQkFBa0IsY0FBYSxtQkFBa0IsZUFBYyxrQkFBaUI7QUFBQSxFQUFFLE1BQU0sV0FBVyxFQUFDO0FBQUEsSUFBQyxZQUFZRCxJQUFFQyxJQUFFO0FBQUMsWUFBTSxHQUFFLEtBQUssV0FBU0QsSUFBRUEsTUFBRyxHQUFHLFlBQVksTUFBSSxLQUFLLFVBQVEsS0FBSyxXQUFXQyxFQUFDLEdBQUUsS0FBSyxVQUFRLEdBQUUsS0FBSyx3QkFBc0IsUUFBUSxPQUFPLFlBQVksR0FBRSxLQUFLLFlBQVk7QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFPO0FBQUEsSUFBQyxVQUFTO0FBQUMsUUFBRSxJQUFJLEtBQUssVUFBUyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBT0QsSUFBRTtBQUFDLFdBQUssd0JBQXNCLEtBQUssd0JBQXdCQSxFQUFDLE1BQUksS0FBSyxVQUFRQSxHQUFFLFdBQVMsS0FBSyxVQUFRQSxHQUFFLFFBQVEsQ0FBQyxFQUFFO0FBQUEsSUFBTztBQUFBLElBQUMsS0FBS0EsSUFBRTtBQUFDLFdBQUssd0JBQXdCQSxFQUFDLE1BQUksS0FBSyxVQUFRQSxHQUFFLFVBQVEsS0FBSyxVQUFTLEtBQUssYUFBYSxHQUFFLEVBQUUsS0FBSyxRQUFRLFdBQVc7QUFBQSxJQUFDO0FBQUEsSUFBQyxNQUFNQSxJQUFFO0FBQUMsV0FBSyxVQUFRQSxHQUFFLFdBQVNBLEdBQUUsUUFBUSxTQUFPLElBQUUsSUFBRUEsR0FBRSxRQUFRLENBQUMsRUFBRSxVQUFRLEtBQUs7QUFBQSxJQUFPO0FBQUEsSUFBQyxlQUFjO0FBQUMsWUFBTUEsS0FBRSxLQUFLLElBQUksS0FBSyxPQUFPO0FBQUUsVUFBR0EsTUFBRyxHQUFHO0FBQU8sWUFBTUMsS0FBRUQsS0FBRSxLQUFLO0FBQVEsV0FBSyxVQUFRLEdBQUVDLE1BQUcsRUFBRUEsS0FBRSxJQUFFLEtBQUssUUFBUSxnQkFBYyxLQUFLLFFBQVEsWUFBWTtBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWE7QUFBQyxXQUFLLHlCQUF1QixFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsQ0FBQUQsT0FBRyxLQUFLLE9BQU9BLEVBQUMsQ0FBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBRyxDQUFBQSxPQUFHLEtBQUssS0FBS0EsRUFBQyxDQUFDLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxlQUFlLE1BQUksRUFBRSxHQUFHLEtBQUssVUFBUyxJQUFHLENBQUFBLE9BQUcsS0FBSyxPQUFPQSxFQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsQ0FBQUEsT0FBRyxLQUFLLE1BQU1BLEVBQUMsQ0FBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBRyxDQUFBQSxPQUFHLEtBQUssS0FBS0EsRUFBQyxDQUFDO0FBQUEsSUFBRTtBQUFBLElBQUMsd0JBQXdCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLDBCQUF3QixVQUFRQSxHQUFFLGVBQWEsWUFBVUEsR0FBRTtBQUFBLElBQVk7QUFBQSxJQUFDLE9BQU8sY0FBYTtBQUFDLGFBQU0sa0JBQWlCLFNBQVMsbUJBQWlCLFVBQVUsaUJBQWU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLFFBQU0sS0FBRyxnQkFBZSxLQUFHLGFBQVksS0FBRyxhQUFZLEtBQUcsY0FBYSxLQUFHLFFBQU8sS0FBRyxRQUFPLEtBQUcsUUFBTyxLQUFHLFNBQVEsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsVUFBVSxFQUFFLElBQUcsS0FBRyxhQUFhLEVBQUUsSUFBRyxLQUFHLGFBQWEsRUFBRSxJQUFHLEtBQUcsWUFBWSxFQUFFLElBQUcsS0FBRyxPQUFPLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxZQUFXLEtBQUcsVUFBUyxLQUFHLFdBQVUsS0FBRyxrQkFBaUIsS0FBRyxLQUFHLElBQUcsS0FBRyxFQUFDLENBQUMsRUFBRSxHQUFFLElBQUcsQ0FBQyxFQUFFLEdBQUUsR0FBRSxHQUFFLEtBQUcsRUFBQyxVQUFTLEtBQUksVUFBUyxNQUFHLE9BQU0sU0FBUSxNQUFLLE9BQUcsT0FBTSxNQUFHLE1BQUssS0FBRSxHQUFFLEtBQUcsRUFBQyxVQUFTLG9CQUFtQixVQUFTLFdBQVUsT0FBTSxvQkFBbUIsTUFBSyxvQkFBbUIsT0FBTSxXQUFVLE1BQUssVUFBUztBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUVDLElBQUU7QUFBQyxZQUFNRCxJQUFFQyxFQUFDLEdBQUUsS0FBSyxZQUFVLE1BQUssS0FBSyxpQkFBZSxNQUFLLEtBQUssYUFBVyxPQUFHLEtBQUssZUFBYSxNQUFLLEtBQUssZUFBYSxNQUFLLEtBQUsscUJBQW1CLEVBQUUsUUFBUSx3QkFBdUIsS0FBSyxRQUFRLEdBQUUsS0FBSyxtQkFBbUIsR0FBRSxLQUFLLFFBQVEsU0FBTyxNQUFJLEtBQUssTUFBTTtBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQVU7QUFBQSxJQUFDLE9BQU07QUFBQyxXQUFLLE9BQU8sRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGtCQUFpQjtBQUFDLE9BQUMsU0FBUyxVQUFRLEVBQUUsS0FBSyxRQUFRLEtBQUcsS0FBSyxLQUFLO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTTtBQUFDLFdBQUssT0FBTyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsUUFBTztBQUFDLFdBQUssY0FBWSxFQUFFLEtBQUssUUFBUSxHQUFFLEtBQUssZUFBZTtBQUFBLElBQUM7QUFBQSxJQUFDLFFBQU87QUFBQyxXQUFLLGVBQWUsR0FBRSxLQUFLLGdCQUFnQixHQUFFLEtBQUssWUFBVSxZQUFZLE1BQUksS0FBSyxnQkFBZ0IsR0FBRSxLQUFLLFFBQVEsUUFBUTtBQUFBLElBQUM7QUFBQSxJQUFDLG9CQUFtQjtBQUFDLFdBQUssUUFBUSxTQUFPLEtBQUssYUFBVyxFQUFFLElBQUksS0FBSyxVQUFTLElBQUcsTUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFFLEtBQUssTUFBTTtBQUFBLElBQUU7QUFBQSxJQUFDLEdBQUdELElBQUU7QUFBQyxZQUFNQyxLQUFFLEtBQUssVUFBVTtBQUFFLFVBQUdELEtBQUVDLEdBQUUsU0FBTyxLQUFHRCxLQUFFLEVBQUU7QUFBTyxVQUFHLEtBQUssV0FBVyxRQUFPLEtBQUssRUFBRSxJQUFJLEtBQUssVUFBUyxJQUFHLE1BQUksS0FBSyxHQUFHQSxFQUFDLENBQUM7QUFBRSxZQUFNRSxLQUFFLEtBQUssY0FBYyxLQUFLLFdBQVcsQ0FBQztBQUFFLFVBQUdBLE9BQUlGLEdBQUU7QUFBTyxZQUFNRyxLQUFFSCxLQUFFRSxLQUFFLEtBQUc7QUFBRyxXQUFLLE9BQU9DLElBQUVGLEdBQUVELEVBQUMsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLFVBQVM7QUFBQyxXQUFLLGdCQUFjLEtBQUssYUFBYSxRQUFRLEdBQUUsTUFBTSxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsYUFBT0EsR0FBRSxrQkFBZ0JBLEdBQUUsVUFBU0E7QUFBQSxJQUFDO0FBQUEsSUFBQyxxQkFBb0I7QUFBQyxXQUFLLFFBQVEsWUFBVSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsQ0FBQUEsT0FBRyxLQUFLLFNBQVNBLEVBQUMsQ0FBQyxHQUFFLFlBQVUsS0FBSyxRQUFRLFVBQVEsRUFBRSxHQUFHLEtBQUssVUFBUyxJQUFHLE1BQUksS0FBSyxNQUFNLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsTUFBSSxLQUFLLGtCQUFrQixDQUFDLElBQUcsS0FBSyxRQUFRLFNBQU8sR0FBRyxZQUFZLEtBQUcsS0FBSyx3QkFBd0I7QUFBQSxJQUFDO0FBQUEsSUFBQywwQkFBeUI7QUFBQyxpQkFBVUEsTUFBSyxFQUFFLEtBQUssc0JBQXFCLEtBQUssUUFBUSxFQUFFLEdBQUUsR0FBR0EsSUFBRSxJQUFHLENBQUFBLE9BQUdBLEdBQUUsZUFBZSxDQUFDO0FBQUUsWUFBTUEsS0FBRSxFQUFDLGNBQWEsTUFBSSxLQUFLLE9BQU8sS0FBSyxrQkFBa0IsRUFBRSxDQUFDLEdBQUUsZUFBYyxNQUFJLEtBQUssT0FBTyxLQUFLLGtCQUFrQixFQUFFLENBQUMsR0FBRSxhQUFZLE1BQUk7QUFBQyxvQkFBVSxLQUFLLFFBQVEsVUFBUSxLQUFLLE1BQU0sR0FBRSxLQUFLLGdCQUFjLGFBQWEsS0FBSyxZQUFZLEdBQUUsS0FBSyxlQUFhLFdBQVcsTUFBSSxLQUFLLGtCQUFrQixHQUFFLE1BQUksS0FBSyxRQUFRLFFBQVE7QUFBQSxNQUFFLEVBQUM7QUFBRSxXQUFLLGVBQWEsSUFBSSxHQUFHLEtBQUssVUFBU0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFNBQVNBLElBQUU7QUFBQyxVQUFHLGtCQUFrQixLQUFLQSxHQUFFLE9BQU8sT0FBTyxFQUFFO0FBQU8sWUFBTUMsS0FBRSxHQUFHRCxHQUFFLEdBQUc7QUFBRSxNQUFBQyxPQUFJRCxHQUFFLGVBQWUsR0FBRSxLQUFLLE9BQU8sS0FBSyxrQkFBa0JDLEVBQUMsQ0FBQztBQUFBLElBQUU7QUFBQSxJQUFDLGNBQWNELElBQUU7QUFBQyxhQUFPLEtBQUssVUFBVSxFQUFFLFFBQVFBLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQywyQkFBMkJBLElBQUU7QUFBQyxVQUFHLENBQUMsS0FBSyxtQkFBbUI7QUFBTyxZQUFNQyxLQUFFLEVBQUUsUUFBUSxJQUFHLEtBQUssa0JBQWtCO0FBQUUsTUFBQUEsR0FBRSxVQUFVLE9BQU8sRUFBRSxHQUFFQSxHQUFFLGdCQUFnQixjQUFjO0FBQUUsWUFBTUMsS0FBRSxFQUFFLFFBQVEsc0JBQXNCRixFQUFDLE1BQUssS0FBSyxrQkFBa0I7QUFBRSxNQUFBRSxPQUFJQSxHQUFFLFVBQVUsSUFBSSxFQUFFLEdBQUVBLEdBQUUsYUFBYSxnQkFBZSxNQUFNO0FBQUEsSUFBRTtBQUFBLElBQUMsa0JBQWlCO0FBQUMsWUFBTUYsS0FBRSxLQUFLLGtCQUFnQixLQUFLLFdBQVc7QUFBRSxVQUFHLENBQUNBLEdBQUU7QUFBTyxZQUFNQyxLQUFFLE9BQU8sU0FBU0QsR0FBRSxhQUFhLGtCQUFrQixHQUFFLEVBQUU7QUFBRSxXQUFLLFFBQVEsV0FBU0MsTUFBRyxLQUFLLFFBQVE7QUFBQSxJQUFlO0FBQUEsSUFBQyxPQUFPRCxJQUFFQyxLQUFFLE1BQUs7QUFBQyxVQUFHLEtBQUssV0FBVztBQUFPLFlBQU1DLEtBQUUsS0FBSyxXQUFXLEdBQUVDLEtBQUVILE9BQUksSUFBR0ksS0FBRUgsTUFBRyxFQUFFLEtBQUssVUFBVSxHQUFFQyxJQUFFQyxJQUFFLEtBQUssUUFBUSxJQUFJO0FBQUUsVUFBR0MsT0FBSUYsR0FBRTtBQUFPLFlBQU1JLEtBQUUsS0FBSyxjQUFjRixFQUFDLEdBQUVDLEtBQUUsQ0FBQUosT0FBRyxFQUFFLFFBQVEsS0FBSyxVQUFTQSxJQUFFLEVBQUMsZUFBY0csSUFBRSxXQUFVLEtBQUssa0JBQWtCSixFQUFDLEdBQUUsTUFBSyxLQUFLLGNBQWNFLEVBQUMsR0FBRSxJQUFHSSxHQUFDLENBQUM7QUFBRSxVQUFHRCxHQUFFLEVBQUUsRUFBRSxpQkFBaUI7QUFBTyxVQUFHLENBQUNILE1BQUcsQ0FBQ0UsR0FBRTtBQUFPLFlBQU1HLEtBQUUsUUFBUSxLQUFLLFNBQVM7QUFBRSxXQUFLLE1BQU0sR0FBRSxLQUFLLGFBQVcsTUFBRyxLQUFLLDJCQUEyQkQsRUFBQyxHQUFFLEtBQUssaUJBQWVGO0FBQUUsWUFBTUksS0FBRUwsS0FBRSx3QkFBc0IscUJBQW9CTSxLQUFFTixLQUFFLHVCQUFxQjtBQUFxQixNQUFBQyxHQUFFLFVBQVUsSUFBSUssRUFBQyxHQUFFLEVBQUVMLEVBQUMsR0FBRUYsR0FBRSxVQUFVLElBQUlNLEVBQUMsR0FBRUosR0FBRSxVQUFVLElBQUlJLEVBQUMsR0FBRSxLQUFLLGVBQWUsTUFBSTtBQUFDLFFBQUFKLEdBQUUsVUFBVSxPQUFPSSxJQUFFQyxFQUFDLEdBQUVMLEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRUYsR0FBRSxVQUFVLE9BQU8sSUFBR08sSUFBRUQsRUFBQyxHQUFFLEtBQUssYUFBVyxPQUFHSCxHQUFFLEVBQUU7QUFBQSxNQUFDLEdBQUVILElBQUUsS0FBSyxZQUFZLENBQUMsR0FBRUssTUFBRyxLQUFLLE1BQU07QUFBQSxJQUFDO0FBQUEsSUFBQyxjQUFhO0FBQUMsYUFBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLE9BQU87QUFBQSxJQUFDO0FBQUEsSUFBQyxhQUFZO0FBQUMsYUFBTyxFQUFFLFFBQVEsSUFBRyxLQUFLLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxZQUFXO0FBQUMsYUFBTyxFQUFFLEtBQUssSUFBRyxLQUFLLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBZ0I7QUFBQyxXQUFLLGNBQVksY0FBYyxLQUFLLFNBQVMsR0FBRSxLQUFLLFlBQVU7QUFBQSxJQUFLO0FBQUEsSUFBQyxrQkFBa0JQLElBQUU7QUFBQyxhQUFPLEVBQUUsSUFBRUEsT0FBSSxLQUFHLEtBQUcsS0FBR0EsT0FBSSxLQUFHLEtBQUc7QUFBQSxJQUFFO0FBQUEsSUFBQyxrQkFBa0JBLElBQUU7QUFBQyxhQUFPLEVBQUUsSUFBRUEsT0FBSSxLQUFHLEtBQUcsS0FBR0EsT0FBSSxLQUFHLEtBQUc7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFPLGdCQUFnQkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxLQUFLLFdBQVU7QUFBQyxjQUFNQyxLQUFFLEdBQUcsb0JBQW9CLE1BQUtELEVBQUM7QUFBRSxZQUFHLFlBQVUsT0FBT0EsSUFBRTtBQUFDLGNBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsZ0JBQUcsV0FBU0MsR0FBRUQsRUFBQyxLQUFHQSxHQUFFLFdBQVcsR0FBRyxLQUFHLGtCQUFnQkEsR0FBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFlBQUFDLEdBQUVELEVBQUMsRUFBRTtBQUFBLFVBQUM7QUFBQSxRQUFDLE1BQU0sQ0FBQUMsR0FBRSxHQUFHRCxFQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLHVDQUFzQyxTQUFTQSxJQUFFO0FBQUMsVUFBTUMsS0FBRSxFQUFFLHVCQUF1QixJQUFJO0FBQUUsUUFBRyxDQUFDQSxNQUFHLENBQUNBLEdBQUUsVUFBVSxTQUFTLEVBQUUsRUFBRTtBQUFPLElBQUFELEdBQUUsZUFBZTtBQUFFLFVBQU1FLEtBQUUsR0FBRyxvQkFBb0JELEVBQUMsR0FBRUUsS0FBRSxLQUFLLGFBQWEsa0JBQWtCO0FBQUUsV0FBT0EsTUFBR0QsR0FBRSxHQUFHQyxFQUFDLEdBQUUsS0FBS0QsR0FBRSxrQkFBa0IsS0FBRyxXQUFTLEVBQUUsaUJBQWlCLE1BQUssT0FBTyxLQUFHQSxHQUFFLEtBQUssR0FBRSxLQUFLQSxHQUFFLGtCQUFrQixNQUFJQSxHQUFFLEtBQUssR0FBRSxLQUFLQSxHQUFFLGtCQUFrQjtBQUFBLEVBQUUsQ0FBQyxHQUFFLEVBQUUsR0FBRyxRQUFPLElBQUcsTUFBSTtBQUFDLFVBQU1GLEtBQUUsRUFBRSxLQUFLLDJCQUEyQjtBQUFFLGVBQVVDLE1BQUtELEdBQUUsSUFBRyxvQkFBb0JDLEVBQUM7QUFBQSxFQUFDLENBQUMsR0FBRSxFQUFFLEVBQUU7QUFBRSxRQUFNLEtBQUcsZ0JBQWUsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxTQUFTLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxhQUFZLEtBQUcsUUFBTyxLQUFHLFlBQVcsS0FBRyxjQUFhLEtBQUcsV0FBVyxFQUFFLEtBQUssRUFBRSxJQUFHLEtBQUcsK0JBQThCLEtBQUcsRUFBQyxRQUFPLE1BQUssUUFBTyxLQUFFLEdBQUUsS0FBRyxFQUFDLFFBQU8sa0JBQWlCLFFBQU8sVUFBUztBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlELElBQUVDLElBQUU7QUFBQyxZQUFNRCxJQUFFQyxFQUFDLEdBQUUsS0FBSyxtQkFBaUIsT0FBRyxLQUFLLGdCQUFjLENBQUM7QUFBRSxZQUFNQyxLQUFFLEVBQUUsS0FBSyxFQUFFO0FBQUUsaUJBQVVGLE1BQUtFLElBQUU7QUFBQyxjQUFNRCxLQUFFLEVBQUUsdUJBQXVCRCxFQUFDLEdBQUVFLEtBQUUsRUFBRSxLQUFLRCxFQUFDLEVBQUUsT0FBTyxDQUFBRCxPQUFHQSxPQUFJLEtBQUssUUFBUTtBQUFFLGlCQUFPQyxNQUFHQyxHQUFFLFVBQVEsS0FBSyxjQUFjLEtBQUtGLEVBQUM7QUFBQSxNQUFDO0FBQUMsV0FBSyxvQkFBb0IsR0FBRSxLQUFLLFFBQVEsVUFBUSxLQUFLLDBCQUEwQixLQUFLLGVBQWMsS0FBSyxTQUFTLENBQUMsR0FBRSxLQUFLLFFBQVEsVUFBUSxLQUFLLE9BQU87QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFVO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxTQUFTLElBQUUsS0FBSyxLQUFLLElBQUUsS0FBSyxLQUFLO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTTtBQUFDLFVBQUcsS0FBSyxvQkFBa0IsS0FBSyxTQUFTLEVBQUU7QUFBTyxVQUFJQSxLQUFFLENBQUM7QUFBRSxVQUFHLEtBQUssUUFBUSxXQUFTQSxLQUFFLEtBQUssdUJBQXVCLHNDQUFzQyxFQUFFLE9BQU8sQ0FBQUEsT0FBR0EsT0FBSSxLQUFLLFFBQVEsRUFBRSxJQUFJLENBQUFBLE9BQUcsR0FBRyxvQkFBb0JBLElBQUUsRUFBQyxRQUFPLE1BQUUsQ0FBQyxDQUFDLElBQUdBLEdBQUUsVUFBUUEsR0FBRSxDQUFDLEVBQUUsaUJBQWlCO0FBQU8sVUFBRyxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsRUFBRSxpQkFBaUI7QUFBTyxpQkFBVUMsTUFBS0QsR0FBRSxDQUFBQyxHQUFFLEtBQUs7QUFBRSxZQUFNQSxLQUFFLEtBQUssY0FBYztBQUFFLFdBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssU0FBUyxNQUFNQSxFQUFDLElBQUUsR0FBRSxLQUFLLDBCQUEwQixLQUFLLGVBQWMsSUFBRSxHQUFFLEtBQUssbUJBQWlCO0FBQUcsWUFBTUMsS0FBRSxTQUFTRCxHQUFFLENBQUMsRUFBRSxZQUFZLElBQUVBLEdBQUUsTUFBTSxDQUFDLENBQUM7QUFBRyxXQUFLLGVBQWUsTUFBSTtBQUFDLGFBQUssbUJBQWlCLE9BQUcsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxJQUFHLEVBQUUsR0FBRSxLQUFLLFNBQVMsTUFBTUEsRUFBQyxJQUFFLElBQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFO0FBQUEsTUFBQyxHQUFFLEtBQUssVUFBUyxJQUFFLEdBQUUsS0FBSyxTQUFTLE1BQU1BLEVBQUMsSUFBRSxHQUFHLEtBQUssU0FBU0MsRUFBQyxDQUFDO0FBQUEsSUFBSTtBQUFBLElBQUMsT0FBTTtBQUFDLFVBQUcsS0FBSyxvQkFBa0IsQ0FBQyxLQUFLLFNBQVMsRUFBRTtBQUFPLFVBQUcsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUsaUJBQWlCO0FBQU8sWUFBTUYsS0FBRSxLQUFLLGNBQWM7QUFBRSxXQUFLLFNBQVMsTUFBTUEsRUFBQyxJQUFFLEdBQUcsS0FBSyxTQUFTLHNCQUFzQixFQUFFQSxFQUFDLENBQUMsTUFBSyxFQUFFLEtBQUssUUFBUSxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLE9BQU8sSUFBRyxFQUFFO0FBQUUsaUJBQVVBLE1BQUssS0FBSyxlQUFjO0FBQUMsY0FBTUMsS0FBRSxFQUFFLHVCQUF1QkQsRUFBQztBQUFFLFFBQUFDLE1BQUcsQ0FBQyxLQUFLLFNBQVNBLEVBQUMsS0FBRyxLQUFLLDBCQUEwQixDQUFDRCxFQUFDLEdBQUUsS0FBRTtBQUFBLE1BQUM7QUFBQyxXQUFLLG1CQUFpQixNQUFHLEtBQUssU0FBUyxNQUFNQSxFQUFDLElBQUUsSUFBRyxLQUFLLGVBQWUsTUFBSTtBQUFDLGFBQUssbUJBQWlCLE9BQUcsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFO0FBQUEsTUFBQyxHQUFFLEtBQUssVUFBUyxJQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsU0FBU0EsS0FBRSxLQUFLLFVBQVM7QUFBQyxhQUFPQSxHQUFFLFVBQVUsU0FBUyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsYUFBT0EsR0FBRSxTQUFPLFFBQVFBLEdBQUUsTUFBTSxHQUFFQSxHQUFFLFNBQU8sRUFBRUEsR0FBRSxNQUFNLEdBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMsZ0JBQWU7QUFBQyxhQUFPLEtBQUssU0FBUyxVQUFVLFNBQVMscUJBQXFCLElBQUUsVUFBUTtBQUFBLElBQVE7QUFBQSxJQUFDLHNCQUFxQjtBQUFDLFVBQUcsQ0FBQyxLQUFLLFFBQVEsT0FBTztBQUFPLFlBQU1BLEtBQUUsS0FBSyx1QkFBdUIsRUFBRTtBQUFFLGlCQUFVQyxNQUFLRCxJQUFFO0FBQUMsY0FBTUEsS0FBRSxFQUFFLHVCQUF1QkMsRUFBQztBQUFFLFFBQUFELE1BQUcsS0FBSywwQkFBMEIsQ0FBQ0MsRUFBQyxHQUFFLEtBQUssU0FBU0QsRUFBQyxDQUFDO0FBQUEsTUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLHVCQUF1QkEsSUFBRTtBQUFDLFlBQU1DLEtBQUUsRUFBRSxLQUFLLElBQUcsS0FBSyxRQUFRLE1BQU07QUFBRSxhQUFPLEVBQUUsS0FBS0QsSUFBRSxLQUFLLFFBQVEsTUFBTSxFQUFFLE9BQU8sQ0FBQUEsT0FBRyxDQUFDQyxHQUFFLFNBQVNELEVBQUMsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLDBCQUEwQkEsSUFBRUMsSUFBRTtBQUFDLFVBQUdELEdBQUUsT0FBTyxZQUFVRSxNQUFLRixHQUFFLENBQUFFLEdBQUUsVUFBVSxPQUFPLGFBQVksQ0FBQ0QsRUFBQyxHQUFFQyxHQUFFLGFBQWEsaUJBQWdCRCxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxnQkFBZ0JELElBQUU7QUFBQyxZQUFNQyxLQUFFLENBQUM7QUFBRSxhQUFNLFlBQVUsT0FBT0QsTUFBRyxZQUFZLEtBQUtBLEVBQUMsTUFBSUMsR0FBRSxTQUFPLFFBQUksS0FBSyxLQUFLLFdBQVU7QUFBQyxjQUFNQyxLQUFFLEdBQUcsb0JBQW9CLE1BQUtELEVBQUM7QUFBRSxZQUFHLFlBQVUsT0FBT0QsSUFBRTtBQUFDLGNBQUcsV0FBU0UsR0FBRUYsRUFBQyxFQUFFLE9BQU0sSUFBSSxVQUFVLG9CQUFvQkEsRUFBQyxHQUFHO0FBQUUsVUFBQUUsR0FBRUYsRUFBQyxFQUFFO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBQztBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsSUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLFNBQVNBLElBQUU7QUFBQyxLQUFDLFFBQU1BLEdBQUUsT0FBTyxXQUFTQSxHQUFFLGtCQUFnQixRQUFNQSxHQUFFLGVBQWUsWUFBVUEsR0FBRSxlQUFlO0FBQUUsZUFBVUEsTUFBSyxFQUFFLGdDQUFnQyxJQUFJLEVBQUUsSUFBRyxvQkFBb0JBLElBQUUsRUFBQyxRQUFPLE1BQUUsQ0FBQyxFQUFFLE9BQU87QUFBQSxFQUFDLENBQUMsR0FBRSxFQUFFLEVBQUU7QUFBRSxRQUFNLEtBQUcsWUFBVyxLQUFHLGdCQUFlLEtBQUcsYUFBWSxLQUFHLFdBQVUsS0FBRyxhQUFZLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxTQUFTLEVBQUUsSUFBRyxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsUUFBUSxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxVQUFVLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxRQUFPLEtBQUcsNkRBQTRELEtBQUcsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFHLEtBQUcsa0JBQWlCLEtBQUcsRUFBRSxJQUFFLFlBQVUsYUFBWSxLQUFHLEVBQUUsSUFBRSxjQUFZLFdBQVUsS0FBRyxFQUFFLElBQUUsZUFBYSxnQkFBZSxLQUFHLEVBQUUsSUFBRSxpQkFBZSxjQUFhLEtBQUcsRUFBRSxJQUFFLGVBQWEsZUFBYyxLQUFHLEVBQUUsSUFBRSxnQkFBYyxjQUFhLEtBQUcsRUFBQyxXQUFVLE1BQUcsVUFBUyxtQkFBa0IsU0FBUSxXQUFVLFFBQU8sQ0FBQyxHQUFFLENBQUMsR0FBRSxjQUFhLE1BQUssV0FBVSxTQUFRLEdBQUUsS0FBRyxFQUFDLFdBQVUsb0JBQW1CLFVBQVMsb0JBQW1CLFNBQVEsVUFBUyxRQUFPLDJCQUEwQixjQUFhLDBCQUF5QixXQUFVLDBCQUF5QjtBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUVDLElBQUU7QUFBQyxZQUFNRCxJQUFFQyxFQUFDLEdBQUUsS0FBSyxVQUFRLE1BQUssS0FBSyxVQUFRLEtBQUssU0FBUyxZQUFXLEtBQUssUUFBTSxFQUFFLEtBQUssS0FBSyxVQUFTLEVBQUUsRUFBRSxDQUFDLEtBQUcsRUFBRSxLQUFLLEtBQUssVUFBUyxFQUFFLEVBQUUsQ0FBQyxLQUFHLEVBQUUsUUFBUSxJQUFHLEtBQUssT0FBTyxHQUFFLEtBQUssWUFBVSxLQUFLLGNBQWM7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxTQUFRO0FBQUMsYUFBTyxLQUFLLFNBQVMsSUFBRSxLQUFLLEtBQUssSUFBRSxLQUFLLEtBQUs7QUFBQSxJQUFDO0FBQUEsSUFBQyxPQUFNO0FBQUMsVUFBRyxFQUFFLEtBQUssUUFBUSxLQUFHLEtBQUssU0FBUyxFQUFFO0FBQU8sWUFBTUQsS0FBRSxFQUFDLGVBQWMsS0FBSyxTQUFRO0FBQUUsVUFBRyxDQUFDLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBR0EsRUFBQyxFQUFFLGtCQUFpQjtBQUFDLFlBQUcsS0FBSyxjQUFjLEdBQUUsa0JBQWlCLFNBQVMsbUJBQWlCLENBQUMsS0FBSyxRQUFRLFFBQVEsYUFBYSxFQUFFLFlBQVVBLE1BQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxTQUFTLEtBQUssUUFBUSxFQUFFLEdBQUUsR0FBR0EsSUFBRSxhQUFZLENBQUM7QUFBRSxhQUFLLFNBQVMsTUFBTSxHQUFFLEtBQUssU0FBUyxhQUFhLGlCQUFnQixJQUFFLEdBQUUsS0FBSyxNQUFNLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHQSxFQUFDO0FBQUEsTUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU07QUFBQyxVQUFHLEVBQUUsS0FBSyxRQUFRLEtBQUcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtBQUFPLFlBQU1BLEtBQUUsRUFBQyxlQUFjLEtBQUssU0FBUTtBQUFFLFdBQUssY0FBY0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFVBQVM7QUFBQyxXQUFLLFdBQVMsS0FBSyxRQUFRLFFBQVEsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxZQUFVLEtBQUssY0FBYyxHQUFFLEtBQUssV0FBUyxLQUFLLFFBQVEsT0FBTztBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWNBLElBQUU7QUFBQyxVQUFHLENBQUMsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHQSxFQUFDLEVBQUUsa0JBQWlCO0FBQUMsWUFBRyxrQkFBaUIsU0FBUyxnQkFBZ0IsWUFBVUEsTUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLFNBQVMsS0FBSyxRQUFRLEVBQUUsR0FBRSxJQUFJQSxJQUFFLGFBQVksQ0FBQztBQUFFLGFBQUssV0FBUyxLQUFLLFFBQVEsUUFBUSxHQUFFLEtBQUssTUFBTSxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssU0FBUyxhQUFhLGlCQUFnQixPQUFPLEdBQUUsRUFBRSxvQkFBb0IsS0FBSyxPQUFNLFFBQVEsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUdBLEVBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBV0EsSUFBRTtBQUFDLFVBQUcsWUFBVSxRQUFPQSxLQUFFLE1BQU0sV0FBV0EsRUFBQyxHQUFHLGFBQVcsQ0FBQyxFQUFFQSxHQUFFLFNBQVMsS0FBRyxjQUFZLE9BQU9BLEdBQUUsVUFBVSxzQkFBc0IsT0FBTSxJQUFJLFVBQVUsR0FBRyxHQUFHLFlBQVksQ0FBQyxnR0FBZ0c7QUFBRSxhQUFPQTtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsVUFBRyxXQUFTLEVBQUUsT0FBTSxJQUFJLFVBQVUsdUVBQXVFO0FBQUUsVUFBSUEsS0FBRSxLQUFLO0FBQVMsbUJBQVcsS0FBSyxRQUFRLFlBQVVBLEtBQUUsS0FBSyxVQUFRLEVBQUUsS0FBSyxRQUFRLFNBQVMsSUFBRUEsS0FBRSxFQUFFLEtBQUssUUFBUSxTQUFTLElBQUUsWUFBVSxPQUFPLEtBQUssUUFBUSxjQUFZQSxLQUFFLEtBQUssUUFBUTtBQUFXLFlBQU1DLEtBQUUsS0FBSyxpQkFBaUI7QUFBRSxXQUFLLFVBQVEsRUFBRSxhQUFhRCxJQUFFLEtBQUssT0FBTUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVU7QUFBQyxhQUFPLEtBQUssTUFBTSxVQUFVLFNBQVMsRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsWUFBTUQsS0FBRSxLQUFLO0FBQVEsVUFBR0EsR0FBRSxVQUFVLFNBQVMsU0FBUyxFQUFFLFFBQU87QUFBRyxVQUFHQSxHQUFFLFVBQVUsU0FBUyxXQUFXLEVBQUUsUUFBTztBQUFHLFVBQUdBLEdBQUUsVUFBVSxTQUFTLGVBQWUsRUFBRSxRQUFNO0FBQU0sVUFBR0EsR0FBRSxVQUFVLFNBQVMsaUJBQWlCLEVBQUUsUUFBTTtBQUFTLFlBQU1DLEtBQUUsVUFBUSxpQkFBaUIsS0FBSyxLQUFLLEVBQUUsaUJBQWlCLGVBQWUsRUFBRSxLQUFLO0FBQUUsYUFBT0QsR0FBRSxVQUFVLFNBQVMsUUFBUSxJQUFFQyxLQUFFLEtBQUcsS0FBR0EsS0FBRSxLQUFHO0FBQUEsSUFBRTtBQUFBLElBQUMsZ0JBQWU7QUFBQyxhQUFPLFNBQU8sS0FBSyxTQUFTLFFBQVEsU0FBUztBQUFBLElBQUM7QUFBQSxJQUFDLGFBQVk7QUFBQyxZQUFLLEVBQUMsUUFBT0QsR0FBQyxJQUFFLEtBQUs7QUFBUSxhQUFNLFlBQVUsT0FBT0EsS0FBRUEsR0FBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUFBLE9BQUcsT0FBTyxTQUFTQSxJQUFFLEVBQUUsQ0FBQyxJQUFFLGNBQVksT0FBT0EsS0FBRSxDQUFBQyxPQUFHRCxHQUFFQyxJQUFFLEtBQUssUUFBUSxJQUFFRDtBQUFBLElBQUM7QUFBQSxJQUFDLG1CQUFrQjtBQUFDLFlBQU1BLEtBQUUsRUFBQyxXQUFVLEtBQUssY0FBYyxHQUFFLFdBQVUsQ0FBQyxFQUFDLE1BQUssbUJBQWtCLFNBQVEsRUFBQyxVQUFTLEtBQUssUUFBUSxTQUFRLEVBQUMsR0FBRSxFQUFDLE1BQUssVUFBUyxTQUFRLEVBQUMsUUFBTyxLQUFLLFdBQVcsRUFBQyxFQUFDLENBQUMsRUFBQztBQUFFLGNBQU8sS0FBSyxhQUFXLGFBQVcsS0FBSyxRQUFRLGFBQVcsRUFBRSxpQkFBaUIsS0FBSyxPQUFNLFVBQVMsUUFBUSxHQUFFQSxHQUFFLFlBQVUsQ0FBQyxFQUFDLE1BQUssZUFBYyxTQUFRLE1BQUUsQ0FBQyxJQUFHLEVBQUMsR0FBR0EsSUFBRSxHQUFHLEVBQUUsS0FBSyxRQUFRLGNBQWEsQ0FBQyxRQUFPQSxFQUFDLENBQUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFnQixFQUFDLEtBQUlBLElBQUUsUUFBT0MsR0FBQyxHQUFFO0FBQUMsWUFBTUMsS0FBRSxFQUFFLEtBQUssK0RBQThELEtBQUssS0FBSyxFQUFFLE9BQU8sQ0FBQUYsT0FBRyxFQUFFQSxFQUFDLENBQUM7QUFBRSxNQUFBRSxHQUFFLFVBQVEsRUFBRUEsSUFBRUQsSUFBRUQsT0FBSSxJQUFHLENBQUNFLEdBQUUsU0FBU0QsRUFBQyxDQUFDLEVBQUUsTUFBTTtBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCRCxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQUssV0FBVTtBQUFDLGNBQU1DLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0QsRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsY0FBRyxXQUFTQyxHQUFFRCxFQUFDLEVBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBQyxHQUFFRCxFQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxXQUFXQSxJQUFFO0FBQUMsVUFBRyxNQUFJQSxHQUFFLFVBQVEsWUFBVUEsR0FBRSxRQUFNLFVBQVFBLEdBQUUsSUFBSTtBQUFPLFlBQU1DLEtBQUUsRUFBRSxLQUFLLEVBQUU7QUFBRSxpQkFBVUMsTUFBS0QsSUFBRTtBQUFDLGNBQU1BLEtBQUUsR0FBRyxZQUFZQyxFQUFDO0FBQUUsWUFBRyxDQUFDRCxNQUFHLFVBQUtBLEdBQUUsUUFBUSxVQUFVO0FBQVMsY0FBTUUsS0FBRUgsR0FBRSxhQUFhLEdBQUVJLEtBQUVELEdBQUUsU0FBU0YsR0FBRSxLQUFLO0FBQUUsWUFBR0UsR0FBRSxTQUFTRixHQUFFLFFBQVEsS0FBRyxhQUFXQSxHQUFFLFFBQVEsYUFBVyxDQUFDRyxNQUFHLGNBQVlILEdBQUUsUUFBUSxhQUFXRyxHQUFFO0FBQVMsWUFBR0gsR0FBRSxNQUFNLFNBQVNELEdBQUUsTUFBTSxNQUFJLFlBQVVBLEdBQUUsUUFBTSxVQUFRQSxHQUFFLE9BQUsscUNBQXFDLEtBQUtBLEdBQUUsT0FBTyxPQUFPLEdBQUc7QUFBUyxjQUFNTSxLQUFFLEVBQUMsZUFBY0wsR0FBRSxTQUFRO0FBQUUsb0JBQVVELEdBQUUsU0FBT00sR0FBRSxhQUFXTixLQUFHQyxHQUFFLGNBQWNLLEVBQUM7QUFBQSxNQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxzQkFBc0JOLElBQUU7QUFBQyxZQUFNQyxLQUFFLGtCQUFrQixLQUFLRCxHQUFFLE9BQU8sT0FBTyxHQUFFRSxLQUFFLGFBQVdGLEdBQUUsS0FBSUcsS0FBRSxDQUFDLElBQUcsRUFBRSxFQUFFLFNBQVNILEdBQUUsR0FBRztBQUFFLFVBQUcsQ0FBQ0csTUFBRyxDQUFDRCxHQUFFO0FBQU8sVUFBR0QsTUFBRyxDQUFDQyxHQUFFO0FBQU8sTUFBQUYsR0FBRSxlQUFlO0FBQUUsWUFBTUksS0FBRSxLQUFLLFFBQVEsRUFBRSxJQUFFLE9BQUssRUFBRSxLQUFLLE1BQUssRUFBRSxFQUFFLENBQUMsS0FBRyxFQUFFLEtBQUssTUFBSyxFQUFFLEVBQUUsQ0FBQyxLQUFHLEVBQUUsUUFBUSxJQUFHSixHQUFFLGVBQWUsVUFBVSxHQUFFTSxLQUFFLEdBQUcsb0JBQW9CRixFQUFDO0FBQUUsVUFBR0QsR0FBRSxRQUFPSCxHQUFFLGdCQUFnQixHQUFFTSxHQUFFLEtBQUssR0FBRSxLQUFLQSxHQUFFLGdCQUFnQk4sRUFBQztBQUFFLE1BQUFNLEdBQUUsU0FBUyxNQUFJTixHQUFFLGdCQUFnQixHQUFFTSxHQUFFLEtBQUssR0FBRUYsR0FBRSxNQUFNO0FBQUEsSUFBRTtBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLElBQUcsR0FBRyxxQkFBcUIsR0FBRSxFQUFFLEdBQUcsVUFBUyxJQUFHLElBQUcsR0FBRyxxQkFBcUIsR0FBRSxFQUFFLEdBQUcsVUFBUyxJQUFHLEdBQUcsVUFBVSxHQUFFLEVBQUUsR0FBRyxVQUFTLElBQUcsR0FBRyxVQUFVLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLFNBQVNKLElBQUU7QUFBQyxJQUFBQSxHQUFFLGVBQWUsR0FBRSxHQUFHLG9CQUFvQixJQUFJLEVBQUUsT0FBTztBQUFBLEVBQUMsQ0FBQyxHQUFFLEVBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxZQUFXLEtBQUcsUUFBTyxLQUFHLGdCQUFnQixFQUFFLElBQUcsS0FBRyxFQUFDLFdBQVUsa0JBQWlCLGVBQWMsTUFBSyxZQUFXLE9BQUcsV0FBVSxNQUFHLGFBQVksT0FBTSxHQUFFLEtBQUcsRUFBQyxXQUFVLFVBQVMsZUFBYyxtQkFBa0IsWUFBVyxXQUFVLFdBQVUsV0FBVSxhQUFZLG1CQUFrQjtBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUU7QUFBQyxZQUFNLEdBQUUsS0FBSyxVQUFRLEtBQUssV0FBV0EsRUFBQyxHQUFFLEtBQUssY0FBWSxPQUFHLEtBQUssV0FBUztBQUFBLElBQUk7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLEtBQUtBLElBQUU7QUFBQyxVQUFHLENBQUMsS0FBSyxRQUFRLFVBQVUsUUFBTyxLQUFLLEVBQUVBLEVBQUM7QUFBRSxXQUFLLFFBQVE7QUFBRSxZQUFNQyxLQUFFLEtBQUssWUFBWTtBQUFFLFdBQUssUUFBUSxjQUFZLEVBQUVBLEVBQUMsR0FBRUEsR0FBRSxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssa0JBQWtCLE1BQUk7QUFBQyxVQUFFRCxFQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsS0FBS0EsSUFBRTtBQUFDLFdBQUssUUFBUSxhQUFXLEtBQUssWUFBWSxFQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUUsS0FBSyxrQkFBa0IsTUFBSTtBQUFDLGFBQUssUUFBUSxHQUFFLEVBQUVBLEVBQUM7QUFBQSxNQUFDLENBQUMsS0FBRyxFQUFFQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssZ0JBQWMsRUFBRSxJQUFJLEtBQUssVUFBUyxFQUFFLEdBQUUsS0FBSyxTQUFTLE9BQU8sR0FBRSxLQUFLLGNBQVk7QUFBQSxJQUFHO0FBQUEsSUFBQyxjQUFhO0FBQUMsVUFBRyxDQUFDLEtBQUssVUFBUztBQUFDLGNBQU1BLEtBQUUsU0FBUyxjQUFjLEtBQUs7QUFBRSxRQUFBQSxHQUFFLFlBQVUsS0FBSyxRQUFRLFdBQVUsS0FBSyxRQUFRLGNBQVlBLEdBQUUsVUFBVSxJQUFJLE1BQU0sR0FBRSxLQUFLLFdBQVNBO0FBQUEsTUFBQztBQUFDLGFBQU8sS0FBSztBQUFBLElBQVE7QUFBQSxJQUFDLGtCQUFrQkEsSUFBRTtBQUFDLGFBQU9BLEdBQUUsY0FBWSxFQUFFQSxHQUFFLFdBQVcsR0FBRUE7QUFBQSxJQUFDO0FBQUEsSUFBQyxVQUFTO0FBQUMsVUFBRyxLQUFLLFlBQVk7QUFBTyxZQUFNQSxLQUFFLEtBQUssWUFBWTtBQUFFLFdBQUssUUFBUSxZQUFZLE9BQU9BLEVBQUMsR0FBRSxFQUFFLEdBQUdBLElBQUUsSUFBRyxNQUFJO0FBQUMsVUFBRSxLQUFLLFFBQVEsYUFBYTtBQUFBLE1BQUMsQ0FBQyxHQUFFLEtBQUssY0FBWTtBQUFBLElBQUU7QUFBQSxJQUFDLGtCQUFrQkEsSUFBRTtBQUFDLFFBQUVBLElBQUUsS0FBSyxZQUFZLEdBQUUsS0FBSyxRQUFRLFVBQVU7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLFFBQU0sS0FBRyxpQkFBZ0IsS0FBRyxVQUFVLEVBQUUsSUFBRyxLQUFHLGNBQWMsRUFBRSxJQUFHLEtBQUcsWUFBVyxLQUFHLEVBQUMsV0FBVSxNQUFHLGFBQVksS0FBSSxHQUFFLEtBQUcsRUFBQyxXQUFVLFdBQVUsYUFBWSxVQUFTO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUEsSUFBRTtBQUFDLFlBQU0sR0FBRSxLQUFLLFVBQVEsS0FBSyxXQUFXQSxFQUFDLEdBQUUsS0FBSyxZQUFVLE9BQUcsS0FBSyx1QkFBcUI7QUFBQSxJQUFJO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFXO0FBQUEsSUFBQyxXQUFVO0FBQUMsV0FBSyxjQUFZLEtBQUssUUFBUSxhQUFXLEtBQUssUUFBUSxZQUFZLE1BQU0sR0FBRSxFQUFFLElBQUksVUFBUyxFQUFFLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBRyxDQUFBQSxPQUFHLEtBQUssZUFBZUEsRUFBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLFVBQVMsSUFBRyxDQUFBQSxPQUFHLEtBQUssZUFBZUEsRUFBQyxDQUFDLEdBQUUsS0FBSyxZQUFVO0FBQUEsSUFBRztBQUFBLElBQUMsYUFBWTtBQUFDLFdBQUssY0FBWSxLQUFLLFlBQVUsT0FBRyxFQUFFLElBQUksVUFBUyxFQUFFO0FBQUEsSUFBRTtBQUFBLElBQUMsZUFBZUEsSUFBRTtBQUFDLFlBQUssRUFBQyxhQUFZQyxHQUFDLElBQUUsS0FBSztBQUFRLFVBQUdELEdBQUUsV0FBUyxZQUFVQSxHQUFFLFdBQVNDLE1BQUdBLEdBQUUsU0FBU0QsR0FBRSxNQUFNLEVBQUU7QUFBTyxZQUFNRSxLQUFFLEVBQUUsa0JBQWtCRCxFQUFDO0FBQUUsWUFBSUMsR0FBRSxTQUFPRCxHQUFFLE1BQU0sSUFBRSxLQUFLLHlCQUF1QixLQUFHQyxHQUFFQSxHQUFFLFNBQU8sQ0FBQyxFQUFFLE1BQU0sSUFBRUEsR0FBRSxDQUFDLEVBQUUsTUFBTTtBQUFBLElBQUM7QUFBQSxJQUFDLGVBQWVGLElBQUU7QUFBQyxnQkFBUUEsR0FBRSxRQUFNLEtBQUssdUJBQXFCQSxHQUFFLFdBQVMsS0FBRztBQUFBLElBQVU7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLHFEQUFvRCxLQUFHLGVBQWMsS0FBRyxpQkFBZ0IsS0FBRztBQUFBLEVBQWUsTUFBTSxHQUFFO0FBQUEsSUFBQyxjQUFhO0FBQUMsV0FBSyxXQUFTLFNBQVM7QUFBQSxJQUFJO0FBQUEsSUFBQyxXQUFVO0FBQUMsWUFBTUEsS0FBRSxTQUFTLGdCQUFnQjtBQUFZLGFBQU8sS0FBSyxJQUFJLE9BQU8sYUFBV0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU07QUFBQyxZQUFNQSxLQUFFLEtBQUssU0FBUztBQUFFLFdBQUssaUJBQWlCLEdBQUUsS0FBSyxzQkFBc0IsS0FBSyxVQUFTLElBQUcsQ0FBQUMsT0FBR0EsS0FBRUQsRUFBQyxHQUFFLEtBQUssc0JBQXNCLElBQUcsSUFBRyxDQUFBQyxPQUFHQSxLQUFFRCxFQUFDLEdBQUUsS0FBSyxzQkFBc0IsSUFBRyxJQUFHLENBQUFDLE9BQUdBLEtBQUVELEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxRQUFPO0FBQUMsV0FBSyx3QkFBd0IsS0FBSyxVQUFTLFVBQVUsR0FBRSxLQUFLLHdCQUF3QixLQUFLLFVBQVMsRUFBRSxHQUFFLEtBQUssd0JBQXdCLElBQUcsRUFBRSxHQUFFLEtBQUssd0JBQXdCLElBQUcsRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsYUFBTyxLQUFLLFNBQVMsSUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLG1CQUFrQjtBQUFDLFdBQUssc0JBQXNCLEtBQUssVUFBUyxVQUFVLEdBQUUsS0FBSyxTQUFTLE1BQU0sV0FBUztBQUFBLElBQVE7QUFBQSxJQUFDLHNCQUFzQkEsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLFlBQU1DLEtBQUUsS0FBSyxTQUFTO0FBQUUsV0FBSywyQkFBMkJILElBQUUsQ0FBQUEsT0FBRztBQUFDLFlBQUdBLE9BQUksS0FBSyxZQUFVLE9BQU8sYUFBV0EsR0FBRSxjQUFZRyxHQUFFO0FBQU8sYUFBSyxzQkFBc0JILElBQUVDLEVBQUM7QUFBRSxjQUFNRyxLQUFFLE9BQU8saUJBQWlCSixFQUFDLEVBQUUsaUJBQWlCQyxFQUFDO0FBQUUsUUFBQUQsR0FBRSxNQUFNLFlBQVlDLElBQUUsR0FBR0MsR0FBRSxPQUFPLFdBQVdFLEVBQUMsQ0FBQyxDQUFDLElBQUk7QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxzQkFBc0JKLElBQUVDLElBQUU7QUFBQyxZQUFNQyxLQUFFRixHQUFFLE1BQU0saUJBQWlCQyxFQUFDO0FBQUUsTUFBQUMsTUFBRyxFQUFFLGlCQUFpQkYsSUFBRUMsSUFBRUMsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLHdCQUF3QkYsSUFBRUMsSUFBRTtBQUFDLFdBQUssMkJBQTJCRCxJQUFFLENBQUFBLE9BQUc7QUFBQyxjQUFNRSxLQUFFLEVBQUUsaUJBQWlCRixJQUFFQyxFQUFDO0FBQUUsaUJBQU9DLE1BQUcsRUFBRSxvQkFBb0JGLElBQUVDLEVBQUMsR0FBRUQsR0FBRSxNQUFNLFlBQVlDLElBQUVDLEVBQUMsS0FBR0YsR0FBRSxNQUFNLGVBQWVDLEVBQUM7QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQywyQkFBMkJELElBQUVDLElBQUU7QUFBQyxVQUFHLEVBQUVELEVBQUMsRUFBRSxDQUFBQyxHQUFFRCxFQUFDO0FBQUEsVUFBTyxZQUFVRSxNQUFLLEVBQUUsS0FBS0YsSUFBRSxLQUFLLFFBQVEsRUFBRSxDQUFBQyxHQUFFQyxFQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxRQUFNLEtBQUcsYUFBWSxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsZ0JBQWdCLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLFNBQVMsRUFBRSxJQUFHLEtBQUcsZ0JBQWdCLEVBQUUsSUFBRyxLQUFHLG9CQUFvQixFQUFFLElBQUcsS0FBRyxrQkFBa0IsRUFBRSxJQUFHLEtBQUcsUUFBUSxFQUFFLGFBQVksS0FBRyxjQUFhLEtBQUcsUUFBTyxLQUFHLGdCQUFlLEtBQUcsRUFBQyxVQUFTLE1BQUcsT0FBTSxNQUFHLFVBQVMsS0FBRSxHQUFFLEtBQUcsRUFBQyxVQUFTLG9CQUFtQixPQUFNLFdBQVUsVUFBUyxVQUFTO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUYsSUFBRUMsSUFBRTtBQUFDLFlBQU1ELElBQUVDLEVBQUMsR0FBRSxLQUFLLFVBQVEsRUFBRSxRQUFRLGlCQUFnQixLQUFLLFFBQVEsR0FBRSxLQUFLLFlBQVUsS0FBSyxvQkFBb0IsR0FBRSxLQUFLLGFBQVcsS0FBSyxxQkFBcUIsR0FBRSxLQUFLLFdBQVMsT0FBRyxLQUFLLG1CQUFpQixPQUFHLEtBQUssYUFBVyxJQUFJLE1BQUcsS0FBSyxtQkFBbUI7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFPO0FBQUEsSUFBQyxPQUFPRCxJQUFFO0FBQUMsYUFBTyxLQUFLLFdBQVMsS0FBSyxLQUFLLElBQUUsS0FBSyxLQUFLQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsS0FBS0EsSUFBRTtBQUFDLFdBQUssWUFBVSxLQUFLLG9CQUFrQixFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsRUFBQyxlQUFjQSxHQUFDLENBQUMsRUFBRSxxQkFBbUIsS0FBSyxXQUFTLE1BQUcsS0FBSyxtQkFBaUIsTUFBRyxLQUFLLFdBQVcsS0FBSyxHQUFFLFNBQVMsS0FBSyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssY0FBYyxHQUFFLEtBQUssVUFBVSxLQUFLLE1BQUksS0FBSyxhQUFhQSxFQUFDLENBQUM7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFNO0FBQUMsV0FBSyxZQUFVLENBQUMsS0FBSyxxQkFBbUIsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEVBQUUscUJBQW1CLEtBQUssV0FBUyxPQUFHLEtBQUssbUJBQWlCLE1BQUcsS0FBSyxXQUFXLFdBQVcsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxLQUFLLGVBQWUsTUFBSSxLQUFLLFdBQVcsR0FBRSxLQUFLLFVBQVMsS0FBSyxZQUFZLENBQUM7QUFBQSxJQUFHO0FBQUEsSUFBQyxVQUFTO0FBQUMsUUFBRSxJQUFJLFFBQU8sRUFBRSxHQUFFLEVBQUUsSUFBSSxLQUFLLFNBQVEsRUFBRSxHQUFFLEtBQUssVUFBVSxRQUFRLEdBQUUsS0FBSyxXQUFXLFdBQVcsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxlQUFjO0FBQUMsV0FBSyxjQUFjO0FBQUEsSUFBQztBQUFBLElBQUMsc0JBQXFCO0FBQUMsYUFBTyxJQUFJLEdBQUcsRUFBQyxXQUFVLFFBQVEsS0FBSyxRQUFRLFFBQVEsR0FBRSxZQUFXLEtBQUssWUFBWSxFQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyx1QkFBc0I7QUFBQyxhQUFPLElBQUksR0FBRyxFQUFDLGFBQVksS0FBSyxTQUFRLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxhQUFhQSxJQUFFO0FBQUMsZUFBUyxLQUFLLFNBQVMsS0FBSyxRQUFRLEtBQUcsU0FBUyxLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUUsS0FBSyxTQUFTLE1BQU0sVUFBUSxTQUFRLEtBQUssU0FBUyxnQkFBZ0IsYUFBYSxHQUFFLEtBQUssU0FBUyxhQUFhLGNBQWEsSUFBRSxHQUFFLEtBQUssU0FBUyxhQUFhLFFBQU8sUUFBUSxHQUFFLEtBQUssU0FBUyxZQUFVO0FBQUUsWUFBTUMsS0FBRSxFQUFFLFFBQVEsZUFBYyxLQUFLLE9BQU87QUFBRSxNQUFBQSxPQUFJQSxHQUFFLFlBQVUsSUFBRyxFQUFFLEtBQUssUUFBUSxHQUFFLEtBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssZUFBZSxNQUFJO0FBQUMsYUFBSyxRQUFRLFNBQU8sS0FBSyxXQUFXLFNBQVMsR0FBRSxLQUFLLG1CQUFpQixPQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsSUFBRyxFQUFDLGVBQWNELEdBQUMsQ0FBQztBQUFBLE1BQUMsR0FBRSxLQUFLLFNBQVEsS0FBSyxZQUFZLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxxQkFBb0I7QUFBQyxRQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsQ0FBQUEsT0FBRztBQUFDLHFCQUFXQSxHQUFFLFFBQU0sS0FBSyxRQUFRLFdBQVMsS0FBSyxLQUFLLElBQUUsS0FBSywyQkFBMkI7QUFBQSxNQUFFLENBQUMsR0FBRSxFQUFFLEdBQUcsUUFBTyxJQUFHLE1BQUk7QUFBQyxhQUFLLFlBQVUsQ0FBQyxLQUFLLG9CQUFrQixLQUFLLGNBQWM7QUFBQSxNQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsQ0FBQUEsT0FBRztBQUFDLFVBQUUsSUFBSSxLQUFLLFVBQVMsSUFBRyxDQUFBQyxPQUFHO0FBQUMsZUFBSyxhQUFXRCxHQUFFLFVBQVEsS0FBSyxhQUFXQyxHQUFFLFdBQVMsYUFBVyxLQUFLLFFBQVEsV0FBUyxLQUFLLFFBQVEsWUFBVSxLQUFLLEtBQUssSUFBRSxLQUFLLDJCQUEyQjtBQUFBLFFBQUUsQ0FBQztBQUFBLE1BQUMsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLGFBQVk7QUFBQyxXQUFLLFNBQVMsTUFBTSxVQUFRLFFBQU8sS0FBSyxTQUFTLGFBQWEsZUFBYyxJQUFFLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixZQUFZLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixNQUFNLEdBQUUsS0FBSyxtQkFBaUIsT0FBRyxLQUFLLFVBQVUsS0FBSyxNQUFJO0FBQUMsaUJBQVMsS0FBSyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssa0JBQWtCLEdBQUUsS0FBSyxXQUFXLE1BQU0sR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxjQUFhO0FBQUMsYUFBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLE1BQU07QUFBQSxJQUFDO0FBQUEsSUFBQyw2QkFBNEI7QUFBQyxVQUFHLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRSxFQUFFLGlCQUFpQjtBQUFPLFlBQU1ELEtBQUUsS0FBSyxTQUFTLGVBQWEsU0FBUyxnQkFBZ0IsY0FBYUMsS0FBRSxLQUFLLFNBQVMsTUFBTTtBQUFVLG1CQUFXQSxNQUFHLEtBQUssU0FBUyxVQUFVLFNBQVMsRUFBRSxNQUFJRCxPQUFJLEtBQUssU0FBUyxNQUFNLFlBQVUsV0FBVSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLGVBQWUsTUFBSTtBQUFDLGFBQUssU0FBUyxVQUFVLE9BQU8sRUFBRSxHQUFFLEtBQUssZUFBZSxNQUFJO0FBQUMsZUFBSyxTQUFTLE1BQU0sWUFBVUM7QUFBQSxRQUFDLEdBQUUsS0FBSyxPQUFPO0FBQUEsTUFBQyxHQUFFLEtBQUssT0FBTyxHQUFFLEtBQUssU0FBUyxNQUFNO0FBQUEsSUFBRTtBQUFBLElBQUMsZ0JBQWU7QUFBQyxZQUFNRCxLQUFFLEtBQUssU0FBUyxlQUFhLFNBQVMsZ0JBQWdCLGNBQWFDLEtBQUUsS0FBSyxXQUFXLFNBQVMsR0FBRUMsS0FBRUQsS0FBRTtBQUFFLFVBQUdDLE1BQUcsQ0FBQ0YsSUFBRTtBQUFDLGNBQU1BLEtBQUUsRUFBRSxJQUFFLGdCQUFjO0FBQWUsYUFBSyxTQUFTLE1BQU1BLEVBQUMsSUFBRSxHQUFHQyxFQUFDO0FBQUEsTUFBSTtBQUFDLFVBQUcsQ0FBQ0MsTUFBR0YsSUFBRTtBQUFDLGNBQU1BLEtBQUUsRUFBRSxJQUFFLGlCQUFlO0FBQWMsYUFBSyxTQUFTLE1BQU1BLEVBQUMsSUFBRSxHQUFHQyxFQUFDO0FBQUEsTUFBSTtBQUFBLElBQUM7QUFBQSxJQUFDLG9CQUFtQjtBQUFDLFdBQUssU0FBUyxNQUFNLGNBQVksSUFBRyxLQUFLLFNBQVMsTUFBTSxlQUFhO0FBQUEsSUFBRTtBQUFBLElBQUMsT0FBTyxnQkFBZ0JELElBQUVDLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBSyxXQUFVO0FBQUMsY0FBTUMsS0FBRSxHQUFHLG9CQUFvQixNQUFLRixFQUFDO0FBQUUsWUFBRyxZQUFVLE9BQU9BLElBQUU7QUFBQyxjQUFHLFdBQVNFLEdBQUVGLEVBQUMsRUFBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFFLEdBQUVGLEVBQUMsRUFBRUMsRUFBQztBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsR0FBRyxVQUFTLElBQUcsNEJBQTJCLFNBQVNELElBQUU7QUFBQyxVQUFNQyxLQUFFLEVBQUUsdUJBQXVCLElBQUk7QUFBRSxLQUFDLEtBQUksTUFBTSxFQUFFLFNBQVMsS0FBSyxPQUFPLEtBQUdELEdBQUUsZUFBZSxHQUFFLEVBQUUsSUFBSUMsSUFBRSxJQUFHLENBQUFELE9BQUc7QUFBQyxNQUFBQSxHQUFFLG9CQUFrQixFQUFFLElBQUlDLElBQUUsSUFBRyxNQUFJO0FBQUMsVUFBRSxJQUFJLEtBQUcsS0FBSyxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQyxDQUFDO0FBQUUsVUFBTUMsS0FBRSxFQUFFLFFBQVEsYUFBYTtBQUFFLElBQUFBLE1BQUcsR0FBRyxZQUFZQSxFQUFDLEVBQUUsS0FBSyxHQUFFLEdBQUcsb0JBQW9CRCxFQUFDLEVBQUUsT0FBTyxJQUFJO0FBQUEsRUFBQyxDQUFDLEdBQUUsRUFBRSxFQUFFLEdBQUUsRUFBRSxFQUFFO0FBQUUsUUFBTSxLQUFHLGlCQUFnQixLQUFHLGFBQVksS0FBRyxPQUFPLEVBQUUsR0FBRyxFQUFFLElBQUcsS0FBRyxRQUFPLEtBQUcsV0FBVSxLQUFHLFVBQVMsS0FBRyxtQkFBa0IsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxnQkFBZ0IsRUFBRSxJQUFHLEtBQUcsU0FBUyxFQUFFLElBQUcsS0FBRyxTQUFTLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxHQUFHLEVBQUUsSUFBRyxLQUFHLGtCQUFrQixFQUFFLElBQUcsS0FBRyxFQUFDLFVBQVMsTUFBRyxVQUFTLE1BQUcsUUFBTyxNQUFFLEdBQUUsS0FBRyxFQUFDLFVBQVMsb0JBQW1CLFVBQVMsV0FBVSxRQUFPLFVBQVM7QUFBQSxFQUFFLE1BQU0sV0FBVyxFQUFDO0FBQUEsSUFBQyxZQUFZRCxJQUFFQyxJQUFFO0FBQUMsWUFBTUQsSUFBRUMsRUFBQyxHQUFFLEtBQUssV0FBUyxPQUFHLEtBQUssWUFBVSxLQUFLLG9CQUFvQixHQUFFLEtBQUssYUFBVyxLQUFLLHFCQUFxQixHQUFFLEtBQUssbUJBQW1CO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsY0FBYTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBVztBQUFBLElBQUMsT0FBT0QsSUFBRTtBQUFDLGFBQU8sS0FBSyxXQUFTLEtBQUssS0FBSyxJQUFFLEtBQUssS0FBS0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLEtBQUtBLElBQUU7QUFBQyxXQUFLLFlBQVUsRUFBRSxRQUFRLEtBQUssVUFBUyxJQUFHLEVBQUMsZUFBY0EsR0FBQyxDQUFDLEVBQUUscUJBQW1CLEtBQUssV0FBUyxNQUFHLEtBQUssVUFBVSxLQUFLLEdBQUUsS0FBSyxRQUFRLFVBQVMsSUFBSSxLQUFJLEtBQUssR0FBRSxLQUFLLFNBQVMsYUFBYSxjQUFhLElBQUUsR0FBRSxLQUFLLFNBQVMsYUFBYSxRQUFPLFFBQVEsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLGVBQWUsTUFBSTtBQUFDLGFBQUssUUFBUSxVQUFRLENBQUMsS0FBSyxRQUFRLFlBQVUsS0FBSyxXQUFXLFNBQVMsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsRUFBQyxlQUFjQSxHQUFDLENBQUM7QUFBQSxNQUFDLEdBQUUsS0FBSyxVQUFTLElBQUU7QUFBQSxJQUFFO0FBQUEsSUFBQyxPQUFNO0FBQUMsV0FBSyxhQUFXLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRSxFQUFFLHFCQUFtQixLQUFLLFdBQVcsV0FBVyxHQUFFLEtBQUssU0FBUyxLQUFLLEdBQUUsS0FBSyxXQUFTLE9BQUcsS0FBSyxTQUFTLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxVQUFVLEtBQUssR0FBRSxLQUFLLGVBQWUsTUFBSTtBQUFDLGFBQUssU0FBUyxVQUFVLE9BQU8sSUFBRyxFQUFFLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixZQUFZLEdBQUUsS0FBSyxTQUFTLGdCQUFnQixNQUFNLEdBQUUsS0FBSyxRQUFRLFVBQVMsSUFBSSxLQUFJLE1BQU0sR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7QUFBQSxNQUFDLEdBQUUsS0FBSyxVQUFTLElBQUU7QUFBQSxJQUFHO0FBQUEsSUFBQyxVQUFTO0FBQUMsV0FBSyxVQUFVLFFBQVEsR0FBRSxLQUFLLFdBQVcsV0FBVyxHQUFFLE1BQU0sUUFBUTtBQUFBLElBQUM7QUFBQSxJQUFDLHNCQUFxQjtBQUFDLFlBQU1BLEtBQUUsUUFBUSxLQUFLLFFBQVEsUUFBUTtBQUFFLGFBQU8sSUFBSSxHQUFHLEVBQUMsV0FBVSxzQkFBcUIsV0FBVUEsSUFBRSxZQUFXLE1BQUcsYUFBWSxLQUFLLFNBQVMsWUFBVyxlQUFjQSxLQUFFLE1BQUk7QUFBQyxxQkFBVyxLQUFLLFFBQVEsV0FBUyxLQUFLLEtBQUssSUFBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUU7QUFBQSxNQUFDLElBQUUsS0FBSSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsdUJBQXNCO0FBQUMsYUFBTyxJQUFJLEdBQUcsRUFBQyxhQUFZLEtBQUssU0FBUSxDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMscUJBQW9CO0FBQUMsUUFBRSxHQUFHLEtBQUssVUFBUyxJQUFHLENBQUFBLE9BQUc7QUFBQyxxQkFBV0EsR0FBRSxRQUFNLEtBQUssUUFBUSxXQUFTLEtBQUssS0FBSyxJQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRTtBQUFBLE1BQUUsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQUssV0FBVTtBQUFDLGNBQU1DLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0QsRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsY0FBRyxXQUFTQyxHQUFFRCxFQUFDLEtBQUdBLEdBQUUsV0FBVyxHQUFHLEtBQUcsa0JBQWdCQSxHQUFFLE9BQU0sSUFBSSxVQUFVLG9CQUFvQkEsRUFBQyxHQUFHO0FBQUUsVUFBQUMsR0FBRUQsRUFBQyxFQUFFLElBQUk7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsVUFBUyxJQUFHLGdDQUErQixTQUFTQSxJQUFFO0FBQUMsVUFBTUMsS0FBRSxFQUFFLHVCQUF1QixJQUFJO0FBQUUsUUFBRyxDQUFDLEtBQUksTUFBTSxFQUFFLFNBQVMsS0FBSyxPQUFPLEtBQUdELEdBQUUsZUFBZSxHQUFFLEVBQUUsSUFBSSxFQUFFO0FBQU8sTUFBRSxJQUFJQyxJQUFFLElBQUcsTUFBSTtBQUFDLFFBQUUsSUFBSSxLQUFHLEtBQUssTUFBTTtBQUFBLElBQUMsQ0FBQztBQUFFLFVBQU1DLEtBQUUsRUFBRSxRQUFRLEVBQUU7QUFBRSxJQUFBQSxNQUFHQSxPQUFJRCxNQUFHLEdBQUcsWUFBWUMsRUFBQyxFQUFFLEtBQUssR0FBRSxHQUFHLG9CQUFvQkQsRUFBQyxFQUFFLE9BQU8sSUFBSTtBQUFBLEVBQUMsQ0FBQyxHQUFFLEVBQUUsR0FBRyxRQUFPLElBQUcsTUFBSTtBQUFDLGVBQVVELE1BQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxJQUFHLG9CQUFvQkEsRUFBQyxFQUFFLEtBQUs7QUFBQSxFQUFDLENBQUMsR0FBRSxFQUFFLEdBQUcsUUFBTyxJQUFHLE1BQUk7QUFBQyxlQUFVQSxNQUFLLEVBQUUsS0FBSyw4Q0FBOEMsRUFBRSxhQUFVLGlCQUFpQkEsRUFBQyxFQUFFLFlBQVUsR0FBRyxvQkFBb0JBLEVBQUMsRUFBRSxLQUFLO0FBQUEsRUFBQyxDQUFDLEdBQUUsRUFBRSxFQUFFLEdBQUUsRUFBRSxFQUFFO0FBQUUsUUFBTSxLQUFHLEVBQUMsS0FBSSxDQUFDLFNBQVEsT0FBTSxNQUFLLFFBQU8sUUFBTyxnQkFBZ0IsR0FBRSxHQUFFLENBQUMsVUFBUyxRQUFPLFNBQVEsS0FBSyxHQUFFLE1BQUssQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLE1BQUssQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUksQ0FBQyxPQUFNLFVBQVMsT0FBTSxTQUFRLFNBQVEsUUFBUSxHQUFFLElBQUcsQ0FBQyxHQUFFLElBQUcsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLE9BQU0sQ0FBQyxHQUFFLE1BQUssQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFFLFFBQU8sQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUcsQ0FBQyxFQUFDLEdBQUUsS0FBRyxvQkFBSSxJQUFJLENBQUMsY0FBYSxRQUFPLFFBQU8sWUFBVyxZQUFXLFVBQVMsT0FBTSxZQUFZLENBQUMsR0FBRSxLQUFHLDJEQUEwRCxLQUFHLENBQUNBLElBQUVDLE9BQUk7QUFBQyxVQUFNQyxLQUFFRixHQUFFLFNBQVMsWUFBWTtBQUFFLFdBQU9DLEdBQUUsU0FBU0MsRUFBQyxJQUFFLENBQUMsR0FBRyxJQUFJQSxFQUFDLEtBQUcsUUFBUSxHQUFHLEtBQUtGLEdBQUUsU0FBUyxDQUFDLElBQUVDLEdBQUUsT0FBTyxDQUFBRCxPQUFHQSxjQUFhLE1BQU0sRUFBRSxLQUFLLENBQUFBLE9BQUdBLEdBQUUsS0FBS0UsRUFBQyxDQUFDO0FBQUEsRUFBQyxHQUFFLEtBQUcsRUFBQyxXQUFVLElBQUcsU0FBUSxDQUFDLEdBQUUsWUFBVyxJQUFHLE1BQUssT0FBRyxVQUFTLE1BQUcsWUFBVyxNQUFLLFVBQVMsY0FBYSxHQUFFLEtBQUcsRUFBQyxXQUFVLFVBQVMsU0FBUSxVQUFTLFlBQVcscUJBQW9CLE1BQUssV0FBVSxVQUFTLFdBQVUsWUFBVyxtQkFBa0IsVUFBUyxTQUFRLEdBQUUsS0FBRyxFQUFDLE9BQU0sa0NBQWlDLFVBQVMsbUJBQWtCO0FBQUEsRUFBRSxNQUFNLFdBQVcsRUFBQztBQUFBLElBQUMsWUFBWUYsSUFBRTtBQUFDLFlBQU0sR0FBRSxLQUFLLFVBQVEsS0FBSyxXQUFXQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsY0FBYTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBaUI7QUFBQSxJQUFDLGFBQVk7QUFBQyxhQUFPLE9BQU8sT0FBTyxLQUFLLFFBQVEsT0FBTyxFQUFFLElBQUksQ0FBQUEsT0FBRyxLQUFLLHlCQUF5QkEsRUFBQyxDQUFDLEVBQUUsT0FBTyxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsYUFBWTtBQUFDLGFBQU8sS0FBSyxXQUFXLEVBQUUsU0FBTztBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWNBLElBQUU7QUFBQyxhQUFPLEtBQUssY0FBY0EsRUFBQyxHQUFFLEtBQUssUUFBUSxVQUFRLEVBQUMsR0FBRyxLQUFLLFFBQVEsU0FBUSxHQUFHQSxHQUFDLEdBQUU7QUFBQSxJQUFJO0FBQUEsSUFBQyxTQUFRO0FBQUMsWUFBTUEsS0FBRSxTQUFTLGNBQWMsS0FBSztBQUFFLE1BQUFBLEdBQUUsWUFBVSxLQUFLLGVBQWUsS0FBSyxRQUFRLFFBQVE7QUFBRSxpQkFBUyxDQUFDQyxJQUFFQyxFQUFDLEtBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxPQUFPLEVBQUUsTUFBSyxZQUFZRixJQUFFRSxJQUFFRCxFQUFDO0FBQUUsWUFBTUEsS0FBRUQsR0FBRSxTQUFTLENBQUMsR0FBRUUsS0FBRSxLQUFLLHlCQUF5QixLQUFLLFFBQVEsVUFBVTtBQUFFLGFBQU9BLE1BQUdELEdBQUUsVUFBVSxJQUFJLEdBQUdDLEdBQUUsTUFBTSxHQUFHLENBQUMsR0FBRUQ7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJELElBQUU7QUFBQyxZQUFNLGlCQUFpQkEsRUFBQyxHQUFFLEtBQUssY0FBY0EsR0FBRSxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBY0EsSUFBRTtBQUFDLGlCQUFTLENBQUNDLElBQUVDLEVBQUMsS0FBSSxPQUFPLFFBQVFGLEVBQUMsRUFBRSxPQUFNLGlCQUFpQixFQUFDLFVBQVNDLElBQUUsT0FBTUMsR0FBQyxHQUFFLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxZQUFZRixJQUFFQyxJQUFFQyxJQUFFO0FBQUMsWUFBTUMsS0FBRSxFQUFFLFFBQVFELElBQUVGLEVBQUM7QUFBRSxNQUFBRyxRQUFLRixLQUFFLEtBQUsseUJBQXlCQSxFQUFDLEtBQUcsRUFBRUEsRUFBQyxJQUFFLEtBQUssc0JBQXNCLEVBQUVBLEVBQUMsR0FBRUUsRUFBQyxJQUFFLEtBQUssUUFBUSxPQUFLQSxHQUFFLFlBQVUsS0FBSyxlQUFlRixFQUFDLElBQUVFLEdBQUUsY0FBWUYsS0FBRUUsR0FBRSxPQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsZUFBZUgsSUFBRTtBQUFDLGFBQU8sS0FBSyxRQUFRLFlBQVMsU0FBU0EsSUFBRUMsSUFBRUMsSUFBRTtBQUFDLFlBQUcsQ0FBQ0YsR0FBRSxPQUFPLFFBQU9BO0FBQUUsWUFBR0UsTUFBRyxjQUFZLE9BQU9BLEdBQUUsUUFBT0EsR0FBRUYsRUFBQztBQUFFLGNBQU1HLEtBQUcsSUFBSSxPQUFPLFlBQVcsZ0JBQWdCSCxJQUFFLFdBQVcsR0FBRUksS0FBRSxDQUFDLEVBQUUsT0FBTyxHQUFHRCxHQUFFLEtBQUssaUJBQWlCLEdBQUcsQ0FBQztBQUFFLG1CQUFVSCxNQUFLSSxJQUFFO0FBQUMsZ0JBQU1GLEtBQUVGLEdBQUUsU0FBUyxZQUFZO0FBQUUsY0FBRyxDQUFDLE9BQU8sS0FBS0MsRUFBQyxFQUFFLFNBQVNDLEVBQUMsR0FBRTtBQUFDLFlBQUFGLEdBQUUsT0FBTztBQUFFO0FBQUEsVUFBUTtBQUFDLGdCQUFNRyxLQUFFLENBQUMsRUFBRSxPQUFPLEdBQUdILEdBQUUsVUFBVSxHQUFFSSxLQUFFLENBQUMsRUFBRSxPQUFPSCxHQUFFLEdBQUcsS0FBRyxDQUFDLEdBQUVBLEdBQUVDLEVBQUMsS0FBRyxDQUFDLENBQUM7QUFBRSxxQkFBVUQsTUFBS0UsR0FBRSxJQUFHRixJQUFFRyxFQUFDLEtBQUdKLEdBQUUsZ0JBQWdCQyxHQUFFLFFBQVE7QUFBQSxRQUFDO0FBQUMsZUFBT0UsR0FBRSxLQUFLO0FBQUEsTUFBUyxHQUFFSCxJQUFFLEtBQUssUUFBUSxXQUFVLEtBQUssUUFBUSxVQUFVLElBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMseUJBQXlCQSxJQUFFO0FBQUMsYUFBTyxFQUFFQSxJQUFFLENBQUMsUUFBTyxJQUFJLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxzQkFBc0JBLElBQUVDLElBQUU7QUFBQyxVQUFHLEtBQUssUUFBUSxLQUFLLFFBQU9BLEdBQUUsWUFBVSxJQUFHLEtBQUtBLEdBQUUsT0FBT0QsRUFBQztBQUFFLE1BQUFDLEdBQUUsY0FBWUQsR0FBRTtBQUFBLElBQVc7QUFBQSxFQUFDO0FBQUMsUUFBTSxLQUFHLG9CQUFJLElBQUksQ0FBQyxZQUFXLGFBQVksWUFBWSxDQUFDLEdBQUUsS0FBRyxRQUFPLEtBQUcsUUFBTyxLQUFHLGtCQUFpQixLQUFHLFVBQVMsS0FBRyxpQkFBZ0IsS0FBRyxTQUFRLEtBQUcsU0FBUSxLQUFHLFNBQVEsS0FBRyxFQUFDLE1BQUssUUFBTyxLQUFJLE9BQU0sT0FBTSxFQUFFLElBQUUsU0FBTyxTQUFRLFFBQU8sVUFBUyxNQUFLLEVBQUUsSUFBRSxVQUFRLE9BQU0sR0FBRSxLQUFHLEVBQUMsV0FBVSxJQUFHLFdBQVUsTUFBRyxVQUFTLG1CQUFrQixXQUFVLE9BQUcsYUFBWSxJQUFHLE9BQU0sR0FBRSxvQkFBbUIsQ0FBQyxPQUFNLFNBQVEsVUFBUyxNQUFNLEdBQUUsTUFBSyxPQUFHLFFBQU8sQ0FBQyxHQUFFLENBQUMsR0FBRSxXQUFVLE9BQU0sY0FBYSxNQUFLLFVBQVMsTUFBRyxZQUFXLE1BQUssVUFBUyxPQUFHLFVBQVMsZ0hBQStHLE9BQU0sSUFBRyxTQUFRLGNBQWEsR0FBRSxLQUFHLEVBQUMsV0FBVSxVQUFTLFdBQVUsV0FBVSxVQUFTLG9CQUFtQixXQUFVLDRCQUEyQixhQUFZLHFCQUFvQixPQUFNLG1CQUFrQixvQkFBbUIsU0FBUSxNQUFLLFdBQVUsUUFBTywyQkFBMEIsV0FBVSxxQkFBb0IsY0FBYSwwQkFBeUIsVUFBUyxXQUFVLFlBQVcsbUJBQWtCLFVBQVMsb0JBQW1CLFVBQVMsVUFBUyxPQUFNLDZCQUE0QixTQUFRLFNBQVE7QUFBQSxFQUFFLE1BQU0sV0FBVyxFQUFDO0FBQUEsSUFBQyxZQUFZQSxJQUFFQyxJQUFFO0FBQUMsVUFBRyxXQUFTLEVBQUUsT0FBTSxJQUFJLFVBQVUsc0VBQXNFO0FBQUUsWUFBTUQsSUFBRUMsRUFBQyxHQUFFLEtBQUssYUFBVyxNQUFHLEtBQUssV0FBUyxHQUFFLEtBQUssYUFBVyxNQUFLLEtBQUssaUJBQWUsQ0FBQyxHQUFFLEtBQUssVUFBUSxNQUFLLEtBQUssbUJBQWlCLE1BQUssS0FBSyxjQUFZLE1BQUssS0FBSyxNQUFJLE1BQUssS0FBSyxjQUFjLEdBQUUsS0FBSyxRQUFRLFlBQVUsS0FBSyxVQUFVO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBVyxVQUFTO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsY0FBYTtBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBUztBQUFBLElBQUMsU0FBUTtBQUFDLFdBQUssYUFBVztBQUFBLElBQUU7QUFBQSxJQUFDLFVBQVM7QUFBQyxXQUFLLGFBQVc7QUFBQSxJQUFFO0FBQUEsSUFBQyxnQkFBZTtBQUFDLFdBQUssYUFBVyxDQUFDLEtBQUs7QUFBQSxJQUFVO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxlQUFhLEtBQUssU0FBUyxJQUFFLEtBQUssT0FBTyxJQUFFLEtBQUssT0FBTztBQUFBLElBQUU7QUFBQSxJQUFDLFVBQVM7QUFBQyxtQkFBYSxLQUFLLFFBQVEsR0FBRSxFQUFFLElBQUksS0FBSyxTQUFTLFFBQVEsRUFBRSxHQUFFLElBQUcsS0FBSyxpQkFBaUIsR0FBRSxLQUFLLFNBQVMsYUFBYSx3QkFBd0IsS0FBRyxLQUFLLFNBQVMsYUFBYSxTQUFRLEtBQUssU0FBUyxhQUFhLHdCQUF3QixDQUFDLEdBQUUsS0FBSyxlQUFlLEdBQUUsTUFBTSxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTTtBQUFDLFVBQUcsV0FBUyxLQUFLLFNBQVMsTUFBTSxRQUFRLE9BQU0sSUFBSSxNQUFNLHFDQUFxQztBQUFFLFVBQUcsQ0FBQyxLQUFLLGVBQWUsS0FBRyxDQUFDLEtBQUssV0FBVztBQUFPLFlBQU1ELEtBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxNQUFNLENBQUMsR0FBRUMsTUFBRyxFQUFFLEtBQUssUUFBUSxLQUFHLEtBQUssU0FBUyxjQUFjLGlCQUFpQixTQUFTLEtBQUssUUFBUTtBQUFFLFVBQUdELEdBQUUsb0JBQWtCLENBQUNDLEdBQUU7QUFBTyxXQUFLLGVBQWU7QUFBRSxZQUFNQyxLQUFFLEtBQUssZUFBZTtBQUFFLFdBQUssU0FBUyxhQUFhLG9CQUFtQkEsR0FBRSxhQUFhLElBQUksQ0FBQztBQUFFLFlBQUssRUFBQyxXQUFVQyxHQUFDLElBQUUsS0FBSztBQUFRLFVBQUcsS0FBSyxTQUFTLGNBQWMsZ0JBQWdCLFNBQVMsS0FBSyxHQUFHLE1BQUlBLEdBQUUsT0FBT0QsRUFBQyxHQUFFLEVBQUUsUUFBUSxLQUFLLFVBQVMsS0FBSyxZQUFZLFVBQVUsVUFBVSxDQUFDLElBQUcsS0FBSyxVQUFRLEtBQUssY0FBY0EsRUFBQyxHQUFFQSxHQUFFLFVBQVUsSUFBSSxFQUFFLEdBQUUsa0JBQWlCLFNBQVMsZ0JBQWdCLFlBQVVGLE1BQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxTQUFTLEtBQUssUUFBUSxFQUFFLEdBQUUsR0FBR0EsSUFBRSxhQUFZLENBQUM7QUFBRSxXQUFLLGVBQWUsTUFBSTtBQUFDLFVBQUUsUUFBUSxLQUFLLFVBQVMsS0FBSyxZQUFZLFVBQVUsT0FBTyxDQUFDLEdBQUUsVUFBSyxLQUFLLGNBQVksS0FBSyxPQUFPLEdBQUUsS0FBSyxhQUFXO0FBQUEsTUFBRSxHQUFFLEtBQUssS0FBSSxLQUFLLFlBQVksQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU07QUFBQyxVQUFHLEtBQUssU0FBUyxLQUFHLENBQUMsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxNQUFNLENBQUMsRUFBRSxrQkFBaUI7QUFBQyxZQUFHLEtBQUssZUFBZSxFQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUUsa0JBQWlCLFNBQVMsZ0JBQWdCLFlBQVVBLE1BQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxTQUFTLEtBQUssUUFBUSxFQUFFLEdBQUUsSUFBSUEsSUFBRSxhQUFZLENBQUM7QUFBRSxhQUFLLGVBQWUsRUFBRSxJQUFFLE9BQUcsS0FBSyxlQUFlLEVBQUUsSUFBRSxPQUFHLEtBQUssZUFBZSxFQUFFLElBQUUsT0FBRyxLQUFLLGFBQVcsTUFBSyxLQUFLLGVBQWUsTUFBSTtBQUFDLGVBQUsscUJBQXFCLE1BQUksS0FBSyxjQUFZLEtBQUssZUFBZSxHQUFFLEtBQUssU0FBUyxnQkFBZ0Isa0JBQWtCLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxLQUFLLFlBQVksVUFBVSxRQUFRLENBQUM7QUFBQSxRQUFFLEdBQUUsS0FBSyxLQUFJLEtBQUssWUFBWSxDQUFDO0FBQUEsTUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLFNBQVE7QUFBQyxXQUFLLFdBQVMsS0FBSyxRQUFRLE9BQU87QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBZ0I7QUFBQyxhQUFPLFFBQVEsS0FBSyxVQUFVLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBZ0I7QUFBQyxhQUFPLEtBQUssUUFBTSxLQUFLLE1BQUksS0FBSyxrQkFBa0IsS0FBSyxlQUFhLEtBQUssdUJBQXVCLENBQUMsSUFBRyxLQUFLO0FBQUEsSUFBRztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsWUFBTUMsS0FBRSxLQUFLLG9CQUFvQkQsRUFBQyxFQUFFLE9BQU87QUFBRSxVQUFHLENBQUNDLEdBQUUsUUFBTztBQUFLLE1BQUFBLEdBQUUsVUFBVSxPQUFPLElBQUcsRUFBRSxHQUFFQSxHQUFFLFVBQVUsSUFBSSxNQUFNLEtBQUssWUFBWSxJQUFJLE9BQU87QUFBRSxZQUFNQyxNQUFHLENBQUFGLE9BQUc7QUFBQyxXQUFFO0FBQUMsVUFBQUEsTUFBRyxLQUFLLE1BQU0sTUFBSSxLQUFLLE9BQU8sQ0FBQztBQUFBLFFBQUMsU0FBTyxTQUFTLGVBQWVBLEVBQUM7QUFBRyxlQUFPQTtBQUFBLE1BQUMsR0FBRyxLQUFLLFlBQVksSUFBSSxFQUFFLFNBQVM7QUFBRSxhQUFPQyxHQUFFLGFBQWEsTUFBS0MsRUFBQyxHQUFFLEtBQUssWUFBWSxLQUFHRCxHQUFFLFVBQVUsSUFBSSxFQUFFLEdBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMsV0FBV0QsSUFBRTtBQUFDLFdBQUssY0FBWUEsSUFBRSxLQUFLLFNBQVMsTUFBSSxLQUFLLGVBQWUsR0FBRSxLQUFLLEtBQUs7QUFBQSxJQUFFO0FBQUEsSUFBQyxvQkFBb0JBLElBQUU7QUFBQyxhQUFPLEtBQUssbUJBQWlCLEtBQUssaUJBQWlCLGNBQWNBLEVBQUMsSUFBRSxLQUFLLG1CQUFpQixJQUFJLEdBQUcsRUFBQyxHQUFHLEtBQUssU0FBUSxTQUFRQSxJQUFFLFlBQVcsS0FBSyx5QkFBeUIsS0FBSyxRQUFRLFdBQVcsRUFBQyxDQUFDLEdBQUUsS0FBSztBQUFBLElBQWdCO0FBQUEsSUFBQyx5QkFBd0I7QUFBQyxhQUFNLEVBQUMsQ0FBQyxFQUFFLEdBQUUsS0FBSyxVQUFVLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxZQUFXO0FBQUMsYUFBTyxLQUFLLHlCQUF5QixLQUFLLFFBQVEsS0FBSyxLQUFHLEtBQUssU0FBUyxhQUFhLHdCQUF3QjtBQUFBLElBQUM7QUFBQSxJQUFDLDZCQUE2QkEsSUFBRTtBQUFDLGFBQU8sS0FBSyxZQUFZLG9CQUFvQkEsR0FBRSxnQkFBZSxLQUFLLG1CQUFtQixDQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBYTtBQUFDLGFBQU8sS0FBSyxRQUFRLGFBQVcsS0FBSyxPQUFLLEtBQUssSUFBSSxVQUFVLFNBQVMsRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVU7QUFBQyxhQUFPLEtBQUssT0FBSyxLQUFLLElBQUksVUFBVSxTQUFTLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxjQUFjQSxJQUFFO0FBQUMsWUFBTUMsS0FBRSxFQUFFLEtBQUssUUFBUSxXQUFVLENBQUMsTUFBS0QsSUFBRSxLQUFLLFFBQVEsQ0FBQyxHQUFFRyxLQUFFLEdBQUdGLEdBQUUsWUFBWSxDQUFDO0FBQUUsYUFBTyxFQUFFLGFBQWEsS0FBSyxVQUFTRCxJQUFFLEtBQUssaUJBQWlCRyxFQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxhQUFZO0FBQUMsWUFBSyxFQUFDLFFBQU9ILEdBQUMsSUFBRSxLQUFLO0FBQVEsYUFBTSxZQUFVLE9BQU9BLEtBQUVBLEdBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFBQSxPQUFHLE9BQU8sU0FBU0EsSUFBRSxFQUFFLENBQUMsSUFBRSxjQUFZLE9BQU9BLEtBQUUsQ0FBQUMsT0FBR0QsR0FBRUMsSUFBRSxLQUFLLFFBQVEsSUFBRUQ7QUFBQSxJQUFDO0FBQUEsSUFBQyx5QkFBeUJBLElBQUU7QUFBQyxhQUFPLEVBQUVBLElBQUUsQ0FBQyxLQUFLLFVBQVMsS0FBSyxRQUFRLENBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJBLElBQUU7QUFBQyxZQUFNQyxLQUFFLEVBQUMsV0FBVUQsSUFBRSxXQUFVLENBQUMsRUFBQyxNQUFLLFFBQU8sU0FBUSxFQUFDLG9CQUFtQixLQUFLLFFBQVEsbUJBQWtCLEVBQUMsR0FBRSxFQUFDLE1BQUssVUFBUyxTQUFRLEVBQUMsUUFBTyxLQUFLLFdBQVcsRUFBQyxFQUFDLEdBQUUsRUFBQyxNQUFLLG1CQUFrQixTQUFRLEVBQUMsVUFBUyxLQUFLLFFBQVEsU0FBUSxFQUFDLEdBQUUsRUFBQyxNQUFLLFNBQVEsU0FBUSxFQUFDLFNBQVEsSUFBSSxLQUFLLFlBQVksSUFBSSxTQUFRLEVBQUMsR0FBRSxFQUFDLE1BQUssbUJBQWtCLFNBQVEsTUFBRyxPQUFNLGNBQWEsSUFBRyxDQUFBQSxPQUFHO0FBQUMsYUFBSyxlQUFlLEVBQUUsYUFBYSx5QkFBd0JBLEdBQUUsTUFBTSxTQUFTO0FBQUEsTUFBQyxFQUFDLENBQUMsRUFBQztBQUFFLGFBQU0sRUFBQyxHQUFHQyxJQUFFLEdBQUcsRUFBRSxLQUFLLFFBQVEsY0FBYSxDQUFDLFFBQU9BLEVBQUMsQ0FBQyxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsZ0JBQWU7QUFBQyxZQUFNRCxLQUFFLEtBQUssUUFBUSxRQUFRLE1BQU0sR0FBRztBQUFFLGlCQUFVQyxNQUFLRCxHQUFFLEtBQUcsWUFBVUMsR0FBRSxHQUFFLEdBQUcsS0FBSyxVQUFTLEtBQUssWUFBWSxVQUFVLE9BQU8sR0FBRSxLQUFLLFFBQVEsVUFBUyxDQUFBRCxPQUFHO0FBQUMsY0FBTUMsS0FBRSxLQUFLLDZCQUE2QkQsRUFBQztBQUFFLFFBQUFDLEdBQUUsZUFBZSxFQUFFLElBQUUsRUFBRUEsR0FBRSxTQUFTLEtBQUdBLEdBQUUsZUFBZSxFQUFFLElBQUdBLEdBQUUsT0FBTztBQUFBLE1BQUMsQ0FBQztBQUFBLGVBQVUsYUFBV0EsSUFBRTtBQUFDLGNBQU1ELEtBQUVDLE9BQUksS0FBRyxLQUFLLFlBQVksVUFBVSxZQUFZLElBQUUsS0FBSyxZQUFZLFVBQVUsU0FBUyxHQUFFQyxLQUFFRCxPQUFJLEtBQUcsS0FBSyxZQUFZLFVBQVUsWUFBWSxJQUFFLEtBQUssWUFBWSxVQUFVLFVBQVU7QUFBRSxVQUFFLEdBQUcsS0FBSyxVQUFTRCxJQUFFLEtBQUssUUFBUSxVQUFTLENBQUFBLE9BQUc7QUFBQyxnQkFBTUMsS0FBRSxLQUFLLDZCQUE2QkQsRUFBQztBQUFFLFVBQUFDLEdBQUUsZUFBZSxjQUFZRCxHQUFFLE9BQUssS0FBRyxFQUFFLElBQUUsTUFBR0MsR0FBRSxPQUFPO0FBQUEsUUFBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBU0MsSUFBRSxLQUFLLFFBQVEsVUFBUyxDQUFBRixPQUFHO0FBQUMsZ0JBQU1DLEtBQUUsS0FBSyw2QkFBNkJELEVBQUM7QUFBRSxVQUFBQyxHQUFFLGVBQWUsZUFBYUQsR0FBRSxPQUFLLEtBQUcsRUFBRSxJQUFFQyxHQUFFLFNBQVMsU0FBU0QsR0FBRSxhQUFhLEdBQUVDLEdBQUUsT0FBTztBQUFBLFFBQUMsQ0FBQztBQUFBLE1BQUM7QUFBQyxXQUFLLG9CQUFrQixNQUFJO0FBQUMsYUFBSyxZQUFVLEtBQUssS0FBSztBQUFBLE1BQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxTQUFTLFFBQVEsRUFBRSxHQUFFLElBQUcsS0FBSyxpQkFBaUI7QUFBQSxJQUFDO0FBQUEsSUFBQyxZQUFXO0FBQUMsWUFBTUQsS0FBRSxLQUFLLFNBQVMsYUFBYSxPQUFPO0FBQUUsTUFBQUEsT0FBSSxLQUFLLFNBQVMsYUFBYSxZQUFZLEtBQUcsS0FBSyxTQUFTLFlBQVksS0FBSyxLQUFHLEtBQUssU0FBUyxhQUFhLGNBQWFBLEVBQUMsR0FBRSxLQUFLLFNBQVMsYUFBYSwwQkFBeUJBLEVBQUMsR0FBRSxLQUFLLFNBQVMsZ0JBQWdCLE9BQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxTQUFRO0FBQUMsV0FBSyxTQUFTLEtBQUcsS0FBSyxhQUFXLEtBQUssYUFBVyxRQUFJLEtBQUssYUFBVyxNQUFHLEtBQUssWUFBWSxNQUFJO0FBQUMsYUFBSyxjQUFZLEtBQUssS0FBSztBQUFBLE1BQUMsR0FBRSxLQUFLLFFBQVEsTUFBTSxJQUFJO0FBQUEsSUFBRTtBQUFBLElBQUMsU0FBUTtBQUFDLFdBQUsscUJBQXFCLE1BQUksS0FBSyxhQUFXLE9BQUcsS0FBSyxZQUFZLE1BQUk7QUFBQyxhQUFLLGNBQVksS0FBSyxLQUFLO0FBQUEsTUFBQyxHQUFFLEtBQUssUUFBUSxNQUFNLElBQUk7QUFBQSxJQUFFO0FBQUEsSUFBQyxZQUFZQSxJQUFFQyxJQUFFO0FBQUMsbUJBQWEsS0FBSyxRQUFRLEdBQUUsS0FBSyxXQUFTLFdBQVdELElBQUVDLEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyx1QkFBc0I7QUFBQyxhQUFPLE9BQU8sT0FBTyxLQUFLLGNBQWMsRUFBRSxTQUFTLElBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxXQUFXRCxJQUFFO0FBQUMsWUFBTUMsS0FBRSxFQUFFLGtCQUFrQixLQUFLLFFBQVE7QUFBRSxpQkFBVUQsTUFBSyxPQUFPLEtBQUtDLEVBQUMsRUFBRSxJQUFHLElBQUlELEVBQUMsS0FBRyxPQUFPQyxHQUFFRCxFQUFDO0FBQUUsYUFBT0EsS0FBRSxFQUFDLEdBQUdDLElBQUUsR0FBRyxZQUFVLE9BQU9ELE1BQUdBLEtBQUVBLEtBQUUsQ0FBQyxFQUFDLEdBQUVBLEtBQUUsS0FBSyxnQkFBZ0JBLEVBQUMsR0FBRUEsS0FBRSxLQUFLLGtCQUFrQkEsRUFBQyxHQUFFLEtBQUssaUJBQWlCQSxFQUFDLEdBQUVBO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsYUFBT0EsR0FBRSxZQUFVLFVBQUtBLEdBQUUsWUFBVSxTQUFTLE9BQUssRUFBRUEsR0FBRSxTQUFTLEdBQUUsWUFBVSxPQUFPQSxHQUFFLFVBQVFBLEdBQUUsUUFBTSxFQUFDLE1BQUtBLEdBQUUsT0FBTSxNQUFLQSxHQUFFLE1BQUssSUFBRyxZQUFVLE9BQU9BLEdBQUUsVUFBUUEsR0FBRSxRQUFNQSxHQUFFLE1BQU0sU0FBUyxJQUFHLFlBQVUsT0FBT0EsR0FBRSxZQUFVQSxHQUFFLFVBQVFBLEdBQUUsUUFBUSxTQUFTLElBQUdBO0FBQUEsSUFBQztBQUFBLElBQUMscUJBQW9CO0FBQUMsWUFBTUEsS0FBRSxDQUFDO0FBQUUsaUJBQVMsQ0FBQ0MsSUFBRUMsRUFBQyxLQUFJLE9BQU8sUUFBUSxLQUFLLE9BQU8sRUFBRSxNQUFLLFlBQVksUUFBUUQsRUFBQyxNQUFJQyxPQUFJRixHQUFFQyxFQUFDLElBQUVDO0FBQUcsYUFBT0YsR0FBRSxXQUFTLE9BQUdBLEdBQUUsVUFBUSxVQUFTQTtBQUFBLElBQUM7QUFBQSxJQUFDLGlCQUFnQjtBQUFDLFdBQUssWUFBVSxLQUFLLFFBQVEsUUFBUSxHQUFFLEtBQUssVUFBUSxPQUFNLEtBQUssUUFBTSxLQUFLLElBQUksT0FBTyxHQUFFLEtBQUssTUFBSTtBQUFBLElBQUs7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQUssV0FBVTtBQUFDLGNBQU1DLEtBQUUsR0FBRyxvQkFBb0IsTUFBS0QsRUFBQztBQUFFLFlBQUcsWUFBVSxPQUFPQSxJQUFFO0FBQUMsY0FBRyxXQUFTQyxHQUFFRCxFQUFDLEVBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBQyxHQUFFRCxFQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEVBQUU7QUFBRSxRQUFNLEtBQUcsbUJBQWtCLEtBQUcsaUJBQWdCLEtBQUcsRUFBQyxHQUFHLEdBQUcsU0FBUSxTQUFRLElBQUcsUUFBTyxDQUFDLEdBQUUsQ0FBQyxHQUFFLFdBQVUsU0FBUSxVQUFTLCtJQUE4SSxTQUFRLFFBQU8sR0FBRSxLQUFHLEVBQUMsR0FBRyxHQUFHLGFBQVksU0FBUSxpQ0FBZ0M7QUFBQSxFQUFFLE1BQU0sV0FBVyxHQUFFO0FBQUEsSUFBQyxXQUFXLFVBQVM7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxjQUFhO0FBQUMsYUFBTztBQUFBLElBQUU7QUFBQSxJQUFDLFdBQVcsT0FBTTtBQUFDLGFBQU07QUFBQSxJQUFTO0FBQUEsSUFBQyxpQkFBZ0I7QUFBQyxhQUFPLEtBQUssVUFBVSxLQUFHLEtBQUssWUFBWTtBQUFBLElBQUM7QUFBQSxJQUFDLHlCQUF3QjtBQUFDLGFBQU0sRUFBQyxDQUFDLEVBQUUsR0FBRSxLQUFLLFVBQVUsR0FBRSxDQUFDLEVBQUUsR0FBRSxLQUFLLFlBQVksRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLGNBQWE7QUFBQyxhQUFPLEtBQUsseUJBQXlCLEtBQUssUUFBUSxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxnQkFBZ0JBLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBSyxXQUFVO0FBQUMsY0FBTUMsS0FBRSxHQUFHLG9CQUFvQixNQUFLRCxFQUFDO0FBQUUsWUFBRyxZQUFVLE9BQU9BLElBQUU7QUFBQyxjQUFHLFdBQVNDLEdBQUVELEVBQUMsRUFBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFDLEdBQUVELEVBQUMsRUFBRTtBQUFBLFFBQUM7QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFDO0FBQUEsRUFBQztBQUFDLElBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxpQkFBZ0IsS0FBRyxXQUFXLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLGFBQVksS0FBRyxVQUFTLEtBQUcsVUFBUyxLQUFHLGFBQVksS0FBRyxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsc0JBQXFCLEtBQUcsRUFBQyxRQUFPLE1BQUssWUFBVyxnQkFBZSxjQUFhLE9BQUcsUUFBTyxNQUFLLFdBQVUsQ0FBQyxLQUFHLEtBQUcsQ0FBQyxFQUFDLEdBQUUsS0FBRyxFQUFDLFFBQU8saUJBQWdCLFlBQVcsVUFBUyxjQUFhLFdBQVUsUUFBTyxXQUFVLFdBQVUsUUFBTztBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUVDLElBQUU7QUFBQyxZQUFNRCxJQUFFQyxFQUFDLEdBQUUsS0FBSyxlQUFhLG9CQUFJLE9BQUksS0FBSyxzQkFBb0Isb0JBQUksT0FBSSxLQUFLLGVBQWEsY0FBWSxpQkFBaUIsS0FBSyxRQUFRLEVBQUUsWUFBVSxPQUFLLEtBQUssVUFBUyxLQUFLLGdCQUFjLE1BQUssS0FBSyxZQUFVLE1BQUssS0FBSyxzQkFBb0IsRUFBQyxpQkFBZ0IsR0FBRSxpQkFBZ0IsRUFBQyxHQUFFLEtBQUssUUFBUTtBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQVc7QUFBQSxJQUFDLFVBQVM7QUFBQyxXQUFLLGlDQUFpQyxHQUFFLEtBQUsseUJBQXlCLEdBQUUsS0FBSyxZQUFVLEtBQUssVUFBVSxXQUFXLElBQUUsS0FBSyxZQUFVLEtBQUssZ0JBQWdCO0FBQUUsaUJBQVVELE1BQUssS0FBSyxvQkFBb0IsT0FBTyxFQUFFLE1BQUssVUFBVSxRQUFRQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsVUFBUztBQUFDLFdBQUssVUFBVSxXQUFXLEdBQUUsTUFBTSxRQUFRO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsYUFBT0EsR0FBRSxTQUFPLEVBQUVBLEdBQUUsTUFBTSxLQUFHLFNBQVMsTUFBS0EsR0FBRSxhQUFXQSxHQUFFLFNBQU8sR0FBR0EsR0FBRSxNQUFNLGdCQUFjQSxHQUFFLFlBQVcsWUFBVSxPQUFPQSxHQUFFLGNBQVlBLEdBQUUsWUFBVUEsR0FBRSxVQUFVLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQUEsT0FBRyxPQUFPLFdBQVdBLEVBQUMsQ0FBQyxJQUFHQTtBQUFBLElBQUM7QUFBQSxJQUFDLDJCQUEwQjtBQUFDLFdBQUssUUFBUSxpQkFBZSxFQUFFLElBQUksS0FBSyxRQUFRLFFBQU8sRUFBRSxHQUFFLEVBQUUsR0FBRyxLQUFLLFFBQVEsUUFBTyxJQUFHLElBQUcsQ0FBQUEsT0FBRztBQUFDLGNBQU1DLEtBQUUsS0FBSyxvQkFBb0IsSUFBSUQsR0FBRSxPQUFPLElBQUk7QUFBRSxZQUFHQyxJQUFFO0FBQUMsVUFBQUQsR0FBRSxlQUFlO0FBQUUsZ0JBQU1FLEtBQUUsS0FBSyxnQkFBYyxRQUFPQyxLQUFFRixHQUFFLFlBQVUsS0FBSyxTQUFTO0FBQVUsY0FBR0MsR0FBRSxTQUFTLFFBQU8sS0FBS0EsR0FBRSxTQUFTLEVBQUMsS0FBSUMsSUFBRSxVQUFTLFNBQVEsQ0FBQztBQUFFLFVBQUFELEdBQUUsWUFBVUM7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBRTtBQUFBLElBQUMsa0JBQWlCO0FBQUMsWUFBTUgsS0FBRSxFQUFDLE1BQUssS0FBSyxjQUFhLFdBQVUsS0FBSyxRQUFRLFdBQVUsWUFBVyxLQUFLLFFBQVEsV0FBVTtBQUFFLGFBQU8sSUFBSSxxQkFBcUIsQ0FBQUEsT0FBRyxLQUFLLGtCQUFrQkEsRUFBQyxHQUFFQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsa0JBQWtCQSxJQUFFO0FBQUMsWUFBTUMsS0FBRSxDQUFBRCxPQUFHLEtBQUssYUFBYSxJQUFJLElBQUlBLEdBQUUsT0FBTyxFQUFFLEVBQUUsR0FBRUUsS0FBRSxDQUFBRixPQUFHO0FBQUMsYUFBSyxvQkFBb0Isa0JBQWdCQSxHQUFFLE9BQU8sV0FBVSxLQUFLLFNBQVNDLEdBQUVELEVBQUMsQ0FBQztBQUFBLE1BQUMsR0FBRUcsTUFBRyxLQUFLLGdCQUFjLFNBQVMsaUJBQWlCLFdBQVVDLEtBQUVELE1BQUcsS0FBSyxvQkFBb0I7QUFBZ0IsV0FBSyxvQkFBb0Isa0JBQWdCQTtBQUFFLGlCQUFVRyxNQUFLTixJQUFFO0FBQUMsWUFBRyxDQUFDTSxHQUFFLGdCQUFlO0FBQUMsZUFBSyxnQkFBYyxNQUFLLEtBQUssa0JBQWtCTCxHQUFFSyxFQUFDLENBQUM7QUFBRTtBQUFBLFFBQVE7QUFBQyxjQUFNTixLQUFFTSxHQUFFLE9BQU8sYUFBVyxLQUFLLG9CQUFvQjtBQUFnQixZQUFHRixNQUFHSixJQUFFO0FBQUMsY0FBR0UsR0FBRUksRUFBQyxHQUFFLENBQUNILEdBQUU7QUFBQSxRQUFNLE1BQU0sQ0FBQUMsTUFBR0osTUFBR0UsR0FBRUksRUFBQztBQUFBLE1BQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyxtQ0FBa0M7QUFBQyxXQUFLLGVBQWEsb0JBQUksT0FBSSxLQUFLLHNCQUFvQixvQkFBSTtBQUFJLFlBQU1OLEtBQUUsRUFBRSxLQUFLLElBQUcsS0FBSyxRQUFRLE1BQU07QUFBRSxpQkFBVUMsTUFBS0QsSUFBRTtBQUFDLFlBQUcsQ0FBQ0MsR0FBRSxRQUFNLEVBQUVBLEVBQUMsRUFBRTtBQUFTLGNBQU1ELEtBQUUsRUFBRSxRQUFRLFVBQVVDLEdBQUUsSUFBSSxHQUFFLEtBQUssUUFBUTtBQUFFLFVBQUVELEVBQUMsTUFBSSxLQUFLLGFBQWEsSUFBSSxVQUFVQyxHQUFFLElBQUksR0FBRUEsRUFBQyxHQUFFLEtBQUssb0JBQW9CLElBQUlBLEdBQUUsTUFBS0QsRUFBQztBQUFBLE1BQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxTQUFTQSxJQUFFO0FBQUMsV0FBSyxrQkFBZ0JBLE9BQUksS0FBSyxrQkFBa0IsS0FBSyxRQUFRLE1BQU0sR0FBRSxLQUFLLGdCQUFjQSxJQUFFQSxHQUFFLFVBQVUsSUFBSSxFQUFFLEdBQUUsS0FBSyxpQkFBaUJBLEVBQUMsR0FBRSxFQUFFLFFBQVEsS0FBSyxVQUFTLElBQUcsRUFBQyxlQUFjQSxHQUFDLENBQUM7QUFBQSxJQUFFO0FBQUEsSUFBQyxpQkFBaUJBLElBQUU7QUFBQyxVQUFHQSxHQUFFLFVBQVUsU0FBUyxlQUFlLEVBQUUsR0FBRSxRQUFRLG9CQUFtQkEsR0FBRSxRQUFRLFdBQVcsQ0FBQyxFQUFFLFVBQVUsSUFBSSxFQUFFO0FBQUEsVUFBTyxZQUFVQyxNQUFLLEVBQUUsUUFBUUQsSUFBRSxtQkFBbUIsRUFBRSxZQUFVQSxNQUFLLEVBQUUsS0FBS0MsSUFBRSxFQUFFLEVBQUUsQ0FBQUQsR0FBRSxVQUFVLElBQUksRUFBRTtBQUFBLElBQUM7QUFBQSxJQUFDLGtCQUFrQkEsSUFBRTtBQUFDLE1BQUFBLEdBQUUsVUFBVSxPQUFPLEVBQUU7QUFBRSxZQUFNQyxLQUFFLEVBQUUsS0FBSyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUdELEVBQUM7QUFBRSxpQkFBVUEsTUFBS0MsR0FBRSxDQUFBRCxHQUFFLFVBQVUsT0FBTyxFQUFFO0FBQUEsSUFBQztBQUFBLElBQUMsT0FBTyxnQkFBZ0JBLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBSyxXQUFVO0FBQUMsY0FBTUMsS0FBRSxHQUFHLG9CQUFvQixNQUFLRCxFQUFDO0FBQUUsWUFBRyxZQUFVLE9BQU9BLElBQUU7QUFBQyxjQUFHLFdBQVNDLEdBQUVELEVBQUMsS0FBR0EsR0FBRSxXQUFXLEdBQUcsS0FBRyxrQkFBZ0JBLEdBQUUsT0FBTSxJQUFJLFVBQVUsb0JBQW9CQSxFQUFDLEdBQUc7QUFBRSxVQUFBQyxHQUFFRCxFQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFBQztBQUFBLEVBQUM7QUFBQyxJQUFFLEdBQUcsUUFBTyxJQUFHLE1BQUk7QUFBQyxlQUFVQSxNQUFLLEVBQUUsS0FBSyx3QkFBd0IsRUFBRSxJQUFHLG9CQUFvQkEsRUFBQztBQUFBLEVBQUMsQ0FBQyxHQUFFLEVBQUUsRUFBRTtBQUFFLFFBQU0sS0FBRyxXQUFVLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxTQUFTLEVBQUUsSUFBRyxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsUUFBUSxFQUFFLElBQUcsS0FBRyxRQUFRLEVBQUUsSUFBRyxLQUFHLFVBQVUsRUFBRSxJQUFHLEtBQUcsT0FBTyxFQUFFLElBQUcsS0FBRyxhQUFZLEtBQUcsY0FBYSxLQUFHLFdBQVUsS0FBRyxhQUFZLEtBQUcsUUFBTyxLQUFHLE9BQU0sS0FBRyxVQUFTLEtBQUcsUUFBTyxLQUFHLFFBQU8sS0FBRyxvQkFBbUIsS0FBRyxRQUFRLEVBQUUsS0FBSSxLQUFHLDRFQUEyRSxLQUFHLFlBQVksRUFBRSxxQkFBcUIsRUFBRSxpQkFBaUIsRUFBRSxLQUFLLEVBQUUsSUFBRyxLQUFHLElBQUksRUFBRSw0QkFBNEIsRUFBRSw2QkFBNkIsRUFBRTtBQUFBLEVBQTBCLE1BQU0sV0FBVyxFQUFDO0FBQUEsSUFBQyxZQUFZQSxJQUFFO0FBQUMsWUFBTUEsRUFBQyxHQUFFLEtBQUssVUFBUSxLQUFLLFNBQVMsUUFBUSxxQ0FBcUMsR0FBRSxLQUFLLFlBQVUsS0FBSyxzQkFBc0IsS0FBSyxTQUFRLEtBQUssYUFBYSxDQUFDLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxJQUFHLENBQUFBLE9BQUcsS0FBSyxTQUFTQSxFQUFDLENBQUM7QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLE9BQU07QUFBQyxhQUFNO0FBQUEsSUFBSztBQUFBLElBQUMsT0FBTTtBQUFDLFlBQU1BLEtBQUUsS0FBSztBQUFTLFVBQUcsS0FBSyxjQUFjQSxFQUFDLEVBQUU7QUFBTyxZQUFNQyxLQUFFLEtBQUssZUFBZSxHQUFFQyxLQUFFRCxLQUFFLEVBQUUsUUFBUUEsSUFBRSxJQUFHLEVBQUMsZUFBY0QsR0FBQyxDQUFDLElBQUU7QUFBSyxRQUFFLFFBQVFBLElBQUUsSUFBRyxFQUFDLGVBQWNDLEdBQUMsQ0FBQyxFQUFFLG9CQUFrQkMsTUFBR0EsR0FBRSxxQkFBbUIsS0FBSyxZQUFZRCxJQUFFRCxFQUFDLEdBQUUsS0FBSyxVQUFVQSxJQUFFQyxFQUFDO0FBQUEsSUFBRTtBQUFBLElBQUMsVUFBVUQsSUFBRUMsSUFBRTtBQUFDLE1BQUFELE9BQUlBLEdBQUUsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLFVBQVUsRUFBRSx1QkFBdUJBLEVBQUMsQ0FBQyxHQUFFLEtBQUssZUFBZSxNQUFJO0FBQUMsa0JBQVFBLEdBQUUsYUFBYSxNQUFNLEtBQUdBLEdBQUUsZ0JBQWdCLFVBQVUsR0FBRUEsR0FBRSxhQUFhLGlCQUFnQixJQUFFLEdBQUUsS0FBSyxnQkFBZ0JBLElBQUUsSUFBRSxHQUFFLEVBQUUsUUFBUUEsSUFBRSxJQUFHLEVBQUMsZUFBY0MsR0FBQyxDQUFDLEtBQUdELEdBQUUsVUFBVSxJQUFJLEVBQUU7QUFBQSxNQUFDLEdBQUVBLElBQUVBLEdBQUUsVUFBVSxTQUFTLEVBQUUsQ0FBQztBQUFBLElBQUU7QUFBQSxJQUFDLFlBQVlBLElBQUVDLElBQUU7QUFBQyxNQUFBRCxPQUFJQSxHQUFFLFVBQVUsT0FBTyxFQUFFLEdBQUVBLEdBQUUsS0FBSyxHQUFFLEtBQUssWUFBWSxFQUFFLHVCQUF1QkEsRUFBQyxDQUFDLEdBQUUsS0FBSyxlQUFlLE1BQUk7QUFBQyxrQkFBUUEsR0FBRSxhQUFhLE1BQU0sS0FBR0EsR0FBRSxhQUFhLGlCQUFnQixLQUFFLEdBQUVBLEdBQUUsYUFBYSxZQUFXLElBQUksR0FBRSxLQUFLLGdCQUFnQkEsSUFBRSxLQUFFLEdBQUUsRUFBRSxRQUFRQSxJQUFFLElBQUcsRUFBQyxlQUFjQyxHQUFDLENBQUMsS0FBR0QsR0FBRSxVQUFVLE9BQU8sRUFBRTtBQUFBLE1BQUMsR0FBRUEsSUFBRUEsR0FBRSxVQUFVLFNBQVMsRUFBRSxDQUFDO0FBQUEsSUFBRTtBQUFBLElBQUMsU0FBU0EsSUFBRTtBQUFDLFVBQUcsQ0FBQyxDQUFDLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxFQUFFLEVBQUUsU0FBU0EsR0FBRSxHQUFHLEVBQUU7QUFBTyxNQUFBQSxHQUFFLGdCQUFnQixHQUFFQSxHQUFFLGVBQWU7QUFBRSxZQUFNQyxLQUFFLEtBQUssYUFBYSxFQUFFLE9BQU8sQ0FBQUQsT0FBRyxDQUFDLEVBQUVBLEVBQUMsQ0FBQztBQUFFLFVBQUlFO0FBQUUsVUFBRyxDQUFDLElBQUcsRUFBRSxFQUFFLFNBQVNGLEdBQUUsR0FBRyxFQUFFLENBQUFFLEtBQUVELEdBQUVELEdBQUUsUUFBTSxLQUFHLElBQUVDLEdBQUUsU0FBTyxDQUFDO0FBQUEsV0FBTTtBQUFDLGNBQU1FLEtBQUUsQ0FBQyxJQUFHLEVBQUUsRUFBRSxTQUFTSCxHQUFFLEdBQUc7QUFBRSxRQUFBRSxLQUFFLEVBQUVELElBQUVELEdBQUUsUUFBT0csSUFBRSxJQUFFO0FBQUEsTUFBQztBQUFDLE1BQUFELE9BQUlBLEdBQUUsTUFBTSxFQUFDLGVBQWMsS0FBRSxDQUFDLEdBQUUsR0FBRyxvQkFBb0JBLEVBQUMsRUFBRSxLQUFLO0FBQUEsSUFBRTtBQUFBLElBQUMsZUFBYztBQUFDLGFBQU8sRUFBRSxLQUFLLElBQUcsS0FBSyxPQUFPO0FBQUEsSUFBQztBQUFBLElBQUMsaUJBQWdCO0FBQUMsYUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLENBQUFGLE9BQUcsS0FBSyxjQUFjQSxFQUFDLENBQUMsS0FBRztBQUFBLElBQUk7QUFBQSxJQUFDLHNCQUFzQkEsSUFBRUMsSUFBRTtBQUFDLFdBQUsseUJBQXlCRCxJQUFFLFFBQU8sU0FBUztBQUFFLGlCQUFVQSxNQUFLQyxHQUFFLE1BQUssNkJBQTZCRCxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsNkJBQTZCQSxJQUFFO0FBQUMsTUFBQUEsS0FBRSxLQUFLLGlCQUFpQkEsRUFBQztBQUFFLFlBQU1DLEtBQUUsS0FBSyxjQUFjRCxFQUFDLEdBQUVFLEtBQUUsS0FBSyxpQkFBaUJGLEVBQUM7QUFBRSxNQUFBQSxHQUFFLGFBQWEsaUJBQWdCQyxFQUFDLEdBQUVDLE9BQUlGLE1BQUcsS0FBSyx5QkFBeUJFLElBQUUsUUFBTyxjQUFjLEdBQUVELE1BQUdELEdBQUUsYUFBYSxZQUFXLElBQUksR0FBRSxLQUFLLHlCQUF5QkEsSUFBRSxRQUFPLEtBQUssR0FBRSxLQUFLLG1DQUFtQ0EsRUFBQztBQUFBLElBQUM7QUFBQSxJQUFDLG1DQUFtQ0EsSUFBRTtBQUFDLFlBQU1DLEtBQUUsRUFBRSx1QkFBdUJELEVBQUM7QUFBRSxNQUFBQyxPQUFJLEtBQUsseUJBQXlCQSxJQUFFLFFBQU8sVUFBVSxHQUFFRCxHQUFFLE1BQUksS0FBSyx5QkFBeUJDLElBQUUsbUJBQWtCLEdBQUdELEdBQUUsRUFBRSxFQUFFO0FBQUEsSUFBRTtBQUFBLElBQUMsZ0JBQWdCQSxJQUFFQyxJQUFFO0FBQUMsWUFBTUMsS0FBRSxLQUFLLGlCQUFpQkYsRUFBQztBQUFFLFVBQUcsQ0FBQ0UsR0FBRSxVQUFVLFNBQVMsVUFBVSxFQUFFO0FBQU8sWUFBTUMsS0FBRSxDQUFDSCxJQUFFRyxPQUFJO0FBQUMsY0FBTUMsS0FBRSxFQUFFLFFBQVFKLElBQUVFLEVBQUM7QUFBRSxRQUFBRSxNQUFHQSxHQUFFLFVBQVUsT0FBT0QsSUFBRUYsRUFBQztBQUFBLE1BQUM7QUFBRSxNQUFBRSxHQUFFLElBQUcsRUFBRSxHQUFFQSxHQUFFLGtCQUFpQixFQUFFLEdBQUVELEdBQUUsYUFBYSxpQkFBZ0JELEVBQUM7QUFBQSxJQUFDO0FBQUEsSUFBQyx5QkFBeUJELElBQUVDLElBQUVDLElBQUU7QUFBQyxNQUFBRixHQUFFLGFBQWFDLEVBQUMsS0FBR0QsR0FBRSxhQUFhQyxJQUFFQyxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsY0FBY0YsSUFBRTtBQUFDLGFBQU9BLEdBQUUsVUFBVSxTQUFTLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxpQkFBaUJBLElBQUU7QUFBQyxhQUFPQSxHQUFFLFFBQVEsRUFBRSxJQUFFQSxLQUFFLEVBQUUsUUFBUSxJQUFHQSxFQUFDO0FBQUEsSUFBQztBQUFBLElBQUMsaUJBQWlCQSxJQUFFO0FBQUMsYUFBT0EsR0FBRSxRQUFRLDZCQUE2QixLQUFHQTtBQUFBLElBQUM7QUFBQSxJQUFDLE9BQU8sZ0JBQWdCQSxJQUFFO0FBQUMsYUFBTyxLQUFLLEtBQUssV0FBVTtBQUFDLGNBQU1DLEtBQUUsR0FBRyxvQkFBb0IsSUFBSTtBQUFFLFlBQUcsWUFBVSxPQUFPRCxJQUFFO0FBQUMsY0FBRyxXQUFTQyxHQUFFRCxFQUFDLEtBQUdBLEdBQUUsV0FBVyxHQUFHLEtBQUcsa0JBQWdCQSxHQUFFLE9BQU0sSUFBSSxVQUFVLG9CQUFvQkEsRUFBQyxHQUFHO0FBQUUsVUFBQUMsR0FBRUQsRUFBQyxFQUFFO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBQztBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsSUFBRSxHQUFHLFVBQVMsSUFBRyxJQUFHLFNBQVNBLElBQUU7QUFBQyxLQUFDLEtBQUksTUFBTSxFQUFFLFNBQVMsS0FBSyxPQUFPLEtBQUdBLEdBQUUsZUFBZSxHQUFFLEVBQUUsSUFBSSxLQUFHLEdBQUcsb0JBQW9CLElBQUksRUFBRSxLQUFLO0FBQUEsRUFBQyxDQUFDLEdBQUUsRUFBRSxHQUFHLFFBQU8sSUFBRyxNQUFJO0FBQUMsZUFBVUEsTUFBSyxFQUFFLEtBQUssRUFBRSxFQUFFLElBQUcsb0JBQW9CQSxFQUFDO0FBQUEsRUFBQyxDQUFDLEdBQUUsRUFBRSxFQUFFO0FBQUUsUUFBTSxLQUFHLGFBQVksS0FBRyxZQUFZLEVBQUUsSUFBRyxLQUFHLFdBQVcsRUFBRSxJQUFHLEtBQUcsVUFBVSxFQUFFLElBQUcsS0FBRyxXQUFXLEVBQUUsSUFBRyxLQUFHLE9BQU8sRUFBRSxJQUFHLEtBQUcsU0FBUyxFQUFFLElBQUcsS0FBRyxPQUFPLEVBQUUsSUFBRyxLQUFHLFFBQVEsRUFBRSxJQUFHLEtBQUcsUUFBTyxLQUFHLFFBQU8sS0FBRyxXQUFVLEtBQUcsRUFBQyxXQUFVLFdBQVUsVUFBUyxXQUFVLE9BQU0sU0FBUSxHQUFFLEtBQUcsRUFBQyxXQUFVLE1BQUcsVUFBUyxNQUFHLE9BQU0sSUFBRztBQUFBLEVBQUUsTUFBTSxXQUFXLEVBQUM7QUFBQSxJQUFDLFlBQVlBLElBQUVDLElBQUU7QUFBQyxZQUFNRCxJQUFFQyxFQUFDLEdBQUUsS0FBSyxXQUFTLE1BQUssS0FBSyx1QkFBcUIsT0FBRyxLQUFLLDBCQUF3QixPQUFHLEtBQUssY0FBYztBQUFBLElBQUM7QUFBQSxJQUFDLFdBQVcsVUFBUztBQUFDLGFBQU87QUFBQSxJQUFFO0FBQUEsSUFBQyxXQUFXLGNBQWE7QUFBQyxhQUFPO0FBQUEsSUFBRTtBQUFBLElBQUMsV0FBVyxPQUFNO0FBQUMsYUFBTTtBQUFBLElBQU87QUFBQSxJQUFDLE9BQU07QUFBQyxRQUFFLFFBQVEsS0FBSyxVQUFTLEVBQUUsRUFBRSxxQkFBbUIsS0FBSyxjQUFjLEdBQUUsS0FBSyxRQUFRLGFBQVcsS0FBSyxTQUFTLFVBQVUsSUFBSSxNQUFNLEdBQUUsS0FBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsRUFBRSxLQUFLLFFBQVEsR0FBRSxLQUFLLFNBQVMsVUFBVSxJQUFJLElBQUcsRUFBRSxHQUFFLEtBQUssZUFBZSxNQUFJO0FBQUMsYUFBSyxTQUFTLFVBQVUsT0FBTyxFQUFFLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFLEdBQUUsS0FBSyxtQkFBbUI7QUFBQSxNQUFDLEdBQUUsS0FBSyxVQUFTLEtBQUssUUFBUSxTQUFTO0FBQUEsSUFBRTtBQUFBLElBQUMsT0FBTTtBQUFDLFdBQUssUUFBUSxNQUFJLEVBQUUsUUFBUSxLQUFLLFVBQVMsRUFBRSxFQUFFLHFCQUFtQixLQUFLLFNBQVMsVUFBVSxJQUFJLEVBQUUsR0FBRSxLQUFLLGVBQWUsTUFBSTtBQUFDLGFBQUssU0FBUyxVQUFVLElBQUksRUFBRSxHQUFFLEtBQUssU0FBUyxVQUFVLE9BQU8sSUFBRyxFQUFFLEdBQUUsRUFBRSxRQUFRLEtBQUssVUFBUyxFQUFFO0FBQUEsTUFBQyxHQUFFLEtBQUssVUFBUyxLQUFLLFFBQVEsU0FBUztBQUFBLElBQUc7QUFBQSxJQUFDLFVBQVM7QUFBQyxXQUFLLGNBQWMsR0FBRSxLQUFLLFFBQVEsS0FBRyxLQUFLLFNBQVMsVUFBVSxPQUFPLEVBQUUsR0FBRSxNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsSUFBQyxVQUFTO0FBQUMsYUFBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLEVBQUU7QUFBQSxJQUFDO0FBQUEsSUFBQyxxQkFBb0I7QUFBQyxXQUFLLFFBQVEsYUFBVyxLQUFLLHdCQUFzQixLQUFLLDRCQUEwQixLQUFLLFdBQVMsV0FBVyxNQUFJO0FBQUMsYUFBSyxLQUFLO0FBQUEsTUFBQyxHQUFFLEtBQUssUUFBUSxLQUFLO0FBQUEsSUFBRztBQUFBLElBQUMsZUFBZUQsSUFBRUMsSUFBRTtBQUFDLGNBQU9ELEdBQUUsTUFBSztBQUFBLFFBQUMsS0FBSTtBQUFBLFFBQVksS0FBSTtBQUFXLGVBQUssdUJBQXFCQztBQUFFO0FBQUEsUUFBTSxLQUFJO0FBQUEsUUFBVSxLQUFJO0FBQVcsZUFBSywwQkFBd0JBO0FBQUEsTUFBQztBQUFDLFVBQUdBLEdBQUUsUUFBTyxLQUFLLEtBQUssY0FBYztBQUFFLFlBQU1DLEtBQUVGLEdBQUU7QUFBYyxXQUFLLGFBQVdFLE1BQUcsS0FBSyxTQUFTLFNBQVNBLEVBQUMsS0FBRyxLQUFLLG1CQUFtQjtBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsUUFBRSxHQUFHLEtBQUssVUFBUyxJQUFHLENBQUFGLE9BQUcsS0FBSyxlQUFlQSxJQUFFLElBQUUsQ0FBQyxHQUFFLEVBQUUsR0FBRyxLQUFLLFVBQVMsSUFBRyxDQUFBQSxPQUFHLEtBQUssZUFBZUEsSUFBRSxLQUFFLENBQUMsR0FBRSxFQUFFLEdBQUcsS0FBSyxVQUFTLElBQUcsQ0FBQUEsT0FBRyxLQUFLLGVBQWVBLElBQUUsSUFBRSxDQUFDLEdBQUUsRUFBRSxHQUFHLEtBQUssVUFBUyxJQUFHLENBQUFBLE9BQUcsS0FBSyxlQUFlQSxJQUFFLEtBQUUsQ0FBQztBQUFBLElBQUM7QUFBQSxJQUFDLGdCQUFlO0FBQUMsbUJBQWEsS0FBSyxRQUFRLEdBQUUsS0FBSyxXQUFTO0FBQUEsSUFBSTtBQUFBLElBQUMsT0FBTyxnQkFBZ0JBLElBQUU7QUFBQyxhQUFPLEtBQUssS0FBSyxXQUFVO0FBQUMsY0FBTUMsS0FBRSxHQUFHLG9CQUFvQixNQUFLRCxFQUFDO0FBQUUsWUFBRyxZQUFVLE9BQU9BLElBQUU7QUFBQyxjQUFHLFdBQVNDLEdBQUVELEVBQUMsRUFBRSxPQUFNLElBQUksVUFBVSxvQkFBb0JBLEVBQUMsR0FBRztBQUFFLFVBQUFDLEdBQUVELEVBQUMsRUFBRSxJQUFJO0FBQUEsUUFBQztBQUFBLE1BQUMsQ0FBQztBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsU0FBTyxFQUFFLEVBQUUsR0FBRSxFQUFFLEVBQUUsR0FBRSxFQUFDLE9BQU0sR0FBRSxRQUFPLEdBQUUsVUFBUyxJQUFHLFVBQVMsSUFBRyxVQUFTLElBQUcsT0FBTSxJQUFHLFdBQVUsSUFBRyxTQUFRLElBQUcsV0FBVSxJQUFHLEtBQUksSUFBRyxPQUFNLElBQUcsU0FBUSxHQUFFO0FBQUMsQ0FBQztBQU1sMjFELEVBQUMsU0FBUyxHQUFFLEdBQUU7QUFBQyxjQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxFQUFFLE9BQU8sSUFBRSxjQUFZLE9BQU8sVUFBUSxPQUFPLE1BQUksT0FBTyxDQUFDLFNBQVMsR0FBRSxDQUFDLElBQUUsR0FBRyxJQUFFLGVBQWEsT0FBTyxhQUFXLGFBQVcsS0FBRyxNQUFNLFNBQU8sQ0FBQyxDQUFDO0FBQUMsR0FBRSxPQUFNLFNBQVMsR0FBRTtBQUFDO0FBQWEsV0FBUyxFQUFFQyxJQUFFO0FBQUMsUUFBRyxRQUFNQSxHQUFFLFFBQU87QUFBTyxRQUFHLHNCQUFvQkEsR0FBRSxTQUFTLEdBQUU7QUFBQyxVQUFJRCxLQUFFQyxHQUFFO0FBQWMsYUFBT0QsTUFBR0EsR0FBRSxlQUFhO0FBQUEsSUFBTTtBQUFDLFdBQU9DO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRTtBQUFDLFdBQU9BLGNBQWEsRUFBRUEsRUFBQyxFQUFFLFdBQVNBLGNBQWE7QUFBQSxFQUFPO0FBQUMsV0FBUyxFQUFFQSxJQUFFO0FBQUMsV0FBT0EsY0FBYSxFQUFFQSxFQUFDLEVBQUUsZUFBYUEsY0FBYTtBQUFBLEVBQVc7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxXQUFNLGVBQWEsT0FBTyxlQUFhQSxjQUFhLEVBQUVBLEVBQUMsRUFBRSxjQUFZQSxjQUFhO0FBQUEsRUFBVztBQUFDLE1BQUksSUFBRSxLQUFLLEtBQUksSUFBRSxLQUFLLEtBQUksSUFBRSxLQUFLO0FBQU0sV0FBUyxJQUFHO0FBQUMsUUFBSUEsS0FBRSxVQUFVO0FBQWMsV0FBTyxRQUFNQSxNQUFHQSxHQUFFLFVBQVEsTUFBTSxRQUFRQSxHQUFFLE1BQU0sSUFBRUEsR0FBRSxPQUFPLEtBQUssU0FBU0EsSUFBRTtBQUFDLGFBQU9BLEdBQUUsUUFBTSxNQUFJQSxHQUFFO0FBQUEsSUFBTyxFQUFFLEVBQUUsS0FBSyxHQUFHLElBQUUsVUFBVTtBQUFBLEVBQVM7QUFBQyxXQUFTLElBQUc7QUFBQyxXQUFNLENBQUMsaUNBQWlDLEtBQUssRUFBRSxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRUssSUFBRUosSUFBRTtBQUFDLGVBQVNJLE9BQUlBLEtBQUUsUUFBSSxXQUFTSixPQUFJQSxLQUFFO0FBQUksUUFBSUssS0FBRU4sR0FBRSxzQkFBc0IsR0FBRVksS0FBRSxHQUFFQyxLQUFFO0FBQUUsSUFBQVIsTUFBRyxFQUFFTCxFQUFDLE1BQUlZLEtBQUVaLEdBQUUsY0FBWSxLQUFHLEVBQUVNLEdBQUUsS0FBSyxJQUFFTixHQUFFLGVBQWEsR0FBRWEsS0FBRWIsR0FBRSxlQUFhLEtBQUcsRUFBRU0sR0FBRSxNQUFNLElBQUVOLEdBQUUsZ0JBQWM7QUFBRyxRQUFJVyxNQUFHLEVBQUVYLEVBQUMsSUFBRSxFQUFFQSxFQUFDLElBQUUsUUFBUSxnQkFBZU8sS0FBRSxDQUFDLEVBQUUsS0FBR04sSUFBRVMsTUFBR0osR0FBRSxRQUFNQyxNQUFHSSxLQUFFQSxHQUFFLGFBQVcsTUFBSUMsSUFBRUgsTUFBR0gsR0FBRSxPQUFLQyxNQUFHSSxLQUFFQSxHQUFFLFlBQVUsTUFBSUUsSUFBRUMsS0FBRVIsR0FBRSxRQUFNTSxJQUFFRyxLQUFFVCxHQUFFLFNBQU9PO0FBQUUsV0FBTSxFQUFDLE9BQU1DLElBQUUsUUFBT0MsSUFBRSxLQUFJTixJQUFFLE9BQU1DLEtBQUVJLElBQUUsUUFBT0wsS0FBRU0sSUFBRSxNQUFLTCxJQUFFLEdBQUVBLElBQUUsR0FBRUQsR0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVULElBQUU7QUFBQyxRQUFJRyxLQUFFLEVBQUVILEVBQUM7QUFBRSxXQUFNLEVBQUMsWUFBV0csR0FBRSxhQUFZLFdBQVVBLEdBQUUsWUFBVztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVILElBQUU7QUFBQyxXQUFPQSxNQUFHQSxHQUFFLFlBQVUsSUFBSSxZQUFZLElBQUU7QUFBQSxFQUFJO0FBQUMsV0FBUyxFQUFFQSxJQUFFO0FBQUMsYUFBUSxFQUFFQSxFQUFDLElBQUVBLEdBQUUsZ0JBQWNBLEdBQUUsYUFBVyxPQUFPLFVBQVU7QUFBQSxFQUFlO0FBQUMsV0FBUyxFQUFFQSxJQUFFO0FBQUMsV0FBTyxFQUFFLEVBQUVBLEVBQUMsQ0FBQyxFQUFFLE9BQUssRUFBRUEsRUFBQyxFQUFFO0FBQUEsRUFBVTtBQUFDLFdBQVMsRUFBRUEsSUFBRTtBQUFDLFdBQU8sRUFBRUEsRUFBQyxFQUFFLGlCQUFpQkEsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxRQUFJRCxLQUFFLEVBQUVDLEVBQUMsR0FBRUcsS0FBRUosR0FBRSxVQUFTSyxLQUFFTCxHQUFFLFdBQVVNLEtBQUVOLEdBQUU7QUFBVSxXQUFNLDZCQUE2QixLQUFLSSxLQUFFRSxLQUFFRCxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUosSUFBRUcsSUFBRUUsSUFBRTtBQUFDLGVBQVNBLE9BQUlBLEtBQUU7QUFBSSxRQUFJSixJQUFFSyxJQUFFTSxLQUFFLEVBQUVULEVBQUMsR0FBRUssS0FBRSxFQUFFTCxFQUFDLE1BQUcsU0FBU0gsSUFBRTtBQUFDLFVBQUlELEtBQUVDLEdBQUUsc0JBQXNCLEdBQUVHLEtBQUUsRUFBRUosR0FBRSxLQUFLLElBQUVDLEdBQUUsZUFBYSxHQUFFSSxLQUFFLEVBQUVMLEdBQUUsTUFBTSxJQUFFQyxHQUFFLGdCQUFjO0FBQUUsYUFBTyxNQUFJRyxNQUFHLE1BQUlDO0FBQUEsSUFBQyxHQUFFRCxFQUFDLEdBQUVXLEtBQUUsRUFBRVgsRUFBQyxHQUFFYSxLQUFFLEVBQUVoQixJQUFFUSxJQUFFSCxFQUFDLEdBQUVZLEtBQUUsRUFBQyxZQUFXLEdBQUUsV0FBVSxFQUFDLEdBQUVDLEtBQUUsRUFBQyxHQUFFLEdBQUUsR0FBRSxFQUFDO0FBQUUsWUFBT04sTUFBRyxDQUFDQSxNQUFHLENBQUNQLFNBQU0sV0FBUyxFQUFFRixFQUFDLEtBQUcsRUFBRVcsRUFBQyxPQUFLRyxNQUFHaEIsS0FBRUUsUUFBSyxFQUFFRixFQUFDLEtBQUcsRUFBRUEsRUFBQyxJQUFFLEVBQUMsYUFBWUssS0FBRUwsSUFBRyxZQUFXLFdBQVVLLEdBQUUsVUFBUyxJQUFFLEVBQUVMLEVBQUMsSUFBRyxFQUFFRSxFQUFDLE1BQUllLEtBQUUsRUFBRWYsSUFBRSxJQUFFLEdBQUcsS0FBR0EsR0FBRSxZQUFXZSxHQUFFLEtBQUdmLEdBQUUsYUFBV1csT0FBSUksR0FBRSxJQUFFLEVBQUVKLEVBQUMsS0FBSSxFQUFDLEdBQUVFLEdBQUUsT0FBS0MsR0FBRSxhQUFXQyxHQUFFLEdBQUUsR0FBRUYsR0FBRSxNQUFJQyxHQUFFLFlBQVVDLEdBQUUsR0FBRSxPQUFNRixHQUFFLE9BQU0sUUFBT0EsR0FBRSxPQUFNO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRWhCLElBQUU7QUFBQyxRQUFJRCxLQUFFLEVBQUVDLEVBQUMsR0FBRUcsS0FBRUgsR0FBRSxhQUFZSSxLQUFFSixHQUFFO0FBQWEsV0FBTyxLQUFLLElBQUlELEdBQUUsUUFBTUksRUFBQyxLQUFHLE1BQUlBLEtBQUVKLEdBQUUsUUFBTyxLQUFLLElBQUlBLEdBQUUsU0FBT0ssRUFBQyxLQUFHLE1BQUlBLEtBQUVMLEdBQUUsU0FBUSxFQUFDLEdBQUVDLEdBQUUsWUFBVyxHQUFFQSxHQUFFLFdBQVUsT0FBTUcsSUFBRSxRQUFPQyxHQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUosSUFBRTtBQUFDLFdBQU0sV0FBUyxFQUFFQSxFQUFDLElBQUVBLEtBQUVBLEdBQUUsZ0JBQWNBLEdBQUUsZUFBYSxFQUFFQSxFQUFDLElBQUVBLEdBQUUsT0FBSyxTQUFPLEVBQUVBLEVBQUM7QUFBQSxFQUFDO0FBQUMsV0FBUyxFQUFFQSxJQUFFO0FBQUMsV0FBTSxDQUFDLFFBQU8sUUFBTyxXQUFXLEVBQUUsUUFBUSxFQUFFQSxFQUFDLENBQUMsS0FBRyxJQUFFQSxHQUFFLGNBQWMsT0FBSyxFQUFFQSxFQUFDLEtBQUcsRUFBRUEsRUFBQyxJQUFFQSxLQUFFLEVBQUUsRUFBRUEsRUFBQyxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRUcsSUFBRTtBQUFDLFFBQUlDO0FBQUUsZUFBU0QsT0FBSUEsS0FBRSxDQUFDO0FBQUcsUUFBSUUsS0FBRSxFQUFFTCxFQUFDLEdBQUVDLEtBQUVJLFFBQUssU0FBT0QsS0FBRUosR0FBRSxpQkFBZSxTQUFPSSxHQUFFLE9BQU1FLEtBQUUsRUFBRUQsRUFBQyxHQUFFSCxLQUFFRCxLQUFFLENBQUNLLEVBQUMsRUFBRSxPQUFPQSxHQUFFLGtCQUFnQixDQUFDLEdBQUUsRUFBRUQsRUFBQyxJQUFFQSxLQUFFLENBQUMsQ0FBQyxJQUFFQSxJQUFFTyxLQUFFVCxHQUFFLE9BQU9ELEVBQUM7QUFBRSxXQUFPRCxLQUFFVyxLQUFFQSxHQUFFLE9BQU8sRUFBRSxFQUFFVixFQUFDLENBQUMsQ0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVGLElBQUU7QUFBQyxXQUFNLENBQUMsU0FBUSxNQUFLLElBQUksRUFBRSxRQUFRLEVBQUVBLEVBQUMsQ0FBQyxLQUFHO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRTtBQUFDLFdBQU8sRUFBRUEsRUFBQyxLQUFHLFlBQVUsRUFBRUEsRUFBQyxFQUFFLFdBQVNBLEdBQUUsZUFBYTtBQUFBLEVBQUk7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxhQUFRRyxLQUFFLEVBQUVILEVBQUMsR0FBRUMsS0FBRSxFQUFFRCxFQUFDLEdBQUVDLE1BQUcsRUFBRUEsRUFBQyxLQUFHLGFBQVcsRUFBRUEsRUFBQyxFQUFFLFdBQVUsQ0FBQUEsS0FBRSxFQUFFQSxFQUFDO0FBQUUsV0FBT0EsT0FBSSxXQUFTLEVBQUVBLEVBQUMsS0FBRyxXQUFTLEVBQUVBLEVBQUMsS0FBRyxhQUFXLEVBQUVBLEVBQUMsRUFBRSxZQUFVRSxLQUFFRixPQUFHLFNBQVNELElBQUU7QUFBQyxVQUFJRCxLQUFFLFdBQVcsS0FBSyxFQUFFLENBQUM7QUFBRSxVQUFHLFdBQVcsS0FBSyxFQUFFLENBQUMsS0FBRyxFQUFFQyxFQUFDLEtBQUcsWUFBVSxFQUFFQSxFQUFDLEVBQUUsU0FBUyxRQUFPO0FBQUssVUFBSUcsS0FBRSxFQUFFSCxFQUFDO0FBQUUsV0FBSSxFQUFFRyxFQUFDLE1BQUlBLEtBQUVBLEdBQUUsT0FBTSxFQUFFQSxFQUFDLEtBQUcsQ0FBQyxRQUFPLE1BQU0sRUFBRSxRQUFRLEVBQUVBLEVBQUMsQ0FBQyxJQUFFLEtBQUc7QUFBQyxZQUFJRixLQUFFLEVBQUVFLEVBQUM7QUFBRSxZQUFHLFdBQVNGLEdBQUUsYUFBVyxXQUFTQSxHQUFFLGVBQWEsWUFBVUEsR0FBRSxXQUFTLE9BQUssQ0FBQyxhQUFZLGFBQWEsRUFBRSxRQUFRQSxHQUFFLFVBQVUsS0FBR0YsTUFBRyxhQUFXRSxHQUFFLGNBQVlGLE1BQUdFLEdBQUUsVUFBUSxXQUFTQSxHQUFFLE9BQU8sUUFBT0U7QUFBRSxRQUFBQSxLQUFFQSxHQUFFO0FBQUEsTUFBVTtBQUFDLGFBQU87QUFBQSxJQUFJLEdBQUVILEVBQUMsS0FBR0c7QUFBQSxFQUFDO0FBQUMsTUFBSSxJQUFFLE9BQU0sSUFBRSxVQUFTLElBQUUsU0FBUSxJQUFFLFFBQU8sSUFBRSxRQUFPLElBQUUsQ0FBQyxHQUFFLEdBQUUsR0FBRSxDQUFDLEdBQUUsSUFBRSxTQUFRLElBQUUsT0FBTSxJQUFFLFlBQVcsSUFBRSxVQUFTLElBQUUsRUFBRSxRQUFRLFNBQVNILElBQUVELElBQUU7QUFBQyxXQUFPQyxHQUFFLE9BQU8sQ0FBQ0QsS0FBRSxNQUFJLEdBQUVBLEtBQUUsTUFBSSxDQUFDLENBQUM7QUFBQSxFQUFDLElBQUcsQ0FBQyxDQUFDLEdBQUUsSUFBRSxDQUFDLEVBQUUsT0FBTyxHQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxTQUFTQyxJQUFFRCxJQUFFO0FBQUMsV0FBT0MsR0FBRSxPQUFPLENBQUNELElBQUVBLEtBQUUsTUFBSSxHQUFFQSxLQUFFLE1BQUksQ0FBQyxDQUFDO0FBQUEsRUFBQyxJQUFHLENBQUMsQ0FBQyxHQUFFLElBQUUsQ0FBQyxjQUFhLFFBQU8sYUFBWSxjQUFhLFFBQU8sYUFBWSxlQUFjLFNBQVEsWUFBWTtBQUFFLFdBQVMsRUFBRUMsSUFBRTtBQUFDLFFBQUlELEtBQUUsb0JBQUksT0FBSUksS0FBRSxvQkFBSSxPQUFJQyxLQUFFLENBQUM7QUFBRSxhQUFTQyxHQUFFTCxJQUFFO0FBQUMsTUFBQUcsR0FBRSxJQUFJSCxHQUFFLElBQUksR0FBRSxDQUFDLEVBQUUsT0FBT0EsR0FBRSxZQUFVLENBQUMsR0FBRUEsR0FBRSxvQkFBa0IsQ0FBQyxDQUFDLEVBQUUsU0FBUyxTQUFTQSxJQUFFO0FBQUMsWUFBRyxDQUFDRyxHQUFFLElBQUlILEVBQUMsR0FBRTtBQUFDLGNBQUlJLEtBQUVMLEdBQUUsSUFBSUMsRUFBQztBQUFFLFVBQUFJLE1BQUdDLEdBQUVELEVBQUM7QUFBQSxRQUFDO0FBQUEsTUFBQyxFQUFFLEdBQUVBLEdBQUUsS0FBS0osRUFBQztBQUFBLElBQUM7QUFBQyxXQUFPQSxHQUFFLFNBQVMsU0FBU0EsSUFBRTtBQUFDLE1BQUFELEdBQUUsSUFBSUMsR0FBRSxNQUFLQSxFQUFDO0FBQUEsSUFBQyxFQUFFLEdBQUVBLEdBQUUsU0FBUyxTQUFTQSxJQUFFO0FBQUMsTUFBQUcsR0FBRSxJQUFJSCxHQUFFLElBQUksS0FBR0ssR0FBRUwsRUFBQztBQUFBLElBQUMsRUFBRSxHQUFFSTtBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVKLElBQUVELElBQUU7QUFBQyxRQUFJSSxLQUFFSixHQUFFLGVBQWFBLEdBQUUsWUFBWTtBQUFFLFFBQUdDLEdBQUUsU0FBU0QsRUFBQyxFQUFFLFFBQU07QUFBRyxRQUFHSSxNQUFHLEVBQUVBLEVBQUMsR0FBRTtBQUFDLFVBQUlDLEtBQUVMO0FBQUUsU0FBRTtBQUFDLFlBQUdLLE1BQUdKLEdBQUUsV0FBV0ksRUFBQyxFQUFFLFFBQU07QUFBRyxRQUFBQSxLQUFFQSxHQUFFLGNBQVlBLEdBQUU7QUFBQSxNQUFJLFNBQU9BO0FBQUEsSUFBRTtBQUFDLFdBQU07QUFBQSxFQUFFO0FBQUMsV0FBUyxFQUFFSixJQUFFO0FBQUMsV0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFQSxJQUFFLEVBQUMsTUFBS0EsR0FBRSxHQUFFLEtBQUlBLEdBQUUsR0FBRSxPQUFNQSxHQUFFLElBQUVBLEdBQUUsT0FBTSxRQUFPQSxHQUFFLElBQUVBLEdBQUUsT0FBTSxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRUksSUFBRUMsSUFBRTtBQUFDLFdBQU9ELE9BQUksSUFBRSxHQUFFLFNBQVNKLElBQUVHLElBQUU7QUFBQyxVQUFJQyxLQUFFLEVBQUVKLEVBQUMsR0FBRUssS0FBRSxFQUFFTCxFQUFDLEdBQUVDLEtBQUVHLEdBQUUsZ0JBQWVFLEtBQUVELEdBQUUsYUFBWUgsS0FBRUcsR0FBRSxjQUFhTyxLQUFFLEdBQUVDLEtBQUU7QUFBRSxVQUFHWixJQUFFO0FBQUMsUUFBQUssS0FBRUwsR0FBRSxPQUFNQyxLQUFFRCxHQUFFO0FBQU8sWUFBSVUsS0FBRSxFQUFFO0FBQUUsU0FBQ0EsTUFBRyxDQUFDQSxNQUFHLFlBQVVSLFFBQUtTLEtBQUVYLEdBQUUsWUFBV1ksS0FBRVosR0FBRTtBQUFBLE1BQVU7QUFBQyxhQUFNLEVBQUMsT0FBTUssSUFBRSxRQUFPSixJQUFFLEdBQUVVLEtBQUUsRUFBRVosRUFBQyxHQUFFLEdBQUVhLEdBQUM7QUFBQSxJQUFDLEdBQUViLElBQUVLLEVBQUMsQ0FBQyxJQUFFLEVBQUVELEVBQUMsS0FBRSxTQUFTSixJQUFFRCxJQUFFO0FBQUMsVUFBSUksS0FBRSxFQUFFSCxJQUFFLE9BQUcsWUFBVUQsRUFBQztBQUFFLGFBQU9JLEdBQUUsTUFBSUEsR0FBRSxNQUFJSCxHQUFFLFdBQVVHLEdBQUUsT0FBS0EsR0FBRSxPQUFLSCxHQUFFLFlBQVdHLEdBQUUsU0FBT0EsR0FBRSxNQUFJSCxHQUFFLGNBQWFHLEdBQUUsUUFBTUEsR0FBRSxPQUFLSCxHQUFFLGFBQVlHLEdBQUUsUUFBTUgsR0FBRSxhQUFZRyxHQUFFLFNBQU9ILEdBQUUsY0FBYUcsR0FBRSxJQUFFQSxHQUFFLE1BQUtBLEdBQUUsSUFBRUEsR0FBRSxLQUFJQTtBQUFBLElBQUMsR0FBRUMsSUFBRUMsRUFBQyxJQUFFLEdBQUUsU0FBU0wsSUFBRTtBQUFDLFVBQUlELElBQUVJLEtBQUUsRUFBRUgsRUFBQyxHQUFFSSxLQUFFLEVBQUVKLEVBQUMsR0FBRUssS0FBRSxTQUFPTixLQUFFQyxHQUFFLGlCQUFlLFNBQU9ELEdBQUUsTUFBS08sS0FBRSxFQUFFSCxHQUFFLGFBQVlBLEdBQUUsYUFBWUUsS0FBRUEsR0FBRSxjQUFZLEdBQUVBLEtBQUVBLEdBQUUsY0FBWSxDQUFDLEdBQUVILEtBQUUsRUFBRUMsR0FBRSxjQUFhQSxHQUFFLGNBQWFFLEtBQUVBLEdBQUUsZUFBYSxHQUFFQSxLQUFFQSxHQUFFLGVBQWEsQ0FBQyxHQUFFTyxLQUFFLENBQUNSLEdBQUUsYUFBVyxFQUFFSixFQUFDLEdBQUVRLEtBQUUsQ0FBQ0osR0FBRTtBQUFVLGFBQU0sVUFBUSxFQUFFQyxNQUFHRixFQUFDLEVBQUUsY0FBWVMsTUFBRyxFQUFFVCxHQUFFLGFBQVlFLEtBQUVBLEdBQUUsY0FBWSxDQUFDLElBQUVDLEtBQUcsRUFBQyxPQUFNQSxJQUFFLFFBQU9KLElBQUUsR0FBRVUsSUFBRSxHQUFFSixHQUFDO0FBQUEsSUFBQyxHQUFFLEVBQUVSLEVBQUMsQ0FBQyxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRUQsSUFBRU0sSUFBRUgsSUFBRTtBQUFDLFFBQUlVLEtBQUUsc0JBQW9CYixNQUFFLFNBQVNDLElBQUU7QUFBQyxVQUFJRCxLQUFFLEVBQUUsRUFBRUMsRUFBQyxDQUFDLEdBQUVLLEtBQUUsQ0FBQyxZQUFXLE9BQU8sRUFBRSxRQUFRLEVBQUVMLEVBQUMsRUFBRSxRQUFRLEtBQUcsS0FBRyxFQUFFQSxFQUFDLElBQUUsRUFBRUEsRUFBQyxJQUFFQTtBQUFFLGFBQU8sRUFBRUssRUFBQyxJQUFFTixHQUFFLFFBQVEsU0FBU0MsSUFBRTtBQUFDLGVBQU8sRUFBRUEsRUFBQyxLQUFHLEVBQUVBLElBQUVLLEVBQUMsS0FBRyxXQUFTLEVBQUVMLEVBQUM7QUFBQSxNQUFDLEVBQUUsSUFBRSxDQUFDO0FBQUEsSUFBQyxHQUFFQSxFQUFDLElBQUUsQ0FBQyxFQUFFLE9BQU9ELEVBQUMsR0FBRVMsS0FBRSxDQUFDLEVBQUUsT0FBT0ksSUFBRSxDQUFDUCxFQUFDLENBQUMsR0FBRVEsS0FBRUwsR0FBRSxDQUFDLEdBQUVHLEtBQUVILEdBQUUsUUFBUSxTQUFTVCxJQUFFSSxJQUFFO0FBQUMsVUFBSUMsS0FBRSxFQUFFSixJQUFFRyxJQUFFRCxFQUFDO0FBQUUsYUFBT0gsR0FBRSxNQUFJLEVBQUVLLEdBQUUsS0FBSUwsR0FBRSxHQUFHLEdBQUVBLEdBQUUsUUFBTSxFQUFFSyxHQUFFLE9BQU1MLEdBQUUsS0FBSyxHQUFFQSxHQUFFLFNBQU8sRUFBRUssR0FBRSxRQUFPTCxHQUFFLE1BQU0sR0FBRUEsR0FBRSxPQUFLLEVBQUVLLEdBQUUsTUFBS0wsR0FBRSxJQUFJLEdBQUVBO0FBQUEsSUFBQyxJQUFHLEVBQUVDLElBQUVhLElBQUVYLEVBQUMsQ0FBQztBQUFFLFdBQU9TLEdBQUUsUUFBTUEsR0FBRSxRQUFNQSxHQUFFLE1BQUtBLEdBQUUsU0FBT0EsR0FBRSxTQUFPQSxHQUFFLEtBQUlBLEdBQUUsSUFBRUEsR0FBRSxNQUFLQSxHQUFFLElBQUVBLEdBQUUsS0FBSUE7QUFBQSxFQUFDO0FBQUMsV0FBUyxFQUFFWCxJQUFFO0FBQUMsV0FBT0EsR0FBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRTtBQUFDLFdBQU9BLEdBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxXQUFNLENBQUMsT0FBTSxRQUFRLEVBQUUsUUFBUUEsRUFBQyxLQUFHLElBQUUsTUFBSTtBQUFBLEVBQUc7QUFBQyxXQUFTLEVBQUVBLElBQUU7QUFBQyxRQUFJRCxJQUFFSSxLQUFFSCxHQUFFLFdBQVVJLEtBQUVKLEdBQUUsU0FBUUssS0FBRUwsR0FBRSxXQUFVQyxLQUFFSSxLQUFFLEVBQUVBLEVBQUMsSUFBRSxNQUFLQyxLQUFFRCxLQUFFLEVBQUVBLEVBQUMsSUFBRSxNQUFLSCxLQUFFQyxHQUFFLElBQUVBLEdBQUUsUUFBTSxJQUFFQyxHQUFFLFFBQU0sR0FBRVEsS0FBRVQsR0FBRSxJQUFFQSxHQUFFLFNBQU8sSUFBRUMsR0FBRSxTQUFPO0FBQUUsWUFBT0gsSUFBRTtBQUFBLE1BQUMsS0FBSztBQUFFLFFBQUFGLEtBQUUsRUFBQyxHQUFFRyxJQUFFLEdBQUVDLEdBQUUsSUFBRUMsR0FBRSxPQUFNO0FBQUU7QUFBQSxNQUFNLEtBQUs7QUFBRSxRQUFBTCxLQUFFLEVBQUMsR0FBRUcsSUFBRSxHQUFFQyxHQUFFLElBQUVBLEdBQUUsT0FBTTtBQUFFO0FBQUEsTUFBTSxLQUFLO0FBQUUsUUFBQUosS0FBRSxFQUFDLEdBQUVJLEdBQUUsSUFBRUEsR0FBRSxPQUFNLEdBQUVTLEdBQUM7QUFBRTtBQUFBLE1BQU0sS0FBSztBQUFFLFFBQUFiLEtBQUUsRUFBQyxHQUFFSSxHQUFFLElBQUVDLEdBQUUsT0FBTSxHQUFFUSxHQUFDO0FBQUU7QUFBQSxNQUFNO0FBQVEsUUFBQWIsS0FBRSxFQUFDLEdBQUVJLEdBQUUsR0FBRSxHQUFFQSxHQUFFLEVBQUM7QUFBQSxJQUFDO0FBQUMsUUFBSUssS0FBRVAsS0FBRSxFQUFFQSxFQUFDLElBQUU7QUFBSyxRQUFHLFFBQU1PLElBQUU7QUFBQyxVQUFJSyxLQUFFLFFBQU1MLEtBQUUsV0FBUztBQUFRLGNBQU9GLElBQUU7QUFBQSxRQUFDLEtBQUs7QUFBRSxVQUFBUCxHQUFFUyxFQUFDLElBQUVULEdBQUVTLEVBQUMsS0FBR0wsR0FBRVUsRUFBQyxJQUFFLElBQUVULEdBQUVTLEVBQUMsSUFBRTtBQUFHO0FBQUEsUUFBTSxLQUFLO0FBQUUsVUFBQWQsR0FBRVMsRUFBQyxJQUFFVCxHQUFFUyxFQUFDLEtBQUdMLEdBQUVVLEVBQUMsSUFBRSxJQUFFVCxHQUFFUyxFQUFDLElBQUU7QUFBQSxNQUFFO0FBQUEsSUFBQztBQUFDLFdBQU9kO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUMsSUFBRTtBQUFDLFdBQU8sT0FBTyxPQUFPLENBQUMsR0FBRSxFQUFDLEtBQUksR0FBRSxPQUFNLEdBQUUsUUFBTyxHQUFFLE1BQUssRUFBQyxHQUFFQSxFQUFDO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRUQsSUFBRTtBQUFDLFdBQU9BLEdBQUUsUUFBUSxTQUFTQSxJQUFFSSxJQUFFO0FBQUMsYUFBT0osR0FBRUksRUFBQyxJQUFFSCxJQUFFRDtBQUFBLElBQUMsSUFBRyxDQUFDLENBQUM7QUFBQSxFQUFDO0FBQUMsV0FBUyxFQUFFQyxJQUFFRCxJQUFFO0FBQUMsZUFBU0EsT0FBSUEsS0FBRSxDQUFDO0FBQUcsUUFBSUssS0FBRUwsSUFBRU0sS0FBRUQsR0FBRSxXQUFVSCxLQUFFLFdBQVNJLEtBQUVMLEdBQUUsWUFBVUssSUFBRUMsS0FBRUYsR0FBRSxVQUFTRixLQUFFLFdBQVNJLEtBQUVOLEdBQUUsV0FBU00sSUFBRU0sS0FBRVIsR0FBRSxVQUFTSSxLQUFFLFdBQVNJLEtBQUUsb0JBQWtCQSxJQUFFRCxLQUFFUCxHQUFFLGNBQWFHLEtBQUUsV0FBU0ksS0FBRSxJQUFFQSxJQUFFRixLQUFFTCxHQUFFLGdCQUFlVSxLQUFFLFdBQVNMLEtBQUUsSUFBRUEsSUFBRU0sS0FBRVgsR0FBRSxhQUFZWSxLQUFFLFdBQVNELE1BQUdBLElBQUVFLEtBQUViLEdBQUUsU0FBUWMsS0FBRSxXQUFTRCxLQUFFLElBQUVBLElBQUVFLEtBQUUsRUFBRSxZQUFVLE9BQU9ELEtBQUVBLEtBQUUsRUFBRUEsSUFBRSxDQUFDLENBQUMsR0FBRUUsS0FBRU4sT0FBSSxJQUFFLGNBQVksR0FBRU8sS0FBRXJCLEdBQUUsTUFBTSxRQUFPc0IsS0FBRXRCLEdBQUUsU0FBU2dCLEtBQUVJLEtBQUVOLEVBQUMsR0FBRVMsS0FBRSxFQUFFLEVBQUVELEVBQUMsSUFBRUEsS0FBRUEsR0FBRSxrQkFBZ0IsRUFBRXRCLEdBQUUsU0FBUyxNQUFNLEdBQUVRLElBQUVELElBQUVMLEVBQUMsR0FBRXNCLEtBQUUsRUFBRXhCLEdBQUUsU0FBUyxTQUFTLEdBQUV5QixLQUFFLEVBQUUsRUFBQyxXQUFVRCxJQUFFLFNBQVFILElBQUUsVUFBUyxZQUFXLFdBQVVwQixHQUFDLENBQUMsR0FBRXlCLEtBQUUsRUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFTCxJQUFFSSxFQUFDLENBQUMsR0FBRUUsS0FBRWIsT0FBSSxJQUFFWSxLQUFFRixJQUFFSSxLQUFFLEVBQUMsS0FBSUwsR0FBRSxNQUFJSSxHQUFFLE1BQUlSLEdBQUUsS0FBSSxRQUFPUSxHQUFFLFNBQU9KLEdBQUUsU0FBT0osR0FBRSxRQUFPLE1BQUtJLEdBQUUsT0FBS0ksR0FBRSxPQUFLUixHQUFFLE1BQUssT0FBTVEsR0FBRSxRQUFNSixHQUFFLFFBQU1KLEdBQUUsTUFBSyxHQUFFVSxLQUFFN0IsR0FBRSxjQUFjO0FBQU8sUUFBR2MsT0FBSSxLQUFHZSxJQUFFO0FBQUMsVUFBSUMsS0FBRUQsR0FBRTVCLEVBQUM7QUFBRSxhQUFPLEtBQUsyQixFQUFDLEVBQUUsU0FBUyxTQUFTNUIsSUFBRTtBQUFDLFlBQUlELEtBQUUsQ0FBQyxHQUFFLENBQUMsRUFBRSxRQUFRQyxFQUFDLEtBQUcsSUFBRSxJQUFFLElBQUdHLEtBQUUsQ0FBQyxHQUFFLENBQUMsRUFBRSxRQUFRSCxFQUFDLEtBQUcsSUFBRSxNQUFJO0FBQUksUUFBQTRCLEdBQUU1QixFQUFDLEtBQUc4QixHQUFFM0IsRUFBQyxJQUFFSjtBQUFBLE1BQUMsRUFBRTtBQUFBLElBQUM7QUFBQyxXQUFPNkI7QUFBQSxFQUFDO0FBQUMsTUFBSSxJQUFFLEVBQUMsV0FBVSxVQUFTLFdBQVUsQ0FBQyxHQUFFLFVBQVMsV0FBVTtBQUFFLFdBQVMsSUFBRztBQUFDLGFBQVE1QixLQUFFLFVBQVUsUUFBT0QsS0FBRSxJQUFJLE1BQU1DLEVBQUMsR0FBRUcsS0FBRSxHQUFFQSxLQUFFSCxJQUFFRyxLQUFJLENBQUFKLEdBQUVJLEVBQUMsSUFBRSxVQUFVQSxFQUFDO0FBQUUsV0FBTSxDQUFDSixHQUFFLE1BQU0sU0FBU0MsSUFBRTtBQUFDLGFBQU0sRUFBRUEsTUFBRyxjQUFZLE9BQU9BLEdBQUU7QUFBQSxJQUFzQixFQUFFO0FBQUEsRUFBQztBQUFDLFdBQVMsRUFBRUEsSUFBRTtBQUFDLGVBQVNBLE9BQUlBLEtBQUUsQ0FBQztBQUFHLFFBQUlELEtBQUVDLElBQUVJLEtBQUVMLEdBQUUsa0JBQWlCTSxLQUFFLFdBQVNELEtBQUUsQ0FBQyxJQUFFQSxJQUFFSCxLQUFFRixHQUFFLGdCQUFlTyxLQUFFLFdBQVNMLEtBQUUsSUFBRUE7QUFBRSxXQUFPLFNBQVNELElBQUVELElBQUVLLElBQUU7QUFBQyxpQkFBU0EsT0FBSUEsS0FBRUU7QUFBRyxVQUFJTCxJQUFFQyxJQUFFVSxLQUFFLEVBQUMsV0FBVSxVQUFTLGtCQUFpQixDQUFDLEdBQUUsU0FBUSxPQUFPLE9BQU8sQ0FBQyxHQUFFLEdBQUVOLEVBQUMsR0FBRSxlQUFjLENBQUMsR0FBRSxVQUFTLEVBQUMsV0FBVU4sSUFBRSxRQUFPRCxHQUFDLEdBQUUsWUFBVyxDQUFDLEdBQUUsUUFBTyxDQUFDLEVBQUMsR0FBRVMsS0FBRSxDQUFDLEdBQUVLLEtBQUUsT0FBR0YsS0FBRSxFQUFDLE9BQU1DLElBQUUsWUFBVyxTQUFTUixJQUFFO0FBQUMsWUFBSUgsS0FBRSxjQUFZLE9BQU9HLEtBQUVBLEdBQUVRLEdBQUUsT0FBTyxJQUFFUjtBQUFFLFFBQUFHLEdBQUUsR0FBRUssR0FBRSxVQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUVOLElBQUVNLEdBQUUsU0FBUVgsRUFBQyxHQUFFVyxHQUFFLGdCQUFjLEVBQUMsV0FBVSxFQUFFWixFQUFDLElBQUUsRUFBRUEsRUFBQyxJQUFFQSxHQUFFLGlCQUFlLEVBQUVBLEdBQUUsY0FBYyxJQUFFLENBQUMsR0FBRSxRQUFPLEVBQUVELEVBQUMsRUFBQztBQUFFLFlBQUlHLElBQUVXLElBQUVILE1BQUUsU0FBU1YsSUFBRTtBQUFDLGNBQUlELEtBQUUsRUFBRUMsRUFBQztBQUFFLGlCQUFPLEVBQUUsUUFBUSxTQUFTQSxJQUFFRyxJQUFFO0FBQUMsbUJBQU9ILEdBQUUsT0FBT0QsR0FBRSxRQUFRLFNBQVNDLElBQUU7QUFBQyxxQkFBT0EsR0FBRSxVQUFRRztBQUFBLFlBQUMsRUFBRSxDQUFDO0FBQUEsVUFBQyxJQUFHLENBQUMsQ0FBQztBQUFBLFFBQUMsSUFBR0QsS0FBRSxDQUFDLEVBQUUsT0FBT0csSUFBRU8sR0FBRSxRQUFRLFNBQVMsR0FBRUMsS0FBRVgsR0FBRSxRQUFRLFNBQVNGLElBQUVELElBQUU7QUFBQyxjQUFJSSxLQUFFSCxHQUFFRCxHQUFFLElBQUk7QUFBRSxpQkFBT0MsR0FBRUQsR0FBRSxJQUFJLElBQUVJLEtBQUUsT0FBTyxPQUFPLENBQUMsR0FBRUEsSUFBRUosSUFBRSxFQUFDLFNBQVEsT0FBTyxPQUFPLENBQUMsR0FBRUksR0FBRSxTQUFRSixHQUFFLE9BQU8sR0FBRSxNQUFLLE9BQU8sT0FBTyxDQUFDLEdBQUVJLEdBQUUsTUFBS0osR0FBRSxJQUFJLEVBQUMsQ0FBQyxJQUFFQSxJQUFFQztBQUFBLFFBQUMsSUFBRyxDQUFDLENBQUMsR0FBRSxPQUFPLEtBQUthLEVBQUMsRUFBRSxLQUFLLFNBQVNiLElBQUU7QUFBQyxpQkFBT2EsR0FBRWIsRUFBQztBQUFBLFFBQUMsRUFBRSxFQUFFO0FBQUUsZUFBT1ksR0FBRSxtQkFBaUJGLEdBQUUsUUFBUSxTQUFTVixJQUFFO0FBQUMsaUJBQU9BLEdBQUU7QUFBQSxRQUFPLEVBQUUsR0FBRVksR0FBRSxpQkFBaUIsU0FBUyxTQUFTWixJQUFFO0FBQUMsY0FBSUQsS0FBRUMsR0FBRSxNQUFLRyxLQUFFSCxHQUFFLFNBQVFJLEtBQUUsV0FBU0QsS0FBRSxDQUFDLElBQUVBLElBQUVFLEtBQUVMLEdBQUU7QUFBTyxjQUFHLGNBQVksT0FBT0ssSUFBRTtBQUFDLGdCQUFJSixLQUFFSSxHQUFFLEVBQUMsT0FBTU8sSUFBRSxNQUFLYixJQUFFLFVBQVNZLElBQUUsU0FBUVAsR0FBQyxDQUFDLEdBQUVFLEtBQUUsV0FBVTtBQUFBLFlBQUM7QUFBRSxZQUFBRSxHQUFFLEtBQUtQLE1BQUdLLEVBQUM7QUFBQSxVQUFDO0FBQUEsUUFBQyxFQUFFLEdBQUVLLEdBQUUsT0FBTztBQUFBLE1BQUMsR0FBRSxhQUFZLFdBQVU7QUFBQyxZQUFHLENBQUNFLElBQUU7QUFBQyxjQUFJYixLQUFFWSxHQUFFLFVBQVNiLEtBQUVDLEdBQUUsV0FBVUcsS0FBRUgsR0FBRTtBQUFPLGNBQUcsRUFBRUQsSUFBRUksRUFBQyxHQUFFO0FBQUMsWUFBQVMsR0FBRSxRQUFNLEVBQUMsV0FBVSxFQUFFYixJQUFFLEVBQUVJLEVBQUMsR0FBRSxZQUFVUyxHQUFFLFFBQVEsUUFBUSxHQUFFLFFBQU8sRUFBRVQsRUFBQyxFQUFDLEdBQUVTLEdBQUUsUUFBTSxPQUFHQSxHQUFFLFlBQVVBLEdBQUUsUUFBUSxXQUFVQSxHQUFFLGlCQUFpQixTQUFTLFNBQVNaLElBQUU7QUFBQyxxQkFBT1ksR0FBRSxjQUFjWixHQUFFLElBQUksSUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFQSxHQUFFLElBQUk7QUFBQSxZQUFDLEVBQUU7QUFBRSxxQkFBUUksS0FBRSxHQUFFQSxLQUFFUSxHQUFFLGlCQUFpQixRQUFPUixLQUFJLEtBQUcsU0FBS1EsR0FBRSxPQUFNO0FBQUMsa0JBQUlQLEtBQUVPLEdBQUUsaUJBQWlCUixFQUFDLEdBQUVILEtBQUVJLEdBQUUsSUFBR0MsS0FBRUQsR0FBRSxTQUFRSCxLQUFFLFdBQVNJLEtBQUUsQ0FBQyxJQUFFQSxJQUFFRSxLQUFFSCxHQUFFO0FBQUssNEJBQVksT0FBT0osT0FBSVcsS0FBRVgsR0FBRSxFQUFDLE9BQU1XLElBQUUsU0FBUVYsSUFBRSxNQUFLTSxJQUFFLFVBQVNHLEdBQUMsQ0FBQyxLQUFHQztBQUFBLFlBQUUsTUFBTSxDQUFBQSxHQUFFLFFBQU0sT0FBR1IsS0FBRTtBQUFBLFVBQUU7QUFBQSxRQUFDO0FBQUEsTUFBQyxHQUFFLFNBQVFILEtBQUUsV0FBVTtBQUFDLGVBQU8sSUFBSSxTQUFTLFNBQVNELElBQUU7QUFBQyxVQUFBVyxHQUFFLFlBQVksR0FBRVgsR0FBRVksRUFBQztBQUFBLFFBQUMsRUFBRTtBQUFBLE1BQUMsR0FBRSxXQUFVO0FBQUMsZUFBT1YsT0FBSUEsS0FBRSxJQUFJLFNBQVMsU0FBU0YsSUFBRTtBQUFDLGtCQUFRLFFBQVEsRUFBRSxNQUFNLFdBQVU7QUFBQyxZQUFBRSxLQUFFLFFBQU9GLEdBQUVDLEdBQUUsQ0FBQztBQUFBLFVBQUMsRUFBRTtBQUFBLFFBQUMsRUFBRSxJQUFHQztBQUFBLE1BQUMsSUFBRyxTQUFRLFdBQVU7QUFBQyxRQUFBSyxHQUFFLEdBQUVNLEtBQUU7QUFBQSxNQUFFLEVBQUM7QUFBRSxVQUFHLENBQUMsRUFBRWIsSUFBRUQsRUFBQyxFQUFFLFFBQU9ZO0FBQUUsZUFBU0osS0FBRztBQUFDLFFBQUFDLEdBQUUsU0FBUyxTQUFTUixJQUFFO0FBQUMsaUJBQU9BLEdBQUU7QUFBQSxRQUFDLEVBQUUsR0FBRVEsS0FBRSxDQUFDO0FBQUEsTUFBQztBQUFDLGFBQU9HLEdBQUUsV0FBV1AsRUFBQyxFQUFFLE1BQU0sU0FBU0osSUFBRTtBQUFDLFNBQUNhLE1BQUdULEdBQUUsaUJBQWVBLEdBQUUsY0FBY0osRUFBQztBQUFBLE1BQUMsRUFBRSxHQUFFVztBQUFBLElBQUM7QUFBQSxFQUFDO0FBQUMsTUFBSSxJQUFFLEVBQUMsU0FBUSxLQUFFO0FBQUUsTUFBSSxLQUFHLEVBQUMsTUFBSyxrQkFBaUIsU0FBUSxNQUFHLE9BQU0sU0FBUSxJQUFHLFdBQVU7QUFBQSxFQUFDLEdBQUUsUUFBTyxTQUFTWCxJQUFFO0FBQUMsUUFBSUcsS0FBRUgsR0FBRSxPQUFNSSxLQUFFSixHQUFFLFVBQVNLLEtBQUVMLEdBQUUsU0FBUUMsS0FBRUksR0FBRSxRQUFPQyxLQUFFLFdBQVNMLE1BQUdBLElBQUVDLEtBQUVHLEdBQUUsUUFBT08sS0FBRSxXQUFTVixNQUFHQSxJQUFFTSxLQUFFLEVBQUVMLEdBQUUsU0FBUyxNQUFNLEdBQUVVLEtBQUUsQ0FBQyxFQUFFLE9BQU9WLEdBQUUsY0FBYyxXQUFVQSxHQUFFLGNBQWMsTUFBTTtBQUFFLFdBQU9HLE1BQUdPLEdBQUUsU0FBUyxTQUFTYixJQUFFO0FBQUMsTUFBQUEsR0FBRSxpQkFBaUIsVUFBU0ksR0FBRSxRQUFPLENBQUM7QUFBQSxJQUFDLEVBQUUsR0FBRVEsTUFBR0osR0FBRSxpQkFBaUIsVUFBU0osR0FBRSxRQUFPLENBQUMsR0FBRSxXQUFVO0FBQUMsTUFBQUUsTUFBR08sR0FBRSxTQUFTLFNBQVNiLElBQUU7QUFBQyxRQUFBQSxHQUFFLG9CQUFvQixVQUFTSSxHQUFFLFFBQU8sQ0FBQztBQUFBLE1BQUMsRUFBRSxHQUFFUSxNQUFHSixHQUFFLG9CQUFvQixVQUFTSixHQUFFLFFBQU8sQ0FBQztBQUFBLElBQUM7QUFBQSxFQUFDLEdBQUUsTUFBSyxDQUFDLEVBQUM7QUFBRSxNQUFJLEtBQUcsRUFBQyxNQUFLLGlCQUFnQixTQUFRLE1BQUcsT0FBTSxRQUFPLElBQUcsU0FBU0osSUFBRTtBQUFDLFFBQUlELEtBQUVDLEdBQUUsT0FBTUcsS0FBRUgsR0FBRTtBQUFLLElBQUFELEdBQUUsY0FBY0ksRUFBQyxJQUFFLEVBQUUsRUFBQyxXQUFVSixHQUFFLE1BQU0sV0FBVSxTQUFRQSxHQUFFLE1BQU0sUUFBTyxVQUFTLFlBQVcsV0FBVUEsR0FBRSxVQUFTLENBQUM7QUFBQSxFQUFDLEdBQUUsTUFBSyxDQUFDLEVBQUMsR0FBRSxLQUFHLEVBQUMsS0FBSSxRQUFPLE9BQU0sUUFBTyxRQUFPLFFBQU8sTUFBSyxPQUFNO0FBQUUsV0FBUyxHQUFHQyxJQUFFO0FBQUMsUUFBSUcsSUFBRUMsS0FBRUosR0FBRSxRQUFPSyxLQUFFTCxHQUFFLFlBQVdDLEtBQUVELEdBQUUsV0FBVU0sS0FBRU4sR0FBRSxXQUFVWSxLQUFFWixHQUFFLFNBQVFRLEtBQUVSLEdBQUUsVUFBU2EsS0FBRWIsR0FBRSxpQkFBZ0JXLEtBQUVYLEdBQUUsVUFBU08sS0FBRVAsR0FBRSxjQUFhUyxLQUFFVCxHQUFFLFNBQVFlLEtBQUVILEdBQUUsR0FBRUksS0FBRSxXQUFTRCxLQUFFLElBQUVBLElBQUVFLEtBQUVMLEdBQUUsR0FBRU0sS0FBRSxXQUFTRCxLQUFFLElBQUVBLElBQUVFLEtBQUUsY0FBWSxPQUFPWixLQUFFQSxHQUFFLEVBQUMsR0FBRVMsSUFBRSxHQUFFRSxHQUFDLENBQUMsSUFBRSxFQUFDLEdBQUVGLElBQUUsR0FBRUUsR0FBQztBQUFFLElBQUFGLEtBQUVHLEdBQUUsR0FBRUQsS0FBRUMsR0FBRTtBQUFFLFFBQUlDLEtBQUVSLEdBQUUsZUFBZSxHQUFHLEdBQUVTLEtBQUVULEdBQUUsZUFBZSxHQUFHLEdBQUVVLEtBQUUsR0FBRUcsS0FBRSxHQUFFTSxLQUFFO0FBQU8sUUFBR3BCLElBQUU7QUFBQyxVQUFJZSxLQUFFLEVBQUV0QixFQUFDLEdBQUU0QixLQUFFLGdCQUFlQyxLQUFFO0FBQWMsVUFBR1AsT0FBSSxFQUFFdEIsRUFBQyxLQUFHLGFBQVcsRUFBRXNCLEtBQUUsRUFBRXRCLEVBQUMsQ0FBQyxFQUFFLFlBQVUsZUFBYUksT0FBSXdCLEtBQUUsZ0JBQWVDLEtBQUUsZ0JBQWVQLEtBQUVBLElBQUV6QixPQUFJLE1BQUlBLE9BQUksS0FBR0EsT0FBSSxNQUFJSyxPQUFJLEVBQUUsQ0FBQW1CLEtBQUUsR0FBRVAsT0FBSVQsTUFBR2lCLE9BQUlLLE1BQUdBLEdBQUUsaUJBQWVBLEdBQUUsZUFBZSxTQUFPTCxHQUFFTSxFQUFDLEtBQUczQixHQUFFLFFBQU9hLE1BQUdMLEtBQUUsSUFBRTtBQUFHLFVBQUdaLE9BQUksTUFBSUEsT0FBSSxLQUFHQSxPQUFJLE1BQUlLLE9BQUksRUFBRSxDQUFBZ0IsS0FBRSxHQUFFTixPQUFJUCxNQUFHaUIsT0FBSUssTUFBR0EsR0FBRSxpQkFBZUEsR0FBRSxlQUFlLFFBQU1MLEdBQUVPLEVBQUMsS0FBRzVCLEdBQUUsT0FBTVcsTUFBR0gsS0FBRSxJQUFFO0FBQUEsSUFBRTtBQUFDLFFBQUllLElBQUVDLEtBQUUsT0FBTyxPQUFPLEVBQUMsVUFBU3JCLEdBQUMsR0FBRUcsTUFBRyxFQUFFLEdBQUVtQixLQUFFLFNBQUt2QixNQUFFLFNBQVNQLElBQUVELElBQUU7QUFBQyxVQUFJSSxLQUFFSCxHQUFFLEdBQUVJLEtBQUVKLEdBQUUsR0FBRUssS0FBRU4sR0FBRSxvQkFBa0I7QUFBRSxhQUFNLEVBQUMsR0FBRSxFQUFFSSxLQUFFRSxFQUFDLElBQUVBLE1BQUcsR0FBRSxHQUFFLEVBQUVELEtBQUVDLEVBQUMsSUFBRUEsTUFBRyxFQUFDO0FBQUEsSUFBQyxHQUFFLEVBQUMsR0FBRVcsSUFBRSxHQUFFRSxHQUFDLEdBQUUsRUFBRWQsRUFBQyxDQUFDLElBQUUsRUFBQyxHQUFFWSxJQUFFLEdBQUVFLEdBQUM7QUFBRSxXQUFPRixLQUFFYyxHQUFFLEdBQUVaLEtBQUVZLEdBQUUsR0FBRWpCLEtBQUUsT0FBTyxPQUFPLENBQUMsR0FBRWdCLE1BQUlELEtBQUUsQ0FBQyxHQUFHSCxFQUFDLElBQUVKLEtBQUUsTUFBSSxJQUFHTyxHQUFFTixFQUFDLElBQUVGLEtBQUUsTUFBSSxJQUFHUSxHQUFFLGFBQVdHLEdBQUUsb0JBQWtCLE1BQUksSUFBRSxlQUFhZixLQUFFLFNBQU9FLEtBQUUsUUFBTSxpQkFBZUYsS0FBRSxTQUFPRSxLQUFFLFVBQVNVLEdBQUUsSUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFQyxNQUFJMUIsS0FBRSxDQUFDLEdBQUdzQixFQUFDLElBQUVKLEtBQUVILEtBQUUsT0FBSyxJQUFHZixHQUFFbUIsRUFBQyxJQUFFRixLQUFFSixLQUFFLE9BQUssSUFBR2IsR0FBRSxZQUFVLElBQUdBLEdBQUU7QUFBQSxFQUFDO0FBQUMsTUFBSSxLQUFHLEVBQUMsTUFBSyxpQkFBZ0IsU0FBUSxNQUFHLE9BQU0sZUFBYyxJQUFHLFNBQVNILElBQUU7QUFBQyxRQUFJRCxLQUFFQyxHQUFFLE9BQU1HLEtBQUVILEdBQUUsU0FBUUksS0FBRUQsR0FBRSxpQkFBZ0JFLEtBQUUsV0FBU0QsTUFBR0EsSUFBRUgsS0FBRUUsR0FBRSxVQUFTRyxLQUFFLFdBQVNMLE1BQUdBLElBQUVDLEtBQUVDLEdBQUUsY0FBYVMsS0FBRSxXQUFTVixNQUFHQSxJQUFFTSxLQUFFLEVBQUMsV0FBVSxFQUFFVCxHQUFFLFNBQVMsR0FBRSxXQUFVLEVBQUVBLEdBQUUsU0FBUyxHQUFFLFFBQU9BLEdBQUUsU0FBUyxRQUFPLFlBQVdBLEdBQUUsTUFBTSxRQUFPLGlCQUFnQk0sSUFBRSxTQUFRLFlBQVVOLEdBQUUsUUFBUSxTQUFRO0FBQUUsWUFBTUEsR0FBRSxjQUFjLGtCQUFnQkEsR0FBRSxPQUFPLFNBQU8sT0FBTyxPQUFPLENBQUMsR0FBRUEsR0FBRSxPQUFPLFFBQU8sR0FBRyxPQUFPLE9BQU8sQ0FBQyxHQUFFUyxJQUFFLEVBQUMsU0FBUVQsR0FBRSxjQUFjLGVBQWMsVUFBU0EsR0FBRSxRQUFRLFVBQVMsVUFBU08sSUFBRSxjQUFhTSxHQUFDLENBQUMsQ0FBQyxDQUFDLElBQUcsUUFBTWIsR0FBRSxjQUFjLFVBQVFBLEdBQUUsT0FBTyxRQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUVBLEdBQUUsT0FBTyxPQUFNLEdBQUcsT0FBTyxPQUFPLENBQUMsR0FBRVMsSUFBRSxFQUFDLFNBQVFULEdBQUUsY0FBYyxPQUFNLFVBQVMsWUFBVyxVQUFTLE9BQUcsY0FBYWEsR0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFHYixHQUFFLFdBQVcsU0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFFQSxHQUFFLFdBQVcsUUFBTyxFQUFDLHlCQUF3QkEsR0FBRSxVQUFTLENBQUM7QUFBQSxFQUFDLEdBQUUsTUFBSyxDQUFDLEVBQUM7QUFBRSxNQUFJLEtBQUcsRUFBQyxNQUFLLGVBQWMsU0FBUSxNQUFHLE9BQU0sU0FBUSxJQUFHLFNBQVNDLElBQUU7QUFBQyxRQUFJRCxLQUFFQyxHQUFFO0FBQU0sV0FBTyxLQUFLRCxHQUFFLFFBQVEsRUFBRSxTQUFTLFNBQVNDLElBQUU7QUFBQyxVQUFJRyxLQUFFSixHQUFFLE9BQU9DLEVBQUMsS0FBRyxDQUFDLEdBQUVLLEtBQUVOLEdBQUUsV0FBV0MsRUFBQyxLQUFHLENBQUMsR0FBRUMsS0FBRUYsR0FBRSxTQUFTQyxFQUFDO0FBQUUsUUFBRUMsRUFBQyxLQUFHLEVBQUVBLEVBQUMsTUFBSSxPQUFPLE9BQU9BLEdBQUUsT0FBTUUsRUFBQyxHQUFFLE9BQU8sS0FBS0UsRUFBQyxFQUFFLFNBQVMsU0FBU0wsSUFBRTtBQUFDLFlBQUlELEtBQUVNLEdBQUVMLEVBQUM7QUFBRSxrQkFBS0QsS0FBRUUsR0FBRSxnQkFBZ0JELEVBQUMsSUFBRUMsR0FBRSxhQUFhRCxJQUFFLFNBQUtELEtBQUUsS0FBR0EsRUFBQztBQUFBLE1BQUMsRUFBRTtBQUFBLElBQUUsRUFBRTtBQUFBLEVBQUMsR0FBRSxRQUFPLFNBQVNDLElBQUU7QUFBQyxRQUFJRCxLQUFFQyxHQUFFLE9BQU1HLEtBQUUsRUFBQyxRQUFPLEVBQUMsVUFBU0osR0FBRSxRQUFRLFVBQVMsTUFBSyxLQUFJLEtBQUksS0FBSSxRQUFPLElBQUcsR0FBRSxPQUFNLEVBQUMsVUFBUyxXQUFVLEdBQUUsV0FBVSxDQUFDLEVBQUM7QUFBRSxXQUFPLE9BQU8sT0FBT0EsR0FBRSxTQUFTLE9BQU8sT0FBTUksR0FBRSxNQUFNLEdBQUVKLEdBQUUsU0FBT0ksSUFBRUosR0FBRSxTQUFTLFNBQU8sT0FBTyxPQUFPQSxHQUFFLFNBQVMsTUFBTSxPQUFNSSxHQUFFLEtBQUssR0FBRSxXQUFVO0FBQUMsYUFBTyxLQUFLSixHQUFFLFFBQVEsRUFBRSxTQUFTLFNBQVNDLElBQUU7QUFBQyxZQUFJSyxLQUFFTixHQUFFLFNBQVNDLEVBQUMsR0FBRUMsS0FBRUYsR0FBRSxXQUFXQyxFQUFDLEtBQUcsQ0FBQyxHQUFFTSxLQUFFLE9BQU8sS0FBS1AsR0FBRSxPQUFPLGVBQWVDLEVBQUMsSUFBRUQsR0FBRSxPQUFPQyxFQUFDLElBQUVHLEdBQUVILEVBQUMsQ0FBQyxFQUFFLFFBQVEsU0FBU0EsSUFBRUQsSUFBRTtBQUFDLGlCQUFPQyxHQUFFRCxFQUFDLElBQUUsSUFBR0M7QUFBQSxRQUFDLElBQUcsQ0FBQyxDQUFDO0FBQUUsVUFBRUssRUFBQyxLQUFHLEVBQUVBLEVBQUMsTUFBSSxPQUFPLE9BQU9BLEdBQUUsT0FBTUMsRUFBQyxHQUFFLE9BQU8sS0FBS0wsRUFBQyxFQUFFLFNBQVMsU0FBU0QsSUFBRTtBQUFDLFVBQUFLLEdBQUUsZ0JBQWdCTCxFQUFDO0FBQUEsUUFBQyxFQUFFO0FBQUEsTUFBRSxFQUFFO0FBQUEsSUFBQztBQUFBLEVBQUMsR0FBRSxVQUFTLENBQUMsZUFBZSxFQUFDO0FBQUUsTUFBSSxLQUFHLEVBQUMsTUFBSyxVQUFTLFNBQVEsTUFBRyxPQUFNLFFBQU8sVUFBUyxDQUFDLGVBQWUsR0FBRSxJQUFHLFNBQVNBLElBQUU7QUFBQyxRQUFJRCxLQUFFQyxHQUFFLE9BQU1HLEtBQUVILEdBQUUsU0FBUUksS0FBRUosR0FBRSxNQUFLSyxLQUFFRixHQUFFLFFBQU9GLEtBQUUsV0FBU0ksS0FBRSxDQUFDLEdBQUUsQ0FBQyxJQUFFQSxJQUFFQyxLQUFFLEVBQUUsUUFBUSxTQUFTTixJQUFFRyxJQUFFO0FBQUMsYUFBT0gsR0FBRUcsRUFBQyxLQUFFLFNBQVNILElBQUVELElBQUVJLElBQUU7QUFBQyxZQUFJQyxLQUFFLEVBQUVKLEVBQUMsR0FBRUssS0FBRSxDQUFDLEdBQUUsQ0FBQyxFQUFFLFFBQVFELEVBQUMsS0FBRyxJQUFFLEtBQUcsR0FBRUgsS0FBRSxjQUFZLE9BQU9FLEtBQUVBLEdBQUUsT0FBTyxPQUFPLENBQUMsR0FBRUosSUFBRSxFQUFDLFdBQVVDLEdBQUMsQ0FBQyxDQUFDLElBQUVHLElBQUVHLEtBQUVMLEdBQUUsQ0FBQyxHQUFFQyxLQUFFRCxHQUFFLENBQUM7QUFBRSxlQUFPSyxLQUFFQSxNQUFHLEdBQUVKLE1BQUdBLE1BQUcsS0FBR0csSUFBRSxDQUFDLEdBQUUsQ0FBQyxFQUFFLFFBQVFELEVBQUMsS0FBRyxJQUFFLEVBQUMsR0FBRUYsSUFBRSxHQUFFSSxHQUFDLElBQUUsRUFBQyxHQUFFQSxJQUFFLEdBQUVKLEdBQUM7QUFBQSxNQUFDLEdBQUVDLElBQUVKLEdBQUUsT0FBTUUsRUFBQyxHQUFFRDtBQUFBLElBQUMsSUFBRyxDQUFDLENBQUMsR0FBRUUsS0FBRUksR0FBRVAsR0FBRSxTQUFTLEdBQUVhLEtBQUVWLEdBQUUsR0FBRU0sS0FBRU4sR0FBRTtBQUFFLFlBQU1ILEdBQUUsY0FBYyxrQkFBZ0JBLEdBQUUsY0FBYyxjQUFjLEtBQUdhLElBQUViLEdBQUUsY0FBYyxjQUFjLEtBQUdTLEtBQUdULEdBQUUsY0FBY0ssRUFBQyxJQUFFRTtBQUFBLEVBQUMsRUFBQyxHQUFFLEtBQUcsRUFBQyxNQUFLLFNBQVEsT0FBTSxRQUFPLFFBQU8sT0FBTSxLQUFJLFNBQVE7QUFBRSxXQUFTLEdBQUdOLElBQUU7QUFBQyxXQUFPQSxHQUFFLFFBQVEsMkJBQTBCLFNBQVNBLElBQUU7QUFBQyxhQUFPLEdBQUdBLEVBQUM7QUFBQSxJQUFDLEVBQUU7QUFBQSxFQUFDO0FBQUMsTUFBSSxLQUFHLEVBQUMsT0FBTSxPQUFNLEtBQUksUUFBTztBQUFFLFdBQVMsR0FBR0EsSUFBRTtBQUFDLFdBQU9BLEdBQUUsUUFBUSxlQUFjLFNBQVNBLElBQUU7QUFBQyxhQUFPLEdBQUdBLEVBQUM7QUFBQSxJQUFDLEVBQUU7QUFBQSxFQUFDO0FBQUMsV0FBUyxHQUFHQSxJQUFFRCxJQUFFO0FBQUMsZUFBU0EsT0FBSUEsS0FBRSxDQUFDO0FBQUcsUUFBSUksS0FBRUosSUFBRUssS0FBRUQsR0FBRSxXQUFVRSxLQUFFRixHQUFFLFVBQVNGLEtBQUVFLEdBQUUsY0FBYUcsS0FBRUgsR0FBRSxTQUFRRCxLQUFFQyxHQUFFLGdCQUFlUyxLQUFFVCxHQUFFLHVCQUFzQkssS0FBRSxXQUFTSSxLQUFFLElBQUVBLElBQUVDLEtBQUUsRUFBRVQsRUFBQyxHQUFFTyxLQUFFRSxLQUFFWCxLQUFFLElBQUUsRUFBRSxRQUFRLFNBQVNGLElBQUU7QUFBQyxhQUFPLEVBQUVBLEVBQUMsTUFBSWE7QUFBQSxJQUFDLEVBQUUsSUFBRSxHQUFFTixLQUFFSSxHQUFFLFFBQVEsU0FBU1gsSUFBRTtBQUFDLGFBQU9RLEdBQUUsUUFBUVIsRUFBQyxLQUFHO0FBQUEsSUFBQyxFQUFFO0FBQUUsVUFBSU8sR0FBRSxXQUFTQSxLQUFFSTtBQUFHLFFBQUlELEtBQUVILEdBQUUsUUFBUSxTQUFTUixJQUFFSSxJQUFFO0FBQUMsYUFBT0osR0FBRUksRUFBQyxJQUFFLEVBQUVILElBQUUsRUFBQyxXQUFVRyxJQUFFLFVBQVNFLElBQUUsY0FBYUosSUFBRSxTQUFRSyxHQUFDLENBQUMsRUFBRSxFQUFFSCxFQUFDLENBQUMsR0FBRUo7QUFBQSxJQUFDLElBQUcsQ0FBQyxDQUFDO0FBQUUsV0FBTyxPQUFPLEtBQUtXLEVBQUMsRUFBRSxNQUFNLFNBQVNWLElBQUVELElBQUU7QUFBQyxhQUFPVyxHQUFFVixFQUFDLElBQUVVLEdBQUVYLEVBQUM7QUFBQSxJQUFDLEVBQUU7QUFBQSxFQUFDO0FBQUMsTUFBSSxLQUFHLEVBQUMsTUFBSyxRQUFPLFNBQVEsTUFBRyxPQUFNLFFBQU8sSUFBRyxTQUFTQyxJQUFFO0FBQUMsUUFBSUQsS0FBRUMsR0FBRSxPQUFNRyxLQUFFSCxHQUFFLFNBQVFJLEtBQUVKLEdBQUU7QUFBSyxRQUFHLENBQUNELEdBQUUsY0FBY0ssRUFBQyxFQUFFLE9BQU07QUFBQyxlQUFRQyxLQUFFRixHQUFFLFVBQVNGLEtBQUUsV0FBU0ksTUFBR0EsSUFBRUMsS0FBRUgsR0FBRSxTQUFRRCxLQUFFLFdBQVNJLE1BQUdBLElBQUVNLEtBQUVULEdBQUUsb0JBQW1CSyxLQUFFTCxHQUFFLFNBQVFVLEtBQUVWLEdBQUUsVUFBU1EsS0FBRVIsR0FBRSxjQUFhSSxLQUFFSixHQUFFLGFBQVlPLEtBQUVQLEdBQUUsZ0JBQWVNLEtBQUUsV0FBU0MsTUFBR0EsSUFBRUksS0FBRVgsR0FBRSx1QkFBc0JZLEtBQUVoQixHQUFFLFFBQVEsV0FBVWlCLEtBQUUsRUFBRUQsRUFBQyxHQUFFRSxLQUFFTCxPQUFJSSxPQUFJRCxNQUFHLENBQUNOLEtBQUUsQ0FBQyxHQUFHTSxFQUFDLENBQUMsS0FBRSxTQUFTZixJQUFFO0FBQUMsWUFBRyxFQUFFQSxFQUFDLE1BQUksRUFBRSxRQUFNLENBQUM7QUFBRSxZQUFJRCxLQUFFLEdBQUdDLEVBQUM7QUFBRSxlQUFNLENBQUMsR0FBR0EsRUFBQyxHQUFFRCxJQUFFLEdBQUdBLEVBQUMsQ0FBQztBQUFBLE1BQUMsR0FBRWdCLEVBQUMsSUFBR0csS0FBRSxDQUFDSCxFQUFDLEVBQUUsT0FBT0UsRUFBQyxFQUFFLFFBQVEsU0FBU2pCLElBQUVHLElBQUU7QUFBQyxlQUFPSCxHQUFFLE9BQU8sRUFBRUcsRUFBQyxNQUFJLElBQUUsR0FBR0osSUFBRSxFQUFDLFdBQVVJLElBQUUsVUFBU1UsSUFBRSxjQUFhRixJQUFFLFNBQVFILElBQUUsZ0JBQWVDLElBQUUsdUJBQXNCSyxHQUFDLENBQUMsSUFBRVgsRUFBQztBQUFBLE1BQUMsSUFBRyxDQUFDLENBQUMsR0FBRWdCLEtBQUVwQixHQUFFLE1BQU0sV0FBVXFCLEtBQUVyQixHQUFFLE1BQU0sUUFBT3NCLEtBQUUsb0JBQUksT0FBSUMsS0FBRSxNQUFHQyxLQUFFTCxHQUFFLENBQUMsR0FBRWEsS0FBRSxHQUFFQSxLQUFFYixHQUFFLFFBQU9hLE1BQUk7QUFBQyxZQUFJSixLQUFFVCxHQUFFYSxFQUFDLEdBQUVDLEtBQUUsRUFBRUwsRUFBQyxHQUFFTSxLQUFFLEVBQUVOLEVBQUMsTUFBSSxHQUFFQyxLQUFFLENBQUMsR0FBRSxDQUFDLEVBQUUsUUFBUUksRUFBQyxLQUFHLEdBQUVILEtBQUVELEtBQUUsVUFBUSxVQUFTRSxLQUFFLEVBQUUvQixJQUFFLEVBQUMsV0FBVTRCLElBQUUsVUFBU2QsSUFBRSxjQUFhRixJQUFFLGFBQVlKLElBQUUsU0FBUUMsR0FBQyxDQUFDLEdBQUUwQixLQUFFTixLQUFFSyxLQUFFLElBQUUsSUFBRUEsS0FBRSxJQUFFO0FBQUUsUUFBQWQsR0FBRVUsRUFBQyxJQUFFVCxHQUFFUyxFQUFDLE1BQUlLLEtBQUUsR0FBR0EsRUFBQztBQUFHLFlBQUlDLEtBQUUsR0FBR0QsRUFBQyxHQUFFRSxLQUFFLENBQUM7QUFBRSxZQUFHbkMsTUFBR21DLEdBQUUsS0FBS04sR0FBRUUsRUFBQyxLQUFHLENBQUMsR0FBRTlCLE1BQUdrQyxHQUFFLEtBQUtOLEdBQUVJLEVBQUMsS0FBRyxHQUFFSixHQUFFSyxFQUFDLEtBQUcsQ0FBQyxHQUFFQyxHQUFFLE9BQU8sU0FBU3BDLElBQUU7QUFBQyxpQkFBT0E7QUFBQSxRQUFDLEVBQUUsR0FBRTtBQUFDLFVBQUF1QixLQUFFSSxJQUFFTCxLQUFFO0FBQUc7QUFBQSxRQUFLO0FBQUMsUUFBQUQsR0FBRSxJQUFJTSxJQUFFUyxFQUFDO0FBQUEsTUFBQztBQUFDLFVBQUdkLEdBQUUsVUFBUWUsS0FBRSxTQUFTckMsSUFBRTtBQUFDLFlBQUlELEtBQUVtQixHQUFFLE1BQU0sU0FBU25CLElBQUU7QUFBQyxjQUFJSSxLQUFFa0IsR0FBRSxJQUFJdEIsRUFBQztBQUFFLGNBQUdJLEdBQUUsUUFBT0EsR0FBRSxNQUFNLEdBQUVILEVBQUMsRUFBRSxPQUFPLFNBQVNBLElBQUU7QUFBQyxtQkFBT0E7QUFBQSxVQUFDLEVBQUU7QUFBQSxRQUFDLEVBQUU7QUFBRSxZQUFHRCxHQUFFLFFBQU93QixLQUFFeEIsSUFBRTtBQUFBLE1BQU8sR0FBRXVDLEtBQUU3QixLQUFFLElBQUUsR0FBRTZCLEtBQUUsR0FBRUEsTUFBSTtBQUFDLFlBQUcsWUFBVUQsR0FBRUMsRUFBQyxFQUFFO0FBQUEsTUFBSztBQUFDLE1BQUF2QyxHQUFFLGNBQVl3QixPQUFJeEIsR0FBRSxjQUFjSyxFQUFDLEVBQUUsUUFBTSxNQUFHTCxHQUFFLFlBQVV3QixJQUFFeEIsR0FBRSxRQUFNO0FBQUEsSUFBRztBQUFBLEVBQUMsR0FBRSxrQkFBaUIsQ0FBQyxRQUFRLEdBQUUsTUFBSyxFQUFDLE9BQU0sTUFBRSxFQUFDO0FBQUUsV0FBUyxHQUFHQyxJQUFFRCxJQUFFSSxJQUFFO0FBQUMsV0FBTyxFQUFFSCxJQUFFLEVBQUVELElBQUVJLEVBQUMsQ0FBQztBQUFBLEVBQUM7QUFBQyxNQUFJLEtBQUcsRUFBQyxNQUFLLG1CQUFrQixTQUFRLE1BQUcsT0FBTSxRQUFPLElBQUcsU0FBU0gsSUFBRTtBQUFDLFFBQUlELEtBQUVDLEdBQUUsT0FBTUcsS0FBRUgsR0FBRSxTQUFRSSxLQUFFSixHQUFFLE1BQUtLLEtBQUVGLEdBQUUsVUFBU0QsS0FBRSxXQUFTRyxNQUFHQSxJQUFFTyxLQUFFVCxHQUFFLFNBQVFLLEtBQUUsV0FBU0ksTUFBR0EsSUFBRUMsS0FBRVYsR0FBRSxVQUFTUSxLQUFFUixHQUFFLGNBQWFJLEtBQUVKLEdBQUUsYUFBWU8sS0FBRVAsR0FBRSxTQUFRTSxLQUFFTixHQUFFLFFBQU9XLEtBQUUsV0FBU0wsTUFBR0EsSUFBRU0sS0FBRVosR0FBRSxjQUFhYSxLQUFFLFdBQVNELEtBQUUsSUFBRUEsSUFBRUcsS0FBRSxFQUFFbkIsSUFBRSxFQUFDLFVBQVNjLElBQUUsY0FBYUYsSUFBRSxTQUFRRCxJQUFFLGFBQVlILEdBQUMsQ0FBQyxHQUFFWSxLQUFFLEVBQUVwQixHQUFFLFNBQVMsR0FBRXFCLEtBQUUsRUFBRXJCLEdBQUUsU0FBUyxHQUFFc0IsS0FBRSxDQUFDRCxJQUFFRSxLQUFFLEVBQUVILEVBQUMsR0FBRU0sS0FBRSxRQUFNSCxLQUFFLE1BQUksS0FBSVMsS0FBRWhDLEdBQUUsY0FBYyxlQUFjNEIsS0FBRTVCLEdBQUUsTUFBTSxXQUFVaUMsS0FBRWpDLEdBQUUsTUFBTSxRQUFPa0MsS0FBRSxjQUFZLE9BQU9qQixLQUFFQSxHQUFFLE9BQU8sT0FBTyxDQUFDLEdBQUVqQixHQUFFLE9BQU0sRUFBQyxXQUFVQSxHQUFFLFVBQVMsQ0FBQyxDQUFDLElBQUVpQixJQUFFWSxLQUFFLFlBQVUsT0FBT0ssS0FBRSxFQUFDLFVBQVNBLElBQUUsU0FBUUEsR0FBQyxJQUFFLE9BQU8sT0FBTyxFQUFDLFVBQVMsR0FBRSxTQUFRLEVBQUMsR0FBRUEsRUFBQyxHQUFFSixLQUFFOUIsR0FBRSxjQUFjLFNBQU9BLEdBQUUsY0FBYyxPQUFPQSxHQUFFLFNBQVMsSUFBRSxNQUFLK0IsS0FBRSxFQUFDLEdBQUUsR0FBRSxHQUFFLEVBQUM7QUFBRSxRQUFHQyxJQUFFO0FBQUMsVUFBRzdCLElBQUU7QUFBQyxZQUFJZ0MsSUFBRUMsS0FBRSxRQUFNYixLQUFFLElBQUUsR0FBRWMsS0FBRSxRQUFNZCxLQUFFLElBQUUsR0FBRWUsS0FBRSxRQUFNZixLQUFFLFdBQVMsU0FBUWdCLEtBQUVQLEdBQUVULEVBQUMsR0FBRWlCLEtBQUVELEtBQUVwQixHQUFFaUIsRUFBQyxHQUFFSyxLQUFFRixLQUFFcEIsR0FBRWtCLEVBQUMsR0FBRUssS0FBRTNCLEtBQUUsQ0FBQ2tCLEdBQUVLLEVBQUMsSUFBRSxJQUFFLEdBQUVLLEtBQUV0QixPQUFJLElBQUVPLEdBQUVVLEVBQUMsSUFBRUwsR0FBRUssRUFBQyxHQUFFTSxLQUFFdkIsT0FBSSxJQUFFLENBQUNZLEdBQUVLLEVBQUMsSUFBRSxDQUFDVixHQUFFVSxFQUFDLEdBQUVPLEtBQUU3QyxHQUFFLFNBQVMsT0FBTThDLEtBQUUvQixNQUFHOEIsS0FBRSxFQUFFQSxFQUFDLElBQUUsRUFBQyxPQUFNLEdBQUUsUUFBTyxFQUFDLEdBQUVFLE1BQUcvQyxHQUFFLGNBQWMsa0JBQWtCLElBQUVBLEdBQUUsY0FBYyxrQkFBa0IsRUFBRSxVQUFRLEVBQUMsS0FBSSxHQUFFLE9BQU0sR0FBRSxRQUFPLEdBQUUsTUFBSyxFQUFDLEdBQUVnRCxNQUFHRCxJQUFHWCxFQUFDLEdBQUVhLE1BQUdGLElBQUdWLEVBQUMsR0FBRWEsTUFBRyxHQUFHLEdBQUV0QixHQUFFVSxFQUFDLEdBQUVRLEdBQUVSLEVBQUMsQ0FBQyxHQUFFYSxNQUFHN0IsS0FBRU0sR0FBRVUsRUFBQyxJQUFFLElBQUVJLEtBQUVRLE1BQUdGLE1BQUduQixHQUFFLFdBQVNjLEtBQUVPLE1BQUdGLE1BQUduQixHQUFFLFVBQVN1QixNQUFHOUIsS0FBRSxDQUFDTSxHQUFFVSxFQUFDLElBQUUsSUFBRUksS0FBRVEsTUFBR0QsTUFBR3BCLEdBQUUsV0FBU2UsS0FBRU0sTUFBR0QsTUFBR3BCLEdBQUUsVUFBU3dCLE1BQUdyRCxHQUFFLFNBQVMsU0FBTyxFQUFFQSxHQUFFLFNBQVMsS0FBSyxHQUFFc0QsTUFBR0QsTUFBRyxRQUFNOUIsS0FBRThCLElBQUcsYUFBVyxJQUFFQSxJQUFHLGNBQVksSUFBRSxHQUFFRSxNQUFHLFNBQU9wQixLQUFFLFFBQU1MLEtBQUUsU0FBT0EsR0FBRVAsRUFBQyxLQUFHWSxLQUFFLEdBQUVxQixNQUFHakIsS0FBRWEsTUFBR0csS0FBR0UsTUFBRyxHQUFHMUMsS0FBRSxFQUFFeUIsSUFBRUQsS0FBRVksTUFBR0ksTUFBR0QsR0FBRSxJQUFFZCxJQUFFRCxJQUFFeEIsS0FBRSxFQUFFMEIsSUFBRWUsR0FBRSxJQUFFZixFQUFDO0FBQUUsUUFBQVQsR0FBRVQsRUFBQyxJQUFFa0MsS0FBRzFCLEdBQUVSLEVBQUMsSUFBRWtDLE1BQUdsQjtBQUFBLE1BQUM7QUFBQyxVQUFHOUIsSUFBRTtBQUFDLFlBQUlpRCxLQUFHQyxNQUFHLFFBQU1wQyxLQUFFLElBQUUsR0FBRXFDLE1BQUcsUUFBTXJDLEtBQUUsSUFBRSxHQUFFc0MsTUFBRzdCLEdBQUVOLEVBQUMsR0FBRW9DLE1BQUcsUUFBTXBDLEtBQUUsV0FBUyxTQUFRcUMsTUFBR0YsTUFBRzFDLEdBQUV3QyxHQUFFLEdBQUVLLE1BQUdILE1BQUcxQyxHQUFFeUMsR0FBRSxHQUFFSyxNQUFHLE9BQUssQ0FBQyxHQUFFLENBQUMsRUFBRSxRQUFRN0MsRUFBQyxHQUFFOEMsTUFBRyxTQUFPUixNQUFHLFFBQU01QixLQUFFLFNBQU9BLEdBQUVKLEVBQUMsS0FBR2dDLE1BQUcsR0FBRVMsTUFBR0YsTUFBR0YsTUFBR0YsTUFBR2pDLEdBQUVrQyxHQUFFLElBQUU3QixHQUFFNkIsR0FBRSxJQUFFSSxNQUFHckMsR0FBRSxTQUFRLEtBQUdvQyxNQUFHSixNQUFHakMsR0FBRWtDLEdBQUUsSUFBRTdCLEdBQUU2QixHQUFFLElBQUVJLE1BQUdyQyxHQUFFLFVBQVFtQyxLQUFHLEtBQUdqRCxNQUFHa0QsT0FBRyxTQUFTaEUsSUFBRUQsSUFBRUksSUFBRTtBQUFDLGNBQUlDLEtBQUUsR0FBR0osSUFBRUQsSUFBRUksRUFBQztBQUFFLGlCQUFPQyxLQUFFRCxLQUFFQSxLQUFFQztBQUFBLFFBQUMsR0FBRThELEtBQUdOLEtBQUcsRUFBRSxJQUFFLEdBQUc5QyxLQUFFb0QsTUFBR0osS0FBR0YsS0FBRzlDLEtBQUUsS0FBR2lELEdBQUU7QUFBRSxRQUFBaEMsR0FBRU4sRUFBQyxJQUFFLElBQUdLLEdBQUVMLEVBQUMsSUFBRSxLQUFHbUM7QUFBQSxNQUFFO0FBQUMsTUFBQTdELEdBQUUsY0FBY0ssRUFBQyxJQUFFMEI7QUFBQSxJQUFDO0FBQUEsRUFBQyxHQUFFLGtCQUFpQixDQUFDLFFBQVEsRUFBQztBQUFFLE1BQUksS0FBRyxFQUFDLE1BQUssU0FBUSxTQUFRLE1BQUcsT0FBTSxRQUFPLElBQUcsU0FBUzlCLElBQUU7QUFBQyxRQUFJRCxJQUFFSSxLQUFFSCxHQUFFLE9BQU1JLEtBQUVKLEdBQUUsTUFBS0ssS0FBRUwsR0FBRSxTQUFRQyxLQUFFRSxHQUFFLFNBQVMsT0FBTUcsS0FBRUgsR0FBRSxjQUFjLGVBQWNELEtBQUUsRUFBRUMsR0FBRSxTQUFTLEdBQUVTLEtBQUUsRUFBRVYsRUFBQyxHQUFFTSxLQUFFLENBQUMsR0FBRSxDQUFDLEVBQUUsUUFBUU4sRUFBQyxLQUFHLElBQUUsV0FBUztBQUFRLFFBQUdELE1BQUdLLElBQUU7QUFBQyxVQUFJTyxNQUFFLFNBQVNiLElBQUVELElBQUU7QUFBQyxlQUFPLEVBQUUsWUFBVSxRQUFPQyxLQUFFLGNBQVksT0FBT0EsS0FBRUEsR0FBRSxPQUFPLE9BQU8sQ0FBQyxHQUFFRCxHQUFFLE9BQU0sRUFBQyxXQUFVQSxHQUFFLFVBQVMsQ0FBQyxDQUFDLElBQUVDLE1BQUdBLEtBQUUsRUFBRUEsSUFBRSxDQUFDLENBQUM7QUFBQSxNQUFDLEdBQUVLLEdBQUUsU0FBUUYsRUFBQyxHQUFFUSxLQUFFLEVBQUVWLEVBQUMsR0FBRU0sS0FBRSxRQUFNSyxLQUFFLElBQUUsR0FBRUYsS0FBRSxRQUFNRSxLQUFFLElBQUUsR0FBRUgsS0FBRU4sR0FBRSxNQUFNLFVBQVVLLEVBQUMsSUFBRUwsR0FBRSxNQUFNLFVBQVVTLEVBQUMsSUFBRU4sR0FBRU0sRUFBQyxJQUFFVCxHQUFFLE1BQU0sT0FBT0ssRUFBQyxHQUFFTSxLQUFFUixHQUFFTSxFQUFDLElBQUVULEdBQUUsTUFBTSxVQUFVUyxFQUFDLEdBQUVHLEtBQUUsRUFBRWQsRUFBQyxHQUFFZSxLQUFFRCxLQUFFLFFBQU1ILEtBQUVHLEdBQUUsZ0JBQWMsSUFBRUEsR0FBRSxlQUFhLElBQUUsR0FBRUcsS0FBRVQsS0FBRSxJQUFFSyxLQUFFLEdBQUVLLEtBQUVOLEdBQUVOLEVBQUMsR0FBRWEsS0FBRUosS0FBRUwsR0FBRUgsRUFBQyxJQUFFSyxHQUFFSCxFQUFDLEdBQUVXLEtBQUVMLEtBQUUsSUFBRUwsR0FBRUgsRUFBQyxJQUFFLElBQUVVLElBQUVJLEtBQUUsR0FBR0gsSUFBRUUsSUFBRUQsRUFBQyxHQUFFSyxLQUFFYjtBQUFFLE1BQUFULEdBQUUsY0FBY0MsRUFBQyxNQUFJTCxLQUFFLENBQUMsR0FBRzBCLEVBQUMsSUFBRUgsSUFBRXZCLEdBQUUsZUFBYXVCLEtBQUVELElBQUV0QjtBQUFBLElBQUU7QUFBQSxFQUFDLEdBQUUsUUFBTyxTQUFTQyxJQUFFO0FBQUMsUUFBSUQsS0FBRUMsR0FBRSxPQUFNRyxLQUFFSCxHQUFFLFFBQVEsU0FBUUksS0FBRSxXQUFTRCxLQUFFLHdCQUFzQkE7QUFBRSxZQUFNQyxPQUFJLFlBQVUsT0FBT0EsT0FBSUEsS0FBRUwsR0FBRSxTQUFTLE9BQU8sY0FBY0ssRUFBQyxPQUFLLEVBQUVMLEdBQUUsU0FBUyxRQUFPSyxFQUFDLE1BQUlMLEdBQUUsU0FBUyxRQUFNSztBQUFBLEVBQUUsR0FBRSxVQUFTLENBQUMsZUFBZSxHQUFFLGtCQUFpQixDQUFDLGlCQUFpQixFQUFDO0FBQUUsV0FBUyxHQUFHSixJQUFFRCxJQUFFSSxJQUFFO0FBQUMsV0FBTyxXQUFTQSxPQUFJQSxLQUFFLEVBQUMsR0FBRSxHQUFFLEdBQUUsRUFBQyxJQUFHLEVBQUMsS0FBSUgsR0FBRSxNQUFJRCxHQUFFLFNBQU9JLEdBQUUsR0FBRSxPQUFNSCxHQUFFLFFBQU1ELEdBQUUsUUFBTUksR0FBRSxHQUFFLFFBQU9ILEdBQUUsU0FBT0QsR0FBRSxTQUFPSSxHQUFFLEdBQUUsTUFBS0gsR0FBRSxPQUFLRCxHQUFFLFFBQU1JLEdBQUUsRUFBQztBQUFBLEVBQUM7QUFBQyxXQUFTLEdBQUdILElBQUU7QUFBQyxXQUFNLENBQUMsR0FBRSxHQUFFLEdBQUUsQ0FBQyxFQUFFLE1BQU0sU0FBU0QsSUFBRTtBQUFDLGFBQU9DLEdBQUVELEVBQUMsS0FBRztBQUFBLElBQUMsRUFBRTtBQUFBLEVBQUM7QUFBQyxNQUFJLEtBQUcsRUFBQyxNQUFLLFFBQU8sU0FBUSxNQUFHLE9BQU0sUUFBTyxrQkFBaUIsQ0FBQyxpQkFBaUIsR0FBRSxJQUFHLFNBQVNDLElBQUU7QUFBQyxRQUFJRCxLQUFFQyxHQUFFLE9BQU1HLEtBQUVILEdBQUUsTUFBS0ksS0FBRUwsR0FBRSxNQUFNLFdBQVVNLEtBQUVOLEdBQUUsTUFBTSxRQUFPRSxLQUFFRixHQUFFLGNBQWMsaUJBQWdCTyxLQUFFLEVBQUVQLElBQUUsRUFBQyxnQkFBZSxZQUFXLENBQUMsR0FBRUcsS0FBRSxFQUFFSCxJQUFFLEVBQUMsYUFBWSxLQUFFLENBQUMsR0FBRWEsS0FBRSxHQUFHTixJQUFFRixFQUFDLEdBQUVJLEtBQUUsR0FBR04sSUFBRUcsSUFBRUosRUFBQyxHQUFFWSxLQUFFLEdBQUdELEVBQUMsR0FBRUQsS0FBRSxHQUFHSCxFQUFDO0FBQUUsSUFBQVQsR0FBRSxjQUFjSSxFQUFDLElBQUUsRUFBQywwQkFBeUJTLElBQUUscUJBQW9CSixJQUFFLG1CQUFrQkssSUFBRSxrQkFBaUJGLEdBQUMsR0FBRVosR0FBRSxXQUFXLFNBQU8sT0FBTyxPQUFPLENBQUMsR0FBRUEsR0FBRSxXQUFXLFFBQU8sRUFBQyxnQ0FBK0JjLElBQUUsdUJBQXNCRixHQUFDLENBQUM7QUFBQSxFQUFDLEVBQUMsR0FBRSxLQUFHLEVBQUUsRUFBQyxrQkFBaUIsQ0FBQyxJQUFHLElBQUcsSUFBRyxFQUFFLEVBQUMsQ0FBQyxHQUFFLEtBQUcsQ0FBQyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsSUFBRyxJQUFHLElBQUcsRUFBRSxHQUFFLEtBQUcsRUFBRSxFQUFDLGtCQUFpQixHQUFFLENBQUM7QUFBRSxJQUFFLGNBQVksSUFBRyxFQUFFLFFBQU0sSUFBRyxFQUFFLGdCQUFjLElBQUcsRUFBRSxlQUFhLElBQUcsRUFBRSxtQkFBaUIsSUFBRyxFQUFFLG1CQUFpQixJQUFHLEVBQUUsaUJBQWUsR0FBRSxFQUFFLGlCQUFlLElBQUcsRUFBRSxPQUFLLElBQUcsRUFBRSxPQUFLLElBQUcsRUFBRSxTQUFPLElBQUcsRUFBRSxrQkFBZ0IsR0FBRSxFQUFFLGdCQUFjLElBQUcsRUFBRSxrQkFBZ0IsSUFBRyxPQUFPLGVBQWUsR0FBRSxjQUFhLEVBQUMsT0FBTSxLQUFFLENBQUM7QUFBQyxFQUFFOyIsIm5hbWVzIjpbInQiLCJlIiwiaSIsInMiLCJuIiwiciIsIm8iLCJhIiwibCIsImMiLCJoIiwiZCIsInUiLCJmIiwicCIsIm0iLCJ2IiwieSIsImciLCJiIiwieCIsInciLCJPIiwiaiIsIkUiLCJQIiwiTSIsIlciLCJCIiwiUiIsIlMiLCJWIiwiayIsIkgiLCJUIiwicSIsIkMiLCJOIiwiSSIsIl8iLCJYIiwiWSIsIkciLCJLIiwiUSIsIloiLCIkIiwiZWUiLCJ0ZSIsIm5lIiwicmUiLCJvZSIsImllIiwiYWUiLCJzZSIsImZlIiwiY2UiLCJwZSIsInVlIiwibGUiLCJoZSIsIm1lIiwidmUiLCJ5ZSIsImdlIiwiYmUiLCJ4ZSIsIndlIl19
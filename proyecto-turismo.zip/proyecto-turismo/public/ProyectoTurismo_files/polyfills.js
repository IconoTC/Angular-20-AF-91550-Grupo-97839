// angular:polyfills:angular:polyfills
import "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/zone__js.js?v=3385e9c1";


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuZ3VsYXI6cG9seWZpbGxzOmFuZ3VsYXI6cG9seWZpbGxzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnem9uZS5qcyc7Il0sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTzsiLCJuYW1lcyI6W119
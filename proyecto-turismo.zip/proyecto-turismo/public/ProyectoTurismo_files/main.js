import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/main.js");// src/main.ts
import { bootstrapApplication } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_platform-browser.js?v=3385e9c1";

// src/app/app.config.ts
import { provideTranslateHttpLoader } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@ngx-translate_http-loader.js?v=3385e9c1";
import { provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { provideRouter } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";

// src/app/components/home/home.ts
import { Component, inject } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";

// src/app/services/servicio-museos.ts
import { Injectable } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i0 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var ServicioMuseos = class _ServicioMuseos {
  museos = [
    { id: 1, nombre: "Museo del Prado", telefono: "913 30 28 00", direccion: "Calle de Ruiz de Alarc\xF3n, 23, 28014 Madrid", horario: "10:00 \u2013 20:00", imagen: "https://upload.wikimedia.org/wikipedia/commons/6/68/Museo_del_Prado_2016_%2825185969599%29.jpg", web: "https://www.museodelprado.es/", coordenadas: [40.4137818, -3.6921271], precio: 15, abierto: true },
    { id: 2, nombre: "Reina Sofia", telefono: "917741000", direccion: "Calle Santa Isabel", horario: "Cierra a las 21:00", imagen: "https://recursos.museoreinasofia.es/styles/large_landscape/public/Visita/sabatini.jpg.webp", web: "http://www.museoreinasofia.es", coordenadas: [40.408644, -3.693992], precio: 15, abierto: true },
    { id: 3, nombre: "Biblioteca Nacional", telefono: " 91 516 89 67 / 91 580 77 59", direccion: "Paseo de Recoletos, 20-22. 28071. Madrid.", horario: "De Martes a Sabado de 10 a 20 h. Domingos de 10 a 14 h.", imagen: "https://patrimonioypaisaje.madrid.es/FWProjects/monumenta/Edificios/25821/04.14-img3C.jpg", web: "museo@bne.es", coordenadas: [40.42348498519113, -3.6910447306827954], precio: 0, abierto: true },
    { id: 4, nombre: "Museo Thyssen", telefono: "917911370", direccion: "Paseo del Prado, 8", horario: "10:00 a 19:00", imagen: "https://www.museothyssen.org/themes/thyssen/img/thyssen-redes-sociales.jpg", web: "https://www.museothyssen.org/", coordenadas: [40.416137331924666, -3.694930865545187], precio: 13, abierto: true },
    { id: 5, nombre: "Real academia de Bellas Artes de San Fernando", telefono: "+34 91-524 08 64", direccion: "Alcal\xE1, 13 28014 Madrid", horario: "Martes a domingo de 10:00 a 15:00 horas, incluyendo festivos. Lunes cerrado.", imagen: "https://www.realacademiabellasartessanfernando.com/wp-content/uploads/2023/02/DSC00191-scaled.jpg", web: "https://www.realacademiabellasartessanfernando.com/es", coordenadas: [40.4180405, -3.7029775], precio: 8, abierto: true },
    { id: 6, nombre: "Museo Arqueol\xF3gico", telefono: "915777912", direccion: "Calle de Serrano, 13, 28001 Madrid", horario: "9:30\u201320:00", imagen: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/07/26/8b/44/entrada-museo-arqueologico.jpg?w=1200&h=1200&s=1", web: "http://www.man.es/man/home.html", coordenadas: [40.423553, -3.689402], precio: 3, abierto: true },
    { id: 7, nombre: "Museo Ciencias Naturales", telefono: "914111328", direccion: "C/Jos\xE9 Gutierrez Abascal", horario: "10.00 a 17.00", imagen: "https://estaticos.esmadrid.com/cdn/farfuture/vRECDnNX8Zss7WBKZaSAvXL80YO3vSStu3G-sIdz9NE/mtime:1646728991/sites/default/files/styles/content_type_full/public/recursosturisticos/infoturistica/museo_de_ciencias_naturales_4.jpg?itok=2sXEh5HX", web: "http://www.mncn.csic.es/es", coordenadas: [40.4404062, -3.6912279], precio: 7, abierto: true },
    { id: 8, nombre: "Museo del Traje", telefono: "+34 91 550 47 00", direccion: "Avenida de Juan de Herrera, 228040", horario: "Mar-S\xE1b: 9:30-19:00 h; Dom-Fest: 10:00-15:00 h Jueves (julio y agosto): 9:30 \u2013 22:30 h", imagen: "https://estaticos.esmadrid.com/cdn/farfuture/kvJKokxVD1Xx7E2RpzInIBSVbFOT7YS5YkLv4_MdBPo/mtime:1638267451/sites/default/files/recursosturisticos/infoturistica/museo_del_traje_madrid_destinoc_alvaro_lopez_13.jpg", web: "http://www.culturaydeporte.gob.es/mtraje/inicio.html", coordenadas: [40.4400972, -3.7318693], precio: 3, abierto: true },
    { id: 9, nombre: "Museo de Ciencias y Tecnologia", telefono: "914250919", direccion: "Parque de Andalucia. C/Pintor Vel\xE1zquez,5 28100 Alcobendas, Madrid", horario: "11:00-19:00", imagen: "https://www.esmadrid.com/sites/default/files/styles/content_type_full/public/recursosturisticos/infoturistica/museo_nacional_de_ciencia_y_tecnologia.jpg?itok=uTnl5LLm", web: "http://www.muncyt.es/", coordenadas: [40.5375439, -3.643642], precio: 3, abierto: true },
    { id: 10, nombre: "Museo de Lope de Vega", telefono: "914299216", direccion: "Callede Cervantes, 11,28014 Madrid", horario: "Mar-Dom: 10:00 - 18:00", imagen: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2a/69/c4/b5/caption.jpg?w=1400&h=800&s=1", web: "http://casamuseolopedevega.org/es/", coordenadas: [40.3980385, -3.7054334], precio: 0, abierto: true },
    { id: 11, nombre: "Museo de cera", telefono: "+34 91 319 93 30", direccion: "Plaza de Col\xF3n, 1", horario: "11:00\u201319:00", imagen: "https://media.istockphoto.com/id/862579804/es/foto/vista-exterior-del-museo-de-cera-de-madrid.jpg?s=170667a&w=0&k=20&c=f41bGPr1q5pcTDvfD5SsjWtKedH_0uEodOSx1xlUGpM=", web: "https://www.museodecerademadrid.com", coordenadas: [40.4250641, -3.6935975], precio: 18, abierto: true },
    { id: 12, nombre: "Museo de dibujo e ilustracci\xF3n", telefono: "+34 91 758 83 79", direccion: "Amaniel 29-31. 28015 Madrid", horario: "Cerrado Temporalmente", imagen: "https://images.adsttc.com/media/images/512a/f0b8/b3fc/4b11/a700/a6f4/large_jpg/1309145300-jesus-granada-5.jpg?1414269001", web: "https://museo.abc.es/", coordenadas: [40.4276904, -3.7117588], precio: 0, abierto: false },
    { id: 13, nombre: "Museo de la imprenta", telefono: "914294881", direccion: "28012, Calle de Concepci\xF3n Jer\xF3nima, 15, 28012 Madrid", horario: "10:00-20:00", imagen: "https://artedemadrid.wordpress.com/wp-content/uploads/2011/12/sala-maquinas.jpg?w=784&h=588", web: "https://museomadrid.com/imprenta-municipal-artes-del-libro/", coordenadas: [40.4138972, -3.7054722], precio: 0, abierto: true },
    { id: 14, nombre: "Museo Naval", telefono: "(+34) 91 523 85 16", direccion: " Paseo del Prado, 3 28014 ", horario: "Mar - Dom: 10:00 - 19:00 h ", imagen: "https://www.arkiplus.com/wp-content/uploads/2019/02/museo-naval-de-madrid.jpg", web: "https://www.esmadrid.com/informacion-turistica/museo-naval", coordenadas: [40.41851257605143, -3.6928194306791697], precio: 3, abierto: true },
    { id: 15, nombre: "Museo Sorolla", telefono: "+34 91 310 15 84", direccion: "Paseo del General Martinez Campos, 37, 28010 Madrid", horario: "9:30-20:00", imagen: "https://upload.wikimedia.org/wikipedia/commons/4/4e/Museo_Sorolla_%28Madrid%29_07.jpg", web: "https://www.culturaydeporte.gob.es/msorolla/inicio.html", coordenadas: [40.4354555, -3.6947111], precio: 3, abierto: true },
    { id: 16, nombre: "Museo de la ilusion", telefono: "+34 911 03 34 55", direccion: "Calle del Dr. Cortezo 8", horario: "Cierra a las 22:00", imagen: "https://www.madridlowcost.es/wp-content/uploads/2020/06/museo-de-las-ilusiones-770x492.jpg", web: "https://museumofillusions.es/", coordenadas: [40.4134667, -3.7060788], precio: 15, abierto: true }
  ];
  getAll() {
    return this.museos;
  }
  buscarMuseo(id) {
    return this.museos.find((item) => item.id == id);
  }
  static \u0275fac = function ServicioMuseos_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ServicioMuseos)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _ServicioMuseos, factory: _ServicioMuseos.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(ServicioMuseos, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/components/home/home.ts
import { CommonModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common.js?v=3385e9c1";
import * as i02 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i1 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common.js?v=3385e9c1";
var _c0 = (a0) => ({ active: a0 });
function Home_For_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i02.\u0275\u0275getCurrentView();
    i02.\u0275\u0275elementStart(0, "button", 10);
    i02.\u0275\u0275listener("click", function Home_For_3_Template_button_click_0_listener() {
      const $index_r2 = i02.\u0275\u0275restoreView(_r1).$index;
      const ctx_r2 = i02.\u0275\u0275nextContext();
      return i02.\u0275\u0275resetView(ctx_r2.selectSlide($index_r2));
    });
    i02.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const museo_r4 = ctx.$implicit;
    const $index_r2 = ctx.$index;
    const ctx_r2 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275classProp("active", ctx_r2.activeSlideIndex === $index_r2);
    i02.\u0275\u0275attribute("data-bs-slide-to", $index_r2)("aria-current", ctx_r2.activeSlideIndex === $index_r2 ? "true" : null)("aria-label", "Slide " + museo_r4.id);
  }
}
function Home_For_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "div", 4);
    i02.\u0275\u0275element(1, "img", 11);
    i02.\u0275\u0275elementStart(2, "div", 12)(3, "h5");
    i02.\u0275\u0275text(4);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(5, "p");
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const museo_r5 = ctx.$implicit;
    i02.\u0275\u0275property("ngClass", i02.\u0275\u0275pureFunction1(7, _c0, museo_r5.id == 1));
    i02.\u0275\u0275advance();
    i02.\u0275\u0275property("src", i02.\u0275\u0275interpolate(museo_r5.imagen), i02.\u0275\u0275sanitizeUrl)("alt", i02.\u0275\u0275interpolate(museo_r5.nombre));
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate(museo_r5.nombre);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(museo_r5.direccion);
  }
}
var Home = class _Home {
  museos = [];
  activeSlideIndex = 0;
  museosService = inject(ServicioMuseos);
  constructor() {
    this.museos = this.museosService.getAll();
  }
  selectSlide(idx) {
    this.activeSlideIndex = idx;
  }
  static \u0275fac = function Home_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Home)();
  };
  static \u0275cmp = /* @__PURE__ */ i02.\u0275\u0275defineComponent({ type: _Home, selectors: [["app-home"]], decls: 15, vars: 0, consts: [["id", "carouselExampleCaptions", 1, "carousel", "slide"], [1, "carousel-indicators"], ["type", "button", "data-bs-target", "#carouselExampleIndicators", 3, "active"], [1, "carousel-inner"], [1, "carousel-item", 3, "ngClass"], ["type", "button", "data-bs-target", "#carouselExampleCaptions", "data-bs-slide", "prev", 1, "carousel-control-prev"], ["aria-hidden", "true", 1, "carousel-control-prev-icon"], [1, "visually-hidden"], ["type", "button", "data-bs-target", "#carouselExampleCaptions", "data-bs-slide", "next", 1, "carousel-control-next"], ["aria-hidden", "true", 1, "carousel-control-next-icon"], ["type", "button", "data-bs-target", "#carouselExampleIndicators", 3, "click"], [1, "d-block", "w-100", 3, "src", "alt"], [1, "carousel-caption", "d-none", "d-md-block"]], template: function Home_Template(rf, ctx) {
    if (rf & 1) {
      i02.\u0275\u0275elementStart(0, "div", 0)(1, "div", 1);
      i02.\u0275\u0275repeaterCreate(2, Home_For_3_Template, 1, 5, "button", 2, i02.\u0275\u0275repeaterTrackByIndex);
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(4, "div", 3);
      i02.\u0275\u0275repeaterCreate(5, Home_For_6_Template, 7, 9, "div", 4, i02.\u0275\u0275repeaterTrackByIndex);
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(7, "button", 5);
      i02.\u0275\u0275element(8, "span", 6);
      i02.\u0275\u0275elementStart(9, "span", 7);
      i02.\u0275\u0275text(10, "Previous");
      i02.\u0275\u0275elementEnd()();
      i02.\u0275\u0275elementStart(11, "button", 8);
      i02.\u0275\u0275element(12, "span", 9);
      i02.\u0275\u0275elementStart(13, "span", 7);
      i02.\u0275\u0275text(14, "Next");
      i02.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      i02.\u0275\u0275advance(2);
      i02.\u0275\u0275repeater(ctx.museos);
      i02.\u0275\u0275advance(3);
      i02.\u0275\u0275repeater(ctx.museos);
    }
  }, dependencies: [CommonModule, i1.NgClass, i1.NgComponentOutlet, i1.NgForOf, i1.NgIf, i1.NgTemplateOutlet, i1.NgStyle, i1.NgSwitch, i1.NgSwitchCase, i1.NgSwitchDefault, i1.NgPlural, i1.NgPluralCase, i1.AsyncPipe, i1.UpperCasePipe, i1.LowerCasePipe, i1.JsonPipe, i1.SlicePipe, i1.DecimalPipe, i1.PercentPipe, i1.TitleCasePipe, i1.CurrencyPipe, i1.DatePipe, i1.I18nPluralPipe, i1.I18nSelectPipe, i1.KeyValuePipe], styles: ["\n\n#carouselExampleCaptions[_ngcontent-%COMP%] {\n  margin: 0 auto;\n  width: 60%;\n}\n/*# sourceMappingURL=home.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(Home, [{
    type: Component,
    args: [{ selector: "app-home", imports: [CommonModule], template: `<div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    @for (museo of museos; track $index){
      <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            [attr.data-bs-slide-to]="$index"
            [class.active]="activeSlideIndex === $index"
            [attr.aria-current]="activeSlideIndex === $index ? 'true' : null"
            [attr.aria-label]="'Slide ' + museo.id"
            (click)="selectSlide($index)"
          ></button>
    }
  </div>
  <div class="carousel-inner">
    @for (museo of museos; track $index){
      <div class="carousel-item" [ngClass]="{active: museo.id == 1}">
        <img src="{{museo.imagen}}" class="d-block w-100" alt="{{museo.nombre}}">
        <div class="carousel-caption d-none d-md-block">
          <h5>{{museo.nombre}}</h5>
          <p>{{museo.direccion}}</p>
        </div>
      </div>
    }
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
`, styles: ["/* src/app/components/home/home.css */\n#carouselExampleCaptions {\n  margin: 0 auto;\n  width: 60%;\n}\n/*# sourceMappingURL=home.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(Home, { className: "Home", filePath: "src/app/components/home/home.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fhome%2Fhome.ts%40Home";
  function Home_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i02.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i02.\u0275\u0275replaceMetadata(Home, m.default, [i02, i1], [CommonModule, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Home_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Home_HmrLoad(d.timestamp)));
})();

// src/app/components/museos/museos.ts
import { Component as Component2, inject as inject3, ViewChild } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { RouterLink } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";
import { MatTableDataSource, MatTableModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_table.js?v=3385e9c1";
import { MatSort, MatSortModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_sort.js?v=3385e9c1";
import { MatPaginator, MatPaginatorModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_paginator.js?v=3385e9c1";
import { MatInputModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_input.js?v=3385e9c1";
import { FormsModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_forms.js?v=3385e9c1";

// src/app/pipes/estado-pipe.ts
import { inject as inject2, Pipe } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { TranslateService } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@ngx-translate_core.js?v=3385e9c1";
import * as i03 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var EstadoPipe = class _EstadoPipe {
  translateService = inject2(TranslateService);
  transform(value, ...args) {
    if (value) {
      return this.translateService.instant("pipe.abierto");
    } else {
      return this.translateService.instant("pipe.cerrado");
    }
  }
  static \u0275fac = function EstadoPipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _EstadoPipe)();
  };
  static \u0275pipe = /* @__PURE__ */ i03.\u0275\u0275definePipe({ name: "estado", type: _EstadoPipe, pure: false });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassMetadata(EstadoPipe, [{
    type: Pipe,
    args: [{
      name: "estado",
      pure: false
    }]
  }], null, null);
})();

// src/app/components/museos/museos.ts
import * as i04 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i12 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_bidi.js?v=3385e9c1";
import * as i2 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_table.js?v=3385e9c1";
import * as i3 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_sort.js?v=3385e9c1";
import * as i4 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_paginator.js?v=3385e9c1";
import * as i5 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_input.js?v=3385e9c1";
import * as i6 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_text-field.js?v=3385e9c1";
import * as i7 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_forms.js?v=3385e9c1";
var _c02 = () => [2, 4, 6, 8];
function Museos_th_7_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "th", 12);
    i04.\u0275\u0275text(1, " Nombre ");
    i04.\u0275\u0275elementEnd();
  }
}
function Museos_td_8_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "td", 13)(1, "a", 14);
    i04.\u0275\u0275text(2);
    i04.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const museo_r1 = ctx.$implicit;
    i04.\u0275\u0275advance();
    i04.\u0275\u0275property("routerLink", i04.\u0275\u0275interpolate1("/detalle-museo/", museo_r1.id));
    i04.\u0275\u0275advance();
    i04.\u0275\u0275textInterpolate1(" ", museo_r1.nombre, " ");
  }
}
function Museos_th_10_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "th", 12);
    i04.\u0275\u0275text(1, " Abierto | Cerrado ");
    i04.\u0275\u0275elementEnd();
  }
}
function Museos_td_11_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "td", 13);
    i04.\u0275\u0275text(1);
    i04.\u0275\u0275pipe(2, "estado");
    i04.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const museo_r2 = ctx.$implicit;
    i04.\u0275\u0275advance();
    i04.\u0275\u0275textInterpolate1(" ", i04.\u0275\u0275pipeBind1(2, 1, museo_r2.abierto), " ");
  }
}
function Museos_th_13_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "th", 12);
    i04.\u0275\u0275text(1, " Horario ");
    i04.\u0275\u0275elementEnd();
  }
}
function Museos_td_14_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "td", 13);
    i04.\u0275\u0275text(1);
    i04.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const museo_r3 = ctx.$implicit;
    i04.\u0275\u0275advance();
    i04.\u0275\u0275textInterpolate1(" ", museo_r3.horario, " ");
  }
}
function Museos_th_16_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "th", 12);
    i04.\u0275\u0275text(1, " Precio ");
    i04.\u0275\u0275elementEnd();
  }
}
function Museos_td_17_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "td", 13);
    i04.\u0275\u0275text(1);
    i04.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const museo_r4 = ctx.$implicit;
    i04.\u0275\u0275advance();
    i04.\u0275\u0275textInterpolate1(" ", museo_r4.precio, " ");
  }
}
function Museos_tr_18_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275element(0, "tr", 15);
  }
}
function Museos_tr_19_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275element(0, "tr", 16);
  }
}
var Museos = class _Museos {
  museos = [];
  displayedColumns = ["nombre", "abierto", "horario", "precio"];
  // propiedades del museo
  dataSource;
  dato = "";
  sort;
  paginador;
  // Con las nuevas versiones de Angular, inyectamos los servicios con inject
  // En las versiones anteriores se hacia a través del constructor
  museosService = inject3(ServicioMuseos);
  filtrar() {
    this.dataSource.filter = this.dato.toLowerCase();
  }
  ngOnInit() {
    this.museos = this.museosService.getAll();
    this.dataSource = new MatTableDataSource(this.museos);
  }
  ngAfterViewInit() {
    if (this.sort != void 0) {
      this.dataSource.sort = this.sort;
    }
    if (this.paginador != void 0) {
      this.dataSource.paginator = this.paginador;
    }
    this.dataSource.filterPredicate = (item, filter) => {
      return item.nombre.toLowerCase().includes(filter);
    };
  }
  static \u0275fac = function Museos_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Museos)();
  };
  static \u0275cmp = /* @__PURE__ */ i04.\u0275\u0275defineComponent({ type: _Museos, selectors: [["app-museos"]], viewQuery: function Museos_Query(rf, ctx) {
    if (rf & 1) {
      i04.\u0275\u0275viewQuery(MatSort, 5);
      i04.\u0275\u0275viewQuery(MatPaginator, 5);
    }
    if (rf & 2) {
      let _t;
      i04.\u0275\u0275queryRefresh(_t = i04.\u0275\u0275loadQuery()) && (ctx.sort = _t.first);
      i04.\u0275\u0275queryRefresh(_t = i04.\u0275\u0275loadQuery()) && (ctx.paginador = _t.first);
    }
  }, decls: 21, vars: 8, consts: [[1, "example-full-width"], ["matInput", "", 3, "ngModelChange", "keyup", "ngModel"], ["mat-table", "", "matSort", "", 1, "mat-elevation-z8", 3, "dataSource"], ["matColumnDef", "nombre"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "abierto"], ["matColumnDef", "horario"], ["matColumnDef", "precio"], ["mat-header-row", "", 4, "matHeaderRowDef"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["showFirstLastButtons", "", "aria-label", "Select page", 3, "length", "pageSize", "pageSizeOptions"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-cell", ""], [3, "routerLink"], ["mat-header-row", ""], ["mat-row", ""]], template: function Museos_Template(rf, ctx) {
    if (rf & 1) {
      i04.\u0275\u0275elementStart(0, "div")(1, "mat-form-field", 0)(2, "mat-label");
      i04.\u0275\u0275text(3, "Buscar:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(4, "input", 1);
      i04.\u0275\u0275twoWayListener("ngModelChange", function Museos_Template_input_ngModelChange_4_listener($event) {
        i04.\u0275\u0275twoWayBindingSet(ctx.dato, $event) || (ctx.dato = $event);
        return $event;
      });
      i04.\u0275\u0275listener("keyup", function Museos_Template_input_keyup_4_listener() {
        return ctx.filtrar();
      });
      i04.\u0275\u0275elementEnd()();
      i04.\u0275\u0275elementStart(5, "table", 2);
      i04.\u0275\u0275elementContainerStart(6, 3);
      i04.\u0275\u0275template(7, Museos_th_7_Template, 2, 0, "th", 4)(8, Museos_td_8_Template, 3, 3, "td", 5);
      i04.\u0275\u0275elementContainerEnd();
      i04.\u0275\u0275elementContainerStart(9, 6);
      i04.\u0275\u0275template(10, Museos_th_10_Template, 2, 0, "th", 4)(11, Museos_td_11_Template, 3, 3, "td", 5);
      i04.\u0275\u0275elementContainerEnd();
      i04.\u0275\u0275elementContainerStart(12, 7);
      i04.\u0275\u0275template(13, Museos_th_13_Template, 2, 0, "th", 4)(14, Museos_td_14_Template, 2, 1, "td", 5);
      i04.\u0275\u0275elementContainerEnd();
      i04.\u0275\u0275elementContainerStart(15, 8);
      i04.\u0275\u0275template(16, Museos_th_16_Template, 2, 0, "th", 4)(17, Museos_td_17_Template, 2, 1, "td", 5);
      i04.\u0275\u0275elementContainerEnd();
      i04.\u0275\u0275template(18, Museos_tr_18_Template, 1, 0, "tr", 9)(19, Museos_tr_19_Template, 1, 0, "tr", 10);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(20, "mat-paginator", 11);
      i04.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i04.\u0275\u0275advance(4);
      i04.\u0275\u0275twoWayProperty("ngModel", ctx.dato);
      i04.\u0275\u0275advance();
      i04.\u0275\u0275property("dataSource", ctx.dataSource);
      i04.\u0275\u0275advance(13);
      i04.\u0275\u0275property("matHeaderRowDef", ctx.displayedColumns);
      i04.\u0275\u0275advance();
      i04.\u0275\u0275property("matRowDefColumns", ctx.displayedColumns);
      i04.\u0275\u0275advance();
      i04.\u0275\u0275property("length", ctx.museos.length)("pageSize", 4)("pageSizeOptions", i04.\u0275\u0275pureFunction0(7, _c02));
    }
  }, dependencies: [RouterLink, MatTableModule, i12.Dir, i2.MatTable, i2.MatRecycleRows, i2.MatHeaderCellDef, i2.MatHeaderRowDef, i2.MatColumnDef, i2.MatCellDef, i2.MatRowDef, i2.MatFooterCellDef, i2.MatFooterRowDef, i2.MatHeaderCell, i2.MatCell, i2.MatFooterCell, i2.MatHeaderRow, i2.MatRow, i2.MatFooterRow, i2.MatNoDataRow, i2.MatTextColumn, MatSortModule, i3.MatSort, i3.MatSortHeader, MatPaginatorModule, i4.MatPaginator, MatInputModule, i5.MatInput, i5.MatFormField, i5.MatLabel, i5.MatHint, i5.MatError, i5.MatPrefix, i5.MatSuffix, i6.CdkAutofill, i6.CdkTextareaAutosize, FormsModule, i7.\u0275NgNoValidate, i7.NgSelectOption, i7.\u0275NgSelectMultipleOption, i7.DefaultValueAccessor, i7.NumberValueAccessor, i7.RangeValueAccessor, i7.CheckboxControlValueAccessor, i7.SelectControlValueAccessor, i7.SelectMultipleControlValueAccessor, i7.RadioControlValueAccessor, i7.NgControlStatus, i7.NgControlStatusGroup, i7.RequiredValidator, i7.MinLengthValidator, i7.MaxLengthValidator, i7.PatternValidator, i7.CheckboxRequiredValidator, i7.EmailValidator, i7.MinValidator, i7.MaxValidator, i7.NgModel, i7.NgModelGroup, i7.NgForm, EstadoPipe], styles: ["\n\ndiv[_ngcontent-%COMP%] {\n  width: 90%;\n  margin: 0 auto;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\ntable[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.example-full-width[_ngcontent-%COMP%] {\n  width: 30%;\n  float: right;\n}\n/*# sourceMappingURL=museos.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassMetadata(Museos, [{
    type: Component2,
    args: [{ selector: "app-museos", imports: [RouterLink, MatTableModule, MatSortModule, MatPaginatorModule, MatInputModule, FormsModule, EstadoPipe], template: '<div>\n\n  <!-- El campo de busqueda va fuera de la tabla -->\n  <mat-form-field class="example-full-width">\n    <mat-label>Buscar:</mat-label>\n    <input matInput [(ngModel)]="dato" (keyup)="filtrar()">\n  </mat-form-field>\n\n  <table mat-table matSort [dataSource]="dataSource" class="mat-elevation-z8">\n\n    <ng-container matColumnDef="nombre">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header> Nombre </th>\n      <td mat-cell *matCellDef="let museo">\n        <a routerLink="/detalle-museo/{{museo.id}}">\n          {{museo.nombre}}\n        </a>\n      </td>\n    </ng-container>\n\n    <ng-container matColumnDef="abierto">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header> Abierto | Cerrado </th>\n      <td mat-cell *matCellDef="let museo"> {{museo.abierto | estado}} </td>\n    </ng-container>\n\n    <ng-container matColumnDef="horario">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header> Horario </th>\n      <td mat-cell *matCellDef="let museo"> {{museo.horario}} </td>\n    </ng-container>\n\n    <ng-container matColumnDef="precio">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header> Precio </th>\n      <td mat-cell *matCellDef="let museo"> {{museo.precio}} </td>\n    </ng-container>\n\n    <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>\n    <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>\n  </table>\n\n  <!-- El paginador va fuera de la tabla -->\n  <mat-paginator [length]="museos.length"\n              showFirstLastButtons\n              [pageSize]="4"\n              [pageSizeOptions]="[2,4,6,8]"\n              aria-label="Select page">\n  </mat-paginator>\n\n</div>\n', styles: ["/* src/app/components/museos/museos.css */\ndiv {\n  width: 90%;\n  margin: 0 auto;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\ntable {\n  width: 100%;\n}\n.example-full-width {\n  width: 30%;\n  float: right;\n}\n/*# sourceMappingURL=museos.css.map */\n"] }]
  }], null, { sort: [{
    type: ViewChild,
    args: [MatSort]
  }], paginador: [{
    type: ViewChild,
    args: [MatPaginator]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(Museos, { className: "Museos", filePath: "src/app/components/museos/museos.ts", lineNumber: 19 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fmuseos%2Fmuseos.ts%40Museos";
  function Museos_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i04.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i04.\u0275\u0275replaceMetadata(Museos, m.default, [i04, i12, i2, i3, i4, i5, i6, i7], [MatSort, MatPaginator, RouterLink, MatTableModule, MatSortModule, MatPaginatorModule, MatInputModule, FormsModule, EstadoPipe, Component2, ViewChild], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Museos_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Museos_HmrLoad(d.timestamp)));
})();

// src/app/components/detalle-museo/detalle-museo.ts
import { Component as Component3, inject as inject4 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { CommonModule as CommonModule2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common.js?v=3385e9c1";
import { MatIconModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_icon.js?v=3385e9c1";
import * as i05 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i13 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";
import * as i22 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common.js?v=3385e9c1";
import * as i32 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_icon.js?v=3385e9c1";
import * as i42 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_bidi.js?v=3385e9c1";
var _c03 = () => ({ "color": "red" });
function DetalleMuseo_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "span");
    i05.\u0275\u0275text(1, "Abierto");
    i05.\u0275\u0275elementEnd();
  }
}
function DetalleMuseo_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "span", 10);
    i05.\u0275\u0275text(1, "Cerrado");
    i05.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i05.\u0275\u0275property("ngStyle", i05.\u0275\u0275pureFunction0(1, _c03));
  }
}
var DetalleMuseo = class _DetalleMuseo {
  ruta;
  museo;
  museosService = inject4(ServicioMuseos);
  constructor(ruta) {
    this.ruta = ruta;
    let id = ruta.snapshot.params["id"];
    this.museo = this.museosService.buscarMuseo(id);
  }
  static \u0275fac = function DetalleMuseo_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DetalleMuseo)(i05.\u0275\u0275directiveInject(i13.ActivatedRoute));
  };
  static \u0275cmp = /* @__PURE__ */ i05.\u0275\u0275defineComponent({ type: _DetalleMuseo, selectors: [["app-detalle-museo"]], decls: 33, vars: 19, consts: [[1, "row"], [1, "col-3"], [1, "col-6"], [1, "card"], [1, "card-img-top", 3, "src", "alt"], [1, "card-body"], [1, "card-title"], [1, "card-text"], [1, "list-group", "list-group-flush"], [1, "list-group-item"], [3, "ngStyle"], ["target", "_blank", 1, "card-link", 3, "href"]], template: function DetalleMuseo_Template(rf, ctx) {
    if (rf & 1) {
      i05.\u0275\u0275elementStart(0, "div", 0);
      i05.\u0275\u0275element(1, "div", 1);
      i05.\u0275\u0275elementStart(2, "div", 2)(3, "div", 3);
      i05.\u0275\u0275element(4, "img", 4);
      i05.\u0275\u0275elementStart(5, "div", 5)(6, "h5", 6);
      i05.\u0275\u0275text(7);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(8, "p", 7);
      i05.\u0275\u0275text(9);
      i05.\u0275\u0275elementEnd()();
      i05.\u0275\u0275elementStart(10, "ul", 8)(11, "li", 9)(12, "mat-icon");
      i05.\u0275\u0275text(13, "phone_in_talk");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275text(14);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(15, "li", 9)(16, "mat-icon");
      i05.\u0275\u0275text(17, "schedule");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275text(18);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(19, "li", 9)(20, "mat-icon");
      i05.\u0275\u0275text(21, "credit_card");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275text(22);
      i05.\u0275\u0275pipe(23, "currency");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(24, "li", 9);
      i05.\u0275\u0275conditionalCreate(25, DetalleMuseo_Conditional_25_Template, 2, 0, "span")(26, DetalleMuseo_Conditional_26_Template, 2, 2, "span", 10);
      i05.\u0275\u0275elementEnd()();
      i05.\u0275\u0275elementStart(27, "div", 5)(28, "a", 11);
      i05.\u0275\u0275text(29, "Web del museo");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(30, "a", 11);
      i05.\u0275\u0275text(31, "Ubicacion");
      i05.\u0275\u0275elementEnd()()()();
      i05.\u0275\u0275element(32, "div", 1);
      i05.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i05.\u0275\u0275advance(4);
      i05.\u0275\u0275property("src", i05.\u0275\u0275interpolate(ctx.museo == null ? null : ctx.museo.imagen), i05.\u0275\u0275sanitizeUrl)("alt", i05.\u0275\u0275interpolate(ctx.museo == null ? null : ctx.museo.nombre));
      i05.\u0275\u0275advance(3);
      i05.\u0275\u0275textInterpolate(ctx.museo == null ? null : ctx.museo.nombre);
      i05.\u0275\u0275advance(2);
      i05.\u0275\u0275textInterpolate(ctx.museo == null ? null : ctx.museo.direccion);
      i05.\u0275\u0275advance(5);
      i05.\u0275\u0275textInterpolate1(" ", ctx.museo == null ? null : ctx.museo.telefono);
      i05.\u0275\u0275advance(4);
      i05.\u0275\u0275textInterpolate1(" ", ctx.museo == null ? null : ctx.museo.horario);
      i05.\u0275\u0275advance(4);
      i05.\u0275\u0275textInterpolate1(" ", i05.\u0275\u0275pipeBind4(23, 14, ctx.museo == null ? null : ctx.museo.precio, "EUR", "symbol", ".2-2"), " ");
      i05.\u0275\u0275advance(3);
      i05.\u0275\u0275conditional((ctx.museo == null ? null : ctx.museo.abierto) ? 25 : 26);
      i05.\u0275\u0275advance(3);
      i05.\u0275\u0275property("href", i05.\u0275\u0275interpolate(ctx.museo == null ? null : ctx.museo.web), i05.\u0275\u0275sanitizeUrl);
      i05.\u0275\u0275advance(2);
      i05.\u0275\u0275property("href", i05.\u0275\u0275interpolate1("https://www.google.com/maps/place/", ctx.museo == null ? null : ctx.museo.coordenadas), i05.\u0275\u0275sanitizeUrl);
    }
  }, dependencies: [CommonModule2, i22.NgClass, i22.NgComponentOutlet, i22.NgForOf, i22.NgIf, i22.NgTemplateOutlet, i22.NgStyle, i22.NgSwitch, i22.NgSwitchCase, i22.NgSwitchDefault, i22.NgPlural, i22.NgPluralCase, MatIconModule, i32.MatIcon, i42.Dir, i22.AsyncPipe, i22.UpperCasePipe, i22.LowerCasePipe, i22.JsonPipe, i22.SlicePipe, i22.DecimalPipe, i22.PercentPipe, i22.TitleCasePipe, i22.CurrencyPipe, i22.DatePipe, i22.I18nPluralPipe, i22.I18nSelectPipe, i22.KeyValuePipe], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassMetadata(DetalleMuseo, [{
    type: Component3,
    args: [{ selector: "app-detalle-museo", imports: [CommonModule2, MatIconModule], template: `<div class="row"> <!-- dividir el div en 12 columnas -->
  <div class="col-3"></div> <!-- 3 columnas vacias-->

  <div class="col-6">
    <div class="card">
      <img src="{{museo?.imagen}}" class="card-img-top" alt="{{museo?.nombre}}">
      <div class="card-body">
        <h5 class="card-title">{{museo?.nombre}}</h5>
        <p class="card-text">{{museo?.direccion}}</p>
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item"><mat-icon>phone_in_talk</mat-icon> {{museo?.telefono}}</li>
        <li class="list-group-item"><mat-icon>schedule</mat-icon> {{museo?.horario}}</li>
        <li class="list-group-item">
          <mat-icon>credit_card</mat-icon>
          {{museo?.precio | currency: 'EUR': 'symbol': '.2-2'}}
        </li>
        <li class="list-group-item">
          @if (museo?.abierto){
            <span>Abierto</span>
          } @else {
            <span [ngStyle]="{'color': 'red'}" >Cerrado</span>
          }
        </li>
      </ul>
      <div class="card-body">
        <a href="{{museo?.web}}" target="_blank" class="card-link">Web del museo</a>
        <a href="https://www.google.com/maps/place/{{museo?.coordenadas}}"
            target="_blank" class="card-link">Ubicacion</a>
      </div>
    </div>
  </div>

  <div class="col-3"></div> <!-- 3 columnas vacias-->
</div>
` }]
  }], () => [{ type: i13.ActivatedRoute }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(DetalleMuseo, { className: "DetalleMuseo", filePath: "src/app/components/detalle-museo/detalle-museo.ts", lineNumber: 14 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fdetalle-museo%2Fdetalle-museo.ts%40DetalleMuseo";
  function DetalleMuseo_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i05.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i05.\u0275\u0275replaceMetadata(DetalleMuseo, m.default, [i05, i22, i32, i42, i13], [CommonModule2, MatIconModule, Component3], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && DetalleMuseo_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && DetalleMuseo_HmrLoad(d.timestamp)));
})();

// src/app/components/equipo/equipo.ts
import { Component as Component4, inject as inject6, signal } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";

// src/app/services/servicio-equipo.ts
import { HttpHeaders, HttpClient } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common_http.js?v=3385e9c1";
import { Injectable as Injectable2, inject as inject5 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i06 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var ServicioEquipo = class _ServicioEquipo {
  url = "https://rickandmortyapi.com/api/character";
  cabeceras = new HttpHeaders({ "Content-type": "application/json" });
  http = inject5(HttpClient);
  getAll() {
    return this.http.get(this.url, { headers: this.cabeceras });
  }
  static \u0275fac = function ServicioEquipo_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ServicioEquipo)();
  };
  static \u0275prov = /* @__PURE__ */ i06.\u0275\u0275defineInjectable({ token: _ServicioEquipo, factory: _ServicioEquipo.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassMetadata(ServicioEquipo, [{
    type: Injectable2,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/components/equipo/equipo.ts
import { CommonModule as CommonModule3 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common.js?v=3385e9c1";
import * as i07 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i14 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common.js?v=3385e9c1";
var _c04 = () => ({ marginTop: "10px" });
var _forTrack0 = ($index, $item) => $item.id;
function Equipo_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275elementStart(0, "div", 0)(1, "strong", 2);
    i07.\u0275\u0275text(2, "Cargando datos...");
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275element(3, "div", 3);
    i07.\u0275\u0275elementEnd();
  }
}
function Equipo_Conditional_1_For_2_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275elementStart(0, "div", 4)(1, "div", 5);
    i07.\u0275\u0275element(2, "img", 6);
    i07.\u0275\u0275elementStart(3, "div", 7)(4, "h5", 8);
    i07.\u0275\u0275text(5);
    i07.\u0275\u0275elementEnd();
    i07.\u0275\u0275elementStart(6, "p", 9);
    i07.\u0275\u0275text(7);
    i07.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const miembro_r1 = ctx.$implicit;
    i07.\u0275\u0275advance();
    i07.\u0275\u0275property("ngStyle", i07.\u0275\u0275pureFunction0(7, _c04));
    i07.\u0275\u0275advance();
    i07.\u0275\u0275property("src", i07.\u0275\u0275interpolate(miembro_r1.image), i07.\u0275\u0275sanitizeUrl)("alt", i07.\u0275\u0275interpolate(miembro_r1.name));
    i07.\u0275\u0275advance(3);
    i07.\u0275\u0275textInterpolate(miembro_r1.name);
    i07.\u0275\u0275advance(2);
    i07.\u0275\u0275textInterpolate(miembro_r1.species);
  }
}
function Equipo_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i07.\u0275\u0275elementStart(0, "div", 1);
    i07.\u0275\u0275repeaterCreate(1, Equipo_Conditional_1_For_2_Template, 8, 8, "div", 4, _forTrack0);
    i07.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i07.\u0275\u0275nextContext();
    i07.\u0275\u0275property("ngClass", "equipo");
    i07.\u0275\u0275advance();
    i07.\u0275\u0275repeater(ctx_r1.miembros());
  }
}
var Equipo = class _Equipo {
  miembros = signal([], ...ngDevMode ? [{ debugName: "miembros" }] : []);
  cargando = signal(true, ...ngDevMode ? [{ debugName: "cargando" }] : []);
  equipoService = inject6(ServicioEquipo);
  ngOnInit() {
    setTimeout(() => {
      this.equipoService.getAll().subscribe({
        next: (datos) => {
          console.log(datos);
          this.miembros.set(datos.results);
          this.cargando.set(false);
        },
        error: (err) => {
          console.log(err);
        }
      });
    }, 2e3);
  }
  static \u0275fac = function Equipo_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Equipo)();
  };
  static \u0275cmp = /* @__PURE__ */ i07.\u0275\u0275defineComponent({ type: _Equipo, selectors: [["app-equipo"]], decls: 2, vars: 1, consts: [["id", "carga", 1, "d-flex", "align-items-center"], [1, "row", 3, "ngClass"], ["role", "status"], ["aria-hidden", "true", 1, "spinner-border", "ms-auto"], [1, "col-3"], [1, "card", 3, "ngStyle"], [1, "card-img-top", 3, "src", "alt"], [1, "card-body"], [1, "card-title"], [1, "card-text"]], template: function Equipo_Template(rf, ctx) {
    if (rf & 1) {
      i07.\u0275\u0275conditionalCreate(0, Equipo_Conditional_0_Template, 4, 0, "div", 0)(1, Equipo_Conditional_1_Template, 3, 1, "div", 1);
    }
    if (rf & 2) {
      i07.\u0275\u0275conditional(ctx.cargando() ? 0 : 1);
    }
  }, dependencies: [CommonModule3, i14.NgClass, i14.NgComponentOutlet, i14.NgForOf, i14.NgIf, i14.NgTemplateOutlet, i14.NgStyle, i14.NgSwitch, i14.NgSwitchCase, i14.NgSwitchDefault, i14.NgPlural, i14.NgPluralCase, i14.AsyncPipe, i14.UpperCasePipe, i14.LowerCasePipe, i14.JsonPipe, i14.SlicePipe, i14.DecimalPipe, i14.PercentPipe, i14.TitleCasePipe, i14.CurrencyPipe, i14.DatePipe, i14.I18nPluralPipe, i14.I18nSelectPipe, i14.KeyValuePipe], styles: ["\n\n#carga[_ngcontent-%COMP%] {\n  width: 30%;\n  margin: 0 auto;\n  margin-top: 50px;\n}\n.equipo[_ngcontent-%COMP%] {\n  width: 90%;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=equipo.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassMetadata(Equipo, [{
    type: Component4,
    args: [{ selector: "app-equipo", imports: [CommonModule3], template: `@if (cargando()){
  <div id="carga" class="d-flex align-items-center">
    <strong role="status">Cargando datos...</strong>
    <div class="spinner-border ms-auto" aria-hidden="true"></div>
  </div>
} @else {
  <div class="row" [ngClass]=" 'equipo' ">
    @for (miembro of miembros(); track miembro.id){
      <div class="col-3">
        <div class="card" [ngStyle]="{marginTop: '10px'}">
            <img src="{{miembro.image}}" class="card-img-top" alt="{{miembro.name}}">
            <div class="card-body">
              <h5 class="card-title">{{miembro.name}}</h5>
              <p class="card-text">{{miembro.species}}</p>
            </div>
        </div>
      </div>
    }
  </div>
}
`, styles: ["/* src/app/components/equipo/equipo.css */\n#carga {\n  width: 30%;\n  margin: 0 auto;\n  margin-top: 50px;\n}\n.equipo {\n  width: 90%;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=equipo.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassDebugInfo(Equipo, { className: "Equipo", filePath: "src/app/components/equipo/equipo.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fequipo%2Fequipo.ts%40Equipo";
  function Equipo_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i07.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i07.\u0275\u0275replaceMetadata(Equipo, m.default, [i07, i14], [CommonModule3, Component4], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Equipo_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Equipo_HmrLoad(d.timestamp)));
})();

// src/app/components/contacto/contacto.ts
import { Component as Component5, inject as inject7 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { FormsModule as FormsModule2, NonNullableFormBuilder, ReactiveFormsModule, Validators } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_forms.js?v=3385e9c1";
import { MatInputModule as MatInputModule2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_input.js?v=3385e9c1";
import { MatButtonModule } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_button.js?v=3385e9c1";
import * as i08 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i15 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_forms.js?v=3385e9c1";
import * as i23 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_input.js?v=3385e9c1";
import * as i33 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_bidi.js?v=3385e9c1";
import * as i43 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_text-field.js?v=3385e9c1";
import * as i52 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_button.js?v=3385e9c1";
function Contacto_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Campo obligatorio");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Longitud minima 3 caracteres");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Campo obligatorio");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Debe tener 9 digitos y comenzar por 6,7 \xF3 9");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Campo obligatorio");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Email no es valido");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Campo obligatorio");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Longitud minima 5 caracteres");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Campo obligatorio");
    i08.\u0275\u0275elementEnd();
  }
}
function Contacto_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "mat-error");
    i08.\u0275\u0275text(1, "* Longitud minima 10 caracteres");
    i08.\u0275\u0275elementEnd();
  }
}
var Contacto = class _Contacto {
  fb = inject7(NonNullableFormBuilder);
  contactoForm = this.fb.group({
    nombre: ["", [Validators.required, Validators.minLength(3)]],
    telefono: ["", [Validators.required, Validators.pattern("[6,7,9]{1}[0-9]{8}")]],
    email: ["", [Validators.required, Validators.email]],
    asunto: ["", [Validators.required, Validators.minLength(5)]],
    mensaje: ["", [Validators.required, Validators.minLength(10)]]
  });
  guardar() {
    console.log(this.contactoForm.value);
    alert("Mensaje recibido");
  }
  static \u0275fac = function Contacto_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Contacto)();
  };
  static \u0275cmp = /* @__PURE__ */ i08.\u0275\u0275defineComponent({ type: _Contacto, selectors: [["app-contacto"]], decls: 35, vars: 11, consts: [[1, "mat-elevation-z8"], [3, "formGroup"], [1, "example-full-width"], ["type", "text", "matInput", "", "formControlName", "nombre"], ["type", "text", "matInput", "", "formControlName", "telefono"], ["type", "text", "matInput", "", "formControlName", "email"], ["type", "text", "matInput", "", "formControlName", "asunto"], ["rows", "6", "matInput", "", "formControlName", "mensaje"], ["matButton", "elevated"]], template: function Contacto_Template(rf, ctx) {
    if (rf & 1) {
      i08.\u0275\u0275elementStart(0, "div", 0)(1, "form", 1)(2, "mat-form-field", 2)(3, "mat-label");
      i08.\u0275\u0275text(4, "Nombre:");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275element(5, "input", 3);
      i08.\u0275\u0275conditionalCreate(6, Contacto_Conditional_6_Template, 2, 0, "mat-error");
      i08.\u0275\u0275conditionalCreate(7, Contacto_Conditional_7_Template, 2, 0, "mat-error");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275elementStart(8, "mat-form-field", 2)(9, "mat-label");
      i08.\u0275\u0275text(10, "Telefono:");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275element(11, "input", 4);
      i08.\u0275\u0275conditionalCreate(12, Contacto_Conditional_12_Template, 2, 0, "mat-error");
      i08.\u0275\u0275conditionalCreate(13, Contacto_Conditional_13_Template, 2, 0, "mat-error");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275elementStart(14, "mat-form-field", 2)(15, "mat-label");
      i08.\u0275\u0275text(16, "Email:");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275element(17, "input", 5);
      i08.\u0275\u0275conditionalCreate(18, Contacto_Conditional_18_Template, 2, 0, "mat-error");
      i08.\u0275\u0275conditionalCreate(19, Contacto_Conditional_19_Template, 2, 0, "mat-error");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275elementStart(20, "mat-form-field", 2)(21, "mat-label");
      i08.\u0275\u0275text(22, "Asunto:");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275element(23, "input", 6);
      i08.\u0275\u0275conditionalCreate(24, Contacto_Conditional_24_Template, 2, 0, "mat-error");
      i08.\u0275\u0275conditionalCreate(25, Contacto_Conditional_25_Template, 2, 0, "mat-error");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275elementStart(26, "mat-form-field", 2)(27, "mat-label");
      i08.\u0275\u0275text(28, "Mensaje:");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275element(29, "textarea", 7);
      i08.\u0275\u0275conditionalCreate(30, Contacto_Conditional_30_Template, 2, 0, "mat-error");
      i08.\u0275\u0275conditionalCreate(31, Contacto_Conditional_31_Template, 2, 0, "mat-error");
      i08.\u0275\u0275elementEnd();
      i08.\u0275\u0275elementStart(32, "span")(33, "button", 8);
      i08.\u0275\u0275text(34, "Enviar formulario");
      i08.\u0275\u0275elementEnd()()()();
    }
    if (rf & 2) {
      let tmp_1_0;
      let tmp_2_0;
      let tmp_3_0;
      let tmp_4_0;
      let tmp_5_0;
      let tmp_6_0;
      let tmp_7_0;
      let tmp_8_0;
      let tmp_9_0;
      let tmp_10_0;
      i08.\u0275\u0275advance();
      i08.\u0275\u0275property("formGroup", ctx.contactoForm);
      i08.\u0275\u0275advance(5);
      i08.\u0275\u0275conditional(((tmp_1_0 = ctx.contactoForm.get("nombre")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 6 : -1);
      i08.\u0275\u0275advance();
      i08.\u0275\u0275conditional(((tmp_2_0 = ctx.contactoForm.get("nombre")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["minlength"]) ? 7 : -1);
      i08.\u0275\u0275advance(5);
      i08.\u0275\u0275conditional(((tmp_3_0 = ctx.contactoForm.get("telefono")) == null ? null : tmp_3_0.errors == null ? null : tmp_3_0.errors["required"]) ? 12 : -1);
      i08.\u0275\u0275advance();
      i08.\u0275\u0275conditional(((tmp_4_0 = ctx.contactoForm.get("telefono")) == null ? null : tmp_4_0.errors == null ? null : tmp_4_0.errors["pattern"]) ? 13 : -1);
      i08.\u0275\u0275advance(5);
      i08.\u0275\u0275conditional(((tmp_5_0 = ctx.contactoForm.get("email")) == null ? null : tmp_5_0.errors == null ? null : tmp_5_0.errors["required"]) ? 18 : -1);
      i08.\u0275\u0275advance();
      i08.\u0275\u0275conditional(((tmp_6_0 = ctx.contactoForm.get("email")) == null ? null : tmp_6_0.errors == null ? null : tmp_6_0.errors["email"]) ? 19 : -1);
      i08.\u0275\u0275advance(5);
      i08.\u0275\u0275conditional(((tmp_7_0 = ctx.contactoForm.get("asunto")) == null ? null : tmp_7_0.errors == null ? null : tmp_7_0.errors["required"]) ? 24 : -1);
      i08.\u0275\u0275advance();
      i08.\u0275\u0275conditional(((tmp_8_0 = ctx.contactoForm.get("asunto")) == null ? null : tmp_8_0.errors == null ? null : tmp_8_0.errors["minlength"]) ? 25 : -1);
      i08.\u0275\u0275advance(5);
      i08.\u0275\u0275conditional(((tmp_9_0 = ctx.contactoForm.get("mensaje")) == null ? null : tmp_9_0.errors == null ? null : tmp_9_0.errors["required"]) ? 30 : -1);
      i08.\u0275\u0275advance();
      i08.\u0275\u0275conditional(((tmp_10_0 = ctx.contactoForm.get("mensaje")) == null ? null : tmp_10_0.errors == null ? null : tmp_10_0.errors["minlength"]) ? 31 : -1);
    }
  }, dependencies: [FormsModule2, i15.\u0275NgNoValidate, i15.NgSelectOption, i15.\u0275NgSelectMultipleOption, i15.DefaultValueAccessor, i15.NumberValueAccessor, i15.RangeValueAccessor, i15.CheckboxControlValueAccessor, i15.SelectControlValueAccessor, i15.SelectMultipleControlValueAccessor, i15.RadioControlValueAccessor, i15.NgControlStatus, i15.NgControlStatusGroup, i15.RequiredValidator, i15.MinLengthValidator, i15.MaxLengthValidator, i15.PatternValidator, i15.CheckboxRequiredValidator, i15.EmailValidator, i15.MinValidator, i15.MaxValidator, i15.NgModel, i15.NgModelGroup, i15.NgForm, ReactiveFormsModule, i15.FormControlDirective, i15.FormGroupDirective, i15.FormControlName, i15.FormGroupName, i15.FormArrayName, MatInputModule2, i23.MatInput, i23.MatFormField, i23.MatLabel, i23.MatHint, i23.MatError, i23.MatPrefix, i23.MatSuffix, i33.Dir, i43.CdkAutofill, i43.CdkTextareaAutosize, MatButtonModule, i52.MatButton, i52.MatMiniFabButton, i52.MatIconButton, i52.MatFabButton], styles: ["\n\ndiv[_ngcontent-%COMP%] {\n  width: 50%;\n  margin: 0 auto;\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n.example-full-width[_ngcontent-%COMP%] {\n  width: 100%;\n}\nspan[_ngcontent-%COMP%] {\n  text-align: center;\n  display: block;\n}\n/*# sourceMappingURL=contacto.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassMetadata(Contacto, [{
    type: Component5,
    args: [{ selector: "app-contacto", imports: [FormsModule2, ReactiveFormsModule, MatInputModule2, MatButtonModule], template: `<div class="mat-elevation-z8">
  <form [formGroup]="contactoForm">
      <mat-form-field class="example-full-width">
        <mat-label>Nombre:</mat-label>
        <input type="text" matInput formControlName="nombre">
        @if (this.contactoForm.get('nombre')?.errors?.['required']) {
          <mat-error>* Campo obligatorio</mat-error>
        }
        @if (this.contactoForm.get('nombre')?.errors?.['minlength']) {
          <mat-error>* Longitud minima 3 caracteres</mat-error>
        }
      </mat-form-field>

      <mat-form-field class="example-full-width">
        <mat-label>Telefono:</mat-label>
        <input type="text" matInput formControlName="telefono">
        @if (this.contactoForm.get('telefono')?.errors?.['required']) {
          <mat-error>* Campo obligatorio</mat-error>
        }
        @if (this.contactoForm.get('telefono')?.errors?.['pattern']) {
          <mat-error>* Debe tener 9 digitos y comenzar por 6,7 \xF3 9</mat-error>
        }
      </mat-form-field>

      <mat-form-field class="example-full-width">
        <mat-label>Email:</mat-label>
        <input type="text" matInput formControlName="email">
        @if (this.contactoForm.get('email')?.errors?.['required']) {
          <mat-error>* Campo obligatorio</mat-error>
        }
        @if (this.contactoForm.get('email')?.errors?.['email']) {
          <mat-error>* Email no es valido</mat-error>
        }
      </mat-form-field>

      <mat-form-field class="example-full-width">
        <mat-label>Asunto:</mat-label>
        <input type="text" matInput formControlName="asunto">
        @if (this.contactoForm.get('asunto')?.errors?.['required']) {
          <mat-error>* Campo obligatorio</mat-error>
        }
        @if (this.contactoForm.get('asunto')?.errors?.['minlength']) {
          <mat-error>* Longitud minima 5 caracteres</mat-error>
        }
      </mat-form-field>

      <mat-form-field class="example-full-width">
        <mat-label>Mensaje:</mat-label>
        <textarea rows="6" matInput formControlName="mensaje"></textarea>
        @if (this.contactoForm.get('mensaje')?.errors?.['required']) {
          <mat-error>* Campo obligatorio</mat-error>
        }
        @if (this.contactoForm.get('mensaje')?.errors?.['minlength']) {
          <mat-error>* Longitud minima 10 caracteres</mat-error>
        }
      </mat-form-field>

      <span>
        <button matButton="elevated">Enviar formulario</button>
      </span>
  </form>
</div>


<!--
  - mensaje: area de texto, obligatorio y longitud minima 10
-->
`, styles: ["/* src/app/components/contacto/contacto.css */\ndiv {\n  width: 50%;\n  margin: 0 auto;\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n.example-full-width {\n  width: 100%;\n}\nspan {\n  text-align: center;\n  display: block;\n}\n/*# sourceMappingURL=contacto.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(Contacto, { className: "Contacto", filePath: "src/app/components/contacto/contacto.ts", lineNumber: 12 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fcontacto%2Fcontacto.ts%40Contacto";
  function Contacto_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i08.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i08.\u0275\u0275replaceMetadata(Contacto, m.default, [i08, i15, i23, i33, i43, i52], [FormsModule2, ReactiveFormsModule, MatInputModule2, MatButtonModule, Component5], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Contacto_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Contacto_HmrLoad(d.timestamp)));
})();

// src/app/components/error/error.ts
import { Component as Component6 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i09 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var Error = class _Error {
  static \u0275fac = function Error_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Error)();
  };
  static \u0275cmp = /* @__PURE__ */ i09.\u0275\u0275defineComponent({ type: _Error, selectors: [["app-error"]], decls: 2, vars: 0, consts: [["src", "https://cdn.creativefabrica.com/2022/07/11/Error-404-page-not-found-illustration-Graphics-33990706-1-1-580x435.jpg", "alt", "error 404"]], template: function Error_Template(rf, ctx) {
    if (rf & 1) {
      i09.\u0275\u0275domElementStart(0, "div");
      i09.\u0275\u0275domElement(1, "img", 0);
      i09.\u0275\u0275domElementEnd();
    }
  }, styles: ["\n\ndiv[_ngcontent-%COMP%] {\n  width: 70%;\n  margin: 0 auto;\n}\nimg[_ngcontent-%COMP%] {\n  width: 100%;\n}\n/*# sourceMappingURL=error.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassMetadata(Error, [{
    type: Component6,
    args: [{ selector: "app-error", imports: [], template: '<div>\n  <img src="https://cdn.creativefabrica.com/2022/07/11/Error-404-page-not-found-illustration-Graphics-33990706-1-1-580x435.jpg"\n      alt="error 404" />\n</div>\n\n', styles: ["/* src/app/components/error/error.css */\ndiv {\n  width: 70%;\n  margin: 0 auto;\n}\nimg {\n  width: 100%;\n}\n/*# sourceMappingURL=error.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(Error, { className: "Error", filePath: "src/app/components/error/error.ts", lineNumber: 9 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Ferror%2Ferror.ts%40Error";
  function Error_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i09.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i09.\u0275\u0275replaceMetadata(Error, m.default, [i09], [Component6], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Error_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Error_HmrLoad(d.timestamp)));
})();

// src/app/components/login/login.ts
import { Router } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";

// src/app/services/servicio-auth.ts
import { Injectable as Injectable3, inject as inject8 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { Auth, authState, signInWithEmailAndPassword, signOut } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_fire_auth.js?v=3385e9c1";
import * as i010 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var ServicioAuth = class _ServicioAuth {
  //private logado = false;
  auth = inject8(Auth);
  login(email, pw) {
    return signInWithEmailAndPassword(this.auth, email, pw);
  }
  logout() {
    return signOut(this.auth);
  }
  isLogado() {
    return authState(this.auth);
  }
  static \u0275fac = function ServicioAuth_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ServicioAuth)();
  };
  static \u0275prov = /* @__PURE__ */ i010.\u0275\u0275defineInjectable({ token: _ServicioAuth, factory: _ServicioAuth.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i010.\u0275setClassMetadata(ServicioAuth, [{
    type: Injectable3,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/components/login/login.ts
import { Component as Component7, inject as inject9 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { FormsModule as FormsModule3 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_forms.js?v=3385e9c1";
import { MatInputModule as MatInputModule3 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_input.js?v=3385e9c1";
import { MatButtonModule as MatButtonModule2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_button.js?v=3385e9c1";
import * as i011 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import * as i16 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_forms.js?v=3385e9c1";
import * as i24 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_input.js?v=3385e9c1";
import * as i34 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_bidi.js?v=3385e9c1";
import * as i44 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_cdk_text-field.js?v=3385e9c1";
import * as i53 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_material_button.js?v=3385e9c1";
var Login = class _Login {
  usuario = "";
  pw = "";
  auth = inject9(ServicioAuth);
  router = inject9(Router);
  autenticacion() {
    this.auth.login(this.usuario, this.pw).then((datos) => {
      console.log(datos);
      if (datos != null) {
        this.router.navigate(["/admin"]);
      }
    }).catch((err) => {
      console.log(err);
    });
  }
  static \u0275fac = function Login_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Login)();
  };
  static \u0275cmp = /* @__PURE__ */ i011.\u0275\u0275defineComponent({ type: _Login, selectors: [["app-login"]], decls: 16, vars: 2, consts: [[1, "example-full-width"], ["matInput", "", 3, "ngModelChange", "ngModel"], ["matButton", "elevated", 3, "click"]], template: function Login_Template(rf, ctx) {
    if (rf & 1) {
      i011.\u0275\u0275elementStart(0, "div")(1, "h2");
      i011.\u0275\u0275text(2, "Login");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(3, "mat-form-field", 0)(4, "mat-label");
      i011.\u0275\u0275text(5, "Email:");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(6, "input", 1);
      i011.\u0275\u0275twoWayListener("ngModelChange", function Login_Template_input_ngModelChange_6_listener($event) {
        i011.\u0275\u0275twoWayBindingSet(ctx.usuario, $event) || (ctx.usuario = $event);
        return $event;
      });
      i011.\u0275\u0275elementEnd()();
      i011.\u0275\u0275element(7, "br");
      i011.\u0275\u0275elementStart(8, "mat-form-field", 0)(9, "mat-label");
      i011.\u0275\u0275text(10, "Password:");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(11, "input", 1);
      i011.\u0275\u0275twoWayListener("ngModelChange", function Login_Template_input_ngModelChange_11_listener($event) {
        i011.\u0275\u0275twoWayBindingSet(ctx.pw, $event) || (ctx.pw = $event);
        return $event;
      });
      i011.\u0275\u0275elementEnd()();
      i011.\u0275\u0275element(12, "br");
      i011.\u0275\u0275elementStart(13, "span")(14, "button", 2);
      i011.\u0275\u0275listener("click", function Login_Template_button_click_14_listener() {
        return ctx.autenticacion();
      });
      i011.\u0275\u0275text(15, "Logarme");
      i011.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      i011.\u0275\u0275advance(6);
      i011.\u0275\u0275twoWayProperty("ngModel", ctx.usuario);
      i011.\u0275\u0275advance(5);
      i011.\u0275\u0275twoWayProperty("ngModel", ctx.pw);
    }
  }, dependencies: [FormsModule3, i16.\u0275NgNoValidate, i16.NgSelectOption, i16.\u0275NgSelectMultipleOption, i16.DefaultValueAccessor, i16.NumberValueAccessor, i16.RangeValueAccessor, i16.CheckboxControlValueAccessor, i16.SelectControlValueAccessor, i16.SelectMultipleControlValueAccessor, i16.RadioControlValueAccessor, i16.NgControlStatus, i16.NgControlStatusGroup, i16.RequiredValidator, i16.MinLengthValidator, i16.MaxLengthValidator, i16.PatternValidator, i16.CheckboxRequiredValidator, i16.EmailValidator, i16.MinValidator, i16.MaxValidator, i16.NgModel, i16.NgModelGroup, i16.NgForm, MatInputModule3, i24.MatInput, i24.MatFormField, i24.MatLabel, i24.MatHint, i24.MatError, i24.MatPrefix, i24.MatSuffix, i34.Dir, i44.CdkAutofill, i44.CdkTextareaAutosize, MatButtonModule2, i53.MatButton, i53.MatMiniFabButton, i53.MatIconButton, i53.MatFabButton], styles: ["\n\ndiv[_ngcontent-%COMP%] {\n  width: 50%;\n  margin: 0 auto;\n  margin-top: 20px;\n  background-color: gainsboro;\n}\n/*# sourceMappingURL=login.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassMetadata(Login, [{
    type: Component7,
    args: [{ selector: "app-login", imports: [FormsModule3, MatInputModule3, MatButtonModule2], template: '<div>\n  <h2>Login</h2>\n\n  <mat-form-field class="example-full-width">\n    <mat-label>Email:</mat-label>\n    <input matInput [(ngModel)]="usuario">\n  </mat-form-field> <br/>\n\n  <mat-form-field class="example-full-width">\n    <mat-label>Password:</mat-label>\n    <input matInput [(ngModel)]="pw">\n  </mat-form-field> <br/>\n\n  <span>\n    <button matButton="elevated" (click)="autenticacion()">Logarme</button>\n  </span>\n</div>\n', styles: ["/* src/app/components/login/login.css */\ndiv {\n  width: 50%;\n  margin: 0 auto;\n  margin-top: 20px;\n  background-color: gainsboro;\n}\n/*# sourceMappingURL=login.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(Login, { className: "Login", filePath: "src/app/components/login/login.ts", lineNumber: 15 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Flogin%2Flogin.ts%40Login";
  function Login_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i011.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i011.\u0275\u0275replaceMetadata(Login, m.default, [i011, i16, i24, i34, i44, i53], [FormsModule3, MatInputModule3, MatButtonModule2, Component7], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Login_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Login_HmrLoad(d.timestamp)));
})();

// src/app/components/admin/admin.ts
import { Component as Component8, inject as inject10 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { Router as Router2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";
import * as i012 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var Admin = class _Admin {
  auth = inject10(ServicioAuth);
  router = inject10(Router2);
  cerrarSesion() {
    this.auth.logout();
    this.router.navigate(["/home"]);
  }
  static \u0275fac = function Admin_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Admin)();
  };
  static \u0275cmp = /* @__PURE__ */ i012.\u0275\u0275defineComponent({ type: _Admin, selectors: [["app-admin"]], decls: 4, vars: 0, consts: [[3, "click"]], template: function Admin_Template(rf, ctx) {
    if (rf & 1) {
      i012.\u0275\u0275domElementStart(0, "h2");
      i012.\u0275\u0275text(1, "Zona privada del administrador de la aplicacion");
      i012.\u0275\u0275domElementEnd();
      i012.\u0275\u0275domElementStart(2, "button", 0);
      i012.\u0275\u0275domListener("click", function Admin_Template_button_click_2_listener() {
        return ctx.cerrarSesion();
      });
      i012.\u0275\u0275text(3, "Logout");
      i012.\u0275\u0275domElementEnd();
    }
  }, encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassMetadata(Admin, [{
    type: Component8,
    args: [{ selector: "app-admin", imports: [], template: '<h2>Zona privada del administrador de la aplicacion</h2>\n\n<button (click)="cerrarSesion()">Logout</button>\n' }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassDebugInfo(Admin, { className: "Admin", filePath: "src/app/components/admin/admin.ts", lineNumber: 11 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fadmin%2Fadmin.ts%40Admin";
  function Admin_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i012.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i012.\u0275\u0275replaceMetadata(Admin, m.default, [i012], [Component8], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Admin_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Admin_HmrLoad(d.timestamp)));
})();

// src/app/guards/auth-guard.ts
import { inject as inject11 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { Router as Router3 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";
import { map } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/rxjs_operators.js?v=3385e9c1";
var authGuard = () => {
  const auth = inject11(ServicioAuth);
  const router = inject11(Router3);
  return auth.isLogado().pipe(map((datos) => {
    if (datos != null) {
      return true;
    } else {
      return router.createUrlTree(["/login"]);
    }
  }));
};

// src/app/app.routes.ts
var routes = [
  { path: "home", component: Home },
  { path: "museos", component: Museos },
  { path: "detalle-museo/:id", component: DetalleMuseo },
  { path: "equipo", component: Equipo },
  { path: "contacto", component: Contacto },
  { path: "login", component: Login },
  { path: "admin", component: Admin, canActivate: [authGuard] },
  { path: "", redirectTo: "home", pathMatch: "full" },
  // localhost:4200
  { path: "**", component: Error }
];

// src/app/app.config.ts
import { provideHttpClient } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_common_http.js?v=3385e9c1";
import { provideTranslateService } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@ngx-translate_core.js?v=3385e9c1";
import { initializeApp, provideFirebaseApp } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_fire_app.js?v=3385e9c1";
import { provideAuth, getAuth } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_fire_auth.js?v=3385e9c1";

// src/environments/environment.ts
var environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDMAajB6mI0jC_iS4xkTI1DnHWuUz4kC_Y",
    authDomain: "angular-indra-anabel-10-julio.firebaseapp.com",
    projectId: "angular-indra-anabel-10-julio",
    storageBucket: "angular-indra-anabel-10-julio.firebasestorage.app",
    messagingSenderId: "387041210339",
    appId: "1:387041210339:web:d7d7cb7a3d9a6a8db57ad6"
  }
};

// src/app/app.config.ts
var appConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(),
    provideTranslateHttpLoader(),
    provideTranslateService({
      loader: provideTranslateHttpLoader({
        prefix: "./i18n/",
        suffix: ".json"
      })
    }),
    provideFirebaseApp(() => initializeApp(environment.firebaseConfig)),
    provideAuth(() => getAuth())
  ]
};

// src/app/app.ts
import { Component as Component12 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { RouterOutlet } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";

// src/app/components/header/header.ts
import { Component as Component9, inject as inject12 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { TranslatePipe, TranslateService as TranslateService2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@ngx-translate_core.js?v=3385e9c1";
import * as i013 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var Header = class _Header {
  idioma = "es";
  translate = inject12(TranslateService2);
  constructor() {
    this.translate.use(this.idioma);
  }
  cambiarIdioma(nuevoIdioma) {
    this.idioma = nuevoIdioma;
    this.translate.use(this.idioma);
  }
  static \u0275fac = function Header_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Header)();
  };
  static \u0275cmp = /* @__PURE__ */ i013.\u0275\u0275defineComponent({ type: _Header, selectors: [["app-header"]], decls: 9, vars: 3, consts: [["src", "logo.png", "alt", "Logo Comunidad de Madrid"], ["src", "banderas/spain.png", 3, "click"], ["src", "banderas/inglaterra.png", 3, "click"], ["src", "banderas/francia.png", 3, "click"], ["src", "banderas/alemania.png", 3, "click"]], template: function Header_Template(rf, ctx) {
    if (rf & 1) {
      i013.\u0275\u0275domElement(0, "img", 0);
      i013.\u0275\u0275domElementStart(1, "h1");
      i013.\u0275\u0275text(2);
      i013.\u0275\u0275pipe(3, "translate");
      i013.\u0275\u0275domElementEnd();
      i013.\u0275\u0275domElementStart(4, "span")(5, "img", 1);
      i013.\u0275\u0275domListener("click", function Header_Template_img_click_5_listener() {
        return ctx.cambiarIdioma("es");
      });
      i013.\u0275\u0275domElementEnd();
      i013.\u0275\u0275domElementStart(6, "img", 2);
      i013.\u0275\u0275domListener("click", function Header_Template_img_click_6_listener() {
        return ctx.cambiarIdioma("en");
      });
      i013.\u0275\u0275domElementEnd();
      i013.\u0275\u0275domElementStart(7, "img", 3);
      i013.\u0275\u0275domListener("click", function Header_Template_img_click_7_listener() {
        return ctx.cambiarIdioma("fr");
      });
      i013.\u0275\u0275domElementEnd();
      i013.\u0275\u0275domElementStart(8, "img", 4);
      i013.\u0275\u0275domListener("click", function Header_Template_img_click_8_listener() {
        return ctx.cambiarIdioma("de");
      });
      i013.\u0275\u0275domElementEnd()();
    }
    if (rf & 2) {
      i013.\u0275\u0275advance(2);
      i013.\u0275\u0275textInterpolate(i013.\u0275\u0275pipeBind1(3, 1, "header.titulo"));
    }
  }, dependencies: [TranslatePipe], styles: ["\n\nimg[_ngcontent-%COMP%] {\n  height: 100px;\n  float: left;\n}\nh1[_ngcontent-%COMP%] {\n  color: white;\n  text-align: center;\n  padding-top: 10px;\n}\nspan[_ngcontent-%COMP%] {\n  float: right;\n  margin-right: 15px;\n}\nspan[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 20px;\n  margin: 5px;\n}\n/*# sourceMappingURL=header.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i013.\u0275setClassMetadata(Header, [{
    type: Component9,
    args: [{ selector: "app-header", imports: [TranslatePipe], template: `<img src="logo.png" alt="Logo Comunidad de Madrid" />
<h1>{{ "header.titulo" | translate}}</h1>

<span>
  <img (click)="cambiarIdioma('es')" src="banderas/spain.png" />
  <img (click)="cambiarIdioma('en')" src="banderas/inglaterra.png" />
  <img (click)="cambiarIdioma('fr')" src="banderas/francia.png" />
  <img (click)="cambiarIdioma('de')" src="banderas/alemania.png" />
</span>
`, styles: ["/* src/app/components/header/header.css */\nimg {\n  height: 100px;\n  float: left;\n}\nh1 {\n  color: white;\n  text-align: center;\n  padding-top: 10px;\n}\nspan {\n  float: right;\n  margin-right: 15px;\n}\nspan img {\n  height: 20px;\n  margin: 5px;\n}\n/*# sourceMappingURL=header.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i013.\u0275setClassDebugInfo(Header, { className: "Header", filePath: "src/app/components/header/header.ts", lineNumber: 10 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fheader%2Fheader.ts%40Header";
  function Header_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i013.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i013.\u0275\u0275replaceMetadata(Header, m.default, [i013], [TranslatePipe, Component9], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Header_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Header_HmrLoad(d.timestamp)));
})();

// src/app/components/footer/footer.ts
import { Component as Component10 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { TranslatePipe as TranslatePipe2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@ngx-translate_core.js?v=3385e9c1";
import * as i014 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var _c05 = () => ({ nombre: "Anabel" });
var Footer = class _Footer {
  static \u0275fac = function Footer_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Footer)();
  };
  static \u0275cmp = /* @__PURE__ */ i014.\u0275\u0275defineComponent({ type: _Footer, selectors: [["app-footer"]], decls: 3, vars: 5, template: function Footer_Template(rf, ctx) {
    if (rf & 1) {
      i014.\u0275\u0275domElementStart(0, "p");
      i014.\u0275\u0275text(1);
      i014.\u0275\u0275pipe(2, "translate");
      i014.\u0275\u0275domElementEnd();
    }
    if (rf & 2) {
      i014.\u0275\u0275advance();
      i014.\u0275\u0275textInterpolate(i014.\u0275\u0275pipeBind2(2, 1, "footer.pie_pagina", i014.\u0275\u0275pureFunction0(4, _c05)));
    }
  }, dependencies: [TranslatePipe2], styles: ["\n\np[_ngcontent-%COMP%] {\n  color: white;\n  float: right;\n  margin-right: 10px;\n  font-style: italic;\n}\n/*# sourceMappingURL=footer.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassMetadata(Footer, [{
    type: Component10,
    args: [{ selector: "app-footer", imports: [TranslatePipe2], template: `<p>{{ "footer.pie_pagina" | translate: {nombre: 'Anabel'} }}</p>
`, styles: ["/* src/app/components/footer/footer.css */\np {\n  color: white;\n  float: right;\n  margin-right: 10px;\n  font-style: italic;\n}\n/*# sourceMappingURL=footer.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassDebugInfo(Footer, { className: "Footer", filePath: "src/app/components/footer/footer.ts", lineNumber: 10 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Ffooter%2Ffooter.ts%40Footer";
  function Footer_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i014.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i014.\u0275\u0275replaceMetadata(Footer, m.default, [i014], [TranslatePipe2, Component10], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Footer_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Footer_HmrLoad(d.timestamp)));
})();

// src/app/components/navbar/navbar.ts
import { Component as Component11 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
import { RouterLink as RouterLink2 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_router.js?v=3385e9c1";
import { TranslatePipe as TranslatePipe3 } from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@ngx-translate_core.js?v=3385e9c1";
import * as i015 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var Navbar = class _Navbar {
  static \u0275fac = function Navbar_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Navbar)();
  };
  static \u0275cmp = /* @__PURE__ */ i015.\u0275\u0275defineComponent({ type: _Navbar, selectors: [["app-navbar"]], decls: 28, vars: 15, consts: [["data-bs-theme", "dark", 1, "navbar", "bg-dark", "navbar-expand-lg", "bg-body-tertiary"], [1, "container-fluid"], ["href", "#", 1, "navbar-brand"], ["src", "logo.png", "alt", "Logo", "height", "24", 1, "d-inline-block", "align-text-top"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#navbarNav", "aria-controls", "navbarNav", "aria-expanded", "false", "aria-label", "Toggle navigation", 1, "navbar-toggler"], [1, "navbar-toggler-icon"], ["id", "navbarNav", 1, "collapse", "navbar-collapse"], [1, "navbar-nav"], [1, "nav-item"], ["routerLink", "home", 1, "nav-link"], ["routerLink", "museos", 1, "nav-link"], ["routerLink", "equipo", 1, "nav-link"], ["routerLink", "contacto", 1, "nav-link"], ["routerLink", "admin", 1, "nav-link"]], template: function Navbar_Template(rf, ctx) {
    if (rf & 1) {
      i015.\u0275\u0275elementStart(0, "nav", 0)(1, "div", 1)(2, "a", 2);
      i015.\u0275\u0275element(3, "img", 3);
      i015.\u0275\u0275elementEnd();
      i015.\u0275\u0275elementStart(4, "button", 4);
      i015.\u0275\u0275element(5, "span", 5);
      i015.\u0275\u0275elementEnd();
      i015.\u0275\u0275elementStart(6, "div", 6)(7, "ul", 7)(8, "li", 8)(9, "a", 9);
      i015.\u0275\u0275text(10);
      i015.\u0275\u0275pipe(11, "translate");
      i015.\u0275\u0275elementEnd()();
      i015.\u0275\u0275elementStart(12, "li", 8)(13, "a", 10);
      i015.\u0275\u0275text(14);
      i015.\u0275\u0275pipe(15, "translate");
      i015.\u0275\u0275elementEnd()();
      i015.\u0275\u0275elementStart(16, "li", 8)(17, "a", 11);
      i015.\u0275\u0275text(18);
      i015.\u0275\u0275pipe(19, "translate");
      i015.\u0275\u0275elementEnd()();
      i015.\u0275\u0275elementStart(20, "li", 8)(21, "a", 12);
      i015.\u0275\u0275text(22);
      i015.\u0275\u0275pipe(23, "translate");
      i015.\u0275\u0275elementEnd()();
      i015.\u0275\u0275elementStart(24, "li", 8)(25, "a", 13);
      i015.\u0275\u0275text(26);
      i015.\u0275\u0275pipe(27, "translate");
      i015.\u0275\u0275elementEnd()()()()()();
    }
    if (rf & 2) {
      i015.\u0275\u0275advance(10);
      i015.\u0275\u0275textInterpolate(i015.\u0275\u0275pipeBind1(11, 5, "navbar.home"));
      i015.\u0275\u0275advance(4);
      i015.\u0275\u0275textInterpolate(i015.\u0275\u0275pipeBind1(15, 7, "navbar.museos"));
      i015.\u0275\u0275advance(4);
      i015.\u0275\u0275textInterpolate(i015.\u0275\u0275pipeBind1(19, 9, "navbar.equipo"));
      i015.\u0275\u0275advance(4);
      i015.\u0275\u0275textInterpolate(i015.\u0275\u0275pipeBind1(23, 11, "navbar.contacto"));
      i015.\u0275\u0275advance(4);
      i015.\u0275\u0275textInterpolate(i015.\u0275\u0275pipeBind1(27, 13, "navbar.admin"));
    }
  }, dependencies: [RouterLink2, TranslatePipe3], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i015.\u0275setClassMetadata(Navbar, [{
    type: Component11,
    args: [{ selector: "app-navbar", imports: [RouterLink2, TranslatePipe3], template: '<nav class="navbar bg-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">\n  <div class="container-fluid">\n    <a class="navbar-brand" href="#">\n      <img src="logo.png" alt="Logo"  height="24" class="d-inline-block align-text-top">\n    </a>\n    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">\n      <span class="navbar-toggler-icon"></span>\n    </button>\n    <div class="collapse navbar-collapse" id="navbarNav">\n      <ul class="navbar-nav">\n        <li class="nav-item">\n          <a class="nav-link" routerLink="home">{{"navbar.home" | translate}}</a>\n        </li>\n        <li class="nav-item">\n          <a class="nav-link" routerLink="museos">{{"navbar.museos" | translate}}</a>\n        </li>\n        <li class="nav-item">\n          <a class="nav-link" routerLink="equipo">{{"navbar.equipo" | translate}}</a>\n        </li>\n        <li class="nav-item">\n          <a class="nav-link" routerLink="contacto">{{"navbar.contacto" | translate}}</a>\n        </li>\n        <li class="nav-item">\n          <a class="nav-link" routerLink="admin">{{"navbar.admin" | translate}}</a>\n        </li>\n      </ul>\n    </div>\n  </div>\n</nav>\n' }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i015.\u0275setClassDebugInfo(Navbar, { className: "Navbar", filePath: "src/app/components/navbar/navbar.ts", lineNumber: 11 });
})();
(() => {
  const id = "src%2Fapp%2Fcomponents%2Fnavbar%2Fnavbar.ts%40Navbar";
  function Navbar_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i015.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i015.\u0275\u0275replaceMetadata(Navbar, m.default, [i015], [RouterLink2, TranslatePipe3, Component11], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Navbar_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Navbar_HmrLoad(d.timestamp)));
})();

// src/app/app.ts
import * as i016 from "/@fs/Users/anabel/Desktop/Angular20_Indra_6_Julio_2026/proyecto-turismo/.angular/cache/20.3.31/proyecto-turismo/vite/deps/@angular_core.js?v=3385e9c1";
var App = class _App {
  static \u0275fac = function App_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _App)();
  };
  static \u0275cmp = /* @__PURE__ */ i016.\u0275\u0275defineComponent({ type: _App, selectors: [["app-root"]], decls: 8, vars: 0, template: function App_Template(rf, ctx) {
    if (rf & 1) {
      i016.\u0275\u0275elementStart(0, "header");
      i016.\u0275\u0275element(1, "app-header");
      i016.\u0275\u0275elementEnd();
      i016.\u0275\u0275elementStart(2, "nav");
      i016.\u0275\u0275element(3, "app-navbar");
      i016.\u0275\u0275elementEnd();
      i016.\u0275\u0275elementStart(4, "section");
      i016.\u0275\u0275element(5, "router-outlet");
      i016.\u0275\u0275elementEnd();
      i016.\u0275\u0275elementStart(6, "footer");
      i016.\u0275\u0275element(7, "app-footer");
      i016.\u0275\u0275elementEnd();
    }
  }, dependencies: [RouterOutlet, Header, Footer, Navbar], styles: ["\n\nheader[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: rgb(214, 11, 19);\n}\nsection[_ngcontent-%COMP%] {\n  min-height: 400px;\n}\nfooter[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 60px;\n  background-color: rgb(214, 11, 19);\n}\n/*# sourceMappingURL=app.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i016.\u0275setClassMetadata(App, [{
    type: Component12,
    args: [{ selector: "app-root", imports: [RouterOutlet, Header, Footer, Navbar], template: "<header>\n  <app-header></app-header>\n</header>\n\n<nav>\n  <app-navbar></app-navbar>\n</nav>\n\n<section>\n  <router-outlet></router-outlet>\n</section>\n\n<footer>\n  <app-footer></app-footer>\n</footer>\n", styles: ["/* src/app/app.css */\nheader {\n  width: 100%;\n  height: 100px;\n  background-color: rgb(214, 11, 19);\n}\nsection {\n  min-height: 400px;\n}\nfooter {\n  width: 100%;\n  height: 60px;\n  background-color: rgb(214, 11, 19);\n}\n/*# sourceMappingURL=app.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i016.\u0275setClassDebugInfo(App, { className: "App", filePath: "src/app/app.ts", lineNumber: 13 });
})();
(() => {
  const id = "src%2Fapp%2Fapp.ts%40App";
  function App_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i016.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i016.\u0275\u0275replaceMetadata(App, m.default, [i016], [RouterOutlet, Header, Footer, Navbar, Component12], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && App_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && App_HmrLoad(d.timestamp)));
})();

// src/main.ts
bootstrapApplication(App, appConfig).catch((err) => console.error(err));


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluLnRzIiwic3JjL2FwcC9hcHAuY29uZmlnLnRzIiwic3JjL2FwcC9jb21wb25lbnRzL2hvbWUvaG9tZS50cyIsInNyYy9hcHAvY29tcG9uZW50cy9ob21lL2hvbWUuaHRtbCIsInNyYy9hcHAvc2VydmljZXMvc2VydmljaW8tbXVzZW9zLnRzIiwic3JjL2FwcC9jb21wb25lbnRzL211c2Vvcy9tdXNlb3MudHMiLCJzcmMvYXBwL2NvbXBvbmVudHMvbXVzZW9zL211c2Vvcy5odG1sIiwic3JjL2FwcC9waXBlcy9lc3RhZG8tcGlwZS50cyIsInNyYy9hcHAvY29tcG9uZW50cy9kZXRhbGxlLW11c2VvL2RldGFsbGUtbXVzZW8udHMiLCJzcmMvYXBwL2NvbXBvbmVudHMvZGV0YWxsZS1tdXNlby9kZXRhbGxlLW11c2VvLmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvZXF1aXBvL2VxdWlwby50cyIsInNyYy9hcHAvY29tcG9uZW50cy9lcXVpcG8vZXF1aXBvLmh0bWwiLCJzcmMvYXBwL3NlcnZpY2VzL3NlcnZpY2lvLWVxdWlwby50cyIsInNyYy9hcHAvY29tcG9uZW50cy9jb250YWN0by9jb250YWN0by50cyIsInNyYy9hcHAvY29tcG9uZW50cy9jb250YWN0by9jb250YWN0by5odG1sIiwic3JjL2FwcC9jb21wb25lbnRzL2Vycm9yL2Vycm9yLnRzIiwic3JjL2FwcC9jb21wb25lbnRzL2Vycm9yL2Vycm9yLmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvbG9naW4vbG9naW4udHMiLCJzcmMvYXBwL2NvbXBvbmVudHMvbG9naW4vbG9naW4uaHRtbCIsInNyYy9hcHAvc2VydmljZXMvc2VydmljaW8tYXV0aC50cyIsInNyYy9hcHAvY29tcG9uZW50cy9hZG1pbi9hZG1pbi50cyIsInNyYy9hcHAvY29tcG9uZW50cy9hZG1pbi9hZG1pbi5odG1sIiwic3JjL2FwcC9ndWFyZHMvYXV0aC1ndWFyZC50cyIsInNyYy9hcHAvYXBwLnJvdXRlcy50cyIsInNyYy9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQudHMiLCJzcmMvYXBwL2FwcC50cyIsInNyYy9hcHAvYXBwLmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci50cyIsInNyYy9hcHAvY29tcG9uZW50cy9oZWFkZXIvaGVhZGVyLmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvZm9vdGVyL2Zvb3Rlci50cyIsInNyYy9hcHAvY29tcG9uZW50cy9mb290ZXIvZm9vdGVyLmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudHMvbmF2YmFyL25hdmJhci50cyIsInNyYy9hcHAvY29tcG9uZW50cy9uYXZiYXIvbmF2YmFyLmh0bWwiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYm9vdHN0cmFwQXBwbGljYXRpb24gfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7IGFwcENvbmZpZyB9IGZyb20gJy4vYXBwL2FwcC5jb25maWcnO1xuaW1wb3J0IHsgQXBwIH0gZnJvbSAnLi9hcHAvYXBwJztcblxuYm9vdHN0cmFwQXBwbGljYXRpb24oQXBwLCBhcHBDb25maWcpXG4gIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmVycm9yKGVycikpO1xuIiwiaW1wb3J0IHsgcHJvdmlkZVRyYW5zbGF0ZUh0dHBMb2FkZXIgfSBmcm9tICdAbmd4LXRyYW5zbGF0ZS9odHRwLWxvYWRlcic7XG5pbXBvcnQgeyBBcHBsaWNhdGlvbkNvbmZpZywgcHJvdmlkZUJyb3dzZXJHbG9iYWxFcnJvckxpc3RlbmVycywgcHJvdmlkZVpvbmVDaGFuZ2VEZXRlY3Rpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IHByb3ZpZGVSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuXG5pbXBvcnQgeyByb3V0ZXMgfSBmcm9tICcuL2FwcC5yb3V0ZXMnO1xuaW1wb3J0IHsgcHJvdmlkZUh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBwcm92aWRlVHJhbnNsYXRlU2VydmljZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuXG5pbXBvcnQgeyBpbml0aWFsaXplQXBwLCBwcm92aWRlRmlyZWJhc2VBcHAgfSBmcm9tICdAYW5ndWxhci9maXJlL2FwcCc7XG5pbXBvcnQgeyBwcm92aWRlQXV0aCwgZ2V0QXV0aCB9IGZyb20gJ0Bhbmd1bGFyL2ZpcmUvYXV0aCc7XG5pbXBvcnQgeyBlbnZpcm9ubWVudCB9IGZyb20gJy4uL2Vudmlyb25tZW50cy9lbnZpcm9ubWVudCc7XG5cbmV4cG9ydCBjb25zdCBhcHBDb25maWc6IEFwcGxpY2F0aW9uQ29uZmlnID0ge1xuICBwcm92aWRlcnM6IFtcbiAgICBwcm92aWRlQnJvd3Nlckdsb2JhbEVycm9yTGlzdGVuZXJzKCksXG4gICAgcHJvdmlkZVpvbmVDaGFuZ2VEZXRlY3Rpb24oeyBldmVudENvYWxlc2Npbmc6IHRydWUgfSksXG4gICAgcHJvdmlkZVJvdXRlcihyb3V0ZXMpLFxuICAgIHByb3ZpZGVIdHRwQ2xpZW50KCksXG4gICAgcHJvdmlkZVRyYW5zbGF0ZUh0dHBMb2FkZXIoKSxcbiAgICBwcm92aWRlVHJhbnNsYXRlU2VydmljZSh7XG4gICAgICBsb2FkZXI6IHByb3ZpZGVUcmFuc2xhdGVIdHRwTG9hZGVyKHtcbiAgICAgICAgcHJlZml4OiAnLi9pMThuLycsXG4gICAgICAgIHN1ZmZpeDogJy5qc29uJ1xuICAgICAgfSlcbiAgICB9KSxcbiAgICBwcm92aWRlRmlyZWJhc2VBcHAoKCkgPT4gaW5pdGlhbGl6ZUFwcChlbnZpcm9ubWVudC5maXJlYmFzZUNvbmZpZykpLFxuICAgIHByb3ZpZGVBdXRoKCgpID0+IGdldEF1dGgoKSlcbiAgXVxufTtcbiIsImltcG9ydCB7IENvbXBvbmVudCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNdXNlbyB9IGZyb20gJy4uLy4uL21vZGVscy9tdXNlbyc7XG5pbXBvcnQgeyBTZXJ2aWNpb011c2VvcyB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3NlcnZpY2lvLW11c2Vvcyc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtaG9tZScsXG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGVdLFxuICB0ZW1wbGF0ZVVybDogJy4vaG9tZS5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2hvbWUuY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgSG9tZSB7XG5cbiAgbXVzZW9zOiBNdXNlb1tdID0gW107XG4gIGFjdGl2ZVNsaWRlSW5kZXggPSAwO1xuXG4gIHByaXZhdGUgbXVzZW9zU2VydmljZSA9IGluamVjdChTZXJ2aWNpb011c2Vvcyk7XG5cbiAgY29uc3RydWN0b3IoKXtcbiAgICB0aGlzLm11c2VvcyA9IHRoaXMubXVzZW9zU2VydmljZS5nZXRBbGwoKTtcbiAgfVxuXG4gIHNlbGVjdFNsaWRlKGlkeDogbnVtYmVyKXtcbiAgICB0aGlzLmFjdGl2ZVNsaWRlSW5kZXggPSBpZHg7XG4gIH1cblxufVxuIiwiPGRpdiBpZD1cImNhcm91c2VsRXhhbXBsZUNhcHRpb25zXCIgY2xhc3M9XCJjYXJvdXNlbCBzbGlkZVwiPlxuICA8ZGl2IGNsYXNzPVwiY2Fyb3VzZWwtaW5kaWNhdG9yc1wiPlxuICAgIEBmb3IgKG11c2VvIG9mIG11c2VvczsgdHJhY2sgJGluZGV4KXtcbiAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgZGF0YS1icy10YXJnZXQ9XCIjY2Fyb3VzZWxFeGFtcGxlSW5kaWNhdG9yc1wiXG4gICAgICAgICAgICBbYXR0ci5kYXRhLWJzLXNsaWRlLXRvXT1cIiRpbmRleFwiXG4gICAgICAgICAgICBbY2xhc3MuYWN0aXZlXT1cImFjdGl2ZVNsaWRlSW5kZXggPT09ICRpbmRleFwiXG4gICAgICAgICAgICBbYXR0ci5hcmlhLWN1cnJlbnRdPVwiYWN0aXZlU2xpZGVJbmRleCA9PT0gJGluZGV4ID8gJ3RydWUnIDogbnVsbFwiXG4gICAgICAgICAgICBbYXR0ci5hcmlhLWxhYmVsXT1cIidTbGlkZSAnICsgbXVzZW8uaWRcIlxuICAgICAgICAgICAgKGNsaWNrKT1cInNlbGVjdFNsaWRlKCRpbmRleClcIlxuICAgICAgICAgID48L2J1dHRvbj5cbiAgICB9XG4gIDwvZGl2PlxuICA8ZGl2IGNsYXNzPVwiY2Fyb3VzZWwtaW5uZXJcIj5cbiAgICBAZm9yIChtdXNlbyBvZiBtdXNlb3M7IHRyYWNrICRpbmRleCl7XG4gICAgICA8ZGl2IGNsYXNzPVwiY2Fyb3VzZWwtaXRlbVwiIFtuZ0NsYXNzXT1cInthY3RpdmU6IG11c2VvLmlkID09IDF9XCI+XG4gICAgICAgIDxpbWcgc3JjPVwie3ttdXNlby5pbWFnZW59fVwiIGNsYXNzPVwiZC1ibG9jayB3LTEwMFwiIGFsdD1cInt7bXVzZW8ubm9tYnJlfX1cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcm91c2VsLWNhcHRpb24gZC1ub25lIGQtbWQtYmxvY2tcIj5cbiAgICAgICAgICA8aDU+e3ttdXNlby5ub21icmV9fTwvaDU+XG4gICAgICAgICAgPHA+e3ttdXNlby5kaXJlY2Npb259fTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICB9XG4gIDwvZGl2PlxuICA8YnV0dG9uIGNsYXNzPVwiY2Fyb3VzZWwtY29udHJvbC1wcmV2XCIgdHlwZT1cImJ1dHRvblwiIGRhdGEtYnMtdGFyZ2V0PVwiI2Nhcm91c2VsRXhhbXBsZUNhcHRpb25zXCIgZGF0YS1icy1zbGlkZT1cInByZXZcIj5cbiAgICA8c3BhbiBjbGFzcz1cImNhcm91c2VsLWNvbnRyb2wtcHJldi1pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9zcGFuPlxuICAgIDxzcGFuIGNsYXNzPVwidmlzdWFsbHktaGlkZGVuXCI+UHJldmlvdXM8L3NwYW4+XG4gIDwvYnV0dG9uPlxuICA8YnV0dG9uIGNsYXNzPVwiY2Fyb3VzZWwtY29udHJvbC1uZXh0XCIgdHlwZT1cImJ1dHRvblwiIGRhdGEtYnMtdGFyZ2V0PVwiI2Nhcm91c2VsRXhhbXBsZUNhcHRpb25zXCIgZGF0YS1icy1zbGlkZT1cIm5leHRcIj5cbiAgICA8c3BhbiBjbGFzcz1cImNhcm91c2VsLWNvbnRyb2wtbmV4dC1pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9zcGFuPlxuICAgIDxzcGFuIGNsYXNzPVwidmlzdWFsbHktaGlkZGVuXCI+TmV4dDwvc3Bhbj5cbiAgPC9idXR0b24+XG48L2Rpdj5cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE11c2VvIH0gZnJvbSAnLi4vbW9kZWxzL211c2VvJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIFNlcnZpY2lvTXVzZW9zIHtcblxuICBwcml2YXRlIG11c2VvczogTXVzZW9bXSA9IFtcbiAgICAgIHsgaWQ6IDEsIG5vbWJyZTogJ011c2VvIGRlbCBQcmFkbycsIHRlbGVmb25vOiAnOTEzIDMwIDI4IDAwJywgZGlyZWNjaW9uOiAnQ2FsbGUgZGUgUnVpeiBkZSBBbGFyY8OzbiwgMjMsIDI4MDE0IE1hZHJpZCcsIGhvcmFyaW86ICcxMDowMCDigJMgMjA6MDAnLCBpbWFnZW46ICdodHRwczovL3VwbG9hZC53aWtpbWVkaWEub3JnL3dpa2lwZWRpYS9jb21tb25zLzYvNjgvTXVzZW9fZGVsX1ByYWRvXzIwMTZfJTI4MjUxODU5Njk1OTklMjkuanBnJywgd2ViOiAnaHR0cHM6Ly93d3cubXVzZW9kZWxwcmFkby5lcy8nLCBjb29yZGVuYWRhczogWzQwLjQxMzc4MTgsIC0zLjY5MjEyNzFdLCBwcmVjaW86IDE1LCBhYmllcnRvOiB0cnVlIH0sXG4gICAgICB7IGlkOiAyLCBub21icmU6ICdSZWluYSBTb2ZpYScsIHRlbGVmb25vOiAnOTE3NzQxMDAwJywgZGlyZWNjaW9uOiAnQ2FsbGUgU2FudGEgSXNhYmVsJywgaG9yYXJpbzogJ0NpZXJyYSBhIGxhcyAyMTowMCcsIGltYWdlbjogJ2h0dHBzOi8vcmVjdXJzb3MubXVzZW9yZWluYXNvZmlhLmVzL3N0eWxlcy9sYXJnZV9sYW5kc2NhcGUvcHVibGljL1Zpc2l0YS9zYWJhdGluaS5qcGcud2VicCcsIHdlYjogJ2h0dHA6Ly93d3cubXVzZW9yZWluYXNvZmlhLmVzJywgY29vcmRlbmFkYXM6IFs0MC40MDg2NDQsIC0zLjY5Mzk5Ml0sIHByZWNpbzogMTUsIGFiaWVydG86IHRydWUgfSxcbiAgICAgIHsgaWQ6IDMsIG5vbWJyZTogJ0JpYmxpb3RlY2EgTmFjaW9uYWwnLCB0ZWxlZm9ubzogJyA5MSA1MTYgODkgNjcgLyA5MSA1ODAgNzcgNTknLCBkaXJlY2Npb246ICdQYXNlbyBkZSBSZWNvbGV0b3MsIDIwLTIyLiAyODA3MS4gTWFkcmlkLicsIGhvcmFyaW86ICdEZSBNYXJ0ZXMgYSBTYWJhZG8gZGUgMTAgYSAyMCBoLiBEb21pbmdvcyBkZSAxMCBhIDE0IGguJywgaW1hZ2VuOiAnaHR0cHM6Ly9wYXRyaW1vbmlveXBhaXNhamUubWFkcmlkLmVzL0ZXUHJvamVjdHMvbW9udW1lbnRhL0VkaWZpY2lvcy8yNTgyMS8wNC4xNC1pbWczQy5qcGcnLCB3ZWI6ICdtdXNlb0BibmUuZXMnLCBjb29yZGVuYWRhczogWzQwLjQyMzQ4NDk4NTE5MTEzLCAtMy42OTEwNDQ3MzA2ODI3OTU0XSwgcHJlY2lvOiAwLCBhYmllcnRvOiB0cnVlIH0sXG4gICAgICB7IGlkOiA0LCBub21icmU6IFwiTXVzZW8gVGh5c3NlblwiLCB0ZWxlZm9ubzogJzkxNzkxMTM3MCcsIGRpcmVjY2lvbjogXCJQYXNlbyBkZWwgUHJhZG8sIDhcIiwgaG9yYXJpbzogJzEwOjAwIGEgMTk6MDAnLCBpbWFnZW46ICdodHRwczovL3d3dy5tdXNlb3RoeXNzZW4ub3JnL3RoZW1lcy90aHlzc2VuL2ltZy90aHlzc2VuLXJlZGVzLXNvY2lhbGVzLmpwZycsIHdlYjogJ2h0dHBzOi8vd3d3Lm11c2VvdGh5c3Nlbi5vcmcvJywgY29vcmRlbmFkYXM6IFs0MC40MTYxMzczMzE5MjQ2NjYsIC0zLjY5NDkzMDg2NTU0NTE4N10sIHByZWNpbzogMTMsIGFiaWVydG86IHRydWUgfSxcbiAgICAgIHsgaWQ6IDUsIG5vbWJyZTogJ1JlYWwgYWNhZGVtaWEgZGUgQmVsbGFzIEFydGVzIGRlIFNhbiBGZXJuYW5kbycsIHRlbGVmb25vOiAnKzM0IDkxLTUyNCAwOCA2NCcsIGRpcmVjY2lvbjogJ0FsY2Fsw6EsIDEzIDI4MDE0IE1hZHJpZCcsIGhvcmFyaW86ICdNYXJ0ZXMgYSBkb21pbmdvIGRlIDEwOjAwIGEgMTU6MDAgaG9yYXMsIGluY2x1eWVuZG8gZmVzdGl2b3MuIEx1bmVzIGNlcnJhZG8uJywgaW1hZ2VuOiAnaHR0cHM6Ly93d3cucmVhbGFjYWRlbWlhYmVsbGFzYXJ0ZXNzYW5mZXJuYW5kby5jb20vd3AtY29udGVudC91cGxvYWRzLzIwMjMvMDIvRFNDMDAxOTEtc2NhbGVkLmpwZycsIHdlYjogJ2h0dHBzOi8vd3d3LnJlYWxhY2FkZW1pYWJlbGxhc2FydGVzc2FuZmVybmFuZG8uY29tL2VzJywgY29vcmRlbmFkYXM6IFs0MC40MTgwNDA1LCAtMy43MDI5Nzc1XSwgcHJlY2lvOiA4LCBhYmllcnRvOiB0cnVlIH0sXG4gICAgICB7IGlkOiA2LCBub21icmU6ICdNdXNlbyBBcnF1ZW9sw7NnaWNvJywgdGVsZWZvbm86ICc5MTU3Nzc5MTInLCBkaXJlY2Npb246ICdDYWxsZSBkZSBTZXJyYW5vLCAxMywgMjgwMDEgTWFkcmlkJywgaG9yYXJpbzogJzk6MzDigJMyMDowMCcsIGltYWdlbjogJ2h0dHBzOi8vZHluYW1pYy1tZWRpYS1jZG4udHJpcGFkdmlzb3IuY29tL21lZGlhL3Bob3RvLW8vMDcvMjYvOGIvNDQvZW50cmFkYS1tdXNlby1hcnF1ZW9sb2dpY28uanBnP3c9MTIwMCZoPTEyMDAmcz0xJywgd2ViOiAnaHR0cDovL3d3dy5tYW4uZXMvbWFuL2hvbWUuaHRtbCcsIGNvb3JkZW5hZGFzOiBbNDAuNDIzNTUzLCAtMy42ODk0MDJdLCBwcmVjaW86IDMsIGFiaWVydG86IHRydWUgfSxcbiAgICAgIHsgaWQ6IDcsIG5vbWJyZTogJ011c2VvIENpZW5jaWFzIE5hdHVyYWxlcycsIHRlbGVmb25vOiAnOTE0MTExMzI4JywgZGlyZWNjaW9uOiAnQy9Kb3PDqSBHdXRpZXJyZXogQWJhc2NhbCcsIGhvcmFyaW86ICcxMC4wMCBhIDE3LjAwJywgaW1hZ2VuOiAnaHR0cHM6Ly9lc3RhdGljb3MuZXNtYWRyaWQuY29tL2Nkbi9mYXJmdXR1cmUvdlJFQ0RuTlg4WnNzN1dCS1phU0F2WEw4MFlPM3ZTU3R1M0ctc0lkejlORS9tdGltZToxNjQ2NzI4OTkxL3NpdGVzL2RlZmF1bHQvZmlsZXMvc3R5bGVzL2NvbnRlbnRfdHlwZV9mdWxsL3B1YmxpYy9yZWN1cnNvc3R1cmlzdGljb3MvaW5mb3R1cmlzdGljYS9tdXNlb19kZV9jaWVuY2lhc19uYXR1cmFsZXNfNC5qcGc/aXRvaz0yc1hFaDVIWCcsIHdlYjogJ2h0dHA6Ly93d3cubW5jbi5jc2ljLmVzL2VzJywgY29vcmRlbmFkYXM6IFs0MC40NDA0MDYyLCAtMy42OTEyMjc5XSwgcHJlY2lvOiA3LCBhYmllcnRvOiB0cnVlIH0sXG4gICAgICB7IGlkOiA4LCBub21icmU6ICdNdXNlbyBkZWwgVHJhamUnLCB0ZWxlZm9ubzogJyszNCA5MSA1NTAgNDcgMDAnLCBkaXJlY2Npb246ICdBdmVuaWRhIGRlIEp1YW4gZGUgSGVycmVyYSwgMjI4MDQwJywgaG9yYXJpbzogJ01hci1Tw6FiOiA5OjMwLTE5OjAwIGg7IERvbS1GZXN0OiAxMDowMC0xNTowMCBoIEp1ZXZlcyAoanVsaW8geSBhZ29zdG8pOiA5OjMwIOKAkyAyMjozMCBoJywgaW1hZ2VuOiAnaHR0cHM6Ly9lc3RhdGljb3MuZXNtYWRyaWQuY29tL2Nkbi9mYXJmdXR1cmUva3ZKS29reFZEMVh4N0UyUnB6SW5JQlNWYkZPVDdZUzVZa0x2NF9NZEJQby9tdGltZToxNjM4MjY3NDUxL3NpdGVzL2RlZmF1bHQvZmlsZXMvcmVjdXJzb3N0dXJpc3RpY29zL2luZm90dXJpc3RpY2EvbXVzZW9fZGVsX3RyYWplX21hZHJpZF9kZXN0aW5vY19hbHZhcm9fbG9wZXpfMTMuanBnJywgd2ViOiAnaHR0cDovL3d3dy5jdWx0dXJheWRlcG9ydGUuZ29iLmVzL210cmFqZS9pbmljaW8uaHRtbCcsIGNvb3JkZW5hZGFzOiBbNDAuNDQwMDk3MiwgLTMuNzMxODY5M10sIHByZWNpbzogMywgYWJpZXJ0bzogdHJ1ZSB9LFxuICAgICAgeyBpZDogOSwgbm9tYnJlOiAnTXVzZW8gZGUgQ2llbmNpYXMgeSBUZWNub2xvZ2lhJywgdGVsZWZvbm86ICc5MTQyNTA5MTknLCBkaXJlY2Npb246ICdQYXJxdWUgZGUgQW5kYWx1Y2lhLiBDL1BpbnRvciBWZWzDoXpxdWV6LDUgMjgxMDAgQWxjb2JlbmRhcywgTWFkcmlkJywgaG9yYXJpbzogJzExOjAwLTE5OjAwJywgaW1hZ2VuOiAnaHR0cHM6Ly93d3cuZXNtYWRyaWQuY29tL3NpdGVzL2RlZmF1bHQvZmlsZXMvc3R5bGVzL2NvbnRlbnRfdHlwZV9mdWxsL3B1YmxpYy9yZWN1cnNvc3R1cmlzdGljb3MvaW5mb3R1cmlzdGljYS9tdXNlb19uYWNpb25hbF9kZV9jaWVuY2lhX3lfdGVjbm9sb2dpYS5qcGc/aXRvaz11VG5sNUxMbScsIHdlYjogJ2h0dHA6Ly93d3cubXVuY3l0LmVzLycsIGNvb3JkZW5hZGFzOiBbNDAuNTM3NTQzOSwgLTMuNjQzNjQyXSwgcHJlY2lvOiAzLjAsIGFiaWVydG86IHRydWUgfSxcbiAgICAgIHsgaWQ6IDEwLCBub21icmU6ICdNdXNlbyBkZSBMb3BlIGRlIFZlZ2EnLCB0ZWxlZm9ubzogJzkxNDI5OTIxNicsIGRpcmVjY2lvbjogJ0NhbGxlZGUgQ2VydmFudGVzLCAxMSwyODAxNCBNYWRyaWQnLCBob3JhcmlvOiAnTWFyLURvbTogMTA6MDAgLSAxODowMCcsIGltYWdlbjogJ2h0dHBzOi8vZHluYW1pYy1tZWRpYS1jZG4udHJpcGFkdmlzb3IuY29tL21lZGlhL3Bob3RvLW8vMmEvNjkvYzQvYjUvY2FwdGlvbi5qcGc/dz0xNDAwJmg9ODAwJnM9MScsIHdlYjogJ2h0dHA6Ly9jYXNhbXVzZW9sb3BlZGV2ZWdhLm9yZy9lcy8nLCBjb29yZGVuYWRhczogWzQwLjM5ODAzODUsIC0zLjcwNTQzMzRdLCBwcmVjaW86IDAsIGFiaWVydG86IHRydWUgfSxcbiAgICAgIHsgaWQ6IDExLCBub21icmU6ICdNdXNlbyBkZSBjZXJhJywgdGVsZWZvbm86ICcrMzQgOTEgMzE5IDkzIDMwJywgZGlyZWNjaW9uOiAnUGxhemEgZGUgQ29sw7NuLCAxJywgaG9yYXJpbzogJzExOjAw4oCTMTk6MDAnLCBpbWFnZW46ICdodHRwczovL21lZGlhLmlzdG9ja3Bob3RvLmNvbS9pZC84NjI1Nzk4MDQvZXMvZm90by92aXN0YS1leHRlcmlvci1kZWwtbXVzZW8tZGUtY2VyYS1kZS1tYWRyaWQuanBnP3M9MTcwNjY3YSZ3PTAmaz0yMCZjPWY0MWJHUHIxcTVwY1REdmZENVNzald0S2VkSF8wdUVvZE9TeDF4bFVHcE09Jywgd2ViOiAnaHR0cHM6Ly93d3cubXVzZW9kZWNlcmFkZW1hZHJpZC5jb20nLCBjb29yZGVuYWRhczogWzQwLjQyNTA2NDEsIC0zLjY5MzU5NzVdLCBwcmVjaW86IDE4LCBhYmllcnRvOiB0cnVlIH0sXG4gICAgICB7IGlkOiAxMiwgbm9tYnJlOiAnTXVzZW8gZGUgZGlidWpvIGUgaWx1c3RyYWNjacOzbicsIHRlbGVmb25vOiAnKzM0IDkxIDc1OCA4MyA3OScsIGRpcmVjY2lvbjogJ0FtYW5pZWwgMjktMzEuIDI4MDE1IE1hZHJpZCcsIGhvcmFyaW86ICdDZXJyYWRvIFRlbXBvcmFsbWVudGUnLCBpbWFnZW46ICdodHRwczovL2ltYWdlcy5hZHN0dGMuY29tL21lZGlhL2ltYWdlcy81MTJhL2YwYjgvYjNmYy80YjExL2E3MDAvYTZmNC9sYXJnZV9qcGcvMTMwOTE0NTMwMC1qZXN1cy1ncmFuYWRhLTUuanBnPzE0MTQyNjkwMDEnLCB3ZWI6ICdodHRwczovL211c2VvLmFiYy5lcy8nLCBjb29yZGVuYWRhczogWzQwLjQyNzY5MDQsIC0zLjcxMTc1ODhdLCBwcmVjaW86IDAsIGFiaWVydG86IGZhbHNlIH0sXG4gICAgICB7IGlkOiAxMywgbm9tYnJlOiAnTXVzZW8gZGUgbGEgaW1wcmVudGEnLCB0ZWxlZm9ubzogJzkxNDI5NDg4MScsIGRpcmVjY2lvbjogJzI4MDEyLCBDYWxsZSBkZSBDb25jZXBjacOzbiBKZXLDs25pbWEsIDE1LCAyODAxMiBNYWRyaWQnLCBob3JhcmlvOiAnMTA6MDAtMjA6MDAnLCBpbWFnZW46ICdodHRwczovL2FydGVkZW1hZHJpZC53b3JkcHJlc3MuY29tL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDExLzEyL3NhbGEtbWFxdWluYXMuanBnP3c9Nzg0Jmg9NTg4Jywgd2ViOiAnaHR0cHM6Ly9tdXNlb21hZHJpZC5jb20vaW1wcmVudGEtbXVuaWNpcGFsLWFydGVzLWRlbC1saWJyby8nLCBjb29yZGVuYWRhczogWzQwLjQxMzg5NzIsIC0zLjcwNTQ3MjJdLCBwcmVjaW86IDAsIGFiaWVydG86IHRydWUgfSxcbiAgICAgIHsgaWQ6IDE0LCBub21icmU6ICdNdXNlbyBOYXZhbCcsIHRlbGVmb25vOiAnKCszNCkgOTEgNTIzIDg1IDE2JywgZGlyZWNjaW9uOiAnIFBhc2VvIGRlbCBQcmFkbywgMyAyODAxNCAnLCBob3JhcmlvOiAnTWFyIC0gRG9tOiAxMDowMCAtIDE5OjAwIGggJywgaW1hZ2VuOiAnaHR0cHM6Ly93d3cuYXJraXBsdXMuY29tL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE5LzAyL211c2VvLW5hdmFsLWRlLW1hZHJpZC5qcGcnLCB3ZWI6ICdodHRwczovL3d3dy5lc21hZHJpZC5jb20vaW5mb3JtYWNpb24tdHVyaXN0aWNhL211c2VvLW5hdmFsJywgY29vcmRlbmFkYXM6IFs0MC40MTg1MTI1NzYwNTE0MywgLTMuNjkyODE5NDMwNjc5MTY5N10sIHByZWNpbzogMywgYWJpZXJ0bzogdHJ1ZSB9LFxuICAgICAgeyBpZDogMTUsIG5vbWJyZTogJ011c2VvIFNvcm9sbGEnLCB0ZWxlZm9ubzogJyszNCA5MSAzMTAgMTUgODQnLCBkaXJlY2Npb246ICdQYXNlbyBkZWwgR2VuZXJhbCBNYXJ0aW5leiBDYW1wb3MsIDM3LCAyODAxMCBNYWRyaWQnLCBob3JhcmlvOiAnOTozMC0yMDowMCcsIGltYWdlbjogJ2h0dHBzOi8vdXBsb2FkLndpa2ltZWRpYS5vcmcvd2lraXBlZGlhL2NvbW1vbnMvNC80ZS9NdXNlb19Tb3JvbGxhXyUyOE1hZHJpZCUyOV8wNy5qcGcnLCB3ZWI6ICdodHRwczovL3d3dy5jdWx0dXJheWRlcG9ydGUuZ29iLmVzL21zb3JvbGxhL2luaWNpby5odG1sJywgY29vcmRlbmFkYXM6IFs0MC40MzU0NTU1LCAtMy42OTQ3MTExXSwgcHJlY2lvOiAzLCBhYmllcnRvOiB0cnVlIH0sXG4gICAgICB7IGlkOiAxNiwgbm9tYnJlOiAnTXVzZW8gZGUgbGEgaWx1c2lvbicsIHRlbGVmb25vOiAnKzM0IDkxMSAwMyAzNCA1NScsIGRpcmVjY2lvbjogJ0NhbGxlIGRlbCBEci4gQ29ydGV6byA4JywgaG9yYXJpbzogJ0NpZXJyYSBhIGxhcyAyMjowMCcsIGltYWdlbjogJ2h0dHBzOi8vd3d3Lm1hZHJpZGxvd2Nvc3QuZXMvd3AtY29udGVudC91cGxvYWRzLzIwMjAvMDYvbXVzZW8tZGUtbGFzLWlsdXNpb25lcy03NzB4NDkyLmpwZycsIHdlYjogJ2h0dHBzOi8vbXVzZXVtb2ZpbGx1c2lvbnMuZXMvJywgY29vcmRlbmFkYXM6IFs0MC40MTM0NjY3LCAtMy43MDYwNzg4XSwgcHJlY2lvOiAxNSwgYWJpZXJ0bzogdHJ1ZSB9XG4gICAgXTtcblxuICAgIGdldEFsbCgpOiBNdXNlb1tde1xuICAgICAgcmV0dXJuIHRoaXMubXVzZW9zO1xuICAgIH1cblxuICAgIGJ1c2Nhck11c2VvKGlkOiBudW1iZXIpOiBNdXNlbyB8IHVuZGVmaW5lZHtcbiAgICAgIHJldHVybiB0aGlzLm11c2Vvcy5maW5kKGl0ZW0gPT4gaXRlbS5pZCA9PSBpZCk7ICAgLy8gTm8gZnVuY2lvbmEgY29uIGlndWFsZGFkIGVzdHJpY3RhID09PVxuICAgIH1cblxufVxuIiwiaW1wb3J0IHsgQWZ0ZXJWaWV3SW5pdCwgQ29tcG9uZW50LCBpbmplY3QsIE9uSW5pdCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNdXNlbyB9IGZyb20gJy4uLy4uL21vZGVscy9tdXNlbyc7XG5pbXBvcnQgeyBSb3V0ZXJMaW5rIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgU2VydmljaW9NdXNlb3MgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9zZXJ2aWNpby1tdXNlb3MnO1xuXG5pbXBvcnQgeyBNYXRUYWJsZURhdGFTb3VyY2UsIE1hdFRhYmxlTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvdGFibGUnO1xuaW1wb3J0IHsgTWF0U29ydCwgTWF0U29ydE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3NvcnQnO1xuaW1wb3J0IHsgTWF0UGFnaW5hdG9yLCBNYXRQYWdpbmF0b3JNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9wYWdpbmF0b3InO1xuaW1wb3J0IHsgTWF0SW5wdXRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pbnB1dCc7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IEVzdGFkb1BpcGUgfSBmcm9tICcuLi8uLi9waXBlcy9lc3RhZG8tcGlwZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1tdXNlb3MnLFxuICBpbXBvcnRzOiBbUm91dGVyTGluaywgTWF0VGFibGVNb2R1bGUsIE1hdFNvcnRNb2R1bGUsIE1hdFBhZ2luYXRvck1vZHVsZSwgTWF0SW5wdXRNb2R1bGUsIEZvcm1zTW9kdWxlLCBFc3RhZG9QaXBlXSxcbiAgdGVtcGxhdGVVcmw6ICcuL211c2Vvcy5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL211c2Vvcy5jc3MnLFxufSlcbmV4cG9ydCBjbGFzcyBNdXNlb3MgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXR7XG5cbiAgbXVzZW9zOiBNdXNlb1tdID0gW107XG4gIGRpc3BsYXllZENvbHVtbnM6IHN0cmluZ1tdID0gWydub21icmUnLCAnYWJpZXJ0bycsICdob3JhcmlvJywgJ3ByZWNpbyddOyAvLyBwcm9waWVkYWRlcyBkZWwgbXVzZW9cbiAgZGF0YVNvdXJjZTogYW55O1xuICBkYXRvOiBzdHJpbmcgPSAnJztcblxuICBAVmlld0NoaWxkKE1hdFNvcnQpIC8vIFNlIGlueWVjdGUgbGEgZGVwZW5kZW5jaWEgY3VhbmRvIHNlYSB2aXNpYmxlIGVuIGVsIG5hdmVnYWRvclxuICBzb3J0OiBNYXRTb3J0IHwgdW5kZWZpbmVkO1xuXG4gIEBWaWV3Q2hpbGQoTWF0UGFnaW5hdG9yKVxuICBwYWdpbmFkb3I6IE1hdFBhZ2luYXRvciB8IHVuZGVmaW5lZDtcblxuICAvLyBDb24gbGFzIG51ZXZhcyB2ZXJzaW9uZXMgZGUgQW5ndWxhciwgaW55ZWN0YW1vcyBsb3Mgc2VydmljaW9zIGNvbiBpbmplY3RcbiAgLy8gRW4gbGFzIHZlcnNpb25lcyBhbnRlcmlvcmVzIHNlIGhhY2lhIGEgdHJhdsOpcyBkZWwgY29uc3RydWN0b3JcbiAgcHJpdmF0ZSBtdXNlb3NTZXJ2aWNlID0gaW5qZWN0KFNlcnZpY2lvTXVzZW9zKTtcblxuICBmaWx0cmFyKCk6IHZvaWR7XG4gICAgdGhpcy5kYXRhU291cmNlLmZpbHRlciA9IHRoaXMuZGF0by50b0xvd2VyQ2FzZSgpO1xuICB9XG5cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5tdXNlb3MgPSB0aGlzLm11c2Vvc1NlcnZpY2UuZ2V0QWxsKCk7XG4gICAgdGhpcy5kYXRhU291cmNlID0gbmV3IE1hdFRhYmxlRGF0YVNvdXJjZSh0aGlzLm11c2Vvcyk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgLy8gQWdyZWdhciBlbCBzb3J0IGFsIGRhdGFTb3VyY2VcbiAgICBpZiAodGhpcy5zb3J0ICE9IHVuZGVmaW5lZCl7XG4gICAgICB0aGlzLmRhdGFTb3VyY2Uuc29ydCA9IHRoaXMuc29ydDtcbiAgICB9XG5cbiAgICAvLyBBZ3JlZ2FyIGVsIHBhZ2luYXRvciBhbCBkYXRhU291cmNlXG4gICAgaWYgKHRoaXMucGFnaW5hZG9yICE9IHVuZGVmaW5lZCl7XG4gICAgICB0aGlzLmRhdGFTb3VyY2UucGFnaW5hdG9yID0gdGhpcy5wYWdpbmFkb3I7XG4gICAgfVxuXG4gICAgLy8gU2kgc29sbyBxdWllcm8gZmlsdHJhciBwb3IgZWwgbm9tYnJlIGRlbCBtdXNlb1xuICAgIHRoaXMuZGF0YVNvdXJjZS5maWx0ZXJQcmVkaWNhdGUgPSAoaXRlbTogTXVzZW8sIGZpbHRlcjogc3RyaW5nKSA9PiB7XG4gICAgICByZXR1cm4gaXRlbS5ub21icmUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhmaWx0ZXIpO1xuICAgIH07XG4gIH1cbn1cbiIsIjxkaXY+XG5cbiAgPCEtLSBFbCBjYW1wbyBkZSBidXNxdWVkYSB2YSBmdWVyYSBkZSBsYSB0YWJsYSAtLT5cbiAgPG1hdC1mb3JtLWZpZWxkIGNsYXNzPVwiZXhhbXBsZS1mdWxsLXdpZHRoXCI+XG4gICAgPG1hdC1sYWJlbD5CdXNjYXI6PC9tYXQtbGFiZWw+XG4gICAgPGlucHV0IG1hdElucHV0IFsobmdNb2RlbCldPVwiZGF0b1wiIChrZXl1cCk9XCJmaWx0cmFyKClcIj5cbiAgPC9tYXQtZm9ybS1maWVsZD5cblxuICA8dGFibGUgbWF0LXRhYmxlIG1hdFNvcnQgW2RhdGFTb3VyY2VdPVwiZGF0YVNvdXJjZVwiIGNsYXNzPVwibWF0LWVsZXZhdGlvbi16OFwiPlxuXG4gICAgPG5nLWNvbnRhaW5lciBtYXRDb2x1bW5EZWY9XCJub21icmVcIj5cbiAgICAgIDx0aCBtYXQtaGVhZGVyLWNlbGwgKm1hdEhlYWRlckNlbGxEZWYgbWF0LXNvcnQtaGVhZGVyPiBOb21icmUgPC90aD5cbiAgICAgIDx0ZCBtYXQtY2VsbCAqbWF0Q2VsbERlZj1cImxldCBtdXNlb1wiPlxuICAgICAgICA8YSByb3V0ZXJMaW5rPVwiL2RldGFsbGUtbXVzZW8ve3ttdXNlby5pZH19XCI+XG4gICAgICAgICAge3ttdXNlby5ub21icmV9fVxuICAgICAgICA8L2E+XG4gICAgICA8L3RkPlxuICAgIDwvbmctY29udGFpbmVyPlxuXG4gICAgPG5nLWNvbnRhaW5lciBtYXRDb2x1bW5EZWY9XCJhYmllcnRvXCI+XG4gICAgICA8dGggbWF0LWhlYWRlci1jZWxsICptYXRIZWFkZXJDZWxsRGVmIG1hdC1zb3J0LWhlYWRlcj4gQWJpZXJ0byB8IENlcnJhZG8gPC90aD5cbiAgICAgIDx0ZCBtYXQtY2VsbCAqbWF0Q2VsbERlZj1cImxldCBtdXNlb1wiPiB7e211c2VvLmFiaWVydG8gfCBlc3RhZG99fSA8L3RkPlxuICAgIDwvbmctY29udGFpbmVyPlxuXG4gICAgPG5nLWNvbnRhaW5lciBtYXRDb2x1bW5EZWY9XCJob3JhcmlvXCI+XG4gICAgICA8dGggbWF0LWhlYWRlci1jZWxsICptYXRIZWFkZXJDZWxsRGVmIG1hdC1zb3J0LWhlYWRlcj4gSG9yYXJpbyA8L3RoPlxuICAgICAgPHRkIG1hdC1jZWxsICptYXRDZWxsRGVmPVwibGV0IG11c2VvXCI+IHt7bXVzZW8uaG9yYXJpb319IDwvdGQ+XG4gICAgPC9uZy1jb250YWluZXI+XG5cbiAgICA8bmctY29udGFpbmVyIG1hdENvbHVtbkRlZj1cInByZWNpb1wiPlxuICAgICAgPHRoIG1hdC1oZWFkZXItY2VsbCAqbWF0SGVhZGVyQ2VsbERlZiBtYXQtc29ydC1oZWFkZXI+IFByZWNpbyA8L3RoPlxuICAgICAgPHRkIG1hdC1jZWxsICptYXRDZWxsRGVmPVwibGV0IG11c2VvXCI+IHt7bXVzZW8ucHJlY2lvfX0gPC90ZD5cbiAgICA8L25nLWNvbnRhaW5lcj5cblxuICAgIDx0ciBtYXQtaGVhZGVyLXJvdyAqbWF0SGVhZGVyUm93RGVmPVwiZGlzcGxheWVkQ29sdW1uc1wiPjwvdHI+XG4gICAgPHRyIG1hdC1yb3cgKm1hdFJvd0RlZj1cImxldCByb3c7IGNvbHVtbnM6IGRpc3BsYXllZENvbHVtbnM7XCI+PC90cj5cbiAgPC90YWJsZT5cblxuICA8IS0tIEVsIHBhZ2luYWRvciB2YSBmdWVyYSBkZSBsYSB0YWJsYSAtLT5cbiAgPG1hdC1wYWdpbmF0b3IgW2xlbmd0aF09XCJtdXNlb3MubGVuZ3RoXCJcbiAgICAgICAgICAgICAgc2hvd0ZpcnN0TGFzdEJ1dHRvbnNcbiAgICAgICAgICAgICAgW3BhZ2VTaXplXT1cIjRcIlxuICAgICAgICAgICAgICBbcGFnZVNpemVPcHRpb25zXT1cIlsyLDQsNiw4XVwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWxlY3QgcGFnZVwiPlxuICA8L21hdC1wYWdpbmF0b3I+XG5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgaW5qZWN0LCBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUcmFuc2xhdGVTZXJ2aWNlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5cbkBQaXBlKHtcbiAgbmFtZTogJ2VzdGFkbycsXG4gIHB1cmU6IGZhbHNlXG59KVxuZXhwb3J0IGNsYXNzIEVzdGFkb1BpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcblxuICBwcml2YXRlIHRyYW5zbGF0ZVNlcnZpY2UgPSBpbmplY3QoVHJhbnNsYXRlU2VydmljZSk7XG5cbiAgdHJhbnNmb3JtKHZhbHVlOiB1bmtub3duLCAuLi5hcmdzOiB1bmtub3duW10pOiB1bmtub3duIHtcbiAgICBpZiAodmFsdWUpe1xuICAgICAgcmV0dXJuIHRoaXMudHJhbnNsYXRlU2VydmljZS5pbnN0YW50KFwicGlwZS5hYmllcnRvXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy50cmFuc2xhdGVTZXJ2aWNlLmluc3RhbnQoXCJwaXBlLmNlcnJhZG9cIik7XG4gICAgfVxuXG4gICAgLy8gT3RyYSBmb3JtYSBlcyBjb25jYXRlbmFyIGxvcyBwaXBlc1xuICAgIC8vIHt7IG11c2V1bT8uYWJpZXJ0byB8IHN0YXR1cyB8IHRyYW5zbGF0ZSB9fVxuICAgIC8vIHJldG9ybmFyIFwicGlwZS5hYmllcnRvXCIgbyBcInBpcGUuY2VycmFkb1wiXG5cbiAgfVxuXG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTXVzZW8gfSBmcm9tICcuLi8uLi9tb2RlbHMvbXVzZW8nO1xuaW1wb3J0IHsgU2VydmljaW9NdXNlb3MgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9zZXJ2aWNpby1tdXNlb3MnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLWRldGFsbGUtbXVzZW8nLFxuICBpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBNYXRJY29uTW9kdWxlXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2RldGFsbGUtbXVzZW8uaHRtbCcsXG4gIHN0eWxlVXJsOiAnLi9kZXRhbGxlLW11c2VvLmNzcycsXG59KVxuZXhwb3J0IGNsYXNzIERldGFsbGVNdXNlbyB7XG5cbiAgbXVzZW8/OiBNdXNlbztcblxuICBwcml2YXRlIG11c2Vvc1NlcnZpY2UgPSBpbmplY3QoU2VydmljaW9NdXNlb3MpO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcnV0YTogQWN0aXZhdGVkUm91dGUpe1xuICAgICAgbGV0IGlkID0gcnV0YS5zbmFwc2hvdC5wYXJhbXNbJ2lkJ107XG4gICAgICB0aGlzLm11c2VvID0gdGhpcy5tdXNlb3NTZXJ2aWNlLmJ1c2Nhck11c2VvKGlkKTtcbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInJvd1wiPiA8IS0tIGRpdmlkaXIgZWwgZGl2IGVuIDEyIGNvbHVtbmFzIC0tPlxuICA8ZGl2IGNsYXNzPVwiY29sLTNcIj48L2Rpdj4gPCEtLSAzIGNvbHVtbmFzIHZhY2lhcy0tPlxuXG4gIDxkaXYgY2xhc3M9XCJjb2wtNlwiPlxuICAgIDxkaXYgY2xhc3M9XCJjYXJkXCI+XG4gICAgICA8aW1nIHNyYz1cInt7bXVzZW8/LmltYWdlbn19XCIgY2xhc3M9XCJjYXJkLWltZy10b3BcIiBhbHQ9XCJ7e211c2VvPy5ub21icmV9fVwiPlxuICAgICAgPGRpdiBjbGFzcz1cImNhcmQtYm9keVwiPlxuICAgICAgICA8aDUgY2xhc3M9XCJjYXJkLXRpdGxlXCI+e3ttdXNlbz8ubm9tYnJlfX08L2g1PlxuICAgICAgICA8cCBjbGFzcz1cImNhcmQtdGV4dFwiPnt7bXVzZW8/LmRpcmVjY2lvbn19PC9wPlxuICAgICAgPC9kaXY+XG4gICAgICA8dWwgY2xhc3M9XCJsaXN0LWdyb3VwIGxpc3QtZ3JvdXAtZmx1c2hcIj5cbiAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtXCI+PG1hdC1pY29uPnBob25lX2luX3RhbGs8L21hdC1pY29uPiB7e211c2VvPy50ZWxlZm9ub319PC9saT5cbiAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtXCI+PG1hdC1pY29uPnNjaGVkdWxlPC9tYXQtaWNvbj4ge3ttdXNlbz8uaG9yYXJpb319PC9saT5cbiAgICAgICAgPGxpIGNsYXNzPVwibGlzdC1ncm91cC1pdGVtXCI+XG4gICAgICAgICAgPG1hdC1pY29uPmNyZWRpdF9jYXJkPC9tYXQtaWNvbj5cbiAgICAgICAgICB7e211c2VvPy5wcmVjaW8gfCBjdXJyZW5jeTogJ0VVUic6ICdzeW1ib2wnOiAnLjItMid9fVxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgY2xhc3M9XCJsaXN0LWdyb3VwLWl0ZW1cIj5cbiAgICAgICAgICBAaWYgKG11c2VvPy5hYmllcnRvKXtcbiAgICAgICAgICAgIDxzcGFuPkFiaWVydG88L3NwYW4+XG4gICAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgICA8c3BhbiBbbmdTdHlsZV09XCJ7J2NvbG9yJzogJ3JlZCd9XCIgPkNlcnJhZG88L3NwYW4+XG4gICAgICAgICAgfVxuICAgICAgICA8L2xpPlxuICAgICAgPC91bD5cbiAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHlcIj5cbiAgICAgICAgPGEgaHJlZj1cInt7bXVzZW8/LndlYn19XCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJjYXJkLWxpbmtcIj5XZWIgZGVsIG11c2VvPC9hPlxuICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9tYXBzL3BsYWNlL3t7bXVzZW8/LmNvb3JkZW5hZGFzfX1cIlxuICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJjYXJkLWxpbmtcIj5VYmljYWNpb248L2E+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG5cbiAgPGRpdiBjbGFzcz1cImNvbC0zXCI+PC9kaXY+IDwhLS0gMyBjb2x1bW5hcyB2YWNpYXMtLT5cbjwvZGl2PlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBpbmplY3QsIE9uSW5pdCwgc2lnbmFsIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTZXJ2aWNpb0VxdWlwbyB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3NlcnZpY2lvLWVxdWlwbyc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuXG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1lcXVpcG8nLFxuICBpbXBvcnRzOiBbQ29tbW9uTW9kdWxlXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2VxdWlwby5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2VxdWlwby5jc3MnLFxufSlcbmV4cG9ydCBjbGFzcyBFcXVpcG8gaW1wbGVtZW50cyBPbkluaXR7XG5cbiAgbWllbWJyb3MgPSBzaWduYWw8YW55W10+KFtdKTtcbiAgY2FyZ2FuZG8gPSBzaWduYWwodHJ1ZSk7XG5cbiAgcHJpdmF0ZSBlcXVpcG9TZXJ2aWNlID0gaW5qZWN0KFNlcnZpY2lvRXF1aXBvKTtcblxuICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5lcXVpcG9TZXJ2aWNlLmdldEFsbCgpLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoZGF0b3MpID0+IHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0b3MpO1xuICAgICAgICAgICAgICB0aGlzLm1pZW1icm9zLnNldChkYXRvcy5yZXN1bHRzKTtcbiAgICAgICAgICAgICAgdGhpcy5jYXJnYW5kby5zZXQoZmFsc2UpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiAoZXJyKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sIDIwMDApO1xuXG4gIH1cblxufVxuIiwiQGlmIChjYXJnYW5kbygpKXtcbiAgPGRpdiBpZD1cImNhcmdhXCIgY2xhc3M9XCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XG4gICAgPHN0cm9uZyByb2xlPVwic3RhdHVzXCI+Q2FyZ2FuZG8gZGF0b3MuLi48L3N0cm9uZz5cbiAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lci1ib3JkZXIgbXMtYXV0b1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvZGl2PlxuICA8L2Rpdj5cbn0gQGVsc2Uge1xuICA8ZGl2IGNsYXNzPVwicm93XCIgW25nQ2xhc3NdPVwiICdlcXVpcG8nIFwiPlxuICAgIEBmb3IgKG1pZW1icm8gb2YgbWllbWJyb3MoKTsgdHJhY2sgbWllbWJyby5pZCl7XG4gICAgICA8ZGl2IGNsYXNzPVwiY29sLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImNhcmRcIiBbbmdTdHlsZV09XCJ7bWFyZ2luVG9wOiAnMTBweCd9XCI+XG4gICAgICAgICAgICA8aW1nIHNyYz1cInt7bWllbWJyby5pbWFnZX19XCIgY2xhc3M9XCJjYXJkLWltZy10b3BcIiBhbHQ9XCJ7e21pZW1icm8ubmFtZX19XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5XCI+XG4gICAgICAgICAgICAgIDxoNSBjbGFzcz1cImNhcmQtdGl0bGVcIj57e21pZW1icm8ubmFtZX19PC9oNT5cbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJjYXJkLXRleHRcIj57e21pZW1icm8uc3BlY2llc319PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgfVxuICA8L2Rpdj5cbn1cbiIsImltcG9ydCB7IEh0dHBIZWFkZXJzLCBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgSW5qZWN0YWJsZSwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBTZXJ2aWNpb0VxdWlwbyB7XG5cbiAgdXJsOiBzdHJpbmcgPSBcImh0dHBzOi8vcmlja2FuZG1vcnR5YXBpLmNvbS9hcGkvY2hhcmFjdGVyXCI7XG4gIGNhYmVjZXJhczogSHR0cEhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydDb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbid9KTtcblxuICBwcml2YXRlIGh0dHAgPSBpbmplY3QoSHR0cENsaWVudCk7XG5cbiAgZ2V0QWxsKCk6IE9ic2VydmFibGU8YW55PntcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldCh0aGlzLnVybCwge2hlYWRlcnM6IHRoaXMuY2FiZWNlcmFzfSk7XG4gIH1cblxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1Hcm91cCwgRm9ybXNNb2R1bGUsIE5vbk51bGxhYmxlRm9ybUJ1aWxkZXIsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBNYXRJbnB1dE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2lucHV0JztcbmltcG9ydCB7IE1hdEJ1dHRvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2J1dHRvbic7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1jb250YWN0bycsXG4gIGltcG9ydHM6IFtGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZSxNYXRJbnB1dE1vZHVsZSwgTWF0QnV0dG9uTW9kdWxlXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2NvbnRhY3RvLmh0bWwnLFxuICBzdHlsZVVybDogJy4vY29udGFjdG8uY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgQ29udGFjdG8ge1xuXG4gIHByaXZhdGUgZmIgPSBpbmplY3QoTm9uTnVsbGFibGVGb3JtQnVpbGRlcik7XG5cbiAgY29udGFjdG9Gb3JtOiBGb3JtR3JvdXAgPSB0aGlzLmZiLmdyb3VwKHtcbiAgICBub21icmU6ICBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkLCBWYWxpZGF0b3JzLm1pbkxlbmd0aCgzKV1dLFxuICAgIHRlbGVmb25vOiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkLCBWYWxpZGF0b3JzLnBhdHRlcm4oJ1s2LDcsOV17MX1bMC05XXs4fScpXV0sXG4gICAgZW1haWw6IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMuZW1haWxdXSxcbiAgICBhc3VudG86IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMubWluTGVuZ3RoKDUpXV0sXG4gICAgbWVuc2FqZTogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZCwgVmFsaWRhdG9ycy5taW5MZW5ndGgoMTApXV1cbiAgfSk7XG5cbiAgZ3VhcmRhcigpOiB2b2lke1xuICAgIGNvbnNvbGUubG9nKHRoaXMuY29udGFjdG9Gb3JtLnZhbHVlKTtcbiAgICBhbGVydChcIk1lbnNhamUgcmVjaWJpZG9cIik7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJtYXQtZWxldmF0aW9uLXo4XCI+XG4gIDxmb3JtIFtmb3JtR3JvdXBdPVwiY29udGFjdG9Gb3JtXCI+XG4gICAgICA8bWF0LWZvcm0tZmllbGQgY2xhc3M9XCJleGFtcGxlLWZ1bGwtd2lkdGhcIj5cbiAgICAgICAgPG1hdC1sYWJlbD5Ob21icmU6PC9tYXQtbGFiZWw+XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG1hdElucHV0IGZvcm1Db250cm9sTmFtZT1cIm5vbWJyZVwiPlxuICAgICAgICBAaWYgKHRoaXMuY29udGFjdG9Gb3JtLmdldCgnbm9tYnJlJyk/LmVycm9ycz8uWydyZXF1aXJlZCddKSB7XG4gICAgICAgICAgPG1hdC1lcnJvcj4qIENhbXBvIG9ibGlnYXRvcmlvPC9tYXQtZXJyb3I+XG4gICAgICAgIH1cbiAgICAgICAgQGlmICh0aGlzLmNvbnRhY3RvRm9ybS5nZXQoJ25vbWJyZScpPy5lcnJvcnM/LlsnbWlubGVuZ3RoJ10pIHtcbiAgICAgICAgICA8bWF0LWVycm9yPiogTG9uZ2l0dWQgbWluaW1hIDMgY2FyYWN0ZXJlczwvbWF0LWVycm9yPlxuICAgICAgICB9XG4gICAgICA8L21hdC1mb3JtLWZpZWxkPlxuXG4gICAgICA8bWF0LWZvcm0tZmllbGQgY2xhc3M9XCJleGFtcGxlLWZ1bGwtd2lkdGhcIj5cbiAgICAgICAgPG1hdC1sYWJlbD5UZWxlZm9ubzo8L21hdC1sYWJlbD5cbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbWF0SW5wdXQgZm9ybUNvbnRyb2xOYW1lPVwidGVsZWZvbm9cIj5cbiAgICAgICAgQGlmICh0aGlzLmNvbnRhY3RvRm9ybS5nZXQoJ3RlbGVmb25vJyk/LmVycm9ycz8uWydyZXF1aXJlZCddKSB7XG4gICAgICAgICAgPG1hdC1lcnJvcj4qIENhbXBvIG9ibGlnYXRvcmlvPC9tYXQtZXJyb3I+XG4gICAgICAgIH1cbiAgICAgICAgQGlmICh0aGlzLmNvbnRhY3RvRm9ybS5nZXQoJ3RlbGVmb25vJyk/LmVycm9ycz8uWydwYXR0ZXJuJ10pIHtcbiAgICAgICAgICA8bWF0LWVycm9yPiogRGViZSB0ZW5lciA5IGRpZ2l0b3MgeSBjb21lbnphciBwb3IgNiw3IMOzIDk8L21hdC1lcnJvcj5cbiAgICAgICAgfVxuICAgICAgPC9tYXQtZm9ybS1maWVsZD5cblxuICAgICAgPG1hdC1mb3JtLWZpZWxkIGNsYXNzPVwiZXhhbXBsZS1mdWxsLXdpZHRoXCI+XG4gICAgICAgIDxtYXQtbGFiZWw+RW1haWw6PC9tYXQtbGFiZWw+XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG1hdElucHV0IGZvcm1Db250cm9sTmFtZT1cImVtYWlsXCI+XG4gICAgICAgIEBpZiAodGhpcy5jb250YWN0b0Zvcm0uZ2V0KCdlbWFpbCcpPy5lcnJvcnM/LlsncmVxdWlyZWQnXSkge1xuICAgICAgICAgIDxtYXQtZXJyb3I+KiBDYW1wbyBvYmxpZ2F0b3JpbzwvbWF0LWVycm9yPlxuICAgICAgICB9XG4gICAgICAgIEBpZiAodGhpcy5jb250YWN0b0Zvcm0uZ2V0KCdlbWFpbCcpPy5lcnJvcnM/LlsnZW1haWwnXSkge1xuICAgICAgICAgIDxtYXQtZXJyb3I+KiBFbWFpbCBubyBlcyB2YWxpZG88L21hdC1lcnJvcj5cbiAgICAgICAgfVxuICAgICAgPC9tYXQtZm9ybS1maWVsZD5cblxuICAgICAgPG1hdC1mb3JtLWZpZWxkIGNsYXNzPVwiZXhhbXBsZS1mdWxsLXdpZHRoXCI+XG4gICAgICAgIDxtYXQtbGFiZWw+QXN1bnRvOjwvbWF0LWxhYmVsPlxuICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBtYXRJbnB1dCBmb3JtQ29udHJvbE5hbWU9XCJhc3VudG9cIj5cbiAgICAgICAgQGlmICh0aGlzLmNvbnRhY3RvRm9ybS5nZXQoJ2FzdW50bycpPy5lcnJvcnM/LlsncmVxdWlyZWQnXSkge1xuICAgICAgICAgIDxtYXQtZXJyb3I+KiBDYW1wbyBvYmxpZ2F0b3JpbzwvbWF0LWVycm9yPlxuICAgICAgICB9XG4gICAgICAgIEBpZiAodGhpcy5jb250YWN0b0Zvcm0uZ2V0KCdhc3VudG8nKT8uZXJyb3JzPy5bJ21pbmxlbmd0aCddKSB7XG4gICAgICAgICAgPG1hdC1lcnJvcj4qIExvbmdpdHVkIG1pbmltYSA1IGNhcmFjdGVyZXM8L21hdC1lcnJvcj5cbiAgICAgICAgfVxuICAgICAgPC9tYXQtZm9ybS1maWVsZD5cblxuICAgICAgPG1hdC1mb3JtLWZpZWxkIGNsYXNzPVwiZXhhbXBsZS1mdWxsLXdpZHRoXCI+XG4gICAgICAgIDxtYXQtbGFiZWw+TWVuc2FqZTo8L21hdC1sYWJlbD5cbiAgICAgICAgPHRleHRhcmVhIHJvd3M9XCI2XCIgbWF0SW5wdXQgZm9ybUNvbnRyb2xOYW1lPVwibWVuc2FqZVwiPjwvdGV4dGFyZWE+XG4gICAgICAgIEBpZiAodGhpcy5jb250YWN0b0Zvcm0uZ2V0KCdtZW5zYWplJyk/LmVycm9ycz8uWydyZXF1aXJlZCddKSB7XG4gICAgICAgICAgPG1hdC1lcnJvcj4qIENhbXBvIG9ibGlnYXRvcmlvPC9tYXQtZXJyb3I+XG4gICAgICAgIH1cbiAgICAgICAgQGlmICh0aGlzLmNvbnRhY3RvRm9ybS5nZXQoJ21lbnNhamUnKT8uZXJyb3JzPy5bJ21pbmxlbmd0aCddKSB7XG4gICAgICAgICAgPG1hdC1lcnJvcj4qIExvbmdpdHVkIG1pbmltYSAxMCBjYXJhY3RlcmVzPC9tYXQtZXJyb3I+XG4gICAgICAgIH1cbiAgICAgIDwvbWF0LWZvcm0tZmllbGQ+XG5cbiAgICAgIDxzcGFuPlxuICAgICAgICA8YnV0dG9uIG1hdEJ1dHRvbj1cImVsZXZhdGVkXCI+RW52aWFyIGZvcm11bGFyaW88L2J1dHRvbj5cbiAgICAgIDwvc3Bhbj5cbiAgPC9mb3JtPlxuPC9kaXY+XG5cblxuPCEtLVxuICAtIG1lbnNhamU6IGFyZWEgZGUgdGV4dG8sIG9ibGlnYXRvcmlvIHkgbG9uZ2l0dWQgbWluaW1hIDEwXG4tLT5cbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtZXJyb3InLFxuICBpbXBvcnRzOiBbXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2Vycm9yLmh0bWwnLFxuICBzdHlsZVVybDogJy4vZXJyb3IuY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgRXJyb3Ige1xuXG59XG4iLCI8ZGl2PlxuICA8aW1nIHNyYz1cImh0dHBzOi8vY2RuLmNyZWF0aXZlZmFicmljYS5jb20vMjAyMi8wNy8xMS9FcnJvci00MDQtcGFnZS1ub3QtZm91bmQtaWxsdXN0cmF0aW9uLUdyYXBoaWNzLTMzOTkwNzA2LTEtMS01ODB4NDM1LmpwZ1wiXG4gICAgICBhbHQ9XCJlcnJvciA0MDRcIiAvPlxuPC9kaXY+XG5cbiIsImltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBTZXJ2aWNpb0F1dGggfSBmcm9tICcuLy4uLy4uL3NlcnZpY2VzL3NlcnZpY2lvLWF1dGgnO1xuaW1wb3J0IHsgQ29tcG9uZW50LCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuXG5pbXBvcnQgeyBNYXRJbnB1dE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2lucHV0JztcbmltcG9ydCB7IE1hdEJ1dHRvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2J1dHRvbic7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1sb2dpbicsXG4gIGltcG9ydHM6IFtGb3Jtc01vZHVsZSwgTWF0SW5wdXRNb2R1bGUsIE1hdEJ1dHRvbk1vZHVsZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9sb2dpbi5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2xvZ2luLmNzcycsXG59KVxuZXhwb3J0IGNsYXNzIExvZ2luIHtcblxuICB1c3VhcmlvOiBzdHJpbmcgPSAnJztcbiAgcHc6IHN0cmluZyA9ICcnO1xuXG4gIGF1dGggPSBpbmplY3QoU2VydmljaW9BdXRoKTtcbiAgcm91dGVyID0gaW5qZWN0KFJvdXRlcik7XG5cbiAgYXV0ZW50aWNhY2lvbigpe1xuICAgIHRoaXMuYXV0aC5sb2dpbih0aGlzLnVzdWFyaW8sIHRoaXMucHcpXG4gICAgICAgIC50aGVuKChkYXRvcykgPT4ge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGRhdG9zKTtcbiAgICAgICAgICAvLyBTb2xvIGVsIHVzdWFyaW8gbG9nYWRvIHB1ZWRlIGlyIGFsIGNvbXBvbmVudGUgYWRtaW5cbiAgICAgICAgICBpZiAoZGF0b3MgIT0gbnVsbCl7XG4gICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9hZG1pbiddKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgfSk7XG4gIH1cbn1cbiIsIjxkaXY+XG4gIDxoMj5Mb2dpbjwvaDI+XG5cbiAgPG1hdC1mb3JtLWZpZWxkIGNsYXNzPVwiZXhhbXBsZS1mdWxsLXdpZHRoXCI+XG4gICAgPG1hdC1sYWJlbD5FbWFpbDo8L21hdC1sYWJlbD5cbiAgICA8aW5wdXQgbWF0SW5wdXQgWyhuZ01vZGVsKV09XCJ1c3VhcmlvXCI+XG4gIDwvbWF0LWZvcm0tZmllbGQ+IDxici8+XG5cbiAgPG1hdC1mb3JtLWZpZWxkIGNsYXNzPVwiZXhhbXBsZS1mdWxsLXdpZHRoXCI+XG4gICAgPG1hdC1sYWJlbD5QYXNzd29yZDo8L21hdC1sYWJlbD5cbiAgICA8aW5wdXQgbWF0SW5wdXQgWyhuZ01vZGVsKV09XCJwd1wiPlxuICA8L21hdC1mb3JtLWZpZWxkPiA8YnIvPlxuXG4gIDxzcGFuPlxuICAgIDxidXR0b24gbWF0QnV0dG9uPVwiZWxldmF0ZWRcIiAoY2xpY2spPVwiYXV0ZW50aWNhY2lvbigpXCI+TG9nYXJtZTwvYnV0dG9uPlxuICA8L3NwYW4+XG48L2Rpdj5cbiIsImltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEluamVjdGFibGUsIGluamVjdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBdXRoLCBhdXRoU3RhdGUsIHNpZ25JbldpdGhFbWFpbEFuZFBhc3N3b3JkLCBzaWduT3V0LCBVc2VyIH0gZnJvbSAnQGFuZ3VsYXIvZmlyZS9hdXRoJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIFNlcnZpY2lvQXV0aCB7XG5cbiAgLy9wcml2YXRlIGxvZ2FkbyA9IGZhbHNlO1xuXG4gIGF1dGggPSBpbmplY3QoQXV0aCk7XG5cbiAgbG9naW4oZW1haWw6IHN0cmluZywgcHc6IHN0cmluZyk6IFByb21pc2U8YW55PntcbiAgICByZXR1cm4gc2lnbkluV2l0aEVtYWlsQW5kUGFzc3dvcmQodGhpcy5hdXRoLCBlbWFpbCxwdyk7XG4gIH1cblxuICBsb2dvdXQoKTogUHJvbWlzZTx2b2lkPntcbiAgICByZXR1cm4gc2lnbk91dCh0aGlzLmF1dGgpO1xuICB9XG5cbiAgaXNMb2dhZG8oKTogT2JzZXJ2YWJsZTxVc2VyIHwgbnVsbD57XG4gICAgLy8gU2kgZWwgdXN1YXJpbyBubyBlc3RhIGxvZ2FkbyByZXRvcm5hIG51bGwsIHNpIGxvIGVzdGEgcmV0b3JuYSBVc2VyXG4gICAgcmV0dXJuIGF1dGhTdGF0ZSh0aGlzLmF1dGgpO1xuICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2VydmljaW9BdXRoIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvc2VydmljaW8tYXV0aCc7XG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtYWRtaW4nLFxuICBpbXBvcnRzOiBbXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2FkbWluLmh0bWwnLFxuICBzdHlsZVVybDogJy4vYWRtaW4uY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgQWRtaW4ge1xuXG4gIGF1dGggPSBpbmplY3QoU2VydmljaW9BdXRoKTtcbiAgcm91dGVyID0gaW5qZWN0KFJvdXRlcik7XG5cbiAgY2VycmFyU2VzaW9uKCl7XG4gICAgdGhpcy5hdXRoLmxvZ291dCgpO1xuXG4gICAgLy8gTGUgZW52aWFtb3MgYWwgY29tcG9uZW50ZSBob21lXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvaG9tZSddKTtcblxuICB9XG5cbn1cbiIsIjxoMj5ab25hIHByaXZhZGEgZGVsIGFkbWluaXN0cmFkb3IgZGUgbGEgYXBsaWNhY2lvbjwvaDI+XG5cbjxidXR0b24gKGNsaWNrKT1cImNlcnJhclNlc2lvbigpXCI+TG9nb3V0PC9idXR0b24+XG4iLCJpbXBvcnQgeyBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENhbkFjdGl2YXRlRm4sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBTZXJ2aWNpb0F1dGggfSBmcm9tICcuLi9zZXJ2aWNlcy9zZXJ2aWNpby1hdXRoJztcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcblxuZXhwb3J0IGNvbnN0IGF1dGhHdWFyZDogQ2FuQWN0aXZhdGVGbiA9ICgpID0+IHtcblxuICBjb25zdCBhdXRoID0gaW5qZWN0KFNlcnZpY2lvQXV0aCk7XG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xuXG4gIHJldHVybiBhdXRoLmlzTG9nYWRvKCkucGlwZShcbiAgICBtYXAoKGRhdG9zKSA9PiB7XG4gICAgICBpZiAoZGF0b3MgIT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gcm91dGVyLmNyZWF0ZVVybFRyZWUoWycvbG9naW4nXSk7XG4gICAgICB9XG4gICAgfSlcbiAgKTtcblxufTtcbiIsImltcG9ydCB7IFJvdXRlcyB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBIb21lIH0gZnJvbSAnLi9jb21wb25lbnRzL2hvbWUvaG9tZSc7XG5pbXBvcnQgeyBNdXNlb3MgfSBmcm9tICcuL2NvbXBvbmVudHMvbXVzZW9zL211c2Vvcyc7XG5pbXBvcnQgeyBEZXRhbGxlTXVzZW8gfSBmcm9tICcuL2NvbXBvbmVudHMvZGV0YWxsZS1tdXNlby9kZXRhbGxlLW11c2VvJztcbmltcG9ydCB7IEVxdWlwbyB9IGZyb20gJy4vY29tcG9uZW50cy9lcXVpcG8vZXF1aXBvJztcbmltcG9ydCB7IENvbnRhY3RvIH0gZnJvbSAnLi9jb21wb25lbnRzL2NvbnRhY3RvL2NvbnRhY3RvJztcbmltcG9ydCB7IEVycm9yIH0gZnJvbSAnLi9jb21wb25lbnRzL2Vycm9yL2Vycm9yJztcbmltcG9ydCB7IExvZ2luIH0gZnJvbSAnLi9jb21wb25lbnRzL2xvZ2luL2xvZ2luJztcbmltcG9ydCB7IEFkbWluIH0gZnJvbSAnLi9jb21wb25lbnRzL2FkbWluL2FkbWluJztcbmltcG9ydCB7IGF1dGhHdWFyZCB9IGZyb20gJy4vZ3VhcmRzL2F1dGgtZ3VhcmQnO1xuXG5leHBvcnQgY29uc3Qgcm91dGVzOiBSb3V0ZXMgPSBbXG4gIHtwYXRoOiAnaG9tZScsIGNvbXBvbmVudDogSG9tZX0sXG4gIHtwYXRoOiAnbXVzZW9zJywgY29tcG9uZW50OiBNdXNlb3N9LFxuICB7cGF0aDogJ2RldGFsbGUtbXVzZW8vOmlkJywgY29tcG9uZW50OiBEZXRhbGxlTXVzZW99LFxuICB7cGF0aDogJ2VxdWlwbycsIGNvbXBvbmVudDogRXF1aXBvfSxcbiAge3BhdGg6ICdjb250YWN0bycsIGNvbXBvbmVudDogQ29udGFjdG99LFxuICB7cGF0aDogJ2xvZ2luJywgY29tcG9uZW50OiBMb2dpbn0sXG4gIHtwYXRoOiAnYWRtaW4nLCBjb21wb25lbnQ6IEFkbWluLCBjYW5BY3RpdmF0ZTogW2F1dGhHdWFyZF19LFxuICB7cGF0aDogJycsIHJlZGlyZWN0VG86ICdob21lJywgcGF0aE1hdGNoOiAnZnVsbCd9LCAgIC8vIGxvY2FsaG9zdDo0MjAwXG4gIHtwYXRoOiAnKionLCBjb21wb25lbnQ6IEVycm9yfVxuXTtcbiIsImV4cG9ydCBjb25zdCBlbnZpcm9ubWVudCA9IHtcbiAgcHJvZHVjdGlvbjogdHJ1ZSxcbiAgZmlyZWJhc2VDb25maWc6IHtcbiAgICBhcGlLZXk6IFwiQUl6YVN5RE1BYWpCNm1JMGpDX2lTNHhrVEkxRG5IV3VVejRrQ19ZXCIsXG4gICAgYXV0aERvbWFpbjogXCJhbmd1bGFyLWluZHJhLWFuYWJlbC0xMC1qdWxpby5maXJlYmFzZWFwcC5jb21cIixcbiAgICBwcm9qZWN0SWQ6IFwiYW5ndWxhci1pbmRyYS1hbmFiZWwtMTAtanVsaW9cIixcbiAgICBzdG9yYWdlQnVja2V0OiBcImFuZ3VsYXItaW5kcmEtYW5hYmVsLTEwLWp1bGlvLmZpcmViYXNlc3RvcmFnZS5hcHBcIixcbiAgICBtZXNzYWdpbmdTZW5kZXJJZDogXCIzODcwNDEyMTAzMzlcIixcbiAgICBhcHBJZDogXCIxOjM4NzA0MTIxMDMzOTp3ZWI6ZDdkN2NiN2EzZDlhNmE4ZGI1N2FkNlwiXG4gIH1cblxufTtcbiIsImltcG9ydCB7IENvbXBvbmVudCwgc2lnbmFsIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXJPdXRsZXQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSBcIi4vY29tcG9uZW50cy9oZWFkZXIvaGVhZGVyXCI7XG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tIFwiLi9jb21wb25lbnRzL2Zvb3Rlci9mb290ZXJcIjtcbmltcG9ydCB7IE5hdmJhciB9IGZyb20gXCIuL2NvbXBvbmVudHMvbmF2YmFyL25hdmJhclwiO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtcm9vdCcsXG4gIGltcG9ydHM6IFtSb3V0ZXJPdXRsZXQsIEhlYWRlciwgRm9vdGVyLCBOYXZiYXJdLFxuICB0ZW1wbGF0ZVVybDogJy4vYXBwLmh0bWwnLFxuICBzdHlsZVVybDogJy4vYXBwLmNzcydcbn0pXG5leHBvcnQgY2xhc3MgQXBwIHtcblxufVxuIiwiPGhlYWRlcj5cbiAgPGFwcC1oZWFkZXI+PC9hcHAtaGVhZGVyPlxuPC9oZWFkZXI+XG5cbjxuYXY+XG4gIDxhcHAtbmF2YmFyPjwvYXBwLW5hdmJhcj5cbjwvbmF2PlxuXG48c2VjdGlvbj5cbiAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxuPC9zZWN0aW9uPlxuXG48Zm9vdGVyPlxuICA8YXBwLWZvb3Rlcj48L2FwcC1mb290ZXI+XG48L2Zvb3Rlcj5cbiIsImltcG9ydCB7IENvbXBvbmVudCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUcmFuc2xhdGVQaXBlLCBUcmFuc2xhdGVTZXJ2aWNlIH0gZnJvbSAnQG5neC10cmFuc2xhdGUvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1oZWFkZXInLFxuICBpbXBvcnRzOiBbVHJhbnNsYXRlUGlwZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9oZWFkZXIuaHRtbCcsXG4gIHN0eWxlVXJsOiAnLi9oZWFkZXIuY3NzJyxcbn0pXG5leHBvcnQgY2xhc3MgSGVhZGVyIHtcblxuICBpZGlvbWE6c3RyaW5nID0gJ2VzJztcblxuICBwcml2YXRlIHRyYW5zbGF0ZSA9IGluamVjdChUcmFuc2xhdGVTZXJ2aWNlKTtcblxuICBjb25zdHJ1Y3Rvcigpe1xuICAgIC8vIEluZGljYW1vcyBlbCBpZGlvbWEgcG9yIGRlZmVjdG8gZGUgbGEgYXBsaWNhY2lvblxuICAgIHRoaXMudHJhbnNsYXRlLnVzZSh0aGlzLmlkaW9tYSk7XG4gIH1cblxuICBjYW1iaWFySWRpb21hKG51ZXZvSWRpb21hOiBzdHJpbmcpe1xuICAgIHRoaXMuaWRpb21hID0gbnVldm9JZGlvbWE7XG5cbiAgICAvLyBGb3J6YW1vcyBlbCBjYW1iaW8gZGUgaWRpb21hXG4gICAgdGhpcy50cmFuc2xhdGUudXNlKHRoaXMuaWRpb21hKTtcbiAgfVxuXG59XG4iLCI8aW1nIHNyYz1cImxvZ28ucG5nXCIgYWx0PVwiTG9nbyBDb211bmlkYWQgZGUgTWFkcmlkXCIgLz5cbjxoMT57eyBcImhlYWRlci50aXR1bG9cIiB8IHRyYW5zbGF0ZX19PC9oMT5cblxuPHNwYW4+XG4gIDxpbWcgKGNsaWNrKT1cImNhbWJpYXJJZGlvbWEoJ2VzJylcIiBzcmM9XCJiYW5kZXJhcy9zcGFpbi5wbmdcIiAvPlxuICA8aW1nIChjbGljayk9XCJjYW1iaWFySWRpb21hKCdlbicpXCIgc3JjPVwiYmFuZGVyYXMvaW5nbGF0ZXJyYS5wbmdcIiAvPlxuICA8aW1nIChjbGljayk9XCJjYW1iaWFySWRpb21hKCdmcicpXCIgc3JjPVwiYmFuZGVyYXMvZnJhbmNpYS5wbmdcIiAvPlxuICA8aW1nIChjbGljayk9XCJjYW1iaWFySWRpb21hKCdkZScpXCIgc3JjPVwiYmFuZGVyYXMvYWxlbWFuaWEucG5nXCIgLz5cbjwvc3Bhbj5cbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVHJhbnNsYXRlUGlwZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtZm9vdGVyJyxcbiAgaW1wb3J0czogW1RyYW5zbGF0ZVBpcGVdLFxuICB0ZW1wbGF0ZVVybDogJy4vZm9vdGVyLmh0bWwnLFxuICBzdHlsZVVybDogJy4vZm9vdGVyLmNzcycsXG59KVxuZXhwb3J0IGNsYXNzIEZvb3RlciB7XG5cbn1cbiIsIjxwPnt7IFwiZm9vdGVyLnBpZV9wYWdpbmFcIiB8IHRyYW5zbGF0ZToge25vbWJyZTogJ0FuYWJlbCd9IH19PC9wPlxuIiwiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXJMaW5rIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgVHJhbnNsYXRlUGlwZSB9IGZyb20gJ0BuZ3gtdHJhbnNsYXRlL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtbmF2YmFyJyxcbiAgaW1wb3J0czogW1JvdXRlckxpbmssIFRyYW5zbGF0ZVBpcGVdLFxuICB0ZW1wbGF0ZVVybDogJy4vbmF2YmFyLmh0bWwnLFxuICBzdHlsZVVybDogJy4vbmF2YmFyLmNzcycsXG59KVxuZXhwb3J0IGNsYXNzIE5hdmJhciB7XG5cbn1cbiIsIjxuYXYgY2xhc3M9XCJuYXZiYXIgYmctZGFyayBuYXZiYXItZXhwYW5kLWxnIGJnLWJvZHktdGVydGlhcnlcIiBkYXRhLWJzLXRoZW1lPVwiZGFya1wiPlxuICA8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+XG4gICAgPGEgY2xhc3M9XCJuYXZiYXItYnJhbmRcIiBocmVmPVwiI1wiPlxuICAgICAgPGltZyBzcmM9XCJsb2dvLnBuZ1wiIGFsdD1cIkxvZ29cIiAgaGVpZ2h0PVwiMjRcIiBjbGFzcz1cImQtaW5saW5lLWJsb2NrIGFsaWduLXRleHQtdG9wXCI+XG4gICAgPC9hPlxuICAgIDxidXR0b24gY2xhc3M9XCJuYXZiYXItdG9nZ2xlclwiIHR5cGU9XCJidXR0b25cIiBkYXRhLWJzLXRvZ2dsZT1cImNvbGxhcHNlXCIgZGF0YS1icy10YXJnZXQ9XCIjbmF2YmFyTmF2XCIgYXJpYS1jb250cm9scz1cIm5hdmJhck5hdlwiIGFyaWEtZXhwYW5kZWQ9XCJmYWxzZVwiIGFyaWEtbGFiZWw9XCJUb2dnbGUgbmF2aWdhdGlvblwiPlxuICAgICAgPHNwYW4gY2xhc3M9XCJuYXZiYXItdG9nZ2xlci1pY29uXCI+PC9zcGFuPlxuICAgIDwvYnV0dG9uPlxuICAgIDxkaXYgY2xhc3M9XCJjb2xsYXBzZSBuYXZiYXItY29sbGFwc2VcIiBpZD1cIm5hdmJhck5hdlwiPlxuICAgICAgPHVsIGNsYXNzPVwibmF2YmFyLW5hdlwiPlxuICAgICAgICA8bGkgY2xhc3M9XCJuYXYtaXRlbVwiPlxuICAgICAgICAgIDxhIGNsYXNzPVwibmF2LWxpbmtcIiByb3V0ZXJMaW5rPVwiaG9tZVwiPnt7XCJuYXZiYXIuaG9tZVwiIHwgdHJhbnNsYXRlfX08L2E+XG4gICAgICAgIDwvbGk+XG4gICAgICAgIDxsaSBjbGFzcz1cIm5hdi1pdGVtXCI+XG4gICAgICAgICAgPGEgY2xhc3M9XCJuYXYtbGlua1wiIHJvdXRlckxpbms9XCJtdXNlb3NcIj57e1wibmF2YmFyLm11c2Vvc1wiIHwgdHJhbnNsYXRlfX08L2E+XG4gICAgICAgIDwvbGk+XG4gICAgICAgIDxsaSBjbGFzcz1cIm5hdi1pdGVtXCI+XG4gICAgICAgICAgPGEgY2xhc3M9XCJuYXYtbGlua1wiIHJvdXRlckxpbms9XCJlcXVpcG9cIj57e1wibmF2YmFyLmVxdWlwb1wiIHwgdHJhbnNsYXRlfX08L2E+XG4gICAgICAgIDwvbGk+XG4gICAgICAgIDxsaSBjbGFzcz1cIm5hdi1pdGVtXCI+XG4gICAgICAgICAgPGEgY2xhc3M9XCJuYXYtbGlua1wiIHJvdXRlckxpbms9XCJjb250YWN0b1wiPnt7XCJuYXZiYXIuY29udGFjdG9cIiB8IHRyYW5zbGF0ZX19PC9hPlxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgY2xhc3M9XCJuYXYtaXRlbVwiPlxuICAgICAgICAgIDxhIGNsYXNzPVwibmF2LWxpbmtcIiByb3V0ZXJMaW5rPVwiYWRtaW5cIj57e1wibmF2YmFyLmFkbWluXCIgfCB0cmFuc2xhdGV9fTwvYT5cbiAgICAgICAgPC9saT5cbiAgICAgIDwvdWw+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9uYXY+XG4iXSwibWFwcGluZ3MiOiI7QUFBQSxTQUFTLDRCQUE0Qjs7O0FDQXJDLFNBQVMsa0NBQWtDO0FBQzNDLFNBQTRCLG9DQUFvQyxrQ0FBa0M7QUFDbEcsU0FBUyxxQkFBcUI7OztBQ0Y5QixTQUFTLFdBQVcsY0FBYzs7O0FFQWxDLFNBQVMsa0JBQWtCOztBQU1yQixJQUFPLGlCQUFQLE1BQU8sZ0JBQWM7RUFFakIsU0FBa0I7SUFDdEIsRUFBRSxJQUFJLEdBQUcsUUFBUSxtQkFBbUIsVUFBVSxnQkFBZ0IsV0FBVyxpREFBOEMsU0FBUyxzQkFBaUIsUUFBUSxrR0FBa0csS0FBSyxpQ0FBaUMsYUFBYSxDQUFDLFlBQVksVUFBVSxHQUFHLFFBQVEsSUFBSSxTQUFTLEtBQUk7SUFDalcsRUFBRSxJQUFJLEdBQUcsUUFBUSxlQUFlLFVBQVUsYUFBYSxXQUFXLHNCQUFzQixTQUFTLHNCQUFzQixRQUFRLDhGQUE4RixLQUFLLGlDQUFpQyxhQUFhLENBQUMsV0FBVyxTQUFTLEdBQUcsUUFBUSxJQUFJLFNBQVMsS0FBSTtJQUNqVSxFQUFFLElBQUksR0FBRyxRQUFRLHVCQUF1QixVQUFVLGdDQUFnQyxXQUFXLDZDQUE2QyxTQUFTLDJEQUEyRCxRQUFRLDZGQUE2RixLQUFLLGdCQUFnQixhQUFhLENBQUMsbUJBQW1CLG1CQUFtQixHQUFHLFFBQVEsR0FBRyxTQUFTLEtBQUk7SUFDdlosRUFBRSxJQUFJLEdBQUcsUUFBUSxpQkFBaUIsVUFBVSxhQUFhLFdBQVcsc0JBQXNCLFNBQVMsaUJBQWlCLFFBQVEsOEVBQThFLEtBQUssaUNBQWlDLGFBQWEsQ0FBQyxvQkFBb0Isa0JBQWtCLEdBQUcsUUFBUSxJQUFJLFNBQVMsS0FBSTtJQUNoVSxFQUFFLElBQUksR0FBRyxRQUFRLGlEQUFpRCxVQUFVLG9CQUFvQixXQUFXLDhCQUEyQixTQUFTLGdGQUFnRixRQUFRLHFHQUFxRyxLQUFLLHlEQUF5RCxhQUFhLENBQUMsWUFBWSxVQUFVLEdBQUcsUUFBUSxHQUFHLFNBQVMsS0FBSTtJQUN6YyxFQUFFLElBQUksR0FBRyxRQUFRLHlCQUFzQixVQUFVLGFBQWEsV0FBVyxzQ0FBc0MsU0FBUyxtQkFBYyxRQUFRLHdIQUF3SCxLQUFLLG1DQUFtQyxhQUFhLENBQUMsV0FBVyxTQUFTLEdBQUcsUUFBUSxHQUFHLFNBQVMsS0FBSTtJQUMzVyxFQUFFLElBQUksR0FBRyxRQUFRLDRCQUE0QixVQUFVLGFBQWEsV0FBVywrQkFBNEIsU0FBUyxpQkFBaUIsUUFBUSxrUEFBa1AsS0FBSyw4QkFBOEIsYUFBYSxDQUFDLFlBQVksVUFBVSxHQUFHLFFBQVEsR0FBRyxTQUFTLEtBQUk7SUFDamUsRUFBRSxJQUFJLEdBQUcsUUFBUSxtQkFBbUIsVUFBVSxvQkFBb0IsV0FBVyxzQ0FBc0MsU0FBUyxrR0FBMEYsUUFBUSxzTkFBc04sS0FBSyx3REFBd0QsYUFBYSxDQUFDLFlBQVksVUFBVSxHQUFHLFFBQVEsR0FBRyxTQUFTLEtBQUk7SUFDaGpCLEVBQUUsSUFBSSxHQUFHLFFBQVEsa0NBQWtDLFVBQVUsYUFBYSxXQUFXLHlFQUFzRSxTQUFTLGVBQWUsUUFBUSwwS0FBMEssS0FBSyx5QkFBeUIsYUFBYSxDQUFDLFlBQVksU0FBUyxHQUFHLFFBQVEsR0FBSyxTQUFTLEtBQUk7SUFDbmMsRUFBRSxJQUFJLElBQUksUUFBUSx5QkFBeUIsVUFBVSxhQUFhLFdBQVcsc0NBQXNDLFNBQVMsMEJBQTBCLFFBQVEsb0dBQW9HLEtBQUssc0NBQXNDLGFBQWEsQ0FBQyxZQUFZLFVBQVUsR0FBRyxRQUFRLEdBQUcsU0FBUyxLQUFJO0lBQzVXLEVBQUUsSUFBSSxJQUFJLFFBQVEsaUJBQWlCLFVBQVUsb0JBQW9CLFdBQVcsd0JBQXFCLFNBQVMsb0JBQWUsUUFBUSx1S0FBdUssS0FBSyx1Q0FBdUMsYUFBYSxDQUFDLFlBQVksVUFBVSxHQUFHLFFBQVEsSUFBSSxTQUFTLEtBQUk7SUFDcFosRUFBRSxJQUFJLElBQUksUUFBUSxxQ0FBa0MsVUFBVSxvQkFBb0IsV0FBVywrQkFBK0IsU0FBUyx5QkFBeUIsUUFBUSw0SEFBNEgsS0FBSyx5QkFBeUIsYUFBYSxDQUFDLFlBQVksVUFBVSxHQUFHLFFBQVEsR0FBRyxTQUFTLE1BQUs7SUFDaFksRUFBRSxJQUFJLElBQUksUUFBUSx3QkFBd0IsVUFBVSxhQUFhLFdBQVcsK0RBQXlELFNBQVMsZUFBZSxRQUFRLCtGQUErRixLQUFLLCtEQUErRCxhQUFhLENBQUMsWUFBWSxVQUFVLEdBQUcsUUFBUSxHQUFHLFNBQVMsS0FBSTtJQUN2WSxFQUFFLElBQUksSUFBSSxRQUFRLGVBQWUsVUFBVSxzQkFBc0IsV0FBVyw4QkFBOEIsU0FBUywrQkFBK0IsUUFBUSxpRkFBaUYsS0FBSyw4REFBOEQsYUFBYSxDQUFDLG1CQUFtQixtQkFBbUIsR0FBRyxRQUFRLEdBQUcsU0FBUyxLQUFJO0lBQzdYLEVBQUUsSUFBSSxJQUFJLFFBQVEsaUJBQWlCLFVBQVUsb0JBQW9CLFdBQVcsdURBQXVELFNBQVMsY0FBYyxRQUFRLHlGQUF5RixLQUFLLDJEQUEyRCxhQUFhLENBQUMsWUFBWSxVQUFVLEdBQUcsUUFBUSxHQUFHLFNBQVMsS0FBSTtJQUMxWCxFQUFFLElBQUksSUFBSSxRQUFRLHVCQUF1QixVQUFVLG9CQUFvQixXQUFXLDJCQUEyQixTQUFTLHNCQUFzQixRQUFRLDhGQUE4RixLQUFLLGlDQUFpQyxhQUFhLENBQUMsWUFBWSxVQUFVLEdBQUcsUUFBUSxJQUFJLFNBQVMsS0FBSTs7RUFHMVYsU0FBTTtBQUNKLFdBQU8sS0FBSztFQUNkO0VBRUEsWUFBWSxJQUFVO0FBQ3BCLFdBQU8sS0FBSyxPQUFPLEtBQUssVUFBUSxLQUFLLE1BQU0sRUFBRTtFQUMvQzs7cUNBM0JTLGlCQUFjO0VBQUE7K0VBQWQsaUJBQWMsU0FBZCxnQkFBYyxXQUFBLFlBRmIsT0FBTSxDQUFBOzs7K0VBRVAsZ0JBQWMsQ0FBQTtVQUgxQjtXQUFXO01BQ1YsWUFBWTtLQUNiOzs7OztBRkZELFNBQVMsb0JBQW9COzs7Ozs7O0FDQXZCLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFPTSxJQUFBLHlCQUFBLFNBQUEsU0FBQSw4Q0FBQTtBQUFBLFlBQUEsWUFBQSw0QkFBQSxHQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsWUFBQSxTQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUM3QixJQUFBLDJCQUFBOzs7Ozs7QUFKQyxJQUFBLDBCQUFBLFVBQUEsT0FBQSxxQkFBQSxTQUFBOzs7Ozs7QUFTTixJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBZ0QsR0FBQSxJQUFBO0FBQzFDLElBQUEscUJBQUEsQ0FBQTtBQUFnQixJQUFBLDJCQUFBO0FBQ3BCLElBQUEsNkJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxxQkFBQSxDQUFBO0FBQW1CLElBQUEsMkJBQUEsRUFBSSxFQUN0Qjs7OztBQUxtQixJQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQSxLQUFBLFNBQUEsTUFBQSxDQUFBLENBQUE7QUFDcEIsSUFBQSx3QkFBQTtBQUFBLElBQUEseUJBQUEsT0FBQSw0QkFBQSxTQUFBLE1BQUEsR0FBc0IsMkJBQUEsRUFBQSxPQUF1Qiw0QkFBQSxTQUFBLE1BQUEsQ0FBc0I7QUFFbEUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxTQUFBLE1BQUE7QUFDRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUEsU0FBQTs7O0FEVFAsSUFBTyxPQUFQLE1BQU8sTUFBSTtFQUVmLFNBQWtCLENBQUE7RUFDbEIsbUJBQW1CO0VBRVgsZ0JBQWdCLE9BQU8sY0FBYztFQUU3QyxjQUFBO0FBQ0UsU0FBSyxTQUFTLEtBQUssY0FBYyxPQUFNO0VBQ3pDO0VBRUEsWUFBWSxLQUFXO0FBQ3JCLFNBQUssbUJBQW1CO0VBQzFCOztxQ0FiVyxPQUFJO0VBQUE7NkVBQUosT0FBSSxXQUFBLENBQUEsQ0FBQSxVQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE1BQUEsMkJBQUEsR0FBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxrQkFBQSw4QkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsa0JBQUEsNEJBQUEsaUJBQUEsUUFBQSxHQUFBLHVCQUFBLEdBQUEsQ0FBQSxlQUFBLFFBQUEsR0FBQSw0QkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGtCQUFBLDRCQUFBLGlCQUFBLFFBQUEsR0FBQSx1QkFBQSxHQUFBLENBQUEsZUFBQSxRQUFBLEdBQUEsNEJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxrQkFBQSw4QkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxTQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLFVBQUEsWUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGNBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUNYakIsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF5RCxHQUFBLE9BQUEsQ0FBQTtBQUVyRCxNQUFBLCtCQUFBLEdBQUEscUJBQUEsR0FBQSxHQUFBLFVBQUEsR0FBQSxvQ0FBQTtBQVdGLE1BQUEsMkJBQUE7QUFDQSxNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsTUFBQSwrQkFBQSxHQUFBLHFCQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUEsb0NBQUE7QUFTRixNQUFBLDJCQUFBO0FBQ0EsTUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUNFLE1BQUEsd0JBQUEsR0FBQSxRQUFBLENBQUE7QUFDQSxNQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQThCLE1BQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsTUFBQSwyQkFBQSxFQUFPO0FBRS9DLE1BQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFDRSxNQUFBLHdCQUFBLElBQUEsUUFBQSxDQUFBO0FBQ0EsTUFBQSw2QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUE4QixNQUFBLHFCQUFBLElBQUEsTUFBQTtBQUFJLE1BQUEsMkJBQUEsRUFBTyxFQUNsQzs7O0FBOUJQLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsSUFBQSxNQUFBO0FBYUEsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxJQUFBLE1BQUE7O29CRFJRLGNBQVksWUFBQSxzQkFBQSxZQUFBLFNBQUEscUJBQUEsWUFBQSxhQUFBLGlCQUFBLG9CQUFBLGFBQUEsaUJBQUEsY0FBQSxrQkFBQSxrQkFBQSxhQUFBLGNBQUEsZ0JBQUEsZ0JBQUEsa0JBQUEsaUJBQUEsYUFBQSxtQkFBQSxtQkFBQSxlQUFBLEdBQUEsUUFBQSxDQUFBLDhIQUFBLEVBQUEsQ0FBQTs7O2dGQUlYLE1BQUksQ0FBQTtVQU5oQjt1QkFDVyxZQUFVLFNBQ1gsQ0FBQyxZQUFZLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQUFBLFFBQUEsQ0FBQSxpSkFBQSxFQUFBLENBQUE7Ozs7aUZBSVosTUFBSSxFQUFBLFdBQUEsUUFBQSxVQUFBLG1DQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBSixNQUFJLEVBQUEsU0FBQSxDQUFBQSxLQUFBLEVBQUEsR0FBQSxDQUFBLGNBQUEsU0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsYUFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxhQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FHWGpCLFNBQXdCLGFBQUFDLFlBQVcsVUFBQUMsU0FBZ0IsaUJBQWlCO0FBRXBFLFNBQVMsa0JBQWtCO0FBRzNCLFNBQVMsb0JBQW9CLHNCQUFzQjtBQUNuRCxTQUFTLFNBQVMscUJBQXFCO0FBQ3ZDLFNBQVMsY0FBYywwQkFBMEI7QUFDakQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxtQkFBbUI7OztBRVQ1QixTQUFTLFVBQUFDLFNBQVEsWUFBMkI7QUFDNUMsU0FBUyx3QkFBd0I7O0FBTTNCLElBQU8sYUFBUCxNQUFPLFlBQVU7RUFFYixtQkFBbUJBLFFBQU8sZ0JBQWdCO0VBRWxELFVBQVUsVUFBbUIsTUFBZTtBQUMxQyxRQUFJLE9BQU07QUFDUixhQUFPLEtBQUssaUJBQWlCLFFBQVEsY0FBYztJQUNyRCxPQUFPO0FBQ0wsYUFBTyxLQUFLLGlCQUFpQixRQUFRLGNBQWM7SUFDckQ7RUFNRjs7cUNBZlcsYUFBVTtFQUFBO3lGQUFWLGFBQVUsTUFBQSxNQUFBLENBQUE7OztnRkFBVixZQUFVLENBQUE7VUFKdEI7V0FBSztNQUNKLE1BQU07TUFDTixNQUFNO0tBQ1A7Ozs7Ozs7Ozs7Ozs7Ozs7QURLSyxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQXVELElBQUEscUJBQUEsR0FBQSxVQUFBO0FBQU8sSUFBQSwyQkFBQTs7Ozs7QUFDOUQsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQSxFQUFxQyxHQUFBLEtBQUEsRUFBQTtBQUVqQyxJQUFBLHFCQUFBLENBQUE7QUFDRixJQUFBLDJCQUFBLEVBQUk7Ozs7QUFGRCxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLDZCQUFBLG1CQUFBLFNBQUEsRUFBQSxDQUF3QztBQUN6QyxJQUFBLHdCQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLFNBQUEsUUFBQSxHQUFBOzs7OztBQU1KLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQWtCLElBQUEsMkJBQUE7Ozs7O0FBQ3pFLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBc0MsSUFBQSxxQkFBQSxDQUFBOztBQUEyQixJQUFBLDJCQUFBOzs7O0FBQTNCLElBQUEsd0JBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsMEJBQUEsR0FBQSxHQUFBLFNBQUEsT0FBQSxHQUFBLEdBQUE7Ozs7O0FBSXRDLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxHQUFBLFdBQUE7QUFBUSxJQUFBLDJCQUFBOzs7OztBQUMvRCxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQXNDLElBQUEscUJBQUEsQ0FBQTtBQUFrQixJQUFBLDJCQUFBOzs7O0FBQWxCLElBQUEsd0JBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsU0FBQSxTQUFBLEdBQUE7Ozs7O0FBSXRDLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFBdUQsSUFBQSxxQkFBQSxHQUFBLFVBQUE7QUFBTyxJQUFBLDJCQUFBOzs7OztBQUM5RCxJQUFBLDZCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQXNDLElBQUEscUJBQUEsQ0FBQTtBQUFpQixJQUFBLDJCQUFBOzs7O0FBQWpCLElBQUEsd0JBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsU0FBQSxRQUFBLEdBQUE7Ozs7O0FBR3hDLElBQUEsd0JBQUEsR0FBQSxNQUFBLEVBQUE7Ozs7O0FBQ0EsSUFBQSx3QkFBQSxHQUFBLE1BQUEsRUFBQTs7O0FEakJFLElBQU8sU0FBUCxNQUFPLFFBQU07RUFFakIsU0FBa0IsQ0FBQTtFQUNsQixtQkFBNkIsQ0FBQyxVQUFVLFdBQVcsV0FBVyxRQUFROztFQUN0RTtFQUNBLE9BQWU7RUFHZjtFQUdBOzs7RUFJUSxnQkFBZ0JDLFFBQU8sY0FBYztFQUU3QyxVQUFPO0FBQ0wsU0FBSyxXQUFXLFNBQVMsS0FBSyxLQUFLLFlBQVc7RUFDaEQ7RUFFQSxXQUFRO0FBQ04sU0FBSyxTQUFTLEtBQUssY0FBYyxPQUFNO0FBQ3ZDLFNBQUssYUFBYSxJQUFJLG1CQUFtQixLQUFLLE1BQU07RUFDdEQ7RUFFQSxrQkFBZTtBQUViLFFBQUksS0FBSyxRQUFRLFFBQVU7QUFDekIsV0FBSyxXQUFXLE9BQU8sS0FBSztJQUM5QjtBQUdBLFFBQUksS0FBSyxhQUFhLFFBQVU7QUFDOUIsV0FBSyxXQUFXLFlBQVksS0FBSztJQUNuQztBQUdBLFNBQUssV0FBVyxrQkFBa0IsQ0FBQyxNQUFhLFdBQWtCO0FBQ2hFLGFBQU8sS0FBSyxPQUFPLFlBQVcsRUFBRyxTQUFTLE1BQU07SUFDbEQ7RUFDRjs7cUNBekNXLFNBQU07RUFBQTs2RUFBTixTQUFNLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLFdBQUEsU0FBQSxhQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO2dDQU9OLFNBQU8sQ0FBQTtnQ0FHUCxjQUFZLENBQUE7Ozs7Ozs7OztBQzVCekIsTUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBSyxHQUFBLGtCQUFBLENBQUEsRUFHd0MsR0FBQSxXQUFBO0FBQzlCLE1BQUEscUJBQUEsR0FBQSxTQUFBO0FBQU8sTUFBQSwyQkFBQTtBQUNsQixNQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQWdCLE1BQUEsK0JBQUEsaUJBQUEsU0FBQSwrQ0FBQSxRQUFBO0FBQUEsUUFBQSxpQ0FBQSxJQUFBLE1BQUEsTUFBQSxNQUFBLElBQUEsT0FBQTtBQUFBLGVBQUE7TUFBQSxDQUFBO0FBQW1CLE1BQUEseUJBQUEsU0FBQSxTQUFBLHlDQUFBO0FBQUEsZUFBUyxJQUFBLFFBQUE7TUFBUyxDQUFBO0FBQXJELE1BQUEsMkJBQUEsRUFBdUQ7QUFHekQsTUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUVFLE1BQUEsc0NBQUEsR0FBQSxDQUFBO0FBQ0UsTUFBQSx5QkFBQSxHQUFBLHNCQUFBLEdBQUEsR0FBQSxNQUFBLENBQUEsRUFBc0QsR0FBQSxzQkFBQSxHQUFBLEdBQUEsTUFBQSxDQUFBOztBQVF4RCxNQUFBLHNDQUFBLEdBQUEsQ0FBQTtBQUNFLE1BQUEseUJBQUEsSUFBQSx1QkFBQSxHQUFBLEdBQUEsTUFBQSxDQUFBLEVBQXNELElBQUEsdUJBQUEsR0FBQSxHQUFBLE1BQUEsQ0FBQTs7QUFJeEQsTUFBQSxzQ0FBQSxJQUFBLENBQUE7QUFDRSxNQUFBLHlCQUFBLElBQUEsdUJBQUEsR0FBQSxHQUFBLE1BQUEsQ0FBQSxFQUFzRCxJQUFBLHVCQUFBLEdBQUEsR0FBQSxNQUFBLENBQUE7O0FBSXhELE1BQUEsc0NBQUEsSUFBQSxDQUFBO0FBQ0UsTUFBQSx5QkFBQSxJQUFBLHVCQUFBLEdBQUEsR0FBQSxNQUFBLENBQUEsRUFBc0QsSUFBQSx1QkFBQSxHQUFBLEdBQUEsTUFBQSxDQUFBOztBQUl4RCxNQUFBLHlCQUFBLElBQUEsdUJBQUEsR0FBQSxHQUFBLE1BQUEsQ0FBQSxFQUF1RCxJQUFBLHVCQUFBLEdBQUEsR0FBQSxNQUFBLEVBQUE7QUFFekQsTUFBQSwyQkFBQTtBQUdBLE1BQUEsd0JBQUEsSUFBQSxpQkFBQSxFQUFBO0FBT0YsTUFBQSwyQkFBQTs7O0FBekNvQixNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLCtCQUFBLFdBQUEsSUFBQSxJQUFBO0FBR08sTUFBQSx3QkFBQTtBQUFBLE1BQUEseUJBQUEsY0FBQSxJQUFBLFVBQUE7QUEwQkgsTUFBQSx3QkFBQSxFQUFBO0FBQUEsTUFBQSx5QkFBQSxtQkFBQSxJQUFBLGdCQUFBO0FBQ2EsTUFBQSx3QkFBQTtBQUFBLE1BQUEseUJBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUlwQixNQUFBLHdCQUFBO0FBQUEsTUFBQSx5QkFBQSxVQUFBLElBQUEsT0FBQSxNQUFBLEVBQXdCLFlBQUEsQ0FBQSxFQUViLG1CQUFBLDhCQUFBLEdBQUFDLElBQUEsQ0FBQTs7b0JEM0JoQixZQUFZLGdCQUFjLFNBQUEsYUFBQSxtQkFBQSxxQkFBQSxvQkFBQSxpQkFBQSxlQUFBLGNBQUEscUJBQUEsb0JBQUEsa0JBQUEsWUFBQSxrQkFBQSxpQkFBQSxXQUFBLGlCQUFBLGlCQUFBLGtCQUFFLGVBQWEsWUFBQSxrQkFBRSxvQkFBa0IsaUJBQUUsZ0JBQWMsYUFBQSxpQkFBQSxhQUFBLFlBQUEsYUFBQSxjQUFBLGNBQUEsZ0JBQUEsd0JBQUUsYUFBVyx1QkFBQSxtQkFBQSxpQ0FBQSx5QkFBQSx3QkFBQSx1QkFBQSxpQ0FBQSwrQkFBQSx1Q0FBQSw4QkFBQSxvQkFBQSx5QkFBQSxzQkFBQSx1QkFBQSx1QkFBQSxxQkFBQSw4QkFBQSxtQkFBQSxpQkFBQSxpQkFBQSxZQUFBLGlCQUFBLFdBQUUsVUFBVSxHQUFBLFFBQUEsQ0FBQSxvUkFBQSxFQUFBLENBQUE7OztnRkFJckcsUUFBTSxDQUFBO1VBTmxCQzt1QkFDVyxjQUFZLFNBQ2IsQ0FBQyxZQUFZLGdCQUFnQixlQUFlLG9CQUFvQixnQkFBZ0IsYUFBYSxVQUFVLEdBQUMsVUFBQSxrcERBQUEsUUFBQSxDQUFBLHFRQUFBLEVBQUEsQ0FBQTs7VUFXaEg7V0FBVSxPQUFPOztVQUdqQjtXQUFVLFlBQVk7Ozs7aUZBVlosUUFBTSxFQUFBLFdBQUEsVUFBQSxVQUFBLHVDQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBTixRQUFNLEVBQUEsU0FBQSxDQUFBQyxLQUFBQyxLQUFBLElBQUEsSUFBQSxJQUFBLElBQUEsSUFBQSxFQUFBLEdBQUEsQ0FBQSxTQUFBLGNBQUEsWUFBQSxnQkFBQSxlQUFBLG9CQUFBLGdCQUFBLGFBQUEsWUFBQUYsWUFBQSxTQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxlQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGVBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUdsQm5CLFNBQVMsYUFBQUcsWUFBVyxVQUFBQyxlQUFjO0FBSWxDLFNBQVMsZ0JBQUFDLHFCQUFvQjtBQUM3QixTQUFTLHFCQUFxQjs7Ozs7Ozs7O0FDY2xCLElBQUEsNkJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxxQkFBQSxHQUFBLFNBQUE7QUFBTyxJQUFBLDJCQUFBOzs7OztBQUViLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBb0MsSUFBQSxxQkFBQSxHQUFBLFNBQUE7QUFBTyxJQUFBLDJCQUFBOzs7QUFBckMsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFDLElBQUEsQ0FBQTs7O0FEUlosSUFBTyxlQUFQLE1BQU8sY0FBWTtFQU1IO0VBSnBCO0VBRVEsZ0JBQWdCQyxRQUFPLGNBQWM7RUFFN0MsWUFBb0IsTUFBb0I7QUFBcEIsU0FBQSxPQUFBO0FBQ2hCLFFBQUksS0FBSyxLQUFLLFNBQVMsT0FBTyxJQUFJO0FBQ2xDLFNBQUssUUFBUSxLQUFLLGNBQWMsWUFBWSxFQUFFO0VBQ2xEOztxQ0FUVyxlQUFZLGdDQUFBLGtCQUFBLENBQUE7RUFBQTs2RUFBWixlQUFZLFdBQUEsQ0FBQSxDQUFBLG1CQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLFVBQUEsVUFBQSxHQUFBLGFBQUEsR0FBQSxNQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsc0JBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUNiekIsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNFLE1BQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFFQSxNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQW1CLEdBQUEsT0FBQSxDQUFBO0FBRWYsTUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLE1BQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBdUIsR0FBQSxNQUFBLENBQUE7QUFDRSxNQUFBLHFCQUFBLENBQUE7QUFBaUIsTUFBQSwyQkFBQTtBQUN4QyxNQUFBLDZCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQXFCLE1BQUEscUJBQUEsQ0FBQTtBQUFvQixNQUFBLDJCQUFBLEVBQUk7QUFFL0MsTUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQSxFQUF3QyxJQUFBLE1BQUEsQ0FBQSxFQUNWLElBQUEsVUFBQTtBQUFVLE1BQUEscUJBQUEsSUFBQSxlQUFBO0FBQWEsTUFBQSwyQkFBQTtBQUFZLE1BQUEscUJBQUEsRUFBQTtBQUFtQixNQUFBLDJCQUFBO0FBQ2xGLE1BQUEsNkJBQUEsSUFBQSxNQUFBLENBQUEsRUFBNEIsSUFBQSxVQUFBO0FBQVUsTUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxNQUFBLDJCQUFBO0FBQVksTUFBQSxxQkFBQSxFQUFBO0FBQWtCLE1BQUEsMkJBQUE7QUFDNUUsTUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQSxFQUE0QixJQUFBLFVBQUE7QUFDaEIsTUFBQSxxQkFBQSxJQUFBLGFBQUE7QUFBVyxNQUFBLDJCQUFBO0FBQ3JCLE1BQUEscUJBQUEsRUFBQTs7QUFDRixNQUFBLDJCQUFBO0FBQ0EsTUFBQSw2QkFBQSxJQUFBLE1BQUEsQ0FBQTtBQUNFLE1BQUEsa0NBQUEsSUFBQSxzQ0FBQSxHQUFBLEdBQUEsTUFBQSxFQUFxQixJQUFBLHNDQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUE7QUFLdkIsTUFBQSwyQkFBQSxFQUFLO0FBRVAsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF1QixJQUFBLEtBQUEsRUFBQTtBQUNzQyxNQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLE1BQUEsMkJBQUE7QUFDeEUsTUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNzQyxNQUFBLHFCQUFBLElBQUEsV0FBQTtBQUFTLE1BQUEsMkJBQUEsRUFBSSxFQUMvQyxFQUNGO0FBR1IsTUFBQSx3QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUNGLE1BQUEsMkJBQUE7OztBQTdCVyxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLE9BQUEsNEJBQUEsSUFBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsTUFBQSxHQUF1QiwyQkFBQSxFQUFBLE9BQXNCLDRCQUFBLElBQUEsU0FBQSxPQUFBLE9BQUEsSUFBQSxNQUFBLE1BQUEsQ0FBdUI7QUFFaEQsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxJQUFBLFNBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxNQUFBO0FBQ0YsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxJQUFBLFNBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxTQUFBO0FBRzBDLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsaUNBQUEsS0FBQSxJQUFBLFNBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxRQUFBO0FBQ0wsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSxpQ0FBQSxLQUFBLElBQUEsU0FBQSxPQUFBLE9BQUEsSUFBQSxNQUFBLE9BQUE7QUFHeEQsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSxpQ0FBQSxLQUFBLDBCQUFBLElBQUEsSUFBQSxJQUFBLFNBQUEsT0FBQSxPQUFBLElBQUEsTUFBQSxRQUFBLE9BQUEsVUFBQSxNQUFBLEdBQUEsR0FBQTtBQUdBLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsV0FBQSxLQUFBLEVBQUE7QUFRQyxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLFFBQUEsNEJBQUEsSUFBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxHQUFxQiwyQkFBQTtBQUNyQixNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLFFBQUEsNkJBQUEsc0NBQUEsSUFBQSxTQUFBLE9BQUEsT0FBQSxJQUFBLE1BQUEsV0FBQSxHQUErRCwyQkFBQTs7b0JEbEI5REYsZUFBWSxhQUFBLHVCQUFBLGFBQUEsVUFBQSxzQkFBQSxhQUFBLGNBQUEsa0JBQUEscUJBQUEsY0FBQSxrQkFBRSxlQUFhLGFBQUEsU0FBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGdCQUFBLEdBQUEsZUFBQSxFQUFBLENBQUE7OztnRkFJMUIsY0FBWSxDQUFBO1VBTnhCRzt1QkFDVyxxQkFBbUIsU0FDcEIsQ0FBQ0gsZUFBYyxhQUFhLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFBQSxDQUFBOzs7O2lGQUkzQixjQUFZLEVBQUEsV0FBQSxnQkFBQSxVQUFBLHFEQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBWixjQUFZLEVBQUEsU0FBQSxDQUFBSSxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxHQUFBLEdBQUEsQ0FBQVIsZUFBQSxlQUFBRyxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxxQkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxxQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRWJ6QixTQUFTLGFBQUFNLFlBQVcsVUFBQUMsU0FBZ0IsY0FBYzs7O0FFQWxELFNBQVMsYUFBYSxrQkFBa0I7QUFDeEMsU0FBUyxjQUFBQyxhQUFZLFVBQUFDLGVBQWM7O0FBTTdCLElBQU8saUJBQVAsTUFBTyxnQkFBYztFQUV6QixNQUFjO0VBQ2QsWUFBeUIsSUFBSSxZQUFZLEVBQUMsZ0JBQWdCLG1CQUFrQixDQUFDO0VBRXJFLE9BQU9BLFFBQU8sVUFBVTtFQUVoQyxTQUFNO0FBQ0osV0FBTyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssRUFBQyxTQUFTLEtBQUssVUFBUyxDQUFDO0VBQzFEOztxQ0FUVyxpQkFBYztFQUFBO2dGQUFkLGlCQUFjLFNBQWQsZ0JBQWMsV0FBQSxZQUZiLE9BQU0sQ0FBQTs7O2dGQUVQLGdCQUFjLENBQUE7VUFIMUJEO1dBQVc7TUFDVixZQUFZO0tBQ2I7Ozs7O0FGSkQsU0FBUyxnQkFBQUUscUJBQW9COzs7Ozs7O0FDRDNCLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBa0QsR0FBQSxVQUFBLENBQUE7QUFDMUIsSUFBQSxxQkFBQSxHQUFBLG1CQUFBO0FBQWlCLElBQUEsMkJBQUE7QUFDdkMsSUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNGLElBQUEsMkJBQUE7Ozs7O0FBSUksSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUFtQixHQUFBLE9BQUEsQ0FBQTtBQUViLElBQUEsd0JBQUEsR0FBQSxPQUFBLENBQUE7QUFDQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXVCLEdBQUEsTUFBQSxDQUFBO0FBQ0UsSUFBQSxxQkFBQSxDQUFBO0FBQWdCLElBQUEsMkJBQUE7QUFDdkMsSUFBQSw2QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUFxQixJQUFBLHFCQUFBLENBQUE7QUFBbUIsSUFBQSwyQkFBQSxFQUFJLEVBQ3hDLEVBQ0o7Ozs7QUFOWSxJQUFBLHdCQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLDhCQUFBLEdBQUFDLElBQUEsQ0FBQTtBQUNULElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsNEJBQUEsV0FBQSxLQUFBLEdBQXVCLDJCQUFBLEVBQUEsT0FBc0IsNEJBQUEsV0FBQSxJQUFBLENBQXNCO0FBRS9DLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsV0FBQSxJQUFBO0FBQ0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxXQUFBLE9BQUE7Ozs7O0FBUGpDLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRSxJQUFBLCtCQUFBLEdBQUEscUNBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQSxVQUFBO0FBV0YsSUFBQSwyQkFBQTs7OztBQVppQixJQUFBLHlCQUFBLFdBQUEsUUFBQTtBQUNmLElBQUEsd0JBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsU0FBQSxDQUFVOzs7QURJUixJQUFPLFNBQVAsTUFBTyxRQUFNO0VBRWpCLFdBQVcsT0FBYyxDQUFBLEdBQUUsR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLFdBQUEsQ0FBQSxJQUFBLENBQUEsQ0FBQTtFQUMzQixXQUFXLE9BQU8sTUFBSSxHQUFBLFlBQUEsQ0FBQSxFQUFBLFdBQUEsV0FBQSxDQUFBLElBQUEsQ0FBQSxDQUFBO0VBRWQsZ0JBQWdCQyxRQUFPLGNBQWM7RUFFN0MsV0FBUTtBQUNOLGVBQVcsTUFBSztBQUNaLFdBQUssY0FBYyxPQUFNLEVBQUcsVUFBVTtRQUNsQyxNQUFNLENBQUMsVUFBUztBQUNkLGtCQUFRLElBQUksS0FBSztBQUNqQixlQUFLLFNBQVMsSUFBSSxNQUFNLE9BQU87QUFDL0IsZUFBSyxTQUFTLElBQUksS0FBSztRQUN6QjtRQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2Isa0JBQVEsSUFBSSxHQUFHO1FBQ2pCO09BQ0Q7SUFDSCxHQUFHLEdBQUk7RUFFYjs7cUNBckJXLFNBQU07RUFBQTs2RUFBTixTQUFNLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsTUFBQSxTQUFBLEdBQUEsVUFBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLEdBQUEsQ0FBQSxlQUFBLFFBQUEsR0FBQSxrQkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxnQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1huQixNQUFBLGtDQUFBLEdBQUEsK0JBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQSxFQUFpQixHQUFBLCtCQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7OztBQUFqQixNQUFBLDRCQUFBLElBQUEsU0FBQSxJQUFBLElBQUEsQ0FBQTs7b0JET1lGLGVBQVksYUFBQSx1QkFBQSxhQUFBLFVBQUEsc0JBQUEsYUFBQSxjQUFBLGtCQUFBLHFCQUFBLGNBQUEsa0JBQUEsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxnQkFBQSxHQUFBLFFBQUEsQ0FBQSxzTUFBQSxFQUFBLENBQUE7OztnRkFJWCxRQUFNLENBQUE7VUFObEJHO3VCQUNXLGNBQVksU0FDYixDQUFDSCxhQUFZLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FBQSxRQUFBLENBQUEsME1BQUEsRUFBQSxDQUFBOzs7O2lGQUlaLFFBQU0sRUFBQSxXQUFBLFVBQUEsVUFBQSx1Q0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQU4sUUFBTSxFQUFBLFNBQUEsQ0FBQUksS0FBQUMsR0FBQSxHQUFBLENBQUFMLGVBQUFHLFVBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGVBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsZUFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBR1huQixTQUFTLGFBQUFHLFlBQVcsVUFBQUMsZUFBYztBQUNsQyxTQUFvQixlQUFBQyxjQUFhLHdCQUF3QixxQkFBcUIsa0JBQWtCO0FBQ2hHLFNBQVMsa0JBQUFDLHVCQUFzQjtBQUMvQixTQUFTLHVCQUF1Qjs7Ozs7Ozs7O0FDR3RCLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7Ozs7O0FBRzlCLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQThCLElBQUEsMkJBQUE7Ozs7O0FBUXpDLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7Ozs7O0FBRzlCLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLGtEQUFBO0FBQTZDLElBQUEsMkJBQUE7Ozs7O0FBUXhELElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7Ozs7O0FBRzlCLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLHNCQUFBO0FBQW9CLElBQUEsMkJBQUE7Ozs7O0FBUS9CLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7Ozs7O0FBRzlCLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQThCLElBQUEsMkJBQUE7Ozs7O0FBUXpDLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLHFCQUFBO0FBQW1CLElBQUEsMkJBQUE7Ozs7O0FBRzlCLElBQUEsNkJBQUEsR0FBQSxXQUFBO0FBQVcsSUFBQSxxQkFBQSxHQUFBLGlDQUFBO0FBQStCLElBQUEsMkJBQUE7OztBRDFDOUMsSUFBTyxXQUFQLE1BQU8sVUFBUTtFQUVYLEtBQUtGLFFBQU8sc0JBQXNCO0VBRTFDLGVBQTBCLEtBQUssR0FBRyxNQUFNO0lBQ3RDLFFBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxVQUFVLFdBQVcsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUM1RCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsVUFBVSxXQUFXLFFBQVEsb0JBQW9CLENBQUMsQ0FBQztJQUM5RSxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsVUFBVSxXQUFXLEtBQUssQ0FBQztJQUNuRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsVUFBVSxXQUFXLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDM0QsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLFVBQVUsV0FBVyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0dBQzlEO0VBRUQsVUFBTztBQUNMLFlBQVEsSUFBSSxLQUFLLGFBQWEsS0FBSztBQUNuQyxVQUFNLGtCQUFrQjtFQUMxQjs7cUNBZlcsV0FBUTtFQUFBOzZFQUFSLFdBQVEsV0FBQSxDQUFBLENBQUEsY0FBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxZQUFBLElBQUEsbUJBQUEsUUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLFlBQUEsSUFBQSxtQkFBQSxVQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsWUFBQSxJQUFBLG1CQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxZQUFBLElBQUEsbUJBQUEsUUFBQSxHQUFBLENBQUEsUUFBQSxLQUFBLFlBQUEsSUFBQSxtQkFBQSxTQUFBLEdBQUEsQ0FBQSxhQUFBLFVBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxrQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1hyQixNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQThCLEdBQUEsUUFBQSxDQUFBLEVBQ0ssR0FBQSxrQkFBQSxDQUFBLEVBQ2MsR0FBQSxXQUFBO0FBQzlCLE1BQUEscUJBQUEsR0FBQSxTQUFBO0FBQU8sTUFBQSwyQkFBQTtBQUNsQixNQUFBLHdCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQ0EsTUFBQSxrQ0FBQSxHQUFBLGlDQUFBLEdBQUEsR0FBQSxXQUFBO0FBR0EsTUFBQSxrQ0FBQSxHQUFBLGlDQUFBLEdBQUEsR0FBQSxXQUFBO0FBR0YsTUFBQSwyQkFBQTtBQUVBLE1BQUEsNkJBQUEsR0FBQSxrQkFBQSxDQUFBLEVBQTJDLEdBQUEsV0FBQTtBQUM5QixNQUFBLHFCQUFBLElBQUEsV0FBQTtBQUFTLE1BQUEsMkJBQUE7QUFDcEIsTUFBQSx3QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUNBLE1BQUEsa0NBQUEsSUFBQSxrQ0FBQSxHQUFBLEdBQUEsV0FBQTtBQUdBLE1BQUEsa0NBQUEsSUFBQSxrQ0FBQSxHQUFBLEdBQUEsV0FBQTtBQUdGLE1BQUEsMkJBQUE7QUFFQSxNQUFBLDZCQUFBLElBQUEsa0JBQUEsQ0FBQSxFQUEyQyxJQUFBLFdBQUE7QUFDOUIsTUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxNQUFBLDJCQUFBO0FBQ2pCLE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFDQSxNQUFBLGtDQUFBLElBQUEsa0NBQUEsR0FBQSxHQUFBLFdBQUE7QUFHQSxNQUFBLGtDQUFBLElBQUEsa0NBQUEsR0FBQSxHQUFBLFdBQUE7QUFHRixNQUFBLDJCQUFBO0FBRUEsTUFBQSw2QkFBQSxJQUFBLGtCQUFBLENBQUEsRUFBMkMsSUFBQSxXQUFBO0FBQzlCLE1BQUEscUJBQUEsSUFBQSxTQUFBO0FBQU8sTUFBQSwyQkFBQTtBQUNsQixNQUFBLHdCQUFBLElBQUEsU0FBQSxDQUFBO0FBQ0EsTUFBQSxrQ0FBQSxJQUFBLGtDQUFBLEdBQUEsR0FBQSxXQUFBO0FBR0EsTUFBQSxrQ0FBQSxJQUFBLGtDQUFBLEdBQUEsR0FBQSxXQUFBO0FBR0YsTUFBQSwyQkFBQTtBQUVBLE1BQUEsNkJBQUEsSUFBQSxrQkFBQSxDQUFBLEVBQTJDLElBQUEsV0FBQTtBQUM5QixNQUFBLHFCQUFBLElBQUEsVUFBQTtBQUFRLE1BQUEsMkJBQUE7QUFDbkIsTUFBQSx3QkFBQSxJQUFBLFlBQUEsQ0FBQTtBQUNBLE1BQUEsa0NBQUEsSUFBQSxrQ0FBQSxHQUFBLEdBQUEsV0FBQTtBQUdBLE1BQUEsa0NBQUEsSUFBQSxrQ0FBQSxHQUFBLEdBQUEsV0FBQTtBQUdGLE1BQUEsMkJBQUE7QUFFQSxNQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFNLElBQUEsVUFBQSxDQUFBO0FBQ3lCLE1BQUEscUJBQUEsSUFBQSxtQkFBQTtBQUFpQixNQUFBLDJCQUFBLEVBQVMsRUFDbEQsRUFDSjs7Ozs7Ozs7Ozs7OztBQTNERCxNQUFBLHdCQUFBO0FBQUEsTUFBQSx5QkFBQSxhQUFBLElBQUEsWUFBQTtBQUlBLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxRQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFVBQUEsS0FBQSxJQUFBLEVBQUE7QUFHQSxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsYUFBQSxJQUFBLFFBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsV0FBQSxLQUFBLElBQUEsRUFBQTtBQVFBLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxVQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFVBQUEsS0FBQSxLQUFBLEVBQUE7QUFHQSxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsYUFBQSxJQUFBLFVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsU0FBQSxLQUFBLEtBQUEsRUFBQTtBQVFBLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxPQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFVBQUEsS0FBQSxLQUFBLEVBQUE7QUFHQSxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsYUFBQSxJQUFBLE9BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsT0FBQSxLQUFBLEtBQUEsRUFBQTtBQVFBLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxRQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFVBQUEsS0FBQSxLQUFBLEVBQUE7QUFHQSxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsYUFBQSxJQUFBLFFBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsV0FBQSxLQUFBLEtBQUEsRUFBQTtBQVFBLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxTQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFVBQUEsS0FBQSxLQUFBLEVBQUE7QUFHQSxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxXQUFBLElBQUEsYUFBQSxJQUFBLFNBQUEsTUFBQSxPQUFBLE9BQUEsU0FBQSxVQUFBLE9BQUEsT0FBQSxTQUFBLE9BQUEsV0FBQSxLQUFBLEtBQUEsRUFBQTs7b0JEN0NJQyxjQUFXLHdCQUFBLG9CQUFBLGtDQUFBLDBCQUFBLHlCQUFBLHdCQUFBLGtDQUFBLGdDQUFBLHdDQUFBLCtCQUFBLHFCQUFBLDBCQUFBLHVCQUFBLHdCQUFBLHdCQUFBLHNCQUFBLCtCQUFBLG9CQUFBLGtCQUFBLGtCQUFBLGFBQUEsa0JBQUEsWUFBRSxxQkFBbUIsMEJBQUEsd0JBQUEscUJBQUEsbUJBQUEsbUJBQUNDLGlCQUFjLGNBQUEsa0JBQUEsY0FBQSxhQUFBLGNBQUEsZUFBQSxlQUFBLFNBQUEsaUJBQUEseUJBQUUsaUJBQWUsZUFBQSxzQkFBQSxtQkFBQSxnQkFBQSxHQUFBLFFBQUEsQ0FBQSwrUkFBQSxFQUFBLENBQUE7OztnRkFJL0QsVUFBUSxDQUFBO1VBTnBCSDt1QkFDVyxnQkFBYyxTQUNmLENBQUNFLGNBQWEscUJBQW9CQyxpQkFBZ0IsZUFBZSxHQUFDLFVBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FBQSxRQUFBLENBQUEsb1JBQUEsRUFBQSxDQUFBOzs7O2lGQUloRSxVQUFRLEVBQUEsV0FBQSxZQUFBLFVBQUEsMkNBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OytEQUFSLFVBQVEsRUFBQSxTQUFBLENBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEdBQUEsR0FBQSxDQUFBUCxjQUFBLHFCQUFBQyxpQkFBQSxpQkFBQUgsVUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsaUJBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsaUJBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVYckIsU0FBUyxhQUFBVSxrQkFBaUI7O0FBUXBCLElBQU8sUUFBUCxNQUFPLE9BQUs7O3FDQUFMLFFBQUs7RUFBQTs2RUFBTCxRQUFLLFdBQUEsQ0FBQSxDQUFBLFdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsT0FBQSxzSEFBQSxPQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxlQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDUmxCLE1BQUEsZ0NBQUEsR0FBQSxLQUFBO0FBQ0UsTUFBQSwyQkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVGLE1BQUEsOEJBQUE7Ozs7O2dGREthLE9BQUssQ0FBQTtVQU5qQkE7dUJBQ1csYUFBVyxTQUNaLENBQUEsR0FBRSxVQUFBLGdMQUFBLFFBQUEsQ0FBQSx5SkFBQSxFQUFBLENBQUE7Ozs7aUZBSUEsT0FBSyxFQUFBLFdBQUEsU0FBQSxVQUFBLHFDQUFBLFlBQUEsRUFBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBTCxPQUFLLEVBQUEsU0FBQSxDQUFBQyxHQUFBLEdBQUEsQ0FBQUQsVUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsY0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxjQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFUmxCLFNBQVMsY0FBYzs7O0FFQ3ZCLFNBQVMsY0FBQUUsYUFBWSxVQUFBQyxlQUFhO0FBQ2xDLFNBQVMsTUFBTSxXQUFXLDRCQUE0QixlQUFxQjs7QUFLckUsSUFBTyxlQUFQLE1BQU8sY0FBWTs7RUFJdkIsT0FBT0EsUUFBTyxJQUFJO0VBRWxCLE1BQU0sT0FBZSxJQUFVO0FBQzdCLFdBQU8sMkJBQTJCLEtBQUssTUFBTSxPQUFNLEVBQUU7RUFDdkQ7RUFFQSxTQUFNO0FBQ0osV0FBTyxRQUFRLEtBQUssSUFBSTtFQUMxQjtFQUVBLFdBQVE7QUFFTixXQUFPLFVBQVUsS0FBSyxJQUFJO0VBQzVCOztxQ0FqQlcsZUFBWTtFQUFBO2lGQUFaLGVBQVksU0FBWixjQUFZLFdBQUEsWUFGWCxPQUFNLENBQUE7OztpRkFFUCxjQUFZLENBQUE7VUFIeEJEO1dBQVc7TUFDVixZQUFZO0tBQ2I7Ozs7O0FGSkQsU0FBUyxhQUFBRSxZQUFXLFVBQUFDLGVBQWM7QUFDbEMsU0FBUyxlQUFBQyxvQkFBbUI7QUFFNUIsU0FBUyxrQkFBQUMsdUJBQXNCO0FBQy9CLFNBQVMsbUJBQUFDLHdCQUF1Qjs7Ozs7OztBQVExQixJQUFPLFFBQVAsTUFBTyxPQUFLO0VBRWhCLFVBQWtCO0VBQ2xCLEtBQWE7RUFFYixPQUFPSCxRQUFPLFlBQVk7RUFDMUIsU0FBU0EsUUFBTyxNQUFNO0VBRXRCLGdCQUFhO0FBQ1gsU0FBSyxLQUFLLE1BQU0sS0FBSyxTQUFTLEtBQUssRUFBRSxFQUNoQyxLQUFLLENBQUMsVUFBUztBQUNkLGNBQVEsSUFBSSxLQUFLO0FBRWpCLFVBQUksU0FBUyxNQUFLO0FBQ2hCLGFBQUssT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDO01BQ2pDO0lBQ0YsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFPO0FBQ2IsY0FBUSxJQUFJLEdBQUc7SUFDakIsQ0FBQztFQUNQOztxQ0FwQlcsUUFBSztFQUFBOzhFQUFMLFFBQUssV0FBQSxDQUFBLENBQUEsV0FBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxZQUFBLElBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxhQUFBLFlBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZUFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ2RsQixNQUFBLDhCQUFBLEdBQUEsS0FBQSxFQUFLLEdBQUEsSUFBQTtBQUNDLE1BQUEsc0JBQUEsR0FBQSxPQUFBO0FBQUssTUFBQSw0QkFBQTtBQUVULE1BQUEsOEJBQUEsR0FBQSxrQkFBQSxDQUFBLEVBQTJDLEdBQUEsV0FBQTtBQUM5QixNQUFBLHNCQUFBLEdBQUEsUUFBQTtBQUFNLE1BQUEsNEJBQUE7QUFDakIsTUFBQSw4QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUFnQixNQUFBLGdDQUFBLGlCQUFBLFNBQUEsOENBQUEsUUFBQTtBQUFBLFFBQUEsa0NBQUEsSUFBQSxTQUFBLE1BQUEsTUFBQSxJQUFBLFVBQUE7QUFBQSxlQUFBO01BQUEsQ0FBQTtBQUFoQixNQUFBLDRCQUFBLEVBQXNDO0FBQ3RCLE1BQUEseUJBQUEsR0FBQSxJQUFBO0FBRWxCLE1BQUEsOEJBQUEsR0FBQSxrQkFBQSxDQUFBLEVBQTJDLEdBQUEsV0FBQTtBQUM5QixNQUFBLHNCQUFBLElBQUEsV0FBQTtBQUFTLE1BQUEsNEJBQUE7QUFDcEIsTUFBQSw4QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUFnQixNQUFBLGdDQUFBLGlCQUFBLFNBQUEsK0NBQUEsUUFBQTtBQUFBLFFBQUEsa0NBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQSxJQUFBLEtBQUE7QUFBQSxlQUFBO01BQUEsQ0FBQTtBQUFoQixNQUFBLDRCQUFBLEVBQWlDO0FBQ2pCLE1BQUEseUJBQUEsSUFBQSxJQUFBO0FBRWxCLE1BQUEsOEJBQUEsSUFBQSxNQUFBLEVBQU0sSUFBQSxVQUFBLENBQUE7QUFDeUIsTUFBQSwwQkFBQSxTQUFBLFNBQUEsMENBQUE7QUFBQSxlQUFTLElBQUEsY0FBQTtNQUFlLENBQUE7QUFBRSxNQUFBLHNCQUFBLElBQUEsU0FBQTtBQUFPLE1BQUEsNEJBQUEsRUFBUyxFQUNsRTs7O0FBVlcsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxXQUFBLElBQUEsT0FBQTtBQUtBLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsV0FBQSxJQUFBLEVBQUE7O29CREFSQyxjQUFXLHdCQUFBLG9CQUFBLGtDQUFBLDBCQUFBLHlCQUFBLHdCQUFBLGtDQUFBLGdDQUFBLHdDQUFBLCtCQUFBLHFCQUFBLDBCQUFBLHVCQUFBLHdCQUFBLHdCQUFBLHNCQUFBLCtCQUFBLG9CQUFBLGtCQUFBLGtCQUFBLGFBQUEsa0JBQUEsWUFBRUMsaUJBQWMsY0FBQSxrQkFBQSxjQUFBLGFBQUEsY0FBQSxlQUFBLGVBQUEsU0FBQSxpQkFBQSx5QkFBRUMsa0JBQWUsZUFBQSxzQkFBQSxtQkFBQSxnQkFBQSxHQUFBLFFBQUEsQ0FBQSwrSkFBQSxFQUFBLENBQUE7OztpRkFJM0MsT0FBSyxDQUFBO1VBTmpCSjt1QkFDVyxhQUFXLFNBQ1osQ0FBQ0UsY0FBYUMsaUJBQWdCQyxnQkFBZSxHQUFDLFVBQUEsNmJBQUEsUUFBQSxDQUFBLG9MQUFBLEVBQUEsQ0FBQTs7OztrRkFJNUMsT0FBSyxFQUFBLFdBQUEsU0FBQSxVQUFBLHFDQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBTCxPQUFLLEVBQUEsU0FBQSxDQUFBQyxNQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxHQUFBLEdBQUEsQ0FBQVIsY0FBQUMsaUJBQUFDLGtCQUFBSixVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxjQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGNBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUdkbEIsU0FBUyxhQUFBVyxZQUFXLFVBQUFDLGdCQUFjO0FBRWxDLFNBQVMsVUFBQUMsZUFBYzs7QUFRakIsSUFBTyxRQUFQLE1BQU8sT0FBSztFQUVoQixPQUFPQyxTQUFPLFlBQVk7RUFDMUIsU0FBU0EsU0FBT0QsT0FBTTtFQUV0QixlQUFZO0FBQ1YsU0FBSyxLQUFLLE9BQU07QUFHaEIsU0FBSyxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUM7RUFFaEM7O3FDQVhXLFFBQUs7RUFBQTs4RUFBTCxRQUFLLFdBQUEsQ0FBQSxDQUFBLFdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZUFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1ZsQixNQUFBLGlDQUFBLEdBQUEsSUFBQTtBQUFJLE1BQUEsc0JBQUEsR0FBQSxpREFBQTtBQUErQyxNQUFBLCtCQUFBO0FBRW5ELE1BQUEsaUNBQUEsR0FBQSxVQUFBLENBQUE7QUFBUSxNQUFBLDZCQUFBLFNBQUEsU0FBQSx5Q0FBQTtBQUFBLGVBQVMsSUFBQSxhQUFBO01BQWMsQ0FBQTtBQUFFLE1BQUEsc0JBQUEsR0FBQSxRQUFBO0FBQU0sTUFBQSwrQkFBQTs7Ozs7aUZEUTFCLE9BQUssQ0FBQTtVQU5qQkU7dUJBQ1csYUFBVyxTQUNaLENBQUEsR0FBRSxVQUFBLGlIQUFBLENBQUE7Ozs7a0ZBSUEsT0FBSyxFQUFBLFdBQUEsU0FBQSxVQUFBLHFDQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBTCxPQUFLLEVBQUEsU0FBQSxDQUFBQyxJQUFBLEdBQUEsQ0FBQUQsVUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsY0FBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxjQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFVmxCLFNBQVMsVUFBQUUsZ0JBQWM7QUFDdkIsU0FBd0IsVUFBQUMsZUFBYztBQUV0QyxTQUFTLFdBQVc7QUFFYixJQUFNLFlBQTJCLE1BQUs7QUFFM0MsUUFBTSxPQUFPQyxTQUFPLFlBQVk7QUFDaEMsUUFBTSxTQUFTQSxTQUFPQyxPQUFNO0FBRTVCLFNBQU8sS0FBSyxTQUFRLEVBQUcsS0FDckIsSUFBSSxDQUFDLFVBQVM7QUFDWixRQUFJLFNBQVMsTUFBTTtBQUNmLGFBQU87SUFDWCxPQUFPO0FBQ0gsYUFBTyxPQUFPLGNBQWMsQ0FBQyxRQUFRLENBQUM7SUFDMUM7RUFDRixDQUFDLENBQUM7QUFHTjs7O0FDVE8sSUFBTSxTQUFpQjtFQUM1QixFQUFDLE1BQU0sUUFBUSxXQUFXLEtBQUk7RUFDOUIsRUFBQyxNQUFNLFVBQVUsV0FBVyxPQUFNO0VBQ2xDLEVBQUMsTUFBTSxxQkFBcUIsV0FBVyxhQUFZO0VBQ25ELEVBQUMsTUFBTSxVQUFVLFdBQVcsT0FBTTtFQUNsQyxFQUFDLE1BQU0sWUFBWSxXQUFXLFNBQVE7RUFDdEMsRUFBQyxNQUFNLFNBQVMsV0FBVyxNQUFLO0VBQ2hDLEVBQUMsTUFBTSxTQUFTLFdBQVcsT0FBTyxhQUFhLENBQUMsU0FBUyxFQUFDO0VBQzFELEVBQUMsTUFBTSxJQUFJLFlBQVksUUFBUSxXQUFXLE9BQU07O0VBQ2hELEVBQUMsTUFBTSxNQUFNLFdBQVcsTUFBSzs7OztBdEJmL0IsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUywrQkFBK0I7QUFFeEMsU0FBUyxlQUFlLDBCQUEwQjtBQUNsRCxTQUFTLGFBQWEsZUFBZTs7O0F1QlQ5QixJQUFNLGNBQWM7RUFDekIsWUFBWTtFQUNaLGdCQUFnQjtJQUNkLFFBQVE7SUFDUixZQUFZO0lBQ1osV0FBVztJQUNYLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsT0FBTzs7Ozs7QXZCSUosSUFBTSxZQUErQjtFQUMxQyxXQUFXO0lBQ1QsbUNBQWtDO0lBQ2xDLDJCQUEyQixFQUFFLGlCQUFpQixLQUFJLENBQUU7SUFDcEQsY0FBYyxNQUFNO0lBQ3BCLGtCQUFpQjtJQUNqQiwyQkFBMEI7SUFDMUIsd0JBQXdCO01BQ3RCLFFBQVEsMkJBQTJCO1FBQ2pDLFFBQVE7UUFDUixRQUFRO09BQ1Q7S0FDRjtJQUNELG1CQUFtQixNQUFNLGNBQWMsWUFBWSxjQUFjLENBQUM7SUFDbEUsWUFBWSxNQUFNLFFBQU8sQ0FBRTs7Ozs7QXdCMUIvQixTQUFTLGFBQUFDLG1CQUF5QjtBQUNsQyxTQUFTLG9CQUFvQjs7O0FFRDdCLFNBQVMsYUFBQUMsWUFBVyxVQUFBQyxnQkFBYztBQUNsQyxTQUFTLGVBQWUsb0JBQUFDLHlCQUF3Qjs7QUFRMUMsSUFBTyxTQUFQLE1BQU8sUUFBTTtFQUVqQixTQUFnQjtFQUVSLFlBQVlELFNBQU9DLGlCQUFnQjtFQUUzQyxjQUFBO0FBRUUsU0FBSyxVQUFVLElBQUksS0FBSyxNQUFNO0VBQ2hDO0VBRUEsY0FBYyxhQUFtQjtBQUMvQixTQUFLLFNBQVM7QUFHZCxTQUFLLFVBQVUsSUFBSSxLQUFLLE1BQU07RUFDaEM7O3FDQWhCVyxTQUFNO0VBQUE7OEVBQU4sU0FBTSxXQUFBLENBQUEsQ0FBQSxZQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLE9BQUEsWUFBQSxPQUFBLDBCQUFBLEdBQUEsQ0FBQSxPQUFBLHNCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsT0FBQSwyQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLE9BQUEsd0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxPQUFBLHlCQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdCQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDVG5CLE1BQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFDQSxNQUFBLGlDQUFBLEdBQUEsSUFBQTtBQUFJLE1BQUEsc0JBQUEsQ0FBQTs7QUFBZ0MsTUFBQSwrQkFBQTtBQUVwQyxNQUFBLGlDQUFBLEdBQUEsTUFBQSxFQUFNLEdBQUEsT0FBQSxDQUFBO0FBQ0MsTUFBQSw2QkFBQSxTQUFBLFNBQUEsdUNBQUE7QUFBQSxlQUFTLElBQUEsY0FBYyxJQUFJO01BQUMsQ0FBQTtBQUFqQyxNQUFBLCtCQUFBO0FBQ0EsTUFBQSxpQ0FBQSxHQUFBLE9BQUEsQ0FBQTtBQUFLLE1BQUEsNkJBQUEsU0FBQSxTQUFBLHVDQUFBO0FBQUEsZUFBUyxJQUFBLGNBQWMsSUFBSTtNQUFDLENBQUE7QUFBakMsTUFBQSwrQkFBQTtBQUNBLE1BQUEsaUNBQUEsR0FBQSxPQUFBLENBQUE7QUFBSyxNQUFBLDZCQUFBLFNBQUEsU0FBQSx1Q0FBQTtBQUFBLGVBQVMsSUFBQSxjQUFjLElBQUk7TUFBQyxDQUFBO0FBQWpDLE1BQUEsK0JBQUE7QUFDQSxNQUFBLGlDQUFBLEdBQUEsT0FBQSxDQUFBO0FBQUssTUFBQSw2QkFBQSxTQUFBLFNBQUEsdUNBQUE7QUFBQSxlQUFTLElBQUEsY0FBYyxJQUFJO01BQUMsQ0FBQTtBQUFqQyxNQUFBLCtCQUFBLEVBQWlFOzs7QUFOL0QsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSxpQ0FBQSwyQkFBQSxHQUFBLEdBQUEsZUFBQSxDQUFBOztvQkRJUSxhQUFhLEdBQUEsUUFBQSxDQUFBLG1XQUFBLEVBQUEsQ0FBQTs7O2lGQUlaLFFBQU0sQ0FBQTtVQU5sQkY7dUJBQ1csY0FBWSxTQUNiLENBQUMsYUFBYSxHQUFDLFVBQUE7Ozs7Ozs7OztHQUFBLFFBQUEsQ0FBQSw0U0FBQSxFQUFBLENBQUE7Ozs7a0ZBSWIsUUFBTSxFQUFBLFdBQUEsVUFBQSxVQUFBLHVDQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBTixRQUFNLEVBQUEsU0FBQSxDQUFBRyxJQUFBLEdBQUEsQ0FBQSxlQUFBSCxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxlQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGVBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUVUbkIsU0FBUyxhQUFBSSxtQkFBaUI7QUFDMUIsU0FBUyxpQkFBQUMsc0JBQXFCOzs7QUFReEIsSUFBTyxTQUFQLE1BQU8sUUFBTTs7cUNBQU4sU0FBTTtFQUFBOzhFQUFOLFNBQU0sV0FBQSxDQUFBLENBQUEsWUFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxVQUFBLFNBQUEsZ0JBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUNUbkIsTUFBQSxpQ0FBQSxHQUFBLEdBQUE7QUFBRyxNQUFBLHNCQUFBLENBQUE7O0FBQXlELE1BQUEsK0JBQUE7OztBQUF6RCxNQUFBLHlCQUFBO0FBQUEsTUFBQSxpQ0FBQSwyQkFBQSxHQUFBLEdBQUEscUJBQUEsK0JBQUEsR0FBQUMsSUFBQSxDQUFBLENBQUE7O29CREtTRCxjQUFhLEdBQUEsUUFBQSxDQUFBLHVKQUFBLEVBQUEsQ0FBQTs7O2lGQUlaLFFBQU0sQ0FBQTtVQU5sQkQ7dUJBQ1csY0FBWSxTQUNiLENBQUNDLGNBQWEsR0FBQyxVQUFBO0dBQUEsUUFBQSxDQUFBLDhLQUFBLEVBQUEsQ0FBQTs7OztrRkFJYixRQUFNLEVBQUEsV0FBQSxVQUFBLFVBQUEsdUNBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUFOLFFBQU0sRUFBQSxTQUFBLENBQUFFLElBQUEsR0FBQSxDQUFBRixnQkFBQUQsV0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsZUFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxlQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFVG5CLFNBQVMsYUFBQUksbUJBQWlCO0FBQzFCLFNBQVMsY0FBQUMsbUJBQWtCO0FBQzNCLFNBQVMsaUJBQUFDLHNCQUFxQjs7QUFReEIsSUFBTyxTQUFQLE1BQU8sUUFBTTs7cUNBQU4sU0FBTTtFQUFBOzhFQUFOLFNBQU0sV0FBQSxDQUFBLENBQUEsWUFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxpQkFBQSxRQUFBLEdBQUEsVUFBQSxXQUFBLG9CQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxRQUFBLEtBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxPQUFBLFlBQUEsT0FBQSxRQUFBLFVBQUEsTUFBQSxHQUFBLGtCQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsa0JBQUEsWUFBQSxrQkFBQSxjQUFBLGlCQUFBLGFBQUEsaUJBQUEsU0FBQSxjQUFBLHFCQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLE1BQUEsYUFBQSxHQUFBLFlBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxjQUFBLFFBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxjQUFBLFVBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxjQUFBLFVBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxjQUFBLFlBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxjQUFBLFNBQUEsR0FBQSxVQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZ0JBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUNWbkIsTUFBQSw4QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUFtRixHQUFBLE9BQUEsQ0FBQSxFQUNwRCxHQUFBLEtBQUEsQ0FBQTtBQUV6QixNQUFBLHlCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0YsTUFBQSw0QkFBQTtBQUNBLE1BQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFDRSxNQUFBLHlCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQ0YsTUFBQSw0QkFBQTtBQUNBLE1BQUEsOEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBcUQsR0FBQSxNQUFBLENBQUEsRUFDNUIsR0FBQSxNQUFBLENBQUEsRUFDQSxHQUFBLEtBQUEsQ0FBQTtBQUNtQixNQUFBLHNCQUFBLEVBQUE7O0FBQTZCLE1BQUEsNEJBQUEsRUFBSTtBQUV6RSxNQUFBLDhCQUFBLElBQUEsTUFBQSxDQUFBLEVBQXFCLElBQUEsS0FBQSxFQUFBO0FBQ3FCLE1BQUEsc0JBQUEsRUFBQTs7QUFBK0IsTUFBQSw0QkFBQSxFQUFJO0FBRTdFLE1BQUEsOEJBQUEsSUFBQSxNQUFBLENBQUEsRUFBcUIsSUFBQSxLQUFBLEVBQUE7QUFDcUIsTUFBQSxzQkFBQSxFQUFBOztBQUErQixNQUFBLDRCQUFBLEVBQUk7QUFFN0UsTUFBQSw4QkFBQSxJQUFBLE1BQUEsQ0FBQSxFQUFxQixJQUFBLEtBQUEsRUFBQTtBQUN1QixNQUFBLHNCQUFBLEVBQUE7O0FBQWlDLE1BQUEsNEJBQUEsRUFBSTtBQUVqRixNQUFBLDhCQUFBLElBQUEsTUFBQSxDQUFBLEVBQXFCLElBQUEsS0FBQSxFQUFBO0FBQ29CLE1BQUEsc0JBQUEsRUFBQTs7QUFBOEIsTUFBQSw0QkFBQSxFQUFJLEVBQ3RFLEVBQ0YsRUFDRCxFQUNGOzs7QUFoQndDLE1BQUEseUJBQUEsRUFBQTtBQUFBLE1BQUEsaUNBQUEsMkJBQUEsSUFBQSxHQUFBLGFBQUEsQ0FBQTtBQUdFLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsaUNBQUEsMkJBQUEsSUFBQSxHQUFBLGVBQUEsQ0FBQTtBQUdBLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsaUNBQUEsMkJBQUEsSUFBQSxHQUFBLGVBQUEsQ0FBQTtBQUdFLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsaUNBQUEsMkJBQUEsSUFBQSxJQUFBLGlCQUFBLENBQUE7QUFHSCxNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLGlDQUFBLDJCQUFBLElBQUEsSUFBQSxjQUFBLENBQUE7O29CRGpCckNELGFBQVlDLGNBQWEsR0FBQSxlQUFBLEVBQUEsQ0FBQTs7O2lGQUl4QixRQUFNLENBQUE7VUFObEJGO3VCQUNXLGNBQVksU0FDYixDQUFDQyxhQUFZQyxjQUFhLEdBQUMsVUFBQSx3eENBQUEsQ0FBQTs7OztrRkFJekIsUUFBTSxFQUFBLFdBQUEsVUFBQSxVQUFBLHVDQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBTixRQUFNLEVBQUEsU0FBQSxDQUFBQyxJQUFBLEdBQUEsQ0FBQUYsYUFBQUMsZ0JBQUFGLFdBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGVBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsZUFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7QU5FYixJQUFPLE1BQVAsTUFBTyxLQUFHOztxQ0FBSCxNQUFHO0VBQUE7OEVBQUgsTUFBRyxXQUFBLENBQUEsQ0FBQSxVQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFVBQUEsU0FBQSxhQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDWmhCLE1BQUEsOEJBQUEsR0FBQSxRQUFBO0FBQ0UsTUFBQSx5QkFBQSxHQUFBLFlBQUE7QUFDRixNQUFBLDRCQUFBO0FBRUEsTUFBQSw4QkFBQSxHQUFBLEtBQUE7QUFDRSxNQUFBLHlCQUFBLEdBQUEsWUFBQTtBQUNGLE1BQUEsNEJBQUE7QUFFQSxNQUFBLDhCQUFBLEdBQUEsU0FBQTtBQUNFLE1BQUEseUJBQUEsR0FBQSxlQUFBO0FBQ0YsTUFBQSw0QkFBQTtBQUVBLE1BQUEsOEJBQUEsR0FBQSxRQUFBO0FBQ0UsTUFBQSx5QkFBQSxHQUFBLFlBQUE7QUFDRixNQUFBLDRCQUFBOztvQkROWSxjQUFjLFFBQVEsUUFBUSxNQUFNLEdBQUEsUUFBQSxDQUFBLGlUQUFBLEVBQUEsQ0FBQTs7O2lGQUluQyxLQUFHLENBQUE7VUFOZkk7dUJBQ1csWUFBVSxTQUNYLENBQUMsY0FBYyxRQUFRLFFBQVEsTUFBTSxHQUFDLFVBQUEsb05BQUEsUUFBQSxDQUFBLDZRQUFBLEVBQUEsQ0FBQTs7OztrRkFJcEMsS0FBRyxFQUFBLFdBQUEsT0FBQSxVQUFBLGtCQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OztnRUFBSCxLQUFHLEVBQUEsU0FBQSxDQUFBQyxJQUFBLEdBQUEsQ0FBQSxjQUFBLFFBQUEsUUFBQSxRQUFBRCxXQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxZQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLFlBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QXpCUmhCLHFCQUFxQixLQUFLLFNBQVMsRUFDaEMsTUFBTSxDQUFDLFFBQVEsUUFBUSxNQUFNLEdBQUcsQ0FBQzsiLCJuYW1lcyI6WyJpMCIsIkNvbXBvbmVudCIsImluamVjdCIsImluamVjdCIsImluamVjdCIsIl9jMCIsIkNvbXBvbmVudCIsImkwIiwiaTEiLCJDb21wb25lbnQiLCJpbmplY3QiLCJDb21tb25Nb2R1bGUiLCJfYzAiLCJpbmplY3QiLCJDb21wb25lbnQiLCJpMCIsImkyIiwiaTMiLCJpNCIsImkxIiwiQ29tcG9uZW50IiwiaW5qZWN0IiwiSW5qZWN0YWJsZSIsImluamVjdCIsIkNvbW1vbk1vZHVsZSIsIl9jMCIsImluamVjdCIsIkNvbXBvbmVudCIsImkwIiwiaTEiLCJDb21wb25lbnQiLCJpbmplY3QiLCJGb3Jtc01vZHVsZSIsIk1hdElucHV0TW9kdWxlIiwiaTAiLCJpMSIsImkyIiwiaTMiLCJpNCIsImk1IiwiQ29tcG9uZW50IiwiaTAiLCJJbmplY3RhYmxlIiwiaW5qZWN0IiwiQ29tcG9uZW50IiwiaW5qZWN0IiwiRm9ybXNNb2R1bGUiLCJNYXRJbnB1dE1vZHVsZSIsIk1hdEJ1dHRvbk1vZHVsZSIsImkwIiwiaTEiLCJpMiIsImkzIiwiaTQiLCJpNSIsIkNvbXBvbmVudCIsImluamVjdCIsIlJvdXRlciIsImluamVjdCIsIkNvbXBvbmVudCIsImkwIiwiaW5qZWN0IiwiUm91dGVyIiwiaW5qZWN0IiwiUm91dGVyIiwiQ29tcG9uZW50IiwiQ29tcG9uZW50IiwiaW5qZWN0IiwiVHJhbnNsYXRlU2VydmljZSIsImkwIiwiQ29tcG9uZW50IiwiVHJhbnNsYXRlUGlwZSIsIl9jMCIsImkwIiwiQ29tcG9uZW50IiwiUm91dGVyTGluayIsIlRyYW5zbGF0ZVBpcGUiLCJpMCIsIkNvbXBvbmVudCIsImkwIl19
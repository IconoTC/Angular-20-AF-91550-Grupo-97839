import { Nota } from './nota';

describe('Nota', () => {
  it('should create an instance', () => {
    const directive = new Nota();
    expect(directive).toBeTruthy();
  });
});

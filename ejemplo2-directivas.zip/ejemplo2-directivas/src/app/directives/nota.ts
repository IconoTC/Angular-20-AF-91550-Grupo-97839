import { Directive, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appNota]'
})
export class Nota implements OnInit{

  @Input()
  alumno: any;

  // En el constructor inyectamos los recursos que vamos a utilizar
  constructor(private renderer: Renderer2, private elRef: ElementRef) {}

  // Este metodo se ejecuta a continuacion del constructor
  ngOnInit(): void {
    if (this.alumno.nota >= 5){
      // document.getElementById("li").innerHTML("........")
      // this.renderer.setProperty(elemento, propiedad, valor)
      this.renderer.setProperty(this.elRef.nativeElement, "innerHTML",
        `${this.alumno.nombre} ${this.alumno.apellido} ${this.alumno.nota} - APROBADO` );
    } else {
      this.renderer.setProperty(this.elRef.nativeElement, "innerHTML",
        `${this.alumno.nombre} ${this.alumno.apellido} ${this.alumno.nota} - SUSPENSO` );
    }
  }

}

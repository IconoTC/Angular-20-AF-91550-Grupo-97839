import { Component, inject} from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  imports: [TranslatePipe],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  idioma:string = 'es';

  private translate = inject(TranslateService);

  constructor(){
    // Indicamos el idioma por defecto de la aplicacion
    this.translate.use(this.idioma);
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;

    // Forzamos el cambio de idioma
    this.translate.use(this.idioma);
  }
}

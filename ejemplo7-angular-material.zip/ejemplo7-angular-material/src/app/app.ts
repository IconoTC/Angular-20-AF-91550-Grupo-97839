import { Component, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [MatTabsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCheckboxModule,
    MatMenuModule,
    MatGridListModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  nombres: any[] = [
    {nombre: 'Juan', color: 'yellow'},
    {nombre: 'Maria', color: 'orange'},
    {nombre: 'Pedro', color: 'pink'},
    {nombre: 'Laura', color: 'blue'},
    {nombre: 'Jorge', color: 'green'},
    {nombre: 'Lucia', color: 'red'}
  ];
}

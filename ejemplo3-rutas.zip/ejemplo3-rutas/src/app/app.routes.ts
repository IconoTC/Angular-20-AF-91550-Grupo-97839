import { Routes } from '@angular/router';
import { Componente1 } from './components/componente1/componente1';
import { Componente2 } from './components/componente2/componente2';
import { Componente3 } from './components/componente3/componente3';

export const routes: Routes = [
  {path: 'c1', component: Componente1},
  {path: 'c2', component: Componente2},
  {path: 'c3/:hotel', component: Componente3}
];

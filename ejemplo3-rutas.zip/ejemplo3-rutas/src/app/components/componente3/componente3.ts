import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-componente3',
  imports: [],
  templateUrl: './componente3.html',
  styleUrl: './componente3.css',
})
export class Componente3 {

  hotel: string = '';
  entrada: string = '';
  salida: string = '';
  habitaciones: number = 0;

  constructor(private ruta: ActivatedRoute){
    console.log(ruta);

    // Recuperar el parametro REST de la ruta
    // Con el mismo nombre que hemos declarado en app.routes.ts 'c3/:hotel'
    this.hotel = this.ruta.snapshot.params['hotel'];

    // Recuperar los query params
    // Con el mismo nombre que se ha enviado en [queryParams]
    this.entrada = this.ruta.snapshot.queryParams['entrada'];
    this.salida = this.ruta.snapshot.queryParams['salida'];
    this.habitaciones = this.ruta.snapshot.queryParams['habitaciones'];
  }

}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ServicioUsuarios {

  url: string = "https://jsonplaceholder.typicode.com/users/";
  cabeceras: HttpHeaders = new HttpHeaders({'Content-type':'application/json'});

  private http = inject(HttpClient);

  // Consultar todos
  getAll(): Observable<any>{
    return this.http.get(this.url, {headers: this.cabeceras});
  }

  // buscar un usuario
  buscarUsuario(id: number): Observable<any>{
    return this.http.get(this.url + id, {headers: this.cabeceras});
  }

  // crear usuario nuevo
  crearUsuario(nuevo: any): Observable<any>{
    return this.http.post(this.url, nuevo, {headers: this.cabeceras});
  }

  // eliminar usuario
  eliminarUsuario(id: number): Observable<any>{
    return this.http.delete(this.url + id, {headers: this.cabeceras});
  }

  // modificar usuario
  modificarUsuario(id: number, actual: any): Observable<any>{
    return this.http.put(this.url + id, actual, {headers: this.cabeceras});
  }
}

import { Component, inject, OnInit, signal } from '@angular/core';

import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { ServicioUsuarios } from './services/servicio-usuarios';
import { FormGroup, FormsModule, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [MatTabsModule, MatIconModule, FormsModule, ReactiveFormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit{

  id: number = 0;
  mostrar: boolean = false;
  usuarios = signal<any[]>([]);
  usuario = signal<any>({});

  private servicioUsuarios = inject(ServicioUsuarios);
  private fb = inject(NonNullableFormBuilder);

  usuarioForm: FormGroup = this.fb.group({
    id: [0, [Validators.required, Validators.min(1)]],
    name: ['', [Validators.required, Validators.minLength(3)]],
    username: ['', [Validators.required, Validators.minLength(5)]],
    email: ['', [Validators.required, Validators.email]],
    company: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(15)]]
  });

  modificar(): void{
    this.servicioUsuarios.modificarUsuario(this.id, this.usuarioForm.value).subscribe({
      next: (datos) => {
        console.log(datos);
        alert("Usuario modificado");
        this.usuario.set({}); // Esconde los datos del usuario
        this.id = 0; // limpiar el formulario
        this.mostrar = false;
      },
      error: (err) => {
        console.log(err);
      }
    });
  }

  editar():void{
    this.usuarioForm.setValue({
      id: this.usuario().id,
      name: this.usuario().name,
      username: this.usuario().username,
      email: this.usuario().email,
      company: this.usuario().company.name
    });
    this.mostrar = true;
  }

  eliminar(): void{
    this.servicioUsuarios.eliminarUsuario(this.id).subscribe({
      next: (datos) => {
        //console.log(datos);
        alert("Usuario eliminado")
        this.usuario.set({}); // Esconde los datos del usuario
        this.id = 0; // limpiar el formulario
      },
      error: (err) => {
        console.log(err);
      }
    });
  }

  buscar(): void{
    this.servicioUsuarios.buscarUsuario(this.id).subscribe({
      next: (item) => {
        console.log(item);
        this.usuario.set(item);
      },
      error: (err) => {
        console.log(err);
      }
    });
  }

  alta(): void{
    //console.log(this.usuarioForm.value);

    // Desde el formulario recogemos el valor company
    // pero al API Rest hay que enviarlo como company.name
    const formValue = this.usuarioForm.getRawValue(); // en formValue tengo this.usuarioForm.value)
    const payload = {  // crear nuevo objeto
      ...formValue,    // vuelco los datos de formValue
      company: {       // modifico la propiedad company para que sea un objeto e incluyo el name
        name: formValue.company
      }
    };
    this.servicioUsuarios.crearUsuario(payload).subscribe({
      next: (datos) => {
        //console.log(datos);
        alert("Usuario creado");
        this.usuarios.update(usuarios => [...usuarios, datos]);
        this.usuarioForm.reset(); // limpiar el formulario
      },
      error: (err) => {
        console.log(err);
      }
    });
  }

  ngOnInit(): void {
    this.servicioUsuarios.getAll().subscribe({
      next: (datos) => {
        //console.log(datos);
        this.usuarios.set(datos);
      },
      error: (err) => {
        console.log(err);
      }
    });
  }


}
